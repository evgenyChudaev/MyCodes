﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFSSRS_SharePoint_Viewer
{
    class clsColumn
    {
        string m_DTCName = null;
        public string DTCName {get { return m_DTCName; }}
        string m_DGHeaderText = null;
        public string DGHeaderText { get { return m_DGHeaderText; }}
        int m_DGColumnWidth = 0;
        public int DGColumnWidth {get { return m_DGColumnWidth; }}
        string m_SPName = null;
        public string SPName {get { return m_SPName; }}
        string m_SPType = null;
        public string SPType { get { return m_SPType; } }
        bool m_Visible = true;
        public bool Visible { get { return m_Visible; } }

        clsDataGridView m_DataGridView = null;

        public clsColumn(string DTCName, string DGHeaderText, int DGColumnWidth, string SPName, string SPType, bool Visible, clsDataGridView DataGridView)
        {
            m_DTCName = DTCName;
            m_DGHeaderText = DGHeaderText;
            m_DGColumnWidth = DGColumnWidth;
            m_SPName = SPName;
            m_SPType = SPType;
            m_Visible = Visible;

            m_DataGridView = DataGridView;
        }
    }
}
