﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.XPath;
using SP = Microsoft.SharePoint.Client;
using Outlook = Microsoft.Office.Interop.Outlook;

using System.Text.RegularExpressions;
using System.Security.Principal;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Windows.Forms.DataVisualization.Charting;
using System.Data.OleDb;
using System.Data.Odbc;
using System.IO.Compression;
using System.Windows.Controls;
using System.Windows.Forms;
using System.ComponentModel;
using System.Threading;
using System.Data.SqlClient;
using TM1API = Applix.TM1.API;


namespace myFSSRS_SharePoint_Viewer
{
    public partial class frmMain : Form
    {
        public enum SPFormOperation
        {
            Open = 1,
            Edit = 2,
            New = 3
        }

        Dictionary<string, clsDataGridView> dicDataGridViews = new Dictionary<string, clsDataGridView>();
        clsDataGridView oCurrentDataGridView = null;
        clsList oCurrentList = null;
        clsSite oCurrentSite = null;
        clsExceptionFile oExceptionFile = null;   // Exception file
        clsExceptionFile oOutstandingWorkflowFile = null; // outstanding workflow
        string sCurrentUserDisplayName = null;


        public frmMain()
        {
            InitializeComponent(); // method called by a default constructor, loads the XAML file and converts it to an object
            backgroundWorker1.DoWork += backgroundWorker1_DoWork;
            backgroundWorker1.ProgressChanged += backgroundWorker1_ProgressChanged;
            //backgroundWorker1.ProgressChanged += backgroundWorker1__RunWorkerCompleted;
            manageProgrssBar("start");
            fieldFilterApplied = false;

            cmbSheduleDetailLevel.SelectedIndex = 0;
            cmbSheduleDetailLevel.SelectedText = "Detailed";          

        }


        private void manageProgrssBar(string command)
        {
            if (command == "start")
            {
                backgroundWorker1.WorkerReportsProgress = true;
                backgroundWorker1.RunWorkerAsync();
            }
            else if (command == "finish")
            {
                pgbLoadSharepointData.Value = 100;
                panelSharepointLoadProgress.Visible = false;
            }

        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(200);
                backgroundWorker1.ReportProgress(i);
            }
            backgroundWorker1.ReportProgress(100);
        }

        private void backgroundWorker1_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            pgbLoadSharepointData.Value = e.ProgressPercentage;
            txtLoadProgress.Text = "Please hold while Sharepoint data is loading... " + pgbLoadSharepointData.Value + " % complete";
        }



        // even procedure for when the main form shows
        private void frmMain_Shown(object sender, EventArgs e)
        {
            // txtLoadProgress.Text = "Please hold while Sharepoint data is loaded...";


            this.Cursor = Cursors.AppStarting;
            System.Windows.Forms.Application.DoEvents(); // allows processing while events are being handled

            clsServer oSPServer = null;

            // your username
            // sCurrentUserDisplayName = System.DirectoryServices.AccountManagement.UserPrincipal.Current.DisplayName;

            //MessageBox.Show(sCurrentUserDisplayName); // Evgeny to test user name
            ReadFromSiteSettings(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\SiteSettings.xml", oSPServer);
            //pgbLoadSharepointData.Value = 50;
            System.Windows.Forms.Application.DoEvents();

            SetCurrentObjects();  //check which tab has been selected, returns relevant datagrid view which is based on the name of the tab control selected
            tbctlReportCatalogue_update(); // update ReportCatalogue tab as soon as application starts
            //pgbLoadSharepointData.Value = 80;

            TabPageChanged();
            tsmiExportAllListsInView.Text = String.Format("All Lists in {0}", tbctlMain.SelectedTab.Text);
            //pgbLoadSharepointData.Value = 90;
            // tscbRCActiveFilterDeliveryDate.SelectedIndex = 0;

            //   this.tscbRCActiveFilterDeliveryDate.SelectedIndexChanged += new System.EventHandler(this.tscbRCActiveFilterDeliveryDate_SelectedIndexChanged);

            tsbRefreshData.Visible = true;
            this.Cursor = Cursors.Default;

            // chart category - remove all the grid lines
            chartCategory.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartCategory.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartCategory.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartCategory.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            //panelSharepointLoadProgress.Visible = false;
            ReaddataGridViewColumns(ref dgvResourcing, ref cmbFieldFilterReportCatalogue);
            ReaddataGridViewColumns(ref dgvResourcingWorkflow, ref cmbFieldFilterWorkflow);
            dgvSummaryView.Columns[1].SortMode = DataGridViewColumnSortMode.Automatic;
            dgvResourcing.Columns["Report Production Folder"].DefaultCellStyle.ForeColor = Color.Blue; // change color of the report production folder.It's a hyperlink            
            manageProgrssBar("finish");

        }




        // reads/parses sharepoint site settings file
        private void ReadFromSiteSettings(string FileName, clsServer oSPServer)
        {
            XPathDocument document = new XPathDocument(FileName);
            XPathNavigator navigator = document.CreateNavigator();
            //backgroundWorker1.RunWorkerAsync();
            foreach (XPathNavigator server in navigator.Select("/SharePointViewer/Server"))
            {
                oSPServer = new clsServer(server.GetAttribute("URL", ""));
                foreach (XPathNavigator site in server.SelectChildren(XPathNodeType.All))
                {
                    clsSite oSPSite = oSPServer.AddSite(site.GetAttribute("Name", ""), site.GetAttribute("Path", ""));

                    foreach (XPathNavigator list in site.SelectChildren(XPathNodeType.All))
                    {
                        clsList oSPList = oSPSite.AddList(list.GetAttribute("Name", ""), list.GetAttribute("SPName", ""));

                        foreach (XPathNavigator dataGridView in list.SelectChildren(XPathNodeType.All))
                        {
                            string sDataGridView = dataGridView.GetAttribute("Name", "");

                            // FILTERING DATAGRIDVIEW BASED ON THE USER NAME FOR RELATIONSHIP MANAGER                          
                            clsDataGridView oDataGridView = oSPList.AddDataGridView(((DataGridView)this.Controls.Find(sDataGridView, true)[0]), dataGridView.SelectSingleNode("CAML").InnerXml.Replace("~UserName~", sCurrentUserDisplayName));
                            dicDataGridViews.Add(sDataGridView, oDataGridView);


                            foreach (XPathNavigator column in dataGridView.SelectChildren("Column", ""))
                            {
                                int nColumnWidth = 0;
                                string sColumnWith = column.GetAttribute("dgColumnWidth", "");
                                if (sColumnWith != "")
                                    nColumnWidth = Convert.ToInt16(sColumnWith);

                                oDataGridView.AddColumn(column.GetAttribute("dtcName", ""), column.GetAttribute("dgHeaderText", ""), nColumnWidth,
                                column.GetAttribute("spName", ""), column.GetAttribute("spType", ""), column.GetAttribute("Visible", "").Trim().ToUpper().Equals("TRUE") ? true : false);
                            }

                            // EMAIL CHOICES HERE. !!!!!
                            foreach (XPathNavigator emailChoice in dataGridView.SelectChildren("Email", ""))
                            {
                                Dictionary<string, string> dicMessageBodies = new Dictionary<string, string>();
                                XPathNodeIterator xpniMessageBodies = emailChoice.SelectChildren("MessageBody", "");

                                while (xpniMessageBodies.MoveNext())
                                {
                                    dicMessageBodies.Add(xpniMessageBodies.Current.GetAttribute("MessageOption", ""), xpniMessageBodies.Current.InnerXml);
                                }


                                oDataGridView.AddEmailChoice(emailChoice.GetAttribute("MenuOption", ""), emailChoice.GetAttribute("MessageOptionColumn", ""), emailChoice.GetAttribute("Subject", ""), emailChoice.GetAttribute("To", ""), emailChoice.GetAttribute("CC", ""), dicMessageBodies);
                            }

                            foreach (XPathNavigator menuOption in dataGridView.SelectChildren("MenuOption", ""))
                            {
                                oDataGridView.SetMenuOptions(menuOption.GetAttribute("OpenNewForm", ""));
                            }
                        }
                    }
                }
            }
            XPathNavigator xpnExceptionFile = navigator.SelectSingleNode("/SharePointViewer/ExceptionFile");
            XPathNavigator xpnOutstandingFile = navigator.SelectSingleNode("/SharePointViewer/outstandingWorkflowFile");
            oExceptionFile = new clsExceptionFile(xpnExceptionFile.GetAttribute("URN", ""), xpnExceptionFile.GetAttribute("FileFilter", ""));
            oOutstandingWorkflowFile = new clsExceptionFile(xpnOutstandingFile.GetAttribute("URN", ""), xpnOutstandingFile.GetAttribute("FileFilter", ""));
            populateFilterNames();  // Load filter names to the cmbSavedFilters
            txtFilterName.Visible = false;
            //  chSelectAll.Visible = true;

            dateTimePicker2.Enabled = false;
            dateTimePicker1.Enabled = false;
        }

        // Load filter names to the cmbSavedFilters

        private void populateFilterNames()
        {
            string teamFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MyTeam.txt";
            List<string> myFilterList = new List<string>();
            string[] lines = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\DefaultSettings.txt");
            string[] splitLine;
            cmbSavedFilters.Items.Add("<ALL>"); // Add default "ALL" filter to include everything
            if (new FileInfo(teamFile).Length != 0)
            {
                cmbSavedFilters.Items.Add("<TEAM>"); // Add default TEAM filter to include everything
            }
            foreach (string line in lines)
            {
                splitLine = line.Split('|');
                if (!myFilterList.Contains(splitLine[0]))
                {
                    myFilterList.Add(splitLine[0]);
                    cmbSavedFilters.Items.Add(splitLine[0]);
                }
            }
        }

        //close the application
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        // event procedure tbctlMain -> When tab index has changed refresh datagrid with new data
        private void tbctlMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            tsmiExportAllListsInView.Text = String.Format("All Lists in {0}", tbctlMain.SelectedTab.Text);
            SetCurrentObjects();
            TabPageChanged();
            loadSettingsForEPM();
        }

        // populates EPM user name textbox with the current username & loads cube names
        bool EPMServerListPopulated = false; // only populate server list once to avoid duplication
        private void loadSettingsForEPM()
        {
            txtEPMUserName.Text = Environment.UserName.ToString();
            if (!EPMServerListPopulated)
            {               
                populateEPMServerList(); // populate server list from the text file
                EPMServerListPopulated = true;
            }
           
        }
        
        // creates and returns a datagridview  !!!!!!!!!!!!
        private clsDataGridView SetupDataGridView()
        {
            foreach (clsColumn oColumn in oCurrentDataGridView.Columns.Values)
            {
                if (oColumn.Visible)
                {

                    DataGridViewColumn dgvcTarget = new DataGridViewTextBoxColumn();   // Hosts a collection of DataGridViewTextBoxCell cells.
                    dgvcTarget.Name = oColumn.DTCName;
                    dgvcTarget.Width = oColumn.DGColumnWidth;
                    dgvcTarget.HeaderText = oColumn.DGHeaderText;
                    dgvcTarget.DataPropertyName = oColumn.DTCName;
                    oCurrentDataGridView.DataGridView.Columns.Add(dgvcTarget);  //  
                    // ask Michal Charron what is ParentList ? Is that a source Sharepooint list?
                    clsList oList = oCurrentDataGridView.ParentList;
                    clsSite oSite = oList.ParentSite;
                    if (!oSite.Connected)
                    {
                        oSite.Connect(tsslStatus);
                    }

                    if (!oList.Connected)
                    {
                        oList.Connect();
                    }

                }
            }
            // method of class clsDataGridView - creates table and populates it with results of CAML query           
            oCurrentDataGridView.ExecuteCAMLQuery(tsslNoOfItems, tsslStatus);

            // return back the updated object
            return oCurrentDataGridView;
        }

        // empty body of the event. 
        private void pbxRCControl_Click(object sender, EventArgs e)
        {

        }

        // Update Report Errors and report reruns. Add "Request Type" field for both
        private void addFieldsToErrorsReruns()
        {
            (dgvRAActive.DataSource as System.Data.DataTable).Columns.Add("Request Type", typeof(System.String));

            for (int i = 0; i < dgvRAActive.Rows.Count; i++)
            {
                (dgvRAActive.DataSource as System.Data.DataTable).Rows[i]["Request Type"] = "Report rerun";
            }

            (dgvETActive.DataSource as System.Data.DataTable).Columns.Add("Request Type", typeof(System.String));
            for (int i = 0; i < dgvETActive.Rows.Count; i++)
            {
                (dgvETActive.DataSource as System.Data.DataTable).Rows[i]["Request Type"] = "Report errors";
            }

        }
        // Duplicate of the below method
        private void tbctlReportCatalogue_update()
        {
            SetCurrentObjects();
            TabPageChanged();
            populateSummaryGrid(); // populate grid summarizing hours by gv on the same tab

            populateFrequency(); // populate list box with frequency types
            populateListBox("Report Status");
            populateListBox("Relationship Manager");
            populateListBox("Deployment Tool");
            populateListBox("Data Source");
            populateListBox("Team Manager");

            // populate another datagridview on the tab. 
            SetCurrentObjects("dgvResourcingWorkflow");
            TabPageChanged();
            populatePlatformListBox(); // populate list box with platform names. Updated after dgvResourcingWorkflow is loaded 
            SetCurrentObjects("dgvRAActive");
            TabPageChanged();
            SetCurrentObjects("dgvETActive");
            TabPageChanged();
            addFieldsToErrorsReruns();

            populateWorkflowCategory(); // populate combobox with the type of workflow
            populateWorkflowStatus("Status");
            populateWorkflowType("Request Type");

            populateWorflowCharts();
        }
        // event handler when children tabs of report catalogue tab have been changed
        private void tbctlReportCatalogue_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetCurrentObjects();
            TabPageChanged();
            populateSummaryGrid(); // populate grid summarizing hours by gv on the same tab
            populatePlatformListBox(); // populate list box with platform names


            populateFrequency();
            populateWorflowCharts();
            // populate another datagridview on the tab. 
            SetCurrentObjects("dgvResourcingWorkflow");
            TabPageChanged();
            SetCurrentObjects("dgvRAActive");
            TabPageChanged();
            SetCurrentObjects("dgvETActive");
            TabPageChanged();


            populateWorkflowCategory(); // populate combobox with the type of workflow
            populateWorkflowStatus("Status");
            populateWorkflowType("Request Type");


        }

        // event handler when children tabs of request submission tab have been changed
        private void tbctlRequestSubmissions_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetCurrentObjects();
            TabPageChanged();
        }

        // event handler for Report Rerun
        private void tbctRunAdhoc_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetCurrentObjects();
            TabPageChanged();
        }

        // event handler for Error Tracking tab control change
        private void tbctErrorTracking_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetCurrentObjects();
            TabPageChanged();
        }

        // event handler for Process Improvement tab control change
        private void tbctlProcessImprovement_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetCurrentObjects();
            TabPageChanged();
        }

        // actions when tab page has changed
        private void TabPageChanged()
        {
            //tsbRefreshData.Visible = false;
            System.Windows.Forms.Application.DoEvents();

            if (oCurrentDataGridView.DataGridView.ColumnCount == 0)
                SetupDataGridView(); // set up data grid view if it hasn't been set up already (column count = 0)
            //  else
            // if (oCurrentDataGridView.DataGridView.Name == "dgvResourcing" )
            //   tsslNoOfItems.Text = String.Format("{0} (Filtered)", dgvResourcing.Rows.Count);
            //  else
            //  tsslNoOfItems.Text = oCurrentDataGridView.DataGridView.Rows.Count.ToString();

            // tsmiDatagridEmail.DropDownItems.Clear();
           

            SetupMenuChoices(); // create menu choices  
            updateDataGridViewItemCount();

        }

        private void updateDataGridViewItemCount()
        {
            if (tbctlMain.SelectedTab.Name.Equals("tbpgReportCatalogue"))
            {

                if (tbctlReportCatalogue.SelectedTab.Name.Equals("tbpgResourcing"))
                {
                    tsslNoOfItems.Text = dgvResourcing.Rows.Count.ToString();
                }
                else if (tbctlReportCatalogue.SelectedTab.Name.Equals("tbpgResourcingWorkflow"))
                {
                    tsslNoOfItems.Text = dgvResourcingWorkflow.Rows.Count.ToString();
                }
                else if (tbctlReportCatalogue.SelectedTab.Name.Equals("tbpgKPI"))
                {
                    tsslNoOfItems.Text = dgvTest.Rows.Count.ToString();
                }


            }
        }

        // create menu choices on the screen for email
        bool isSetup = false;
        private void SetupMenuChoices()
        {
            //  if(isSetup == false)
            //{
            ToolStripItem tsiEmailChoice = null; // hidden tool strip for email 
            ToolStripItem tsiValidationChoice = null; // hidden tool strip for email 
            ToolStripItem tsiOpenReportProductionFolder = null; // hidden tool strip for email 
            // menu for email
            // tssEmail is a toolstrip separator (a lint separating toolstip menu items)
            tssEmail.Visible = true; // tsmiDatagridEmail.Visible = (oCurrentDataGridView.EmailChoices.Count > 0);
           // tsmiDataGridEmailValidate.Visible = true; 


        
           //tsmiDatagridEmailValidate.Visible = true;
            //menu for sharepoint
            //tsmiNewSPForm.Visible = (oCurrentDataGridView.OpenNewForm);

            // foreach (clsEmailChoice oEmailChoice in oCurrentDataGridView.EmailChoices.Values)
            // {   // add dropdown for each email choice
            //MessageBox.Show(oEmailChoice.ToString() + " " + oEmailChoice.MenuOption.ToString());
            // tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add(oEmailChoice.MenuOption); // add menu options to the drop-down list
            if (tbctlReportCatalogue.SelectedTab.Tag.ToString().Equals("dgvResourcing"))
            {
                tsmiDatagridEmail.Visible = true;
                tsmiDatagridEmail.DropDownItems.Clear();
                //  tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Question For Report Contact"); // add menu options to the drop-down list                     
                tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Question For Report Contact"); // add menu options to the drop-down list
                tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
                tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Inform Report Contact of Report Delivery"); // add menu options to the drop-down list
                tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
                tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Question For Relationship Manager");
                tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above



                tsmiDataGridEmailValidate.Visible = true; 
                tsmiDataGridEmailValidate.DropDownItems.Clear();
                
                tsiValidationChoice = tsmiDataGridEmailValidate.DropDownItems.Add("Validate format");
                tsiValidationChoice.Click += new System.EventHandler(this.tsiValidationChoice_Click); // new event handler for each email choice just created above
                
                tsiValidationChoice = tsmiDataGridEmailValidate.DropDownItems.Add("Check address existence");              
                tsiValidationChoice.Click += new System.EventHandler(this.tsiValidationChoice_Click); // new event handler for each email choice just created above

                tsiOpenReportProductionFolder = tsmiDataGridEmailValidate.DropDownItems.Add("Open folder");
               // tsiOpenReportProductionFolder.Click += new System.EventHandler(this.tsiOpenReportProductionFolder_Click); // new event handler for each email choice just created above
                
                


                //tsiValidationChoice.Click += new System.EventHandler(this.tsiValidationChoice_Click); // new event handler for each email choice just created above

                // tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Validate Recepients");
                //tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
                //tsiEmailChoice = tsmiDatagridEmailValidate.DropDownItems.Add("Check Email format");
               // tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
               // tsmiDatagridEmailValidate.Visible = true;

            }
            else if (tbctlReportCatalogue.SelectedTab.Tag.ToString().Equals("dgvResourcingWorkflow"))
            {
                tsmiDatagridEmail.Visible = true;
                tsmiDatagridEmail.DropDownItems.Clear();
                tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Acknowledge Request"); // add menu options to the drop-down list
                tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
                tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Completed Request");
                tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
                tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Question for Request Submitter");
                tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
                tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add("Question For Relationship Manager");
                tsiEmailChoice.Click += new System.EventHandler(this.tsiEmailChoice_Click); // new event handler for each email choice just created above
                //tsiEmailChoice = tsmiDatagridEmail.DropDownItems.Add(); // add menu options to the drop-down list

            }
            else
            {
                tsmiDatagridEmail.DropDownItems.Clear();
                tsmiDatagridEmail.Visible = false;
                
                tsmiDataGridEmailValidate.DropDownItems.Clear();
                tsmiDataGridEmailValidate.Visible = false;
            }

            // }




            // }
            // isSetup = true;

        }

        // event handler for the tsiEmailChoice
        void tsiEmailChoice_Click(object sender, EventArgs e)
        { 
            prepareEmail(((ToolStripItem)sender).Text);
        }

        void tsiValidationChoice_Click(object sender, EventArgs e)
        {
            validateEmailFormat(((ToolStripItem)sender).Text);
        }

        private void validateEmailFormat(string oValidationChoice)
        {
            int itemNo = (int)cmsDatagrid.Tag;
            //string value = "";
           // string sSPServerURL = "http://rbcwss.fg.rbc.com";
            if (tbctlReportCatalogue.SelectedTab.Tag.ToString().Equals("dgvResourcing"))
            {
                string value = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[itemNo]["Recipient"].ToString();
                //string reportNo = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[itemNo]["Report Number"].ToString();
                string sListItemId = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[itemNo]["ListItemId"].ToString();
                // string sDisplayFormURL = sSPServerURL + "/ykl0/H23_ssrcreport/Lists/Post%20EPM%20Report%20Catalogue/DispForm.aspx" + "?ID=" + sListItemId;
                Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                Match match;
                switch (oValidationChoice)
                {
                    case "Validate format":                     
                       match = regex.Match(value);
                        if (match.Success)
                            MessageBox.Show(value + " is correct");
                        else
                            MessageBox.Show(value + " is incorrect");
                        break;
                    

                    case "Check address existence":
                        checkEmailAddress(value);
                        //match = regex.Match(value);
                      /*  if (match.Success)
                            MessageBox.Show(value + " is correct");
                        else
                            MessageBox.Show(value + " is incorrect"); */
                        break;
                        
                   
                    default:
                        break;
                }
            }
        }

        private void checkEmailAddress(string value)
        {       
           
            Outlook.Application olApp = new Outlook.Application();
            Outlook.MailItem olMailItem = olMailItem = (Outlook.MailItem)olApp.CreateItem(Outlook.OlItemType.olMailItem);
          
            olMailItem.To = value;  
           
            Outlook.ExchangeUser olExchangeUser = olApp.Session.AddressLists["Global Address List"].AddressEntries[olMailItem.To].GetExchangeUser();
            MessageBox.Show(olExchangeUser.LastName);

            try
            {
               // olMailItem.Display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, String.Format("Outlook returned the following error \"{0}\".", ex.Message), "Outlook Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

           
        }
        private void sendEmail2(string oEmailChoice, string value, string sSubject, string sMessageBody)
        {
            // string sSubject = null;
            //  string sMessageBody = null;
            Regex rxExchangeProperties = new Regex("~(.*?)~");
            Regex rxDataColumns = new Regex("{(.*?)}");

            // message body customization based on the email choice made earlier
            //  if (oEmailChoice.MessageOptionColumn.Equals(""))
            //     sMessageBody = oEmailChoice.GetMessageBody();
            //  else
            //    sMessageBody = oEmailChoice.GetMessageBody(drvSource["Request Type"].ToString());

            // sMessageBody = sMessageBody.Replace("#DisplayFormURL#", sDisplayFormURL);
            // sSubject = oEmailChoice.Subject;
            //  sMessageBody = "AAAAAA";
            // sSubject = "AAAAAA";

            // collection of matches based on regex applied on the string
            MatchCollection colMatches = rxDataColumns.Matches(sSubject);

            //compiling a subject string based on the regex matches above
            //   foreach (Match oDataColumnMatch in colMatches)
            //  {
            //      sSubject = sSubject.Replace(oDataColumnMatch.Value, drvSource[oDataColumnMatch.Groups[1].Value].ToString());
            //  }

            // regex for message body
            //    colMatches = rxDataColumns.Matches(sMessageBody);
            //   foreach (Match oDataColumnMatch in colMatches)
            // {
            //    sMessageBody = sMessageBody.Replace(oDataColumnMatch.Value, drvSource[oDataColumnMatch.Groups[1].Value].ToString());
            // }

            //  colMatches = rxExchangeProperties.Matches(sMessageBody);

            // creating outlook application instance
            Outlook.Application olApp = new Outlook.Application();
            Outlook.MailItem olMailItem = olMailItem = (Outlook.MailItem)olApp.CreateItem(Outlook.OlItemType.olMailItem);

            // recepient of the email, cc & subject
            // olMailItem.To = drvSource[oEmailChoice.To].ToString(); 
            olMailItem.To = value;
            /// if (oEmailChoice.CC != "")
            // olMailItem.CC = drvSource[oEmailChoice.CC].ToString();
            olMailItem.Subject = sSubject;

            // access outlook contact list
            if (colMatches.Count > 0)
            {
                Outlook.ExchangeUser olExchangeUser = olApp.Session.AddressLists["Global Address List"].AddressEntries[olMailItem.To].GetExchangeUser();
                foreach (Match oMessageBodyMatch in colMatches)
                {
                    string sReplace = "";
                    // checks first name of the person (recepient)
                    if (oMessageBodyMatch.Groups[1].Value == "FirstName")
                        sReplace = olExchangeUser.FirstName;
                    sMessageBody = sMessageBody.Replace(oMessageBodyMatch.Value, sReplace);
                }
            }

            try
            {
                olMailItem.Display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, String.Format("Outlook returned the following error \"{0}\".", ex.Message), "Outlook Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            olMailItem.HTMLBody = sMessageBody + olMailItem.HTMLBody;
            olMailItem.Display(true);
        }

        string gvSelected = "";
        private void prepareEmail(string oEmailChoice)
        {
            //The DefaultView property returns a DataView you can use to sort, filter, and search a DataTable.


            int itemNo = (int)cmsDatagrid.Tag;
            //string value = "";
            string sSPServerURL = "http://rbcwss.fg.rbc.com";
            if (tbctlReportCatalogue.SelectedTab.Tag.ToString().Equals("dgvResourcing"))
            {
                string value = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[itemNo]["Recipient"].ToString();
                string reportNo = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[itemNo]["Report Number"].ToString();
                string sListItemId = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[itemNo]["ListItemId"].ToString();
                string sDisplayFormURL = sSPServerURL + "/ykl0/H23_ssrcreport/Lists/Post%20EPM%20Report%20Catalogue/DispForm.aspx" + "?ID=" + sListItemId;

                switch (oEmailChoice)
                {
                    case "Question For Report Contact":
                        sendEmail2("Question For Report Contact", value, "Question regarding report # " + reportNo, "Hello, " + "<a href='" + sDisplayFormURL + "'>" + "Report details" + "</a>");
                        break;
                    case "Inform Report Contact of Report Delivery":
                        //string gvDay = "";
                        int gvDay;
                        string gvString = "";
                        // USER LOOP HERE INSTEAD BECAUSE lstGvDays.SelectedIndices[0]POINTS THE NEXT ITEM FOR SOME REASON
                        if (lstGvDays.SelectedIndices.Count == 1 && lstGvDays.SelectedIndices[0].ToString() != "<ALL>")  // capture GV day selected from the filter
                        {
                            // Reassignment of gvDay twice since first statement returns selected item - 1 rather than selected item. 
                            // gvDay = lstGvDays.SelectedIndices[0].ToString();
                            gvDay = (int)lstGvDays.SelectedIndices[0];
                            //Console.WriteLine(gvDay);
                            //index = lstGvDays.Items.IndexOf(gvDay);
                            //Console.WriteLine(index);
                            gvString = lstGvDays.Items[gvDay].ToString();
                        }

                        sendEmail2("Inform Report Contact of Report Delivery", value, "Report number " + reportNo + " - " + gvString + " is ready for review", "Hello, " + "Report " + reportNo +
                                     " is waitig for your review here: ");
                        break;
                    case "Question For Relationship Manager":
                        sendEmail2("Question For Relationship Manager", value, "Question regarding report # " + reportNo, "Hello, " + "<a href='" + sDisplayFormURL + "'>" + "Report details" + "</a>");
                        break;
                    default:
                        break;
                }
                //string value = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[itemNo]["ListItemID"].ToString();  

                // MessageBox.Show(value);            
            }
            else if (tbctlReportCatalogue.SelectedTab.Tag.ToString().Equals("dgvResourcingWorkflow"))
            {
                string value = ((System.Data.DataTable)dgvResourcingWorkflow.DataSource).DefaultView[itemNo]["Report Requester"].ToString();
                string requestNo = ((System.Data.DataTable)dgvResourcingWorkflow.DataSource).DefaultView[itemNo]["ID"].ToString();
                string sListItemId = ((System.Data.DataTable)dgvResourcingWorkflow.DataSource).DefaultView[itemNo]["ListItemId"].ToString();
                string sDisplayFormURL = sSPServerURL + "/ykl0/F06_sharedserv/Lists/New%20Report%20Request/DispForm.aspx" + "?ID=" + sListItemId;

                switch (oEmailChoice)
                {
                    case "Acknowledge Request":
                        sendEmail2("Acknowledge Request", value, "Acknowledgement of request  " + requestNo, "Hello, " + "<a href='" + sDisplayFormURL + "'>" + "Request details" + "</a>");
                        break;
                    case "Completed Request":
                        sendEmail2("Completed Request", value, "Completion of request " + requestNo, "Hello, " + "Request " + requestNo + " is now complete");
                        break;
                    case "Question for Request Submitter":
                        sendEmail2("Question for Request Submitter", value, "Question regarding request # " + requestNo, "Hello, " + "<a href='" + sDisplayFormURL + "'>" + "Request details" + "</a>");
                        break;
                    case "Question For Relationship Manager":
                        sendEmail2("Question For Relationship Manager", value, "Question regarding request # " + requestNo, "Hello, " + "<a href='" + sDisplayFormURL + "'>" + "Request details" + "</a>");
                        break;
                    default:
                        break;
                }
            }

        }

        // send email based on the email choice
        private void SendEmail(clsEmailChoice oEmailChoice)
        {
            //The DefaultView property returns a DataView you can use to sort, filter, and search a DataTable.
            DataRowView drvSource = ((DataRowView)((System.Data.DataTable)oCurrentDataGridView.DataGridView.DataSource).DefaultView[(int)cmsDatagrid.Tag]);
            string sListItemId = drvSource["ListItemId"].ToString();
            string sDisplayFormURL = oCurrentSite.ParentServer.URL + oCurrentList.DisplayFormURL + "?ID=" + sListItemId;
            string sSubject = null;
            string sMessageBody = null;
            Regex rxExchangeProperties = new Regex("~(.*?)~");
            Regex rxDataColumns = new Regex("{(.*?)}");

            // message body customization based on the email choice made earlier
            if (oEmailChoice.MessageOptionColumn.Equals(""))
                sMessageBody = oEmailChoice.GetMessageBody();
            else
                sMessageBody = oEmailChoice.GetMessageBody(drvSource["Request Type"].ToString());

            sMessageBody = sMessageBody.Replace("#DisplayFormURL#", sDisplayFormURL);
            sSubject = oEmailChoice.Subject;

            // collection of matches based on regex applied on the string
            MatchCollection colMatches = rxDataColumns.Matches(sSubject);

            //compiling a subject string based on the regex matches above
            foreach (Match oDataColumnMatch in colMatches)
            {
                sSubject = sSubject.Replace(oDataColumnMatch.Value, drvSource[oDataColumnMatch.Groups[1].Value].ToString());
            }

            // regex for message body
            colMatches = rxDataColumns.Matches(sMessageBody);
            foreach (Match oDataColumnMatch in colMatches)
            {
                sMessageBody = sMessageBody.Replace(oDataColumnMatch.Value, drvSource[oDataColumnMatch.Groups[1].Value].ToString());
            }

            colMatches = rxExchangeProperties.Matches(sMessageBody);

            // creating outlook application instance
            Outlook.Application olApp = new Outlook.Application();
            Outlook.MailItem olMailItem = olMailItem = (Outlook.MailItem)olApp.CreateItem(Outlook.OlItemType.olMailItem);

            // recepient of the email, cc & subject
            olMailItem.To = drvSource[oEmailChoice.To].ToString();
            if (oEmailChoice.CC != "")
                olMailItem.CC = drvSource[oEmailChoice.CC].ToString();
            olMailItem.Subject = sSubject;

            // access outlook contact list
            if (colMatches.Count > 0)
            {
                Outlook.ExchangeUser olExchangeUser = olApp.Session.AddressLists["Global Address List"].AddressEntries[olMailItem.To].GetExchangeUser();
                foreach (Match oMessageBodyMatch in colMatches)
                {
                    string sReplace = "";
                    // checks first name of the person (recepient)
                    if (oMessageBodyMatch.Groups[1].Value == "FirstName")
                        sReplace = olExchangeUser.FirstName;


                    sMessageBody = sMessageBody.Replace(oMessageBodyMatch.Value, sReplace);
                }
            }

            try
            {
                olMailItem.Display();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, String.Format("Outlook returned the following error \"{0}\".", ex.Message), "Outlook Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            olMailItem.HTMLBody = sMessageBody + olMailItem.HTMLBody;
            olMailItem.Display(true);
        }

        // formatting
        /*  private void dgvRSActive_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
          {
              if (dgvRSActive.Columns[e.ColumnIndex].Name == "Due Date")
                  HandleDueDate(e);
          } 
          */
        // formatting
        private void dgvRAActive_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgvRAActive.Columns[e.ColumnIndex].Name == "Due Date")
                HandleDueDate(e);
        }
        // formatting
        //   private void dgvRASubmitted_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        //  {
        //      if (dgvRASubmitted.Columns[e.ColumnIndex].Name == "Due Date")
        //        HandleDueDate(e);
        // }
        // formatting cell color for overdue item 
        private void HandleDueDate(DataGridViewCellFormattingEventArgs e)
        {
            if (DateTime.Parse(e.Value.ToString()) < DateTime.Now)
                e.CellStyle.BackColor = Color.Pink;
        }

        // event handler for double-clicking on the table cell
        private void dgv_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            SharePointFormOperation(((DataGridView)sender).Name, e.RowIndex, SPFormOperation.Open);
        }
        // Sharepoint form operations - open, edit, new
        private void SharePointFormOperation(string dgvName, int RowNumber, SPFormOperation FormOperation)
        {
            // int rowNumb = (int)cmsDatagrid.Tag;

            // MessageBox.Show(rowNumb + "YEEE " + tbctlReportCatalogue.SelectedTab.Tag.ToString());
            // string sSPServerURL = oCurrentSite.ParentServer.URL;
            string sSPServerURL = "http://rbcwss.fg.rbc.com";
            string sFormURL = null;
            Process mypr;
            //   MessageBox.Show("Tab name " + tbctlReportCatalogue.SelectedTab.Tag.ToString() + " Current Data Grid View: " + oCurrentDataGridView.Name + "SP URL" + sSPServerURL.ToString() + " site: " + oCurrentSite.ToString());
            if (tbctlReportCatalogue.SelectedTab.Tag.ToString().Equals("dgvResourcing"))
            {
                switch (FormOperation)
                {
                    case SPFormOperation.Open:
                        sFormURL = sSPServerURL + "/ykl0/H23_ssrcreport/Lists/Post%20EPM%20Report%20Catalogue/DispForm.aspx" + "?ID=";
                        break;
                    case SPFormOperation.Edit:
                        sFormURL = sSPServerURL + "/ykl0/H23_ssrcreport/Lists/Post%20EPM%20Report%20Catalogue/EditForm.aspx" + "?ID=";
                        break;
                    case SPFormOperation.New:
                        sFormURL = sSPServerURL + oCurrentList.NewFormURL + "?ID=";
                        break;
                }
                mypr = Process.Start(sFormURL + ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[RowNumber]["ListItemID"]);
            }
            else if (tbctlReportCatalogue.SelectedTab.Tag.ToString().Equals("dgvResourcingWorkflow"))
            {

                switch (FormOperation)
                {
                    case SPFormOperation.Open:
                        sFormURL = sSPServerURL + "/ykl0/F06_sharedserv/Lists/New%20Report%20Request/DispForm.aspx" + "?ID=";
                        mypr = Process.Start(sFormURL + ((System.Data.DataTable)dgvResourcingWorkflow.DataSource).DefaultView[RowNumber]["ListItemID"]);
                        System.Diagnostics.Process.Start("http://google.com");
                        break;
                    case SPFormOperation.Edit:
                        sFormURL = sSPServerURL + "/ykl0/F06_sharedserv/Lists/New%20Report%20Request/EditForm.aspx" + "?ID=";
                        mypr = Process.Start(sFormURL + ((System.Data.DataTable)dgvResourcingWorkflow.DataSource).DefaultView[RowNumber]["ListItemID"]);
                        System.Diagnostics.Process.Start("http://google.com");
                        break;
                    case SPFormOperation.New:
                        sFormURL = sSPServerURL + oCurrentList.NewFormURL + "?ID=";
                        break;
                }
                //    if (dgvResourcingWorkflow.RowCount > 0 && FormOperation != SPFormOperation.New)
                //   {
                // MessageBox.Show(dgvResourcingWorkflow.Rows[RowNumber].Cells["ID"].Value.ToString() + "");
                //  string val = ((System.Data.DataTable)dgvResourcing.DataSource).DefaultView[RowNumber]["ListItemID"]) + "";
                //  MessageBox.Show(+ "");

                // }
                // else if (FormOperation == SPFormOperation.New)
                //     mypr = Process.Start(sFormURL);
            }
            //  else
            //  {

            //  }   



        }

        private void tsbRefreshData_Click(object sender, EventArgs e)
        {
            //TabControl tbctlTarget = ((TabControl)tbctlMain.Controls.Find(tbctlMain.SelectedTab.Tag.ToString(), true)[0]);
            //clsDataGridView oDataGridView = dicDataGridViews[tbctlTarget.SelectedTab.Tag.ToString()];

            oCurrentDataGridView.ExecuteCAMLQuery(tsslNoOfItems, tsslStatus);


        }

        // refresh all lists by way of looping through each tab and swtiching each tab within the loop, which in turn triggers an update event
        // confirm with Michael
        private void RefreshAllLists()
        {
            String sNoOfItems = tsslNoOfItems.Text;
            String sStatus = tsslStatus.Text;
            System.Windows.Forms.TabControl tcCurrentList = (System.Windows.Forms.TabControl)oCurrentDataGridView.DataGridView.Parent.Parent;
            TabPage tpCurrent = tcCurrentList.SelectedTab;

            // switching tabs to call an event procedure that updates each selected tab
            foreach (TabPage tpTarget in tcCurrentList.TabPages)
            {
                tcCurrentList.SelectedTab = tpTarget;
            }

            tcCurrentList.SelectedTab = tpCurrent;
            //foreach (clsDataGridView oDataGridView in oCurrentDataGridView.ParentList.DataGridViews.Values)
            //{
            //    oDataGridView.ExecuteCAMLQuery(tsslNoOfItems, tsslStatus);
            //}

            tsslNoOfItems.Text = sNoOfItems;
            tsslStatus.Text = sStatus;
        }

        // event when you right-click a cell header (or any cell)
        private void dgv_CellContextMenuStripNeeded(object sender, DataGridViewCellContextMenuStripNeededEventArgs e)
        {
            // cmsDatagrid is an object of type ContextMenuStrip class. Represents a shortcut menu.
            cmsDatagrid.Tag = e.RowIndex;
        }

        /* private void tsmiRSActiveWithAll_Click(object sender, EventArgs e)
         {
             DataGridViewClipboardCopyMode dgvccmDefault = dgvRSActive.ClipboardCopyMode;

             dgvRSActive.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
             dgvRSActive.SelectAll();

             Clipboard.SetDataObject(dgvRSActive.GetClipboardContent());

             dgvRSActive.ClearSelection();
             dgvRSActive.CurrentCell = null;
             dgvRSActive.ClipboardCopyMode = dgvccmDefault;
         } */

        // not sure what the object "tsmiRSActiveWithSelected" is.
        /*  private void tsmiRSActiveWithSelected_Click(object sender, EventArgs e)
          {
              DataGridViewClipboardCopyMode dgvccmDefault = dgvRSActive.ClipboardCopyMode;

              dgvRSActive.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;

              Clipboard.SetDataObject(dgvRSActive.GetClipboardContent());

              dgvRSActive.ClipboardCopyMode = dgvccmDefault;
          } */
        // not sure what the object "tsmiRSActiveWithSelected" is.
        /*   private void tsmiRSActiveWithoutAll_Click(object sender, EventArgs e)
           {
               DataGridViewClipboardCopyMode dgvccmDefault = dgvRSActive.ClipboardCopyMode;

               dgvRSActive.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
               dgvRSActive.SelectAll();

               Clipboard.SetDataObject(dgvRSActive.GetClipboardContent());

               dgvRSActive.ClearSelection();
               dgvRSActive.CurrentCell = null;
               dgvRSActive.ClipboardCopyMode = dgvccmDefault;
           } */
        // not sure what the object "tsmiRSActiveWithSelected" is.
        /*   private void tsmiRSActiveWithoutSelected_Click(object sender, EventArgs e)
           {
               DataGridViewClipboardCopyMode dgvccmDefault = dgvRSActive.ClipboardCopyMode;

               dgvRSActive.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;

               Clipboard.SetDataObject(dgvRSActive.GetClipboardContent());

               dgvRSActive.ClipboardCopyMode = dgvccmDefault;
           } */
        // not sure what the object "tsmiRSActiveWithSelected" is.
        // Upated by Evgeny
        /* private void tscbRCActiveFilterDeliveryDate_SelectedIndexChanged(object sender, EventArgs e)
         {
             System.Data.DataTable dtRCActive = (dgvRCActive.DataSource as System.Data.DataTable);
             string sFilterCriteria = null;

             if (tscbRCActiveFilterDeliveryDate.Text == "All Delivery Dates")
             {
                 dtRCActive.DefaultView.RowFilter = "";
                 tsslNoOfItems.Text = dtRCActive.DefaultView.Count.ToString();
             }
             else
             {
                 sFilterCriteria = tscbRCActiveFilterDeliveryDate.Text;
                 if (sFilterCriteria == "Before End of Month")
                     sFilterCriteria = "Before EOM";

                 dtRCActive.DefaultView.RowFilter = String.Format("[Delivery Date Time] LIKE '%{0} @%'", sFilterCriteria);

                 // Added another filter by Evgeny for the new tab
                 (dgvResourcing.DataSource as System.Data.DataTable).DefaultView.RowFilter = String.Format("[Delivery Date Time] LIKE '%{0} @%'", sFilterCriteria);
                 tsslNoOfItems.Text = String.Format("{0} (Filtered)", dtRCActive.DefaultView.Count);
             }
         }  */

        // private void lstGvDays_SelectedIndexChanged(object sender, EventArgs e)
        // {

        //}
        // By Evgeny to filter on the GV day
        private void lstGvDays_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnSelection();

        }


        //check which tab has been selected, returns relevant datagrid view which is based on the name of the tab control selected
        private clsDataGridView SetCurrentObjects()
        {
          //  Console.WriteLine(tbctlMain.SelectedTab.Name.ToString());
            string sMainTabControl = tbctlMain.SelectedTab.Tag.ToString();
          //  Console.WriteLine(sMainTabControl);
            // searches for controls by their name property and builds an arrays of controls that match         

            if (sMainTabControl != "dgvRAActive" && sMainTabControl != "dgvFDM")
            {
                string sDataGridView = ((System.Windows.Forms.TabControl)tbctlMain.Controls.Find(sMainTabControl, true)[0]).SelectedTab.Tag.ToString();

                // Updated by Evgeny (added if statement) to allow having a tab with a datagrid view not connected to Sharepoint
                if (sDataGridView != "tbpgTransitions" && sDataGridView != "dgvRAActive" && sDataGridView != "dgvETActive" && sDataGridView != "tbpgMySchedule")
                {
                    oCurrentDataGridView = dicDataGridViews[sDataGridView];
                    oCurrentList = oCurrentDataGridView.ParentList;
                    oCurrentSite = oCurrentList.ParentSite;
                    // UPdated by Evgeny to also show a new tabs besides 'Active')
                    // tsmiRCActiveFilterBy.Visible = (sDataGridView == "dgvRCActive"
                    //                              || sDataGridView == "dgvResourcing");
                }
            }




            return oCurrentDataGridView;
        }

        // overloaded method to workaround 1 datagrid view per tab control architecture
        private clsDataGridView SetCurrentObjects(string myDataGridViewName)
        {

            // MessageBox.Show("Tab control name: " + sMainTabControl);
            // searches for controls by their name property and builds an arrays of controls that match

            // MessageBox.Show("DataGrid View1: " + tbctlMain.SelectedTab.Tag.ToString());

            string sDataGridView = myDataGridViewName;

            // MessageBox.Show("DataGrid View2: " +sDataGridView);

            oCurrentDataGridView = dicDataGridViews[sDataGridView];
            oCurrentList = oCurrentDataGridView.ParentList;
            oCurrentSite = oCurrentList.ParentSite;

            //tsmiRCActiveFilterBy.Visible = (sDataGridView == "dgvRCActive");
            return oCurrentDataGridView;
        }



        // event handler for clicking on "TSMILatestExceptionFile" toolstrip control
        private void TSMILatestExceptionFile_Click(object sender, EventArgs e)
        {
            var vFiles = new DirectoryInfo(oExceptionFile.URN).GetFiles(oExceptionFile.FileFilter, SearchOption.TopDirectoryOnly)
                            .OrderByDescending(f => f.LastWriteTime).ToList();
            if (vFiles.Count == 0)
            {
                MessageBox.Show(String.Format("No file was found at \"{0}\" with the filter \"{1}\"", oExceptionFile.URN, oExceptionFile.FileFilter), "No File Found"
                    , MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            System.Diagnostics.Process.Start(vFiles[0].FullName);
        }
        // event handler for clicking on "tsmiExceptionFileListing" toolstrip control
        // Checks the network folder and returns name(s) of the exception file & 
        private void tsmiExceptionFileListing_Click(object sender, EventArgs e)
        {
            var vFiles1 = new DirectoryInfo(oExceptionFile.URN).GetFiles(oExceptionFile.FileFilter, SearchOption.TopDirectoryOnly)
                .OrderByDescending(f => f.LastWriteTime).Take(1).ToList();
            var vFiles2 = new DirectoryInfo(oOutstandingWorkflowFile.URN).GetFiles(oOutstandingWorkflowFile.FileFilter, SearchOption.TopDirectoryOnly)
                .OrderByDescending(f => f.LastWriteTime).Take(1).ToList();
            var vFiles = vFiles1.Union(vFiles2);

            if (!vFiles.Any())
            {
                MessageBox.Show(String.Format("No file was found at \"{0}\" with the filter \"{1}\"", oExceptionFile.URN, oExceptionFile.FileFilter), "No File Found"
                    , MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            frmExceptionFilesList oExceptionFilesListForm = new frmExceptionFilesList();
            System.Windows.Forms.ListBox lbxExceptionFiles = oExceptionFilesListForm.lbxExceptionFiles;

            lbxExceptionFiles.Items.Clear();
            foreach (FileSystemInfo oFile in vFiles)
            {
                lbxExceptionFiles.Items.Add(oFile);
            }
            lbxExceptionFiles.SelectedIndex = 0;
            oExceptionFilesListForm.ShowDialog();
            if (lbxExceptionFiles.SelectedIndex != -1)
            {
                System.Diagnostics.Process.Start(((FileSystemInfo)lbxExceptionFiles.SelectedItem).FullName);
            }
        }

        // event handler for opening SP form
        private void tsmiOpenSpForm_Click(object sender, EventArgs e)
        {
            if (cmsDatagrid.Tag != null)
                SharePointFormOperation("NA", (int)cmsDatagrid.Tag, SPFormOperation.Open);
        }

        // event handler for clicking on "Edit SP form"
        private void tsmiEditSPForm_Click(object sender, EventArgs e)
        {
            if (cmsDatagrid.Tag != null)
                // SharePointFormOperation(oCurrentDataGridView.Name, (int)cmsDatagrid.Tag, SPFormOperation.Edit);
                SharePointFormOperation("NA", (int)cmsDatagrid.Tag, SPFormOperation.Edit);
        }
        // event handler for clicking on "New SP form".
        private void tsmiNewSPForm_Click(object sender, EventArgs e)
        {
            SharePointFormOperation(oCurrentDataGridView.Name, cmsDatagrid.Tag == null ? 0 : (int)cmsDatagrid.Tag, SPFormOperation.New);
        }



        // Exporting to Excel via clipboard. Much faster than doing it cell by cell in a loop
        private void exportExcel(string tabName, string childTab, bool saveAll, string folderPath)
        {
            tsslStatus.Text = "Initializing Excel...";

            Excel.Application xlApp = new Excel.Application();
            Workbook xlWorkbook = xlApp.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
            Worksheet xlWorksheet = (Worksheet)xlWorkbook.ActiveSheet;
            Excel.Range xlRange = null;

            DataGridView oDataGridToExport;

            string exportFileName = "";
            string exportTabName = "";
            string pivotField = "";
            oDataGridToExport = dgvResourcing;


            if (tbctlMain.SelectedTab.Name.Equals("tbpgReportCatalogue") || tabName == "tbpgReportCatalogue")
            {
                if (!saveAll) // if exporting only current tab
                {

                    if (tbctlReportCatalogue.SelectedTab.Name.Equals("tbpgResourcing"))
                    {
                        exportTabName = "Report Catalogue";
                        exportFileName = "Sharepoint.xlsx";
                        oDataGridToExport = dgvResourcing;
                        pivotField = "Preparer";

                    }
                    else if (tbctlReportCatalogue.SelectedTab.Name.Equals("tbpgResourcingWorkflow"))
                    {
                        exportTabName = "Workflow";
                        exportFileName = "Sharepoint_Workflow.xlsx";
                        oDataGridToExport = dgvResourcingWorkflow;
                        pivotField = "AssignedTo";
                    }
                    else if (tbctlReportCatalogue.SelectedTab.Name.Equals("tbpgKPI"))
                    {
                        exportTabName = "KPIs";
                        exportFileName = "SharepointKPIs.xlsx";
                        oDataGridToExport = dgvKPI;
                        pivotField = "AssignedTo";
                    }
                }
                else // if exporting everything
                {
                    if (childTab == "tbpgResourcing")
                    {
                        exportTabName = "Report Catalogue";
                        exportFileName = "Sharepoint.xlsx";
                        oDataGridToExport = dgvResourcing;
                        pivotField = "Preparer";
                        //MessageBox.Show("Exported Catalogue");

                    }
                    else if (childTab == "tbpgResourcingWorkflow")
                    {
                        exportTabName = "Workflow";
                        exportFileName = "Sharepoint_Workflow.xlsx";
                        oDataGridToExport = dgvResourcingWorkflow;
                        pivotField = "AssignedTo";
                        // MessageBox.Show("Exported WF");
                    }
                    else if (childTab == "tbpgKPI")
                    {
                        exportTabName = "KPIs";
                        exportFileName = "SharepointKPIs.xlsx";
                        oDataGridToExport = dgvTest;
                        pivotField = "AssignedTo";
                        //MessageBox.Show("Exported KPI");
                    }
                }

            }
            oDataGridToExport.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            oDataGridToExport.SelectAll();
            DataObject data = oDataGridToExport.GetClipboardContent();
            if (data != null)
                Clipboard.SetDataObject(data);

            tsslStatus.Text = "Setting up Excel...";
            System.Windows.Forms.Application.DoEvents();

            foreach (Worksheet xlSourceWorksheet in xlWorkbook.Sheets)
            {
                if (xlSourceWorksheet.Name != xlWorksheet.Name)
                {
                    xlSourceWorksheet.Delete();
                }
            }

            xlWorksheet.Name = exportTabName;
            xlRange = (Excel.Range)xlWorksheet.Cells[1, 1];
            xlRange.Select();
            xlWorksheet.PasteSpecial(xlRange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true);

            Excel.Range oRange = xlWorksheet.UsedRange;
            Excel.PivotCache oPivotCache = (Excel.PivotCache)xlWorkbook.PivotCaches().Add(Excel.XlPivotTableSourceType.xlDatabase, oRange);

            Worksheet oSheet1 = (Excel.Worksheet)xlWorkbook.Worksheets.Add();
            oSheet1.Name = "Visuals";

            Excel.Range oRange2 = (Excel.Range)oSheet1.Range["A3"];

            Excel.PivotTable oPivotTable = (Excel.PivotTable)oSheet1.PivotTables().Add(PivotCache: oPivotCache, TableDestination: oRange2, TableName: "Summary");

            Excel.PivotField pageField = (Excel.PivotField)oPivotTable.PivotFields(pivotField);
            pageField.Orientation = Excel.XlPivotFieldOrientation.xlRowField;

            Excel.PivotField oPivotField1 = (Excel.PivotField)oPivotTable.PivotFields(pivotField);
            oPivotField1.Orientation = Excel.XlPivotFieldOrientation.xlDataField;
            oPivotField1.Function = Excel.XlConsolidationFunction.xlCount;
            oPivotField1.Name = "Count";


            Shape chartShape = oSheet1.Shapes.AddChart();
            chartShape.Chart.SetSourceData(oPivotTable.TableRange1, Type.Missing);
            xlWorkbook.ShowPivotChartActiveFields = true;
            chartShape.Chart.ChartType = XlChartType.xlBarClustered;
            chartShape.Chart.ChartArea.Height = 800;
            chartShape.Chart.PlotArea.Height = 800;

            if (!saveAll)  // show excel files only if exporting 1 tab, otherwise save them in a zipped folder
            {
                xlApp.Visible = true;
            }
            else
            {
                string savePath = folderPath + exportFileName;
                xlWorkbook.SaveAs(savePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                xlWorkbook.Close();
            }

            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);
            Marshal.ReleaseComObject(xlWorkbook);
            Marshal.ReleaseComObject(xlApp);
        }

        private string folderDialogWindow()
        {
            string folderName = "";
            using (var folderDialog = new FolderBrowserDialog())
            {
                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    folderName = folderDialog.SelectedPath;
                }
            }
            return folderName;
        }
        // event handler for clicking on the tsmiExportCurrentList tooltip control - export current list to Excel
        private void tsmiExportCurrentList_Click(object sender, EventArgs e)
        {
            exportExcel("NA", "NA", false, "NA");

        }
        // event handler for tsmiExportAllLists object click event - exports all lists to Excel
        private void tsmiExportAllLists_Click(object sender, EventArgs e)
        {
            string nowDateTime = DateTime.Now.Year.ToString() + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.Day.ToString()
                + " at " + DateTime.Now.Hour.ToString() + "h " + DateTime.Now.Minute.ToString() + "m";
            string initialPath = folderDialogWindow();
            string folderPath = initialPath + @"\SharepointViewer_" + nowDateTime;

            if (Directory.Exists(folderPath))
            {
                MessageBox.Show("That path exists already.");
                return;
            }
            Directory.CreateDirectory(folderPath);

            exportExcel("bpgReportCatalogue", "tbpgResourcing", true, folderPath + @"\");
            exportExcel("bpgReportCatalogue", "tbpgResourcingWorkflow", true, folderPath + @"\");
            exportExcel("bpgReportCatalogue", "tbpgKPI", true, folderPath + @"\");

            tsslStatus.Text = "";

        }

        private void lstRolloverAnalyst_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnListBox(ref lstRolloverAnalyst, ref dgvRolloverDashBoard, "Primary Preparer1");
            formatRolloverDataGrid();
        }

        //private void filterOnListBox(string fieldName, ref DataGridView myDataGridView, System.Windows.Controls.ListBox myListBox)
        private void filterOnListBox(ref System.Windows.Forms.ListBox myListBox, ref DataGridView myDataGridView, string fieldName)
        {
            string strItem = "";
            string rowFilter = string.Format("[" + fieldName + "] ='{0}'", strItem);
            bool isAllSelected = false;
            foreach (var item in myListBox.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    isAllSelected = true;
                    break;
                }
                else
                {
                    rowFilter += string.Format("OR [" + fieldName + "] ='{0}'", strItem);
                }

            }
            // No filter when <ALL> selected
            if (isAllSelected)
                rowFilter = string.Empty;

            (myDataGridView.DataSource as System.Data.DataTable).DefaultView.RowFilter = rowFilter;
        }

        private void filterOnTransitionAnalyst()
        {
            string strItem = "";
            string rowFilter = string.Format("[Report Transition Analyst (from workflow)] ='{0}'", strItem);
            bool isAllSelected = false;
            foreach (var item in lstTransitionAnalyst.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    isAllSelected = true;
                    break;
                }
                else
                {
                    rowFilter += string.Format("OR [Report Transition Analyst (from workflow)] ='{0}'", strItem);
                }

            }
            // No filter when <ALL> selected
            if (isAllSelected)
                rowFilter = string.Empty;

            (dgvTransitions.DataSource as System.Data.DataTable).DefaultView.RowFilter = rowFilter;
        }


        // Applies filters based on selections made by the user in listboxes and date/time picker
        private void filterOnSelection()
        {
            List<string> myFilterList = new List<string>();
            List<string> myWFList = new List<string>();
            tsslStatus.Text = "Loading Settings...";

            // lstEmployees.Sorted = true; // sort employe list
            int emplCount = lstEmployees.Items.Count;

            DateTime dt = dateTimePicker1.Value;
            DateTime dt2 = dateTimePicker2.Value;

            string dateFilter = "";
            if (rbBetween.Checked)
            {
                dateFilter = string.Format("[Due Date] >='{0}' AND [Due Date] <='{1}' ", dt, dt2);
            }
            else if (rbBefore.Checked)
            {
                dateFilter = string.Format("[Due Date] <='{0}' ", dt2);
            }
            else if (rbFrom.Checked)
            {
                dateFilter = string.Format("[Due Date] >='{0}' ", dt);
            }
            else
            {
                dateFilter = string.Format("[Due Date] >='{0}' ", DateTime.Today.AddYears(-1));
            }


            string strItem = "";
            string rowFilter = string.Format("[Preparer] ='{0}'", strItem);
            string rowFilter2 = string.Format("[AssignedTo] ='{0}'", strItem);
            string rowFilter3 = string.Format("[Finance Group] ='{0}'", strItem);
            string rowFilter4 = string.Format("[Request Type] ='{0}'", strItem);
            string rowFilter5 = string.Format("[Status] ='{0}'", strItem);
            string rowFilter6 = string.Format("[Frequency] ='{0}'", strItem);
            string rowFilter7 = string.Format("[Deployment Tool] ='{0}'", strItem);
            string rowFilter8 = string.Format("[Relationship Manager] ='{0}'", strItem);
            string rowFilter9 = string.Format("[Data Source] ='{0}'", strItem);
            string rowFilter10 = string.Format("[Report Status] ='{0}'", strItem);
            string rowFilter11 = string.Format("[Team Manager] ='{0}'", strItem);
            string sFilterCriteria = string.Format("[Delivery Date Time] LIKE '%{0} @%'", "GV0"); // filter for GV days
           // string keywordCatalogueFilter = ;
            bool selectAll = false;  // TO DELETE THIS VARIABLE LATER.
            bool notAll = false;

            //selectAll = false;
            notAll = false;
            foreach (var item in lstEmployees.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                }
                else
                {
                    rowFilter += string.Format("OR [Preparer] ='{0}'", strItem.Replace("'", "''"));
                    rowFilter2 += string.Format("OR [AssignedTo] ='{0}'", strItem.Replace("'", "''"));
                    //Console.WriteLine("RowFilter1: " + rowFilter);
                    //Console.WriteLine("RowFilter2: " + rowFilter2);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(rowFilter);
                myWFList.Add(rowFilter2);
            }

            notAll = false;
            bool selectAllGV = false;  // select all GV days
            foreach (var item in lstGvDays.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAllGV = true;
                    break;
                }
                else
                {
                    sFilterCriteria += string.Format("OR [Delivery Date Time] LIKE '%{0} @%'", strItem);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(sFilterCriteria);
            }

            notAll = false;
            foreach (var item in chlstPlatform.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAllGV = true;
                    break;
                }
                else
                {
                    rowFilter3 += string.Format("OR [Finance Group] ='{0}'", strItem);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(rowFilter3);
                myWFList.Add(rowFilter3);
            }

            notAll = false;
            foreach (var item in lstStatus.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                    
                }
                else
                {
                    rowFilter5 += string.Format("OR [Status] ='{0}'", strItem);
                    notAll = true;
                }

            }
            if (notAll)
            {
                
                myWFList.Add(rowFilter5);
            }

            notAll = false;
            foreach (var item in lstFrequency.SelectedItems)
            {

                strItem = item.ToString();
                if (strItem == "<ALL>" || cmbSavedFilters.Text == "<TEAM>")
                {
                    selectAll = true;                
                    break;
                   
                }
                else
                {
                    rowFilter6 += string.Format("OR [Frequency] ='{0}'", strItem);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(rowFilter6);
            }

            notAll = false;
            foreach (var item in lstCategory.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                   
                }
                else
                {
                    rowFilter4 += string.Format("OR [Request Type] ='{0}'", strItem);
                    notAll = true;
                }

            }
            if (notAll)
            {               
                myWFList.Add(rowFilter4);
            }



            // Additional filder on expanded pane
            notAll = false;
            foreach (var item in lstDeploymentTool.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                }
                else
                {
                    rowFilter7 += string.Format("OR [Deployment Tool] ='{0}'", strItem);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(rowFilter7);
            }

            notAll = false;
            foreach (var item in lstRelationshipManager.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                }
                else
                {
                    rowFilter8 += string.Format("OR [Relationship Manager] ='{0}'", strItem);
                    notAll = true;
                }

            }
            if (notAll)
            {
                myFilterList.Add(rowFilter8);
            }

            notAll = false;
            foreach (var item in lstDataSource.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                    
                }
                else
                {
                    rowFilter9 += string.Format("OR [Data Source] ='{0}'", strItem);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(rowFilter9);
            }

            notAll = false;
            foreach (var item in lstReportStatus.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                }
                else
                {
                    rowFilter10 += string.Format("OR [Report Status] ='{0}'", strItem);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(rowFilter10);
            }        

            notAll = false;
            foreach (var item in lstTeamManager.SelectedItems)
            {
                strItem = item.ToString();
                if (strItem == "<ALL>")
                {
                    selectAll = true;
                    break;
                }
                else
                {
                    rowFilter11 += string.Format("OR [Team Manager] ='{0}'", strItem);
                    notAll = true;
                }
            }
            if (notAll)
            {
                myFilterList.Add(rowFilter11);
            }

            // If no keywords are provided in the txtSearchCatalogue, 
            // then replace it with the relationship manager filter to avoid null pointer exception as a workaround.  
            if (txtSearchCatalogue.Text == "")
            {
                keywordFilterCatalogue = rowFilter8;
            }
            myFilterList.Add(keywordFilterCatalogue);  // also add keyword filter to the filter list to make sure it's correlated with other filters
           // concatenating individual filters into a combined Report Catalogue filter
            string finalFilter = "";
            if (myFilterList.Count > 0)
            {                
                foreach (string filter in myFilterList)
                {
                    finalFilter += "(" + filter + ") AND";
                }
                finalFilter = finalFilter.Substring(0, finalFilter.Length - 4);
            }
            // check filter values
           // Console.WriteLine(keywordFilter);
           // Console.WriteLine(finalFilter);
            
              // If no keywords are provided in the txtSearchWorkflow, 
            // then replace it with the status filter to avoid null pointer exception as a workaround.  
            if (txtSearchWorkflow.Text == "")
            {
                keywordFilterWorkflow = rowFilter5;
            }
            myWFList.Add(keywordFilterWorkflow);  // also add keyword filter to the filter list to make sure it's correlated with other filters
            Console.WriteLine(keywordFilterWorkflow);
            // Concatenating filters into a workflow filter
            string finalWFFilter = "";
            if (myWFList.Count > 0)
            {                
                foreach (string filter in myWFList)
                {
                    finalWFFilter += "(" + filter + ") AND";
                }
                finalWFFilter = finalWFFilter.Substring(0, finalWFFilter.Length - 4);
            }

            Console.WriteLine("FINAL1: " + finalWFFilter);
            Console.WriteLine("FINAL1: " +  finalFilter);
            if (finalFilter.Length > 0)
            {
                (dgvResourcing.DataSource as System.Data.DataTable).DefaultView.RowFilter = finalFilter;
            }

            // Workflow history table filter
            // if checkbox is checked, then don't filter on the date
            //Console.WriteLine(finalWFFilter.Length);
            if (finalWFFilter.Length > 0)
            {
                //  MessageBox.Show(cmbSavedFilters.Text);
                if (chkIncludeAllDates.Checked)
                {
                    (dgvResourcingWorkflow.DataSource as System.Data.DataTable).DefaultView.RowFilter = finalWFFilter;// "(" + rowFilter2 + ")" + "AND (" + rowFilter3 + ")" + "AND (" + rowFilter4 + ")" + "AND (" + rowFilter5 + ")";
                }
                /*  else if (cmbSavedFilters.SelectedItem.ToString() == "<ALL>" || cmbSavedFilters.SelectedItem.ToString() == "<TEAM>")
                  {
                      DateTime currentFiscPeriod = new DateTime(DateTime.Today.AddYears(-1).Year, 11, 1);
                      dateFilter = string.Format("[Due Date] >='{0}' ", currentFiscPeriod);
                      (dgvResourcingWorkflow.DataSource as System.Data.DataTable).DefaultView.RowFilter = finalWFFilter + "AND (" + dateFilter + ")";
                  } */
                else
                {
                    if (rbBetween.Checked && dt > dt2)
                        MessageBox.Show("Start date has to be before the End date. Please select a valid date range and try again.");
                    else
                        (dgvResourcingWorkflow.DataSource as System.Data.DataTable).DefaultView.RowFilter = finalWFFilter + "AND (" + dateFilter + ")";//  "(" + rowFilter2 + ")" + "AND (" + rowFilter3 + ")" + "AND (" + rowFilter4 + ")" + "AND (" + rowFilter5 + ")" + "AND (" + dateFilter + ")";
                }
            }
            /*else if (cmbSavedFilters.SelectedItem.ToString() == "<ALL>" || cmbSavedFilters.SelectedItem.ToString() == "<TEAM>")
            {
                DateTime currentFiscPeriod = new DateTime(DateTime.Today.AddYears(-1).Year, 11, 1);
                dateFilter = string.Format("[Due Date] >='{0}' ", currentFiscPeriod);
                (dgvResourcingWorkflow.DataSource as System.Data.DataTable).DefaultView.RowFilter = finalWFFilter + "AND (" + dateFilter + ")";
            } */

            tsslStatus.Text = "";
            populateSummaryGrid(); // populating datagrid view with the LINQ data based on the filter selected
            updateDataGridViewItemCount(); // update count of items on respective datagridview at the bottom of the page
        }



        bool workflowCategoryPopulated = false;
        private void populateWorkflowCategory()
        {

            int rowCount = dgvResourcingWorkflow.RowCount - 1; // count records for workflow

            // String[] categoryName = new String[rowCount];

            int i = 0;


            List<dgvRecord> categoryList = new List<dgvRecord>();

            while (i < rowCount)
            {
                categoryList.Add(new dgvRecord(i, dgvResourcingWorkflow.Rows[i].Cells["Request Type"].Value.ToString(), "0", "0", "0", "0", "0"));
                i++;
            }

            var query = from p in categoryList   // individual totals
                        group p by new { p.name } into grp
                        select new
                        {
                            platform = grp.Key.name
                        };

            // populate checkedlistbox
            // TO DELETE
            if (!workflowCategoryPopulated)
            {
                foreach (var group in query)
                {
                    if (group.platform == null || group.platform.Equals(""))
                    {
                        //cmbWorkflowCategory.Items.Add("NA");
                    }
                    else
                    {
                        // cmbWorkflowCategory.Items.Add(group.platform);
                    }
                }
            }
            workflowCategoryPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names
        }

        // populate frequency
        bool frequencyPopulated = false;
        private void populateFrequency()
        {
            List<DataGridViewRow> frequencyItems = new List<DataGridViewRow>();

            int rowCount = dgvResourcing.RowCount - 1; // count records for workflow

            //String[] platformName = new String[rowCount];

            int i = 0;
            List<dgvRecord> frequencyList = new List<dgvRecord>();

            while (i < rowCount)
            {
                frequencyList.Add(new dgvRecord(i, dgvResourcing.Rows[i].Cells[6].Value.ToString(), "0", "0", "0", "0", "0"));

                // frequencyItems.Add(dgvResourcingWorkflow.Rows[i]);
                // platformName[i] = dgvResourcingWorkflow.Rows[i].Cells[6].Value != null ? dgvResourcingWorkflow.Rows[i].Cells[6].Value.ToString() : String.Empty;
                i++;
            }

            var query = from p in frequencyList   // individual totals
                        group p by new { p.name } into grp
                        select new
                        {
                            platform = grp.Key.name
                        };

            // populate checkedlistbox
            if (!frequencyPopulated)
            {
                lstFrequency.Items.Add("<ALL>");
                foreach (var group in query)
                {
                    if (group.platform == null || group.platform.Equals(""))
                    {
                        lstFrequency.Items.Add("NA");
                    }
                    else
                    {
                        lstFrequency.Items.Add(group.platform);
                    }
                }
            }
            frequencyPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names
        }


        bool reportStatusPopulated = false;
        private void populateListBox(string lstName)
        {

            // Debug.Print("Inside the procedure" + lstName);
            System.Windows.Forms.ListBox lstMyListBox = lstReportStatus;
            string category = "";
            switch (lstName)
            {
                case "Report Status":
                    lstMyListBox = lstReportStatus;
                    category = "Report Status";
                    break;
                case "Relationship Manager":
                    lstMyListBox = lstRelationshipManager;
                    category = "Relationship Manager";
                    break;
                case "Data Source":
                    lstMyListBox = lstDeploymentTool;
                    category = "Deployment Tool";
                    break;
                case "Deployment Tool":
                    lstMyListBox = lstDataSource;
                    category = "Data Source";
                    break;
                case "Team Manager":
                    lstMyListBox = lstTeamManager;
                    category = "Team Manager";
                    break;
                default:
                    //lstMyListBox = lstDeploymentTool;
                    //category = "Relationship Manager";
                    MessageBox.Show("Error loading information to one of the list boxes");
                    break;
            }

            int rowCount = dgvResourcing.RowCount - 1; // count records for workflow          

            int i = 0;
            List<dgvRecord> myList = new List<dgvRecord>();

            while (i < rowCount)
            {
                myList.Add(new dgvRecord(i, dgvResourcing.Rows[i].Cells[category].Value.ToString(), "0", "0", "0", "0", "0"));
                // Debug.Print(dgvResourcing.Rows[i].Cells[category] + "");       

                i++;
            }

            var query = from p in myList  // individual totals
                        group p by new { p.name } into grp
                        select new
                        {
                            listItem = grp.Key.name
                        };

            // populate listbox
            if (!reportStatusPopulated)
            {
                if (category != "Relationship Manager")
                {
                    lstMyListBox.Items.Add("<ALL>");
                }

                foreach (var group in query)
                {
                    if (group.listItem == null || group.listItem.Equals(""))
                    {
                        lstMyListBox.Items.Add("NA");
                    }
                    else
                    {
                        lstMyListBox.Items.Add(group.listItem);
                    }
                }
            }
            // platformPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names
        }

        bool platformPopulated = false;
        private void populatePlatformListBox()
        {
            List<DataGridViewRow> platformItems = new List<DataGridViewRow>();

            int rowCount = dgvResourcingWorkflow.RowCount - 1; // count records for workflow

            // String[] platformName = new String[rowCount];

            int i = 0;


            List<dgvRecord> platformList = new List<dgvRecord>();

            while (i < rowCount)
            {
                platformList.Add(new dgvRecord(i, dgvResourcingWorkflow.Rows[i].Cells["Finance Group"].Value.ToString(), "0", "0", "0", "0", "0"));

                platformItems.Add(dgvResourcingWorkflow.Rows[i]);
                //   platformName[i] = dgvResourcingWorkflow.Rows[i].Cells[1].Value != null ? dgvResourcingWorkflow.Rows[i].Cells[4].Value.ToString() : String.Empty;
                i++;
            }

            var query = from p in platformList   // individual totals
                        group p by new { p.name } into grp
                        select new
                        {
                            platform = grp.Key.name
                        };

            // populate checkedlistbox
            if (!platformPopulated)
            {
                chlstPlatform.Items.Add("<ALL>");
                foreach (var group in query)
                {
                    if (group.platform == null || group.platform.Equals(""))
                    {
                        chlstPlatform.Items.Add("NA");
                    }
                    else
                    {
                        chlstPlatform.Items.Add(group.platform);
                    }
                }
            }
            platformPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names

        }

        // bool lstMyListboxPopulated = false;
        private void populateTransAnalystListBox(string fieldName, ref System.Windows.Forms.ListBox lstMyListbox, ref DataGridView myDataGridView, bool lstMyListboxPopulated)
        {

            int rowCount = myDataGridView.RowCount - 1; // count records for workflow

            String[] platformName = new String[rowCount];

            int i = 0;


            List<dgvRecord> staffList = new List<dgvRecord>();

            while (i < rowCount)
            {
                staffList.Add(new dgvRecord(i, myDataGridView.Rows[i].Cells[fieldName].Value.ToString(), "0", "0", "0", "0", "0"));
                i++;
            }

            var query = from p in staffList   // individual totals
                        group p by new { p.name } into grp
                        select new
                        {
                            platform = grp.Key.name
                        };



            // populate checkedlistbox
            if (!lstMyListboxPopulated)
            {
                lstMyListbox.Items.Add("<ALL>");
                foreach (var group in query)
                {
                    // Debug.Print(group.platform);
                    if (group.platform == null || group.platform.Equals(""))
                    {
                        lstMyListbox.Items.Add("NA");
                    }
                    else
                    {
                        lstMyListbox.Items.Add(group.platform);
                    }
                }
            }
            //lstMyListboxPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names

        }
        bool wfCatagoryPopulated = false;
        private void populateWorkflowType(string column)  // populate listbox containing names of the workflow categories
        {
            //System.Windows.Forms.ListBox myListBox = listBoxName;
            List<DataGridViewRow> wfItems = new List<DataGridViewRow>();

            int rowCount = dgvResourcingWorkflow.RowCount - 1; // count records for workflow
            //   String[] platformName = new String[rowCount];

            int i = 0;

            List<dgvRecord> platformList = new List<dgvRecord>();

            while (i < rowCount)
            {
                platformList.Add(new dgvRecord(i, dgvResourcingWorkflow.Rows[i].Cells[column].Value.ToString(), "0", "0", "0", "0", "0"));

                wfItems.Add(dgvResourcingWorkflow.Rows[i]);
                //  platformName[i] = dgvResourcingWorkflow.Rows[i].Cells[column].Value != null ? dgvResourcingWorkflow.Rows[i].Cells[4].Value.ToString() : String.Empty;
                i++;
            }

            var query = from p in platformList
                        group p by new { p.name } into grp
                        select new
                        {
                            platform = grp.Key.name
                        };


            if (!wfCatagoryPopulated)
            {
                //  lstCategory.Items.Add("<ALL>");
                foreach (var group in query)
                {
                    if (group.platform == null || group.platform.Equals(""))
                    {
                        lstCategory.Items.Add("NA");
                    }
                    else
                    {
                        lstCategory.Items.Add(group.platform);
                    }
                }
            }
            wfCatagoryPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names

        }


        bool wfStatusPopulated = false;
        private void populateWorkflowStatus(string column)  // populate listbox containing names of the workflow categories
        {

            List<DataGridViewRow> wfItems = new List<DataGridViewRow>();

            int rowCount = dgvResourcingWorkflow.RowCount - 1; // count records for workflow
            //  String[] platformName = new String[rowCount];

            int i = 0;

            List<dgvRecord> platformList = new List<dgvRecord>();

            while (i < rowCount)
            {
                platformList.Add(new dgvRecord(i, dgvResourcingWorkflow.Rows[i].Cells[column].Value.ToString(), "0", "0", "0", "0", "0"));

                wfItems.Add(dgvResourcingWorkflow.Rows[i]);
                //   platformName[i] = dgvResourcingWorkflow.Rows[i].Cells[column].Value != null ? dgvResourcingWorkflow.Rows[i].Cells[4].Value.ToString() : String.Empty;
                i++;
            }

            var query = from p in platformList
                        group p by new { p.name } into grp
                        select new
                        {
                            platform = grp.Key.name
                        };


            if (!wfStatusPopulated)
            {
                //lstStatus.Items.Add("ALL");
                foreach (var group in query)
                {
                    if (group.platform == null || group.platform.Equals(""))
                    {
                        lstStatus.Items.Add("NA");
                    }
                    else
                    {
                        lstStatus.Items.Add(group.platform);
                    }
                }
            }
            wfStatusPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names

        }

        //dgvResourcingWorkflow
        bool titleCreated = false;
        private void populateWorflowCharts()
        {
            // List<DataGridViewRow> rowItems = new List<DataGridViewRow>();     
            int rowCount = dgvResourcingWorkflow.RowCount; // count records for Application catalog

            int i = 0;

            List<dgvRecord> recordList = new List<dgvRecord>();
            string effortRequired = "0.00";
            while (i < rowCount)
            {
                if (dgvResourcingWorkflow.Rows[i].Cells["Effort Required"].Value.ToString() == "" || dgvResourcingWorkflow.Rows[i].Cells["Effort Required"].Value.ToString() == null)
                {
                    effortRequired = "0.00";
                }
                else
                {
                    effortRequired = dgvResourcingWorkflow.Rows[i].Cells["Effort Required"].Value.ToString();
                }
                recordList.Add(new dgvRecord(i, dgvResourcingWorkflow.Rows[i].Cells["Finance Group"].Value.ToString(),  // platform
                                            dgvResourcingWorkflow.Rows[i].Cells["Request Type"].Value.ToString(),    // category
                                            dgvResourcingWorkflow.Rows[i].Cells["Status"].Value.ToString(),
                                            effortRequired, "0", "0")); // status
                // rowItems.Add(dgvResourcing.Rows[i]);                
                i++;
            }

            // stats by platform - TO DO LATER. RADAR CHART
            var query = from p in recordList
                        group p by new { p.name } into grp
                        select new
                        {
                            platform = grp.Key.name,
                            platformRequestCount = grp.Count()   //Sum(p => p.gv1), 

                        };

            var queryPlatform = query.OrderByDescending(p => p.platformRequestCount);

            // stats by category
            var query2 = from p in recordList
                         group p by new { p.report } into grp
                         select new
                         {
                             category = grp.Key.report,
                             requestCategory = grp.Count()   //Sum(p => p.gv1),                           
                         };

            // stats by status           
            var query3 = from p in recordList
                         group p by new { p.gvString } into grp
                         select new
                         {
                             status = grp.Key.gvString,
                             statusCount = grp.Count()   //Sum(p => p.gv1),                           
                         };

            var query4 = from p in recordList
                         group p by new { p.report } into grp
                         select new
                         {
                             category = grp.Key.report,
                             totalEffort = Math.Round(grp.Sum(p => Convert.ToDouble(p.gvTime)), 2) // frequency                           
                         };

            var categoryArray = query2.ToArray(); // putting category LINQ to array list so we can put it in a graph         
            var statusArray = query3.ToArray(); // putting status LINQ to array list so we can put it in a graph
            var platformArray = queryPlatform.ToArray(); // putting platform LINQ to array list so we can put it in a graph
            var categoryEffort = query4.ToArray();


            while (chartCategory.Series.Count > 0) // delete all series
            {
                chartCategory.Series.RemoveAt(0);
            }
            String seriesName = "Category";
            chartCategory.Series.Add(seriesName);
            chartCategory.Series[seriesName].IsVisibleInLegend = false;
            if (!titleCreated)
            {
                Title categoryTitle = new Title();
                categoryTitle.Text = "Request category";
                chartCategory.Titles.Add(categoryTitle);
            }

            if (rbEffortRequired.Checked)
            {

                for (int n = 0; n < categoryEffort.Length; n++)
                {
                    chartCategory.Series[seriesName].Points.AddXY(categoryEffort[n].category, categoryEffort[n].totalEffort);
                    chartCategory.Series[seriesName].Label = "#VALY";
                }
            }
            else
            {
                for (int n = 0; n < categoryArray.Length; n++)
                {
                    chartCategory.Series[seriesName].Points.AddXY(categoryArray[n].category, categoryArray[n].requestCategory);
                    chartCategory.Series[seriesName].Label = "#VALY";
                }
            }



            while (chartStatus.Series.Count > 0) // delete all series
            {
                chartStatus.Series.RemoveAt(0);
            }

            seriesName = "Status";
            chartStatus.Series.Add(seriesName);

            if (!titleCreated)
            {
                Title statusTitle = new Title();
                statusTitle.Text = "Request status";
                chartStatus.Titles.Add(statusTitle);
            }

            for (int n = 0; n < statusArray.Length; n++)
            {
                chartStatus.Series[seriesName].Points.AddXY(statusArray[n].status, statusArray[n].statusCount);
                chartStatus.Series[seriesName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;

                chartStatus.Series[seriesName].LegendText = "#VALX" + "-" + "#VALY";
                chartStatus.Series[seriesName]["PieLabelStyle"] = "Disabled";
            }


            // Radar chart for Platform
            while (chartPlatform.Series.Count > 0) // delete all series
            {
                chartPlatform.Series.RemoveAt(0);
            }
            seriesName = "Platform";
            chartPlatform.Series.Add(seriesName);
            if (!titleCreated)
            {
                Title platformTitle = new Title();
                platformTitle.Text = "Platform";
                chartPlatform.Titles.Add(platformTitle);
                titleCreated = true;
            }
            for (int n = 0; n < platformArray.Length; n++)
            {
                chartPlatform.Series[seriesName].Points.AddXY(platformArray[n].platform, platformArray[n].platformRequestCount);
                chartPlatform.Series[seriesName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pyramid;
                chartPlatform.Series[seriesName].LegendText = "#VALX" + "-" + "#VALY";

            }
            // rescale chart after selections have been made
            chartCategory.ChartAreas[0].RecalculateAxesScale();

        }


        bool listBoxPopulated = false;
        private void populateSummaryGrid()
        {
            List<DataGridViewRow> rowItems = new List<DataGridViewRow>();
            int rowCount = dgvResourcing.RowCount - 1; // count records for Application catalog



            int i = 0;

            // Debug.Print("rowCount: " + rowCount);
            List<dgvRecord> recordList = new List<dgvRecord>();
            string preparerName = "", deployTool = "", dataSource = "";
            while (i < rowCount)
            {
                if (dgvResourcing.Rows[i].Cells["Preparer"].Value.ToString() == "" || dgvResourcing.Rows[i].Cells["Preparer"].Value.ToString() == null)
                {
                    preparerName = "NA";
                }
                else
                {
                    preparerName = dgvResourcing.Rows[i].Cells["Preparer"].Value.ToString();
                }
                if (dgvResourcing.Rows[i].Cells["Deployment Tool"].Value.ToString() == "" || dgvResourcing.Rows[i].Cells["Deployment Tool"].Value.ToString() == null)
                {
                    deployTool = "NA";
                }
                else
                {
                    deployTool = dgvResourcing.Rows[i].Cells["Deployment Tool"].Value.ToString();
                }
                if (dgvResourcing.Rows[i].Cells["Data Source"].Value.ToString() == "" || dgvResourcing.Rows[i].Cells["Data Source"].Value.ToString() == null)
                {
                    dataSource = "NA";
                }
                else
                {
                    dataSource = dgvResourcing.Rows[i].Cells["Data Source"].Value.ToString();
                }
                recordList.Add(new dgvRecord(i, preparerName, deployTool,
                                             dgvResourcing.Rows[i].Cells["Delivery Date Time"].Value.ToString(), dgvResourcing.Rows[i].Cells["Processing Time"].Value.ToString(),
                                             dataSource, dgvResourcing.Rows[i].Cells["Setup Time"].Value.ToString(), 0));


                rowItems.Add(dgvResourcing.Rows[i]);
                i++;
            }

            if (rbProcessTime.Checked) // showing stats for Processing time
            {
                var query = from p in recordList   // individual totals
                            group p by new { p.name } into grp
                            select new
                            {
                                Preparer = grp.Key.name,
                                gv0 = Math.Round(grp.Sum(p => p.gv0_setup), 2),
                                gv1 = Math.Round(grp.Sum(p => p.gv1_setup), 2),
                                gv2 = Math.Round(grp.Sum(p => p.gv2_setup), 2),
                                gv3 = Math.Round(grp.Sum(p => p.gv3_setup), 2),
                                gv4 = Math.Round(grp.Sum(p => p.gv4_setup), 2),
                                gv5 = Math.Round(grp.Sum(p => p.gv5_setup), 2),
                                gv6 = Math.Round(grp.Sum(p => p.gv6_setup), 2),
                                gv7 = Math.Round(grp.Sum(p => p.gv7_setup), 2),
                                gv8 = Math.Round(grp.Sum(p => p.gv8_setup), 2),
                                gv9 = Math.Round(grp.Sum(p => p.gv9_setup), 2),
                                gv10 = Math.Round(grp.Sum(p => p.gv10_setup), 2),
                                gv11 = Math.Round(grp.Sum(p => p.gv11_setup), 2),
                                gv12 = Math.Round(grp.Sum(p => p.gv12_setup), 2),
                                gv13 = Math.Round(grp.Sum(p => p.gv13_setup), 2),
                                gv14 = Math.Round(grp.Sum(p => p.gv14_setup), 2),
                                gv15 = Math.Round(grp.Sum(p => p.gv15_setup), 2),
                                week2 = Math.Round(grp.Sum(p => p.week2_setup), 2),
                                week3 = Math.Round(grp.Sum(p => p.week3_setup), 2),
                                day20 = Math.Round(grp.Sum(p => p.day20_setup), 2),
                                daily = Math.Round(grp.Sum(p => p.daily_setup), 2),
                                weekly = Math.Round(grp.Sum(p => p.weekly_setup), 2),
                                bi_weekly = Math.Round(grp.Sum(p => p.bi_weekly_setup), 2),
                                before_EOM = Math.Round(grp.Sum(p => p.before_EOM_setup), 2),
                                annual = Math.Round(grp.Sum(p => p.annual), 2),
                                semi_annual = Math.Round(grp.Sum(p => p.semi_annual_setup), 2),
                                quarterly = Math.Round(grp.Sum(p => p.quarterly_setup), 2)
                            };

                var query2 = from p in recordList  // grand totals for RS
                             group p by "X" into grp
                             select new
                             {
                                 Preparer = "TOTAL",
                                 gv0 = Math.Round(grp.Sum(p => p.gv0_setup2), 2),
                                 gv1 = Math.Round(grp.Sum(p => p.gv1_setup2), 2),
                                 gv2 = Math.Round(grp.Sum(p => p.gv2_setup2), 2),
                                 gv3 = Math.Round(grp.Sum(p => p.gv3_setup2), 2),
                                 gv4 = Math.Round(grp.Sum(p => p.gv4_setup2), 2),
                                 gv5 = Math.Round(grp.Sum(p => p.gv5_setup2), 2),
                                 gv6 = Math.Round(grp.Sum(p => p.gv6_setup2), 2),
                                 gv7 = Math.Round(grp.Sum(p => p.gv7_setup2), 2),
                                 gv8 = Math.Round(grp.Sum(p => p.gv8_setup2), 2),
                                 gv9 = Math.Round(grp.Sum(p => p.gv9_setup2), 2),
                                 gv10 = Math.Round(grp.Sum(p => p.gv10_setup2), 2),
                                 gv11 = Math.Round(grp.Sum(p => p.gv11_setup2), 2),
                                 gv12 = Math.Round(grp.Sum(p => p.gv12_setup2), 2),
                                 gv13 = Math.Round(grp.Sum(p => p.gv13_setup2), 2),
                                 gv14 = Math.Round(grp.Sum(p => p.gv14_setup2), 2),
                                 gv15 = Math.Round(grp.Sum(p => p.gv15_setup2), 2),
                                 week2 = Math.Round(grp.Sum(p => p.week2_setup2), 2),
                                 week3 = Math.Round(grp.Sum(p => p.week3_setup2), 2),
                                 day20 = Math.Round(grp.Sum(p => p.day20_setup2), 2),
                                 daily = Math.Round(grp.Sum(p => p.daily_setup2), 2),
                                 weekly = Math.Round(grp.Sum(p => p.weekly_setup2), 2),
                                 bi_weekly = Math.Round(grp.Sum(p => p.bi_weekly_setup2), 2),
                                 before_EOM = Math.Round(grp.Sum(p => p.before_EOM_setup2), 2),
                                 annual = Math.Round(grp.Sum(p => p.annual_setup2), 2),
                                 semi_annual = Math.Round(grp.Sum(p => p.semi_annual_setup2), 2),
                                 quarterly = Math.Round(grp.Sum(p => p.quarterly_setup2), 2)
                             };
                // combine 2 query results  
                var resultSum = query.Concat(query2);
                dgvSummaryView.DataSource = resultSum.ToList(); // populating datagrid view with the LINQ data   
                if (!listBoxPopulated)
                {
                    lstEmployees.Items.Add("<ALL>");
                    foreach (var group in query)
                    {
                        if (group.Preparer == null || group.Preparer.Equals(""))
                        {
                            lstEmployees.Items.Add("NA");
                        }
                        else
                        {
                            lstEmployees.Items.Add(group.Preparer);
                        }
                    }
                }

                listBoxPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names
            }

            else if (rbSetupTime.Checked) // showing stats for Processing time
            {
                var query = from p in recordList   // individual totals
                            group p by new { p.name } into grp
                            select new
                            {
                                Preparer = grp.Key.name,
                                gv0 = Math.Round(grp.Sum(p => p.gv0_setup2), 2),
                                gv1 = Math.Round(grp.Sum(p => p.gv1_setup2), 2),
                                gv2 = Math.Round(grp.Sum(p => p.gv2_setup2), 2),
                                gv3 = Math.Round(grp.Sum(p => p.gv3_setup2), 2),
                                gv4 = Math.Round(grp.Sum(p => p.gv4_setup2), 2),
                                gv5 = Math.Round(grp.Sum(p => p.gv5_setup2), 2),
                                gv6 = Math.Round(grp.Sum(p => p.gv6_setup2), 2),
                                gv7 = Math.Round(grp.Sum(p => p.gv7_setup2), 2),
                                gv8 = Math.Round(grp.Sum(p => p.gv8_setup2), 2),
                                gv9 = Math.Round(grp.Sum(p => p.gv9_setup2), 2),
                                gv10 = Math.Round(grp.Sum(p => p.gv10_setup2), 2),
                                gv11 = Math.Round(grp.Sum(p => p.gv11_setup2), 2),
                                gv12 = Math.Round(grp.Sum(p => p.gv12_setup2), 2),
                                gv13 = Math.Round(grp.Sum(p => p.gv13_setup2), 2),
                                gv14 = Math.Round(grp.Sum(p => p.gv14_setup2), 2),
                                gv15 = Math.Round(grp.Sum(p => p.gv15_setup2), 2),
                                week2 = Math.Round(grp.Sum(p => p.week2_setup2), 2),
                                week3 = Math.Round(grp.Sum(p => p.week3_setup2), 2),
                                day20 = Math.Round(grp.Sum(p => p.day20_setup2), 2),
                                daily = Math.Round(grp.Sum(p => p.daily_setup2), 2),
                                weekly = Math.Round(grp.Sum(p => p.weekly_setup2), 2),
                                bi_weekly = Math.Round(grp.Sum(p => p.bi_weekly_setup2), 2),
                                before_EOM = Math.Round(grp.Sum(p => p.before_EOM_setup2), 2),
                                // annual = Math.Round(grp.Sum(p => p.annual2), 2),
                                semi_annual = Math.Round(grp.Sum(p => p.semi_annual_setup2), 2),
                                quarterly = Math.Round(grp.Sum(p => p.quarterly_setup2), 2)
                            };

                var query2 = from p in recordList  // grand totals for RS
                             group p by "X" into grp
                             select new
                             {
                                 Preparer = "TOTAL",
                                 gv0 = Math.Round(grp.Sum(p => p.gv0_setup2), 2),
                                 gv1 = Math.Round(grp.Sum(p => p.gv1_setup2), 2),
                                 gv2 = Math.Round(grp.Sum(p => p.gv2_setup2), 2),
                                 gv3 = Math.Round(grp.Sum(p => p.gv3_setup2), 2),
                                 gv4 = Math.Round(grp.Sum(p => p.gv4_setup2), 2),
                                 gv5 = Math.Round(grp.Sum(p => p.gv5_setup2), 2),
                                 gv6 = Math.Round(grp.Sum(p => p.gv6_setup2), 2),
                                 gv7 = Math.Round(grp.Sum(p => p.gv7_setup2), 2),
                                 gv8 = Math.Round(grp.Sum(p => p.gv8_setup2), 2),
                                 gv9 = Math.Round(grp.Sum(p => p.gv9_setup2), 2),
                                 gv10 = Math.Round(grp.Sum(p => p.gv10_setup2), 2),
                                 gv11 = Math.Round(grp.Sum(p => p.gv11_setup2), 2),
                                 gv12 = Math.Round(grp.Sum(p => p.gv12_setup2), 2),
                                 gv13 = Math.Round(grp.Sum(p => p.gv13_setup2), 2),
                                 gv14 = Math.Round(grp.Sum(p => p.gv14_setup2), 2),
                                 gv15 = Math.Round(grp.Sum(p => p.gv15_setup2), 2),
                                 week2 = Math.Round(grp.Sum(p => p.week2_setup2), 2),
                                 week3 = Math.Round(grp.Sum(p => p.week3_setup2), 2),
                                 day20 = Math.Round(grp.Sum(p => p.day20_setup2), 2),
                                 daily = Math.Round(grp.Sum(p => p.daily_setup2), 2),
                                 weekly = Math.Round(grp.Sum(p => p.weekly_setup2), 2),
                                 bi_weekly = Math.Round(grp.Sum(p => p.bi_weekly_setup2), 2),
                                 before_EOM = Math.Round(grp.Sum(p => p.before_EOM_setup2), 2),
                                 // annual = Math.Round(grp.Sum(p => p.annual2), 2),
                                 semi_annual = Math.Round(grp.Sum(p => p.semi_annual_setup2), 2),
                                 quarterly = Math.Round(grp.Sum(p => p.quarterly_setup2), 2)
                             };
                // combine 2 query results  
                var resultSum = query.Concat(query2);
                dgvSummaryView.DataSource = resultSum.ToList(); // populating datagrid view with the LINQ data   
                if (!listBoxPopulated)
                {
                    lstEmployees.Items.Add("<ALL>");
                    foreach (var group in query)
                    {
                        if (group.Preparer == null || group.Preparer.Equals(""))
                        {
                            lstEmployees.Items.Add("NA");
                        }
                        else
                        {
                            lstEmployees.Items.Add(group.Preparer);
                        }
                    }
                }
                listBoxPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names
            }

            else if (rbRptCount.Checked)  // showing stats for report count
            {

                var query = from p in recordList   // individual totals
                            group p by new { p.name } into grp                           
                            select new
                            {
                                Preparer = grp.Key.name,
                                gv0 = grp.Sum(p => p.gv0),
                                gv1 = grp.Sum(p => p.gv1),
                                gv2 = grp.Sum(p => p.gv2),
                                gv3 = grp.Sum(p => p.gv3),
                                gv4 = grp.Sum(p => p.gv4),
                                gv5 = grp.Sum(p => p.gv5),
                                gv6 = grp.Sum(p => p.gv6),
                                gv7 = grp.Sum(p => p.gv7),
                                gv8 = grp.Sum(p => p.gv8),
                                gv9 = grp.Sum(p => p.gv9),
                                gv10 = grp.Sum(p => p.gv10),
                                gv11 = grp.Sum(p => p.gv11),
                                gv12 = grp.Sum(p => p.gv12),
                                gv13 = grp.Sum(p => p.gv13),
                                gv14 = grp.Sum(p => p.gv14),
                                gv15 = grp.Sum(p => p.gv15),
                                week2 = grp.Sum(p => p.week2),
                                week3 = grp.Sum(p => p.week3),
                                day20 = grp.Sum(p => p.day20),
                                daily = grp.Sum(p => p.daily),
                                weekly = grp.Sum(p => p.weekly),
                                bi_weekly = grp.Sum(p => p.bi_weekly),
                                before_EOM = grp.Sum(p => p.before_EOM),
                                annual = grp.Sum(p => p.annual),
                                semi_annual = grp.Sum(p => p.semi_annual),
                                quarterly = grp.Sum(p => p.quarterly)
                            };

                var query2 = from p in recordList  // grand totals for RS
                             group p by "X" into grp
                             select new
                             {
                                 Preparer = "TOTAL",
                                 gv0 = grp.Sum(p => p.gv0),
                                 gv1 = grp.Sum(p => p.gv1),
                                 gv2 = grp.Sum(p => p.gv2),
                                 gv3 = grp.Sum(p => p.gv3),
                                 gv4 = grp.Sum(p => p.gv4),
                                 gv5 = grp.Sum(p => p.gv5),
                                 gv6 = grp.Sum(p => p.gv6),
                                 gv7 = grp.Sum(p => p.gv7),
                                 gv8 = grp.Sum(p => p.gv8),
                                 gv9 = grp.Sum(p => p.gv9),
                                 gv10 = grp.Sum(p => p.gv10),
                                 gv11 = grp.Sum(p => p.gv11),
                                 gv12 = grp.Sum(p => p.gv12),
                                 gv13 = grp.Sum(p => p.gv13),
                                 gv14 = grp.Sum(p => p.gv14),
                                 gv15 = grp.Sum(p => p.gv15),
                                 week2 = grp.Sum(p => p.week2),
                                 week3 = grp.Sum(p => p.week3),
                                 day20 = grp.Sum(p => p.day20),
                                 daily = grp.Sum(p => p.daily),
                                 weekly = grp.Sum(p => p.weekly),
                                 bi_weekly = grp.Sum(p => p.bi_weekly),
                                 before_EOM = grp.Sum(p => p.before_EOM),
                                 annual = grp.Sum(p => p.annual),
                                 semi_annual = grp.Sum(p => p.semi_annual),
                                 quarterly = grp.Sum(p => p.quarterly)
                             };
                // combine 2 query results  
                var resultSum = query.Concat(query2);
                dgvSummaryView.DataSource = resultSum.ToList(); // populating datagrid view with the LINQ data  
                // populate listbox

                if (!listBoxPopulated)
                {
                    lstEmployees.Items.Add("<ALL>");
                    foreach (var group in query)
                    {
                        if (group.Preparer == null || group.Preparer.Equals(""))
                        {
                            lstEmployees.Items.Add("NA");
                        }
                        else
                        {
                            lstEmployees.Items.Add(group.Preparer);
                        }
                    }
                }
                listBoxPopulated = true; // setting flag to true so that we don't populate listbox again with duplicate employee names
            }
            else if (rbTotalReportCount.Checked) // showing stats for Processing time
            {

                var query = from p in recordList   // individual totals
                            group p by new { p.name } into grp
                            select new
                            {
                                Preparer = grp.Key.name,
                                totalReports = grp.Count()
                            };

                var query2 = from p in recordList  // grand totals for RS
                             group p by "X" into grp
                             select new
                             {
                                 Preparer = "TOTAL",
                                 totalReports = grp.Count()
                             };

                // combine 2 query results  
                var resultSum = query.Concat(query2);
                dgvSummaryView.DataSource = resultSum.ToList(); // populating datagrid view with the LINQ data  

            }
            else if (rbTotalReportCount.Checked) // showing stats for report count by person
            {

                var query = from p in recordList   // individual totals
                            group p by new { p.name } into grp
                            select new
                            {
                                Preparer = grp.Key.name,
                                totalReports = grp.Count()
                            };

                var query2 = from p in recordList  // grand totals for RS
                             group p by "X" into grp
                             select new
                             {
                                 Preparer = "TOTAL",
                                 totalReports = grp.Count()
                             };

                // combine 2 query results  
                var resultSum = query.Concat(query2);
                dgvSummaryView.DataSource = resultSum.ToList(); // populating datagrid view with the LINQ data  

            }
            else if (rbDataSource.Checked) // showing stats for data source
            {

                var query = from p in recordList   // individual totals                            
                            group p by new { p.report } into grp                            
                            select new
                            {
                                Data_Source = grp.Key.report,
                                Total_Reports = grp.Count()
                            };

                var query2 = from p in recordList  // grand totals for RS
                             group p by "X" into grp
                             select new
                             {
                                 Data_Source = "TOTAL",
                                 Total_Reports = grp.Count()
                             };

                // combine 2 query results  
                var resultSum = query.Concat(query2);
               
                dgvSummaryView.DataSource = resultSum.ToList(); // populating datagrid view with the LINQ data  
            }
            else if (rbDeploymentTools.Checked) // showing stats for data source
            {

                var query = from p in recordList   // individual totals
                            group p by new { p.frequency } into grp
                            select new
                            {
                                Deployment = grp.Key.frequency,
                                Total_Reports = grp.Count()
                            };

                var query2 = from p in recordList  // grand totals for RS
                             group p by "X" into grp
                             select new
                             {
                                 Deployment = "TOTAL",
                                 Total_Reports = grp.Count()
                             };

                // combine 2 query results  
                var resultSum = query.Concat(query2);
                dgvSummaryView.DataSource = resultSum.ToList(); // populating datagrid view with the LINQ data  


            }

            selectChartToDisplay(); // refresh the appropriate chart object on the Report Catalogue Tab
            //buildAreaChart();

        }

        // displays different chart type depending on the selection of the radio button
        private void selectChartToDisplay()
        {
            if (rbProcessTime.Checked || rbRptCount.Checked || rbSetupTime.Checked)
            {
                buildAreaChart();
            }
            else if (rbDataSource.Checked)
            {
                buildBarChartCatalogue("Datasource", "Datasource");
            }
            else if (rbDeploymentTools.Checked)
            {
                buildBarChartCatalogue("Deployment Tool", "Deployment tool");
            }
            else if (rbTotalReportCount.Checked)
            {
                buildBarChartCatalogue("Datasource", "Datasource");
            }
        }

        private void lstEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshWorkflow();
            //filterOnSelection();

        }

        private void lstRelationshipManager_SelectedIndexChanged(object sender, EventArgs e)
        {

            filterOnSelection();

        }

        private void lstTeamManager_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnSelection();
        }

        // find and retrun a control
        private System.Windows.Forms.Control FindControl(System.Windows.Forms.Control parent, string ctlName)
        {  //System.Windows.Forms.ListBox myListBox = (System.Windows.Forms.ListBox)this.Controls.Find("List", true)[0];
            foreach (System.Windows.Forms.Control ctl in parent.Controls)
            {
                Console.WriteLine(ctl.Name);
                if (ctl.Name.Equals(ctlName))
                {
                    return ctl;
                }
                FindControl(ctl, ctlName);
            }
            return null;
        }


        //chartCategory
        private void workflowCharts()
        {
            /*
            while (chartCategory.Series.Count > 0)
            {
                chartCategory.Series.RemoveAt(0);
            }
            String seriesName = "";

            
            

            var query = from p in recordList   // individual totals
                        group p by new { p.name } into grp
                        select new
                        {
                            Preparer = grp.Key.name,
                            gvOne = grp.Sum(p => p.gv1),
                            gvTwo = grp.Sum(p => p.gv2),
                            gvThree = grp.Sum(p => p.gv3),
                            gvFour = grp.Sum(p => p.gv4),
                            gvFive = grp.Sum(p => p.gv5),
                            gvSix = grp.Sum(p => p.gv6)
                        };

            for (int i = 0; i < chlstPlatform.Items.Count; i++)          // rows
            {

                seriesName = chlstPlatform.Items[i].ToString();
                chartCategory.Series.Add(seriesName);
                chartCategory.Series[seriesName].XValueMember = dgvSummaryView.Rows[i].Cells[0].Value.ToString();

                for (int j = 1; j < dgvSummaryView.Columns.Count; j++)  // columns
                {
                    chart1.Series[seriesName].Points.AddXY(dgvSummaryView.Columns[j].HeaderText, dgvSummaryView.Rows[i].Cells[j].Value.ToString());
                    chart1.Series[seriesName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedArea;

                }
                chart1.Series[seriesName].Label = "#VALY";
            }   */
        }

        // Build stacked area chart from data
        private void buildAreaChart()
        {

            while (chart1.Series.Count > 0)
            {
                chart1.Series.RemoveAt(0);
            }
            String seriesName = "";

            for (int i = 0; i < dgvSummaryView.Rows.Count - 1; i++)          // rows
            {
                seriesName = dgvSummaryView.Rows[i].Cells[0].Value.ToString();
                chart1.Series.Add(seriesName);
                chart1.Series[seriesName].XValueMember = dgvSummaryView.Rows[i].Cells[0].Value.ToString();

                for (int j = 1; j < dgvSummaryView.Columns.Count; j++)  // columns
                {
                    chart1.Series[seriesName].Points.AddXY(dgvSummaryView.Columns[j].HeaderText, dgvSummaryView.Rows[i].Cells[j].Value.ToString());
                    chart1.Series[seriesName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StackedArea;

                }
                chart1.Series[seriesName].Label = "#VALY";
                chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
            }
        }

        private void buildBarChartCatalogue(String seriesName, String graphTitle)
        {
            while (chart1.Series.Count > 0)
            {
                chart1.Series.RemoveAt(0);
            }
            while (chart1.Titles.Count > 0)
            {
                chart1.Titles.RemoveAt(0);
            }


            chart1.Series.Add(seriesName);
            chart1.Series[seriesName].IsVisibleInLegend = false;
            chart1.Series[seriesName].ChartType = SeriesChartType.Column;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.Series[seriesName].Label = "#VALY";
            Title agingTitle = new Title();
            agingTitle.Text = graphTitle;
            chart1.Titles.Add(agingTitle);

            chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chart1.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chart1.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            for (int n = 0; n < dgvSummaryView.Rows.Count - 1; n++)
            {
                chart1.Series[seriesName].Points.AddXY(dgvSummaryView.Rows[n].Cells[0].Value.ToString(), dgvSummaryView.Rows[n].Cells[1].Value);
            }
            // rescale chart after selections are made each time
            chart1.ChartAreas[0].RecalculateAxesScale();

        }

        private void chlstPlatform_SelectedIndexChanged(object sender, EventArgs e)
        {
            refreshWorkflow();
            //filterOnSelection();  
            // populateWorflowCharts();
        }

        private void lstCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            //filterOnSelection();
            //   buildAreaChart();
            //  populateWorflowCharts();

            refreshWorkflow();
        }

        private void lstStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            // filterOnSelection();
            // buildAreaChart();
            // populateWorflowCharts();
            refreshWorkflow();
        }




        System.Data.DataTable data1, data2, data3, data4, myData;
        private void addErrorsAndReruns()
        {

            data1 = (System.Data.DataTable)(dgvResourcingWorkflow.DataSource);
            data2 = (System.Data.DataTable)(dgvRAActive.DataSource);
            data3 = (System.Data.DataTable)(dgvETActive.DataSource);

            data4 = new System.Data.DataTable();
            data4.Merge(data3);
            data4.Merge(data2);
            data4.Merge(data1);
            DataView dv = data4.DefaultView;

            // data4.Merge();
            // data3.Merge(data1);
            //   data3.Merge(data2);
            // dgvMerged.DataSource = data4;

            //  BindingSource source = new BindingSource();
            //  source.DataSource = data4;

            //   dgvResourcingWorkflow.DataSource = null;
            dgvResourcingWorkflow.DataSource = data4;
            myData = data1.Copy();

        }

        private void removeErrorsAndReruns()
        {
            dgvResourcingWorkflow.DataSource = myData;
        }

        // Filter based on the date range selected
        private void btnFilter_Click(object sender, EventArgs e)
        {
            filterOnSelection();
            populateWorflowCharts();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            FindControl(tbpgResourcingWorkflow, "chartPlatform");
        }

        bool dgvResourcingExpandView = false;
        private void dgvResourcing_DoubleClick(object sender, EventArgs e)
        {
            if (!dgvResourcingExpandView)
            {
                dgvResourcing.Height = 538;
                dgvResourcingExpandView = true;
                dgvResourcing.BringToFront();
            }
            else
            {
                dgvResourcing.Height = 324;
                dgvResourcingExpandView = false;
            }


        }

        // writer team members names to a text file
        private void saveTeamMembers()
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MyTeam.txt"))
            {
                String strItem = "";
                if (lstEmployees.SelectedItems.Count == 0)
                {
                    MessageBox.Show("You need to select team members in the list below");
                    return;
                }
                foreach (var item in lstEmployees.SelectedItems)
                {
                    strItem = item.ToString();
                    file.WriteLine(strItem);
                }
            }
            MessageBox.Show("Your team members have been saved. Check 'Load team' any time to filter your team on the list");
        }

        List<string> myFilterList;
        private void btnLoadDefaultSettings_Click(object sender, EventArgs e)
        {
            if (cmbSavedFilters.Items.Contains(txtFilterName.Text))
            {
                MessageBox.Show("You cannot add a duplicate filter name. Please try another name.");
            }
            else if (txtFilterName.Text.Equals("") || txtFilterName.Text == null)
            {
                MessageBox.Show("Please provide a valid filter name. Click on + button and enter new filter name in the textbox.");
            }
            else if (txtFilterName.Text.Equals("<TEAM>"))
            {
                saveTeamMembers();
                cmbSavedFilters.Items.Add(txtFilterName.Text);
                positionAndResizeFilterBox(false);
            }
            else
            {
                /* myFilterList = new List<string>();
                 string[] controlNames = {"lstGvDays", "lstEmployees", "lstFrequency", "chlstPlatform", 
                 "lstReportStatus", "lstRelationshipManager","lstTeamManager", "lstDataSource", "lstDeploymentTool", "lstCategory", "lstStatus"};
                 iterateListboxes(controlNames, this, "Data"); */
                saveDefaultSettings(false);
                cmbSavedFilters.Items.Add(txtFilterName.Text);
                MessageBox.Show("Your default settings have been saved. You can select your filter from the drop down menu.");
                positionAndResizeFilterBox(false);
            }
        }

        // Identify what is selected in each of the listbox listed in the controlNames array and add result to the myFilterList, 
        // which is written to a text file for permanent storage via saveDefaultSettings method
        int counterListBox = 0;
        private void iterateListboxes(string[] controlNames, System.Windows.Forms.Control parent, string controlName, bool updateReport)
        {
            System.Windows.Forms.ListBox myListBox = new System.Windows.Forms.ListBox();
            string strItem = "";
            foreach (System.Windows.Forms.Control c in parent.Controls)
            {
                if (controlNames.Contains(c.Name))
                {
                    myListBox = (System.Windows.Forms.ListBox)c;
                    foreach (var item in myListBox.SelectedItems)
                    {
                        if (!updateReport)  // if boolean updateReport is false, meaning it's a new report, then save filter with the name provided in txtFilterName
                        {
                            strItem = txtFilterName.Text + "|" + myListBox.Name + "|" + item.ToString();
                            myFilterList.Add(strItem);
                        }
                        else              // case for updating filter. Filter name already exists, so reuse the same filter name selected in the combobox
                        {
                            strItem = cmbSavedFilters.SelectedItem.ToString() + "|" + myListBox.Name + "|" + item.ToString();
                            myFilterList.Add(strItem);
                        }
                    }
                }
                else if (counterListBox > 900) // exit after 300 iterations to prevet stack overflow 
                {
                    return;
                }
                else
                {
                    iterateListboxes(controlNames, c, controlName, updateReport); // recursive call until we find the control name
                    counterListBox++;
                }
            }
        }

        // overwrite file storing custom filters
        private void overwriteDefaultSettings(ref List<string> myList)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\DefaultSettings.txt"))
            {
                foreach (string item in myList)
                {
                    file.WriteLine(item);
                }
            }
        }

        // append lines to file storing custom filters from each listbox
        // parameter updateReport indicates whether it's an update or a new filter for the  iterateListboxes recursive method
        private void saveDefaultSettings(bool updateReport)
        {
            myFilterList = new List<string>();
            string[] controlNames = {"lstGvDays", "lstEmployees", "lstFrequency", "chlstPlatform", 
                                     "lstReportStatus", "lstRelationshipManager","lstTeamManager", "lstDataSource", "lstDeploymentTool", "lstCategory", "lstStatus"};
            iterateListboxes(controlNames, this, "Data", updateReport);

            using (System.IO.StreamWriter file = File.AppendText(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\DefaultSettings.txt"))
            {
                foreach (string item in myFilterList)
                {
                    file.WriteLine(item);
                }
            }
        }

        private void btnBuildTeam_Click(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MyTeam.txt"))
            {
                String strItem = "";
                if (lstEmployees.SelectedItems.Count == 0)
                {
                    MessageBox.Show("You need to select team members in the list below");
                    return;
                }
                foreach (var item in lstEmployees.SelectedItems)
                {
                    strItem = item.ToString();
                    file.WriteLine(strItem);
                }
            }
            MessageBox.Show("Your team members have been saved. Check 'Load team' any time to filter your team on the list");
        }

        // Select everyone
        /*    private void chSelectAll_CheckedChanged(object sender, EventArgs e)
            {
                System.Windows.Forms.ListBox[] myListBoxArray = {lstEmployees, lstRelationshipManager, chlstPlatform, lstReportStatus, lstFrequency, lstGvDays,
                                                                  lstDeploymentTool, lstDataSource, lstTeamManager, lstCategory, lstStatus }; // can't add listboxes from another tab
         

                this.Cursor = Cursors.AppStarting;
                tsslStatus.Visible = true;
                tsslStatus.Text = "Loading Settings...";
                if (chSelectAll.Checked)
                {
                   // chSelectTeam.Checked = false;
                   // chkDefaultSettings.Checked = false;
                    clearListBoxSelection(ref myListBoxArray);
                    selectFromFilter();
                }
                this.Cursor = Cursors.Default;
                tsslStatus.Text = "";
            } */
        // Select team members
        /* private void chSelectTeam_CheckedChanged(object sender, EventArgs e)
         {
             System.Windows.Forms.ListBox[] myListBoxArray = {lstEmployees, lstRelationshipManager, chlstPlatform, lstReportStatus, lstFrequency, lstGvDays,
                                                               lstDeploymentTool, lstDataSource, lstTeamManager, lstCategory, lstStatus }; // can't add listboxes from another tab
         
             this.Cursor = Cursors.AppStarting;
             tsslStatus.Visible = true;
             tsslStatus.Text = "Loading Settings...";
             if (chSelectTeam.Checked)
             {
                 chSelectAll.Checked = false;
                 chkDefaultSettings.Checked = false;
                 clearListBoxSelection(ref myListBoxArray);
                 selectFromFilter();
             }
             this.Cursor = Cursors.Default;
             tsslStatus.Text = "";            
         } */

        private void selectFromFilter()
        {
            if (cmbSavedFilters.SelectedItem.ToString().Equals("<TEAM>")) // when <team> filter is selected
            {
                string[] lines = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MyTeam.txt");

                lstEmployees.SelectedIndex = -1;
                foreach (string line in lines)
                {
                    int index = lstEmployees.FindString(line, -1);
                    if (index != -1)
                    {
                        // Select the found item:
                        lstEmployees.SetSelected(index, true);
                    }
                }
            }
            else if (cmbSavedFilters.SelectedItem.ToString().Equals("<ALL>"))  // when all employees are selected
            {
                for (int i = 0; i < lstEmployees.Items.Count; i++)
                {
                    if (lstEmployees.Items[i].ToString() == "<ALL>")
                    {
                        lstEmployees.SetSelected(i, true);
                        break;
                    }
                }
            }

            // listbox array to efficiently loop through all remaining listboxes
            System.Windows.Forms.ListBox[] myListBoxArray = { chlstPlatform, lstReportStatus, lstFrequency, lstGvDays,
                                                              lstDeploymentTool, lstDataSource, lstTeamManager, lstCategory, lstStatus}; // can't add listboxes from another tab

            for (int i = 0; i < lstRelationshipManager.Items.Count; i++)
            {
                lstRelationshipManager.SetSelected(i, true);
            }


            // select all items on the list 
            foreach (System.Windows.Forms.ListBox lst in myListBoxArray)
            {
                for (int i = 0; i < lst.Items.Count; i++)
                {
                    if (lst.Items[i].ToString() == "<ALL>")
                    {
                        lst.SetSelected(i, true);
                        break;
                    }
                    lst.SetSelected(i, true);
                }
            }



        }


        bool dgvSummaryViewExpandView = false;
        private void dgvSummaryView_DoubleClick(object sender, EventArgs e)
        {
            if (!dgvSummaryViewExpandView)
            {
                dgvSummaryView.Location = new System.Drawing.Point(265, 16);
                dgvSummaryView.BringToFront();
                dgvSummaryView.Height = 538;
                dgvSummaryViewExpandView = true;
            }
            else
            {
                dgvSummaryView.Location = new System.Drawing.Point(265, 374);
                dgvSummaryView.Height = 180;
                dgvSummaryViewExpandView = false;
            }
        }



        bool lstEmployeesChartExpandedView = false;
        private void chart1_DoubleClick(object sender, EventArgs e)
        {
            if (!lstEmployeesChartExpandedView)
            {
                chart1.Location = new System.Drawing.Point(263, 8);
                chart1.BringToFront();
                chart1.Height = 808;
                lstEmployeesChartExpandedView = true;
            }
            else
            {
                chart1.Location = new System.Drawing.Point(265, 586);
                chart1.Height = 262;
                chart1.Width = 1531;
                lstEmployeesChartExpandedView = false;
            }
        }

        // Load Rollover dashboard (Excel) to the rool
        bool lstRolloverListboxPopulated = false;
        private void btnLoadRollover_Click(object sender, EventArgs e)
        {
            if (txtRolloverPath.Text == null || txtRolloverPath.Text.Equals(""))
            {
                MessageBox.Show("Please specify filepath in the input box on the right");
            }
            else
            {
                chklstRolloverFields.Items.Clear();
                loadSpreadsheet("Rollover.xlsx", txtRolloverPath, "Dashboard", "A5", 5, 5, chklstRolloverFields, dgvRolloverDashBoard);
                populateTransAnalystListBox("Primary Preparer1", ref lstRolloverAnalyst, ref dgvRolloverDashBoard, lstRolloverListboxPopulated);
                lstRolloverListboxPopulated = true;
                formatRolloverDataGrid();
            }

        }

        private void formatRolloverDataGrid()
        {
            // first set color for the font to balack
            double myDouble = 0.00;
            string[] myString = new String[5];
            string[] myPercentFieldList = { "% of Reports Rolled Over8", "% of Documentation Completed7", "% of Reports with Control Check9", "% of Documentation Validated15", "% of Report Backup can Run16" };

            foreach (DataGridViewRow row in dgvRolloverDashBoard.Rows)
            {
                // convert  values in some fields as percentages
                myString[0] = row.Cells["% of Reports Rolled Over8"].Value.ToString();
                myString[1] = row.Cells["% of Documentation Completed7"].Value.ToString();
                myString[2] = row.Cells["% of Reports with Control Check9"].Value.ToString();
                myString[3] = row.Cells["% of Documentation Validated15"].Value.ToString();
                myString[4] = row.Cells["% of Report Backup can Run16"].Value.ToString();

                for (int i = 0; i < myString.Length; i++)
                {
                    if (Double.TryParse(myString[i], out myDouble))
                    {
                        row.Cells[myPercentFieldList[i]].Value = myDouble.ToString("#0.##%");
                    }
                }
                row.DefaultCellStyle.ForeColor = Color.Black;
            }
            // format percentage columns and highlight percentage columns background as  light yellow
            foreach (DataGridViewColumn col in dgvRolloverDashBoard.Columns)
            {
                if (col.Name.Contains("Documentation Completed") || col.Name.Contains("Reports Rolled Over") || col.Name.Contains("% of Reports has Control Check")
                    || col.Name.Contains("Completion Date") || col.Name.Contains("Documentation Validated") || col.Name.Contains("Report Backup can Run"))
                {
                    //col.DefaultCellStyle.Format = "#.00\\%";
                    col.DefaultCellStyle.BackColor = Color.FromArgb(252, 250, 161);
                }
            }
        }


        private void loadSpreadsheet(string fileName, System.Windows.Forms.TextBox myTextBox, string workseehtName, string firstCell, int firstRow, int firstCol, CheckedListBox myCheckedListBox, DataGridView myDataGridView)
        {

            //Create COM Objects. Create a COM object for everything that is referenced         

            Excel.Application app = new Microsoft.Office.Interop.Excel.Application();

            string sourcefile = myTextBox.Text;
            string xlFilePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\" + fileName;

            if (File.Exists(xlFilePath))  // Delete file if it already exists in the destination folder
                File.Delete(xlFilePath);

            File.Copy(sourcefile, xlFilePath);

            Excel.Workbook workbook = app.Workbooks.Open(xlFilePath, ReadOnly: true);
            Excel.Worksheet worksheet = workbook.Worksheets[workseehtName];

            app.DisplayAlerts = false;
            int rcount = worksheet.UsedRange.Rows.Count;
            System.Data.DataTable dt = new System.Data.DataTable();

            Excel.Range range = null;

            long fullRow = worksheet.Rows.Count;
            long fullCol = worksheet.Columns.Count;
            int lastRow = worksheet.Cells[fullRow, firstCol].End(Excel.XlDirection.xlUp).Row;
            int lastCol = worksheet.Cells[firstRow, fullCol].End(Excel.XlDirection.xlToLeft).Column;
            string rangeLast = worksheet.Cells[lastRow, lastCol].Address;

            Debug.Print(lastRow + " " + lastCol);
            range = worksheet.get_Range(firstCell, rangeLast);
            object[,] x = (object[,])range.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);
            string fieldName = "";

            for (int n = 1; n <= lastCol; n++)
            {
                if (worksheet.Cells[firstRow, n].Value != null && worksheet.Cells[firstRow, n].Value != "")
                {

                    if (fileName == "Rollover.xlsx")
                    {
                        fieldName = worksheet.Cells[firstRow, n].Value + n;
                    }
                    else
                    {
                        fieldName = worksheet.Cells[firstRow, n].Value;
                    }
                    dt.Columns.Add(fieldName);
                    myCheckedListBox.Items.Add(fieldName);
                    //Console.WriteLine(fieldName);  
                }
            }
            // setting field checkboxes to checked state
            for (int i = 0; i < myCheckedListBox.Items.Count; i++)
            {
                myCheckedListBox.SetItemCheckState(i, CheckState.Checked);
            }

            // populating datagrid view with the data from Excel
            for (int i = 2; i <= lastRow - firstRow; i++)
            {
                DataRow drNew = dt.NewRow();
                for (int j = 1; j < lastCol - 1; j++)
                {
                    drNew[j - 1] = x[i, j];
                }
                dt.Rows.Add(drNew);
            }

            myDataGridView.DataSource = dt;

            GC.Collect();
            GC.WaitForPendingFinalizers();
            app.Quit();
            Marshal.ReleaseComObject(app);

            //File.Delete(xlFilePath);          
            MessageBox.Show("Report loaded!");
        }
        bool lstTransitionAnalystPopulated = false;
        private void btnLoadTransitionSpreadsheet_Click_1(object sender, EventArgs e)
        {
            if (txtTransitionPath.Text == null || txtTransitionPath.Text.Equals(""))
            {
                MessageBox.Show("Please specify filepath in the input box on the right");
            }
            else
            {
                chklstTransitionFields.Items.Clear();
                loadSpreadsheet("Transitions.xlsm", txtTransitionPath, "Template", "A2", 1, 2, chklstTransitionFields, dgvTransitions);
                populateTransAnalystListBox("Report Transition Analyst (from workflow)", ref lstTransitionAnalyst, ref dgvTransitions, lstTransitionAnalystPopulated);
                lstTransitionAnalystPopulated = true;
                changeTransitionIndicatorFormatting(); // Format transition indicator in the datagrid view   
            }
        }

        // change formatting of the transition indicator in the Transition datagird view
        private void changeTransitionIndicatorFormatting()
        {
            int lastRow = dgvTransitions.RowCount;
            // Format dataGridView to show colored status indicators as requested by Yemi 
            string statusName = "";
            char buttonCharacter;
            dgvTransitions.Columns["Trending Indicator"].DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 16);
            for (int i = 0; i <= lastRow - 1; i++)
            {
                buttonCharacter = (char)9679;
                statusName = Convert.ToString(dgvTransitions.Rows[i].Cells["Transition Status"].Value);

                switch (statusName)
                {
                    case "Completed":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Black;
                        break;
                    case "Cancelled":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Red;
                        break;
                    case "NotStarted-Yellow":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Yellow;
                        break;
                    case "InProgress":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Green;
                        break;
                    case "IncompleteRequirements-Yellow":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Yellow;
                        break;
                    case "OwnerNotAvailable-Yellow":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Yellow;
                        break;
                    case "SMENotAvailabel-Yellow":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Yellow;
                        break;
                    case "IncompleteRequirements-Red":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Red;
                        break;
                    case "OwnerNotAvailable-Red":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Red;
                        break;
                    case "SMENotAvailabel-Red":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Red;
                        break;
                    case "NotStarted-Green":
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = buttonCharacter.ToString();
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Style.ForeColor = Color.Green;
                        break;
                    default:
                        dgvTransitions.Rows[i].Cells["Trending Indicator"].Value = "";
                        break;
                }
            }
        }

        private void lstTransitionAnalyst_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnTransitionAnalyst();
            changeTransitionIndicatorFormatting(); // Format transition indicator in the datagrid view
        }



        // Expanding chart areas in the Workflow worksheet
        bool lstCategoryExpandedView = false;
        private void chartCategory_DoubleClick(object sender, EventArgs e)
        {
            if (!lstCategoryExpandedView)
            {
                if (!chartStatusExpandedView && !chartPlatformExpandedView)
                {
                    chartCategory.Location = new System.Drawing.Point(271, 6);
                    chartCategory.BringToFront();
                    chartCategory.Height = 458;
                    chartCategory.Width = 1505;
                    lstCategoryExpandedView = true;
                    dgvResourcingWorkflow.Location = new System.Drawing.Point(6, 516);
                    dgvResourcingWorkflow.Height = 334;
                    dgvResourcingWorkflow.Width = 592;
                }

            }
            else
            {
                chartCategory.Location = new System.Drawing.Point(6, 516);
                chartCategory.Height = 334;
                chartCategory.Width = 592;
                lstCategoryExpandedView = false;

                dgvResourcingWorkflow.Location = new System.Drawing.Point(271, 6);
                dgvResourcingWorkflow.Height = 458;
                dgvResourcingWorkflow.Width = 1505;
            }
        }


        bool chartStatusExpandedView = false;
        private void chartStatus_DoubleClick(object sender, EventArgs e)
        {

            if (!chartStatusExpandedView) // maximize
            {
                if (!lstCategoryExpandedView && !chartPlatformExpandedView)
                {
                    chartStatus.Location = new System.Drawing.Point(271, 6);
                    chartStatus.BringToFront();
                    chartStatus.Height = 458;
                    chartStatus.Width = 1505;

                    chartStatusExpandedView = true;

                    dgvResourcingWorkflow.Location = new System.Drawing.Point(604, 491);
                    dgvResourcingWorkflow.Height = 359;
                    dgvResourcingWorkflow.Width = 671;
                }
            }
            else  // minimize
            {
                chartStatus.Location = new System.Drawing.Point(604, 491);
                chartStatus.Height = 359;
                chartStatus.Width = 671;

                chartStatusExpandedView = false;

                dgvResourcingWorkflow.Location = new System.Drawing.Point(271, 6);
                dgvResourcingWorkflow.Height = 458;
                dgvResourcingWorkflow.Width = 1505;
            }
        }


        bool chartPlatformExpandedView = false;
        private void chartPlatform_DoubleClick(object sender, EventArgs e)
        {
            if (!chartPlatformExpandedView)
            {
                if (!chartStatusExpandedView && !chartPlatformExpandedView)
                {
                    chartPlatform.Location = new System.Drawing.Point(271, 6);
                    chartPlatform.BringToFront();
                    chartPlatform.Height = 458;
                    chartPlatform.Width = 1505;

                    chartPlatformExpandedView = true;

                    dgvResourcingWorkflow.Location = new System.Drawing.Point(1279, 491);
                    dgvResourcingWorkflow.Height = 359;
                    dgvResourcingWorkflow.Width = 497;
                }

            }
            else
            {
                chartPlatform.Location = new System.Drawing.Point(1279, 491);
                chartPlatform.Height = 359;
                chartPlatform.Width = 497;

                chartPlatformExpandedView = false;

                dgvResourcingWorkflow.Location = new System.Drawing.Point(271, 6);
                dgvResourcingWorkflow.Height = 458;
                dgvResourcingWorkflow.Width = 1505;
            }
        }

        private void rbProcessTime_CheckedChanged(object sender, EventArgs e)
        {
            if (rbProcessTime.Checked)
            {
                populateSummaryGrid();
                // buildAreaChart();
            }

        }

        private void rbRptCount_CheckedChanged(object sender, EventArgs e)
        {
            if (rbRptCount.Checked)
            {
                populateSummaryGrid();
                //  buildAreaChart();
            }
        }

        private void rbSetupTime_CheckedChanged(object sender, EventArgs e)
        {
            if (rbSetupTime.Checked)
            {
                populateSummaryGrid();
                // buildAreaChart();
            }
        }


        private void rbDeploymentTools_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDeploymentTools.Checked)
            {

                populateSummaryGrid();
                buildBarChartCatalogue("Deployment Tool", "Deployment tool");
            }
        }

        private void rbDataSource_CheckedChanged(object sender, EventArgs e)
        {
            if (rbDataSource.Checked)
            {
                populateSummaryGrid();
                buildBarChartCatalogue("Datasource", "Datasource");
            }
        }

        // create additional columns 
        public void createWorkflowAdditionalFields()
        {

            Double localOffset = Convert.ToDouble(DateTime.UtcNow.Hour) - Convert.ToDouble(DateTime.Now.Hour);
            // Expressing all time in the local Time         
            Double timeAdjustment = 4 - localOffset;
            // Double timeAdjustment = 4;
            //MessageBox.Show(timeAdjustment + ""); - Check in Toronto
            // Double acknowledgeTimeLimit = 3.00;
            // Double acknowledgeTimeLimit = Convert.ToDouble(cmbAcknowledgementSLA.Value);
            TimeSpan limit;
            //TimeSpan limitOther;

            // overdue acknowledgement buckets
            TimeSpan bucket0 = new TimeSpan(0, 0, 0);
            TimeSpan bucket1 = new TimeSpan(1, 0, 0);
            TimeSpan bucket2 = new TimeSpan(2, 0, 0);
            TimeSpan bucket3 = new TimeSpan(5, 0, 0);
            TimeSpan bucket4 = new TimeSpan(24, 0, 0);

            // date/time variables used when ticket is created outside of normal working hours
            TimeSpan timeLeftToAcknowledge;
            DateTime adjustedCreationDate;
            DateTime originalCreationDate;
            DateTime tempCreationDate;

            TimeSpan endOfDay = new TimeSpan(17, 00, 0); // end of day hours - factor location into account. Toronto - 17:00, Halifax: 4:00 PM Toronto time etc
            TimeSpan startOfDay = new TimeSpan(8, 30, 0); // beginning of day - factor location into account. Toronto - 17:00, Halifax: 4:00 PM Toronto time etc
            // Debug.Print(endOfDay + "");
            //Debug.Print(startOfDay + "");

            int daysToAdd;

            TimeSpan acknowledgeDiff;

            if (!fieldsCreated)  // ensure thatadditional fields are created only once after KPI calc button is clicked for the first time
            {
                dgvKPI.Columns.Add("Days Left", "Days Left");
                dgvKPI.Columns.Add("Days Report Outstanding", "Days Report Outstanding");
                dgvKPI.Columns.Add("Acknowledgement overdue by", "Acknowledgement overdue by");
                dgvKPI.Columns.Add("Acknowledgement overdue bucket", "Acknowledgement overdue bucket");
                dgvKPI.Columns.Add("Ticket Creation2", "Ticket Creation2");
                dgvKPI.Columns.Add("Adj Creation Date", "Adj Creation Date");
                dgvKPI.Columns.Add("RevisedCrDate", "RevisedCrDate");

            }



            dgvKPI.AllowUserToOrderColumns = true;
            // request acknowledgement SLA - by default 4 hrs.

            // limitOther = new TimeSpan(Convert.ToInt32(cmbAcknowledgementOtherSLA.Value), 0, 0); // acknowledgement for errors etc. -2 hrs
            // CALCULATE overdue acknowledgement overdue, aging and days outstanding
            for (int i = 0; i < dgvKPI.RowCount; i++)
            {
                // ACKNOWLEDGEMENT TIME OVERDUE CALCULATION
                if (dgvKPI.Rows[i].Cells["Request Type"].Value.Equals("Report rerun") || dgvKPI.Rows[i].Cells["Request Type"].Value.Equals("Report errors"))
                {
                    limit = new TimeSpan(Convert.ToInt32(cmbAcknowledgementOtherSLA.Value), 0, 0); // acknowledgement for errors etc. -2 hrs
                    //  dgvKPI.Rows[i].Cells["Ticket Creation2"].Value = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Created"].Value).AddHours(timeAdjustment);
                    dgvKPI.Rows[i].Cells["Ticket Creation2"].Value = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Created"].Value).AddHours(timeAdjustment);

                }
                else
                {
                    limit = new TimeSpan(Convert.ToInt32(cmbAcknowledgementSLA.Value), 0, 0);
                    dgvKPI.Rows[i].Cells["Ticket Creation2"].Value = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Created"].Value).AddHours(timeAdjustment); ;
                }


                // Calculate aging - number of days report is outstanding
                if (dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Completed" && dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Resolved"
                            && dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Declined" && dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Cancelled")
                {
                    TimeSpan aging = DateTime.Today.Date - Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Creation2"].Value.ToString()).Date;
                    // TimeSpan aging = DateTime.Today.Date - Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Created"].Value.ToString()).Date;
                    dgvKPI.Rows[i].Cells["Days Report Outstanding"].Value = aging.TotalDays;
                }

                // Calculate days left statistics as due date - today. 
                if (dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Completed" && dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Resolved"
                            && dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Declined" && dgvKPI.Rows[i].Cells["Status"].Value.ToString() != "Cancelled")
                {
                    TimeSpan daysLeft = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Due Date"].Value.ToString()).Date - DateTime.Today.Date;
                    dgvKPI.Rows[i].Cells["Days Left"].Value = daysLeft.TotalDays;
                }


                originalCreationDate = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Creation2"].Value.ToString());



                // calculate different acknowledgement date to creation date variance based on whether ticket was created on the weekend or during non-working hours

                // if request comes on the weekend  - any time during the day
                if (originalCreationDate.DayOfWeek == DayOfWeek.Saturday || originalCreationDate.DayOfWeek == DayOfWeek.Sunday)
                {
                    daysToAdd = originalCreationDate.DayOfWeek == DayOfWeek.Saturday ? 2 : 1;
                    tempCreationDate = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Creation2"].Value.ToString()).AddDays(daysToAdd); // roll forward to the following business day
                    adjustedCreationDate = new DateTime(tempCreationDate.Year, tempCreationDate.Month, tempCreationDate.Day, startOfDay.Hours, startOfDay.Minutes, startOfDay.Seconds);
                }
                // if request comes during the weekday
                else
                {
                    // if request comes after working hours, allocate all SLA hours to the next working day
                    if (originalCreationDate.TimeOfDay > endOfDay)
                    {

                        // calculate the next working day - if Friday evening then it's Monday
                        daysToAdd = originalCreationDate.DayOfWeek == DayOfWeek.Friday ? 3 : 1;
                        tempCreationDate = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Creation2"].Value.ToString()).AddDays(daysToAdd); // roll forward to the following day
                        adjustedCreationDate = new DateTime(tempCreationDate.Year, tempCreationDate.Month, tempCreationDate.Day, startOfDay.Hours, startOfDay.Minutes, startOfDay.Seconds);

                    }
                    // if request comes before EOD, but less than 4 hrs before the EOD, allocate some hours to the following day
                    else if (originalCreationDate.TimeOfDay < endOfDay && (endOfDay - originalCreationDate.TimeOfDay) < limit)
                    {
                        timeLeftToAcknowledge = limit - (endOfDay - originalCreationDate.TimeOfDay);
                        // calculate the next working day - if Friday evening then it's Monday
                        daysToAdd = originalCreationDate.DayOfWeek == DayOfWeek.Friday ? 3 : 1;
                        tempCreationDate = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Creation2"].Value.ToString()).AddDays(daysToAdd); // roll forward to the following day                       
                        adjustedCreationDate = new DateTime(tempCreationDate.Year, tempCreationDate.Month, tempCreationDate.Day, startOfDay.Hours, startOfDay.Minutes, startOfDay.Seconds);
                        limit = timeLeftToAcknowledge;
                    }
                    // if request comes early in the monring (before 8:30 AM)
                    else if (originalCreationDate.TimeOfDay < startOfDay)
                    {
                        tempCreationDate = Convert.ToDateTime(dgvKPI.Rows[i].Cells["Ticket Creation2"].Value.ToString()); // roll forward to the following day
                        adjustedCreationDate = new DateTime(tempCreationDate.Year, tempCreationDate.Month, tempCreationDate.Day, startOfDay.Hours, startOfDay.Minutes, startOfDay.Seconds);
                    }
                    else // in all other cases, leave creation date as is. Other cases represent regular hours during regular days
                    {
                        adjustedCreationDate = originalCreationDate;
                    }
                }
                dgvKPI.Rows[i].Cells["Adj Creation Date"].Value = adjustedCreationDate;



                // calculate variance between acknowledgement date/time and adjusted request creation time
                // Case1: Ticket not acknowledged yet - subtract ticket creation time from current time
                if (dgvKPI.Rows[i].Cells["Acknowledgement Date"].Value.ToString() == null || dgvKPI.Rows[i].Cells["Acknowledgement Date"].Value.ToString() == "")
                {
                    //acknowledgeDiff = ((Convert.ToDateTime("01/01/2000") - (adjustedCreationDate + limit)));
                    acknowledgeDiff = ((DateTime.Now - (adjustedCreationDate + limit)));
                    dgvKPI.Rows[i].Cells["RevisedCrDate"].Value = (adjustedCreationDate + limit);
                    Debug.Print(DateTime.Now + "");
                }
                // Case2: Ticket acknowledged
                else
                {
                    acknowledgeDiff = ((Convert.ToDateTime(dgvKPI.Rows[i].Cells["Acknowledgement Date"].Value.ToString()) - (adjustedCreationDate + limit)));
                    dgvKPI.Rows[i].Cells["RevisedCrDate"].Value = (adjustedCreationDate + limit);
                }


                // calculation of overdue acknowledgement
                if (acknowledgeDiff > bucket0) // determine if acknowledgement is overdue or not
                {
                    dgvKPI.Rows[i].Cells["Acknowledgement overdue by"].Value = acknowledgeDiff;

                    // categorizing overdue time by buckets
                    if (acknowledgeDiff > bucket0 && acknowledgeDiff < bucket1)
                    {
                        dgvKPI.Rows[i].Cells["Acknowledgement overdue bucket"].Value = "< 1 hr";
                    }
                    else if (acknowledgeDiff > bucket1 && acknowledgeDiff < bucket2)
                    {
                        dgvKPI.Rows[i].Cells["Acknowledgement overdue bucket"].Value = "1-2 hrs";
                    }
                    else if (acknowledgeDiff > bucket2 && acknowledgeDiff < bucket3)
                    {
                        dgvKPI.Rows[i].Cells["Acknowledgement overdue bucket"].Value = "2-5 hrs";
                    }
                    else if (acknowledgeDiff > bucket3 && acknowledgeDiff < bucket4)
                    {
                        dgvKPI.Rows[i].Cells["Acknowledgement overdue bucket"].Value = "5-24 hrs";
                    }
                    else if (acknowledgeDiff > bucket4)
                    {
                        dgvKPI.Rows[i].Cells["Acknowledgement overdue bucket"].Value = "> 24 hrs";
                    }
                }
                else
                {
                    dgvKPI.Rows[i].Cells["Acknowledgement overdue by"].Value = bucket0;
                }

            }

        }
        // create datatable from the KPI datagrid so that datasource of the dgvKPI has new columns that were added only to the datagridview
        private void updateKPIDataSource()
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.DataTable dt2 = new System.Data.DataTable();

            foreach (DataGridViewColumn col in dgvKPI.Columns)
            {
                dt.Columns.Add(col.HeaderText);
            }

            foreach (DataGridViewRow row in dgvKPI.Rows)
            {
                DataRow dRow = dt.NewRow();
                foreach (DataGridViewCell cell in row.Cells)
                {
                    dRow[cell.ColumnIndex] = cell.Value;
                }
                dt.Rows.Add(dRow);
            }

            dgvTest.DataSource = dt;
            dgvTest.Refresh();
            dgvTest.Update();

            string[] hiddenColArray = {"Report Name", "Relationship Manager", 
                                          "Finance Group", "Ticket Creation2",  "Adj Creation Date", "ListItemID", "Acknowledgement Overdue BY", "RevisedCrDate" };

            hideFieldsInTable(hiddenColArray, this, "dgvTest");
        }

        // recursive method that finds datagrid view control on the form and hides specified fields
        int counter = 0;
        private void hideFieldsInTable(string[] fieldNames, System.Windows.Forms.Control parent, string controlName)
        {
            DataGridView myGrid = null;
            foreach (System.Windows.Forms.Control c in parent.Controls)
            {

                if (c.Name == controlName)
                {
                    myGrid = (DataGridView)c;
                    foreach (string col in fieldNames)
                    {
                        myGrid.Columns[col].Visible = false;
                    }
                }
                else if (counter > 300) // exit after 200 iterations to prevet stack overflow error
                {
                    return;
                }
                else
                {
                    hideFieldsInTable(fieldNames, c, controlName); // recursive call until we find the control name
                    counter++;
                }

            }
        }

        // Update KPI text boxes on the KPI tab
        private void updateKPITextBoxes()
        {
            int totalWorkflow = dgvTest.Rows.Count;
            txtTotalItems.Text = totalWorkflow.ToString();
            txtTotalItems.ForeColor = Color.Green;
            txtTotalItems.Font = new System.Drawing.Font(txtTotalItems.Font.FontFamily, 30);

            // int totalWorkflow = dgvKPI.Rows.Count;
            txtOverdueAcknowledge.ForeColor = Color.Red;
            txtOverdueAcknowledge.Font = new System.Drawing.Font(txtOverdueAcknowledge.Font.FontFamily, 30);


            int numberOfOverdue = 0;
            for (int i = 0; i < totalWorkflow; i++)
            {
                if (dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value != null && dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value.ToString() != "")
                {
                    numberOfOverdue++;
                }
            }
            txtOverdueAcknowledge.Text = numberOfOverdue.ToString();

            tsslNoOfItems.Text = dgvTest.Rows.Count.ToString(); // update number of items on the KPI tab
        }

        // Event triggered by the button CaclKPI click
        private void btn_CalcKPI_Click(object sender, EventArgs e)
        {
            refreshKpi();
        }

        bool fieldsCreated = false; // flag that ensures that additional fields are created only once to avoind duplicate fields
        private void refreshKpi()
        {
            dgvKPI.DataSource = dgvResourcingWorkflow.DataSource;
            createWorkflowAdditionalFields();
            fieldsCreated = true;

            updateKPIDataSource(); // copy data from dgvKPI into dgvTest - temporary fix as dgvKPI wasn't filtering properly.
            buildOverdueAcknowledgementChart();
            buildDaysLeftAgingCharts();
            updateKPITextBoxes();
            filterOnOverdueAcknowledgement();
        }

        bool KPIchartsTitlesCreated = false;
        private void buildDaysLeftAgingCharts()
        {
            int rowCount = dgvTest.RowCount; // count records for Application catalog
            int i = 0;

            List<dgvRecord> DaysLeftList = new List<dgvRecord>(); // list of days left
            List<dgvRecord> reportAgingList = new List<dgvRecord>(); // list of report aging
            int daysLeftBucket;
            string daysLeftStr = "";

            int daysOutstandingBucket;
            string daysOutstandingBucketStr = "";

            string sortOrderDaysLeft;
            while (i < rowCount)
            {   // days left
                if (dgvTest.Rows[i].Cells["Days Left"].Value != null && dgvTest.Rows[i].Cells["Days Left"].Value.ToString() != "")
                {
                    daysLeftBucket = Convert.ToInt32(dgvTest.Rows[i].Cells["Days Left"].Value.ToString());
                    if (daysLeftBucket == 0)
                    {
                        daysLeftStr = "0";
                        sortOrderDaysLeft = "4";
                    }
                    else if (daysLeftBucket > 0 && daysLeftBucket <= 3)
                    {
                        daysLeftStr = "1 to 3";
                        sortOrderDaysLeft = "3";
                    }
                    else if (daysLeftBucket > 3 && daysLeftBucket <= 10)
                    {
                        daysLeftStr = "3 to 10";
                        sortOrderDaysLeft = "2";
                    }
                    else if (daysLeftBucket > 10)
                    {
                        daysLeftStr = "> 10";
                        sortOrderDaysLeft = "1";
                    }
                    else
                    {
                        daysLeftStr = "< 0";
                        sortOrderDaysLeft = "5";
                    }
                    DaysLeftList.Add(new dgvRecord(i, dgvTest.Rows[i].Cells["AssignedTo"].Value.ToString(), daysLeftStr,
                          Convert.ToString(daysLeftBucket), sortOrderDaysLeft, "0", "0"));
                }
                // days outstanding
                string sortOrderOutstanding;
                if (dgvTest.Rows[i].Cells["Days Report Outstanding"].Value != null && dgvTest.Rows[i].Cells["Days Report Outstanding"].Value.ToString() != "")
                {
                    daysOutstandingBucket = Convert.ToInt32(dgvTest.Rows[i].Cells["Days Report Outstanding"].Value.ToString());

                    if (daysOutstandingBucket >= 0 && daysOutstandingBucket <= 10)
                    {
                        daysOutstandingBucketStr = "0 to 10";
                        sortOrderOutstanding = "6";
                    }
                    else if (daysOutstandingBucket > 10 && daysOutstandingBucket <= 20)
                    {
                        daysOutstandingBucketStr = "10 to 20";
                        sortOrderOutstanding = "5";
                    }
                    else if (daysOutstandingBucket > 20 && daysOutstandingBucket <= 30)
                    {
                        daysOutstandingBucketStr = "20 to 30";
                        sortOrderOutstanding = "4";
                    }
                    else if (daysOutstandingBucket > 30 && daysOutstandingBucket <= 50)
                    {
                        daysOutstandingBucketStr = "30 to 50";
                        sortOrderOutstanding = "3";
                    }
                    else if (daysOutstandingBucket > 50 && daysOutstandingBucket <= 100)
                    {
                        daysOutstandingBucketStr = "50 to 100";
                        sortOrderOutstanding = "2";
                    }
                    else
                    {
                        daysOutstandingBucketStr = "> 100";
                        sortOrderOutstanding = "1";
                    }
                    reportAgingList.Add(new dgvRecord(i, dgvTest.Rows[i].Cells["AssignedTo"].Value.ToString(), daysOutstandingBucketStr,
                          Convert.ToString(daysOutstandingBucket), sortOrderOutstanding, "0", "0"));
                }
                i++;
            }

            var query = from p in DaysLeftList
                        where p.name != "" && p.name != null
                        group p by new { p.report, p.gvTime } into grp
                        select new
                        {
                            analyst = grp.Key.report,
                            sortOrderLeftDays = grp.Key.gvTime,
                            overdueRequestCount = grp.Count()
                        };

            var query2 = from p in reportAgingList
                         where p.report != "" && p.report != null
                         group p by new { p.report, p.gvTime } into grp
                         select new
                         {
                             agingBucket = grp.Key.report,
                             sortOrderAging = grp.Key.gvTime,
                             agingBucketCount = grp.Count()
                         };

            var queryPlatform = query.OrderByDescending(p => p.sortOrderLeftDays);
            var categoryArray = queryPlatform.ToArray(); // putting status LINQ to array list so we can put it in a graph    

            var queryPlatform2 = query2.OrderByDescending(p => p.sortOrderAging); // query.OrderByDescending(p => p.);
            var categoryArray2 = queryPlatform2.ToArray(); // putting status LINQ to array list so we can put it in a graph      
            if (categoryArray2.Length > 0)
                lbNoResultsDaysLeft.Visible = false;
            else
                lbNoResultsDaysLeft.Visible = true;

            // days left chart
            while (chartDaysLeft.Series.Count > 0) // delete all series
            {
                chartDaysLeft.Series.RemoveAt(0);
            }

            while (chartDaysLeft.Titles.Count > 0)
            {
                chartDaysLeft.Titles.RemoveAt(0);
            }

            chartDaysLeft.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartDaysLeft.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartDaysLeft.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartDaysLeft.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            String seriesName = "";
            seriesName = "Days Left";
            chartDaysLeft.Series.Add(seriesName);
            chartDaysLeft.Series[seriesName].IsVisibleInLegend = false;
            chartDaysLeft.Series[seriesName].ChartType = SeriesChartType.Column;
            chartDaysLeft.ChartAreas[0].AxisX.Interval = 1;
            chartDaysLeft.Series[seriesName].Label = "#VALY";
            Title dayLeftTitle = new Title();
            dayLeftTitle.Text = "Days left before Due Date";
            chartDaysLeft.Titles.Add(dayLeftTitle);


            for (int n = 0; n < categoryArray.Length; n++)
            {
                chartDaysLeft.Series[seriesName].Points.AddXY(categoryArray[n].analyst, categoryArray[n].overdueRequestCount);
            }

            // aging
            while (chartDaysOutstanding.Series.Count > 0) // delete all series
            {
                chartDaysOutstanding.Series.RemoveAt(0);
            }

            while (chartDaysOutstanding.Titles.Count > 0)
            {
                chartDaysOutstanding.Titles.RemoveAt(0);
            }

            chartDaysOutstanding.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartDaysOutstanding.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartDaysOutstanding.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartDaysOutstanding.ChartAreas[0].AxisY.MinorGrid.Enabled = false;

            seriesName = "Report Aging";
            chartDaysOutstanding.Series.Add(seriesName);
            chartDaysOutstanding.Series[seriesName].IsVisibleInLegend = false;
            chartDaysOutstanding.Series[seriesName].ChartType = SeriesChartType.Column;
            chartDaysOutstanding.ChartAreas[0].AxisX.Interval = 1;
            chartDaysOutstanding.Series[seriesName].Label = "#VALY";
            Title agingTitle = new Title();
            agingTitle.Text = "Report Aging";
            chartDaysOutstanding.Titles.Add(agingTitle);

            if (categoryArray2.Length > 0)
                lbNoResultsDaysOutstanding.Visible = false;
            else
                lbNoResultsDaysOutstanding.Visible = true;

            for (int n = 0; n < categoryArray2.Length; n++)
            {
                chartDaysOutstanding.Series[seriesName].Points.AddXY(categoryArray2[n].agingBucket, categoryArray2[n].agingBucketCount);
            }

        }

        private void buildOverdueAcknowledgementChart()
        {
            int rowCount = dgvTest.RowCount - 1; // count records for Application catalog

            int i = 0;

            List<dgvRecord> KPIList = new List<dgvRecord>();

            while (i < rowCount)
            {
                if (dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value != null && dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value.ToString() != "")
                {
                    KPIList.Add(new dgvRecord(i, dgvTest.Rows[i].Cells["AssignedTo"].Value.ToString(), dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value.ToString(),
                         dgvTest.Rows[i].Cells["Id"].Value.ToString(), "0", "0", "0"));
                }
                i++;
            }


            var query = from p in KPIList
                        where p.name != "" && p.name != null
                        group p by new { p.name } into grp
                        select new
                        {
                            analyst = grp.Key.name,
                            overdueRequestCount = grp.Count()   //Sum(p => p.gv1), 
                        };

            var queryPlatform = query.OrderByDescending(p => p.overdueRequestCount);
            var categoryArray = queryPlatform.ToArray(); // putting status LINQ to array list so we can put it in a graph           

            while (chartAcknowledge.Series.Count > 0) // delete all series
            {
                chartAcknowledge.Series.RemoveAt(0);
            }

            while (chartAcknowledge.Titles.Count > 0)
            {
                chartAcknowledge.Titles.RemoveAt(0);
            }

            chartAcknowledge.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartAcknowledge.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartAcknowledge.ChartAreas[0].AxisX.MinorGrid.Enabled = false;
            chartAcknowledge.ChartAreas[0].AxisY.MinorGrid.Enabled = false;


            String seriesName = "";
            seriesName = "Overdue acknowledgement";
            chartAcknowledge.Series.Add(seriesName);
            chartAcknowledge.Series[seriesName].IsVisibleInLegend = false;
            chartAcknowledge.Series[seriesName].ChartType = SeriesChartType.Bar;
            chartAcknowledge.ChartAreas[0].AxisX.Interval = 1;
            chartAcknowledge.Series[seriesName].Label = "#VALY";
            Title overdueAcknowledge = new Title();
            overdueAcknowledge.Text = "Overdue acknowledgements by person";

            // hide label notifying about no results when results are available
            if (categoryArray.Length > 0)
                lbNoResultsAcknowledgement.Visible = false;
            else
                lbNoResultsAcknowledgement.Visible = true;

            chartAcknowledge.Titles.Add(overdueAcknowledge);
            for (int n = 0; n < categoryArray.Length; n++)
            {
                chartAcknowledge.Series[seriesName].Points.AddXY(categoryArray[n].analyst, categoryArray[n].overdueRequestCount); //.AddXY(categoryArray[n].analyst, categoryArray[n].overdueRequestCount);              
            }

        }

        private void buildOverdueAcknowledgementChart2()
        {
            int rowCount = dgvTest.RowCount - 1; // count records for Application catalog

            int i = 0;

            List<dgvRecord> KPIList = new List<dgvRecord>();

            while (i < rowCount)
            {
                if (dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value != null && dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value.ToString() != "")
                {
                    KPIList.Add(new dgvRecord(i, dgvTest.Rows[i].Cells["AssignedTo"].Value.ToString(), dgvTest.Rows[i].Cells["Acknowledgement overdue bucket"].Value.ToString(),
                         dgvTest.Rows[i].Cells["Id"].Value.ToString(), "0", "0", "0"));
                }
                i++;
            }


            var query = from p in KPIList
                        where p.name != "" && p.name != null
                        group p by new { p.name } into grp
                        select new
                        {
                            analyst = grp.Key.name,
                            overdueRequestCount = grp.Count()   //Sum(p => p.gv1), 
                        };

            var queryPlatform = query.OrderByDescending(p => p.overdueRequestCount);
            var categoryArray = queryPlatform.ToArray(); // putting status LINQ to array list so we can put it in a graph           

            if (categoryArray.Length > 0)
                lbNoResultsDaysLeft.Visible = false;

            while (chartAcknowledge.Series.Count > 0) // delete all series
            {
                chartAcknowledge.Series.RemoveAt(0);
            }

            String seriesName = "";
            seriesName = "Overdue acknowledgement";
            chartAcknowledge.Series.Add(seriesName);
            chartAcknowledge.Series[seriesName].IsVisibleInLegend = false;
            chartAcknowledge.Series[seriesName].ChartType = SeriesChartType.Bar;
            chartAcknowledge.ChartAreas[0].AxisX.Interval = 1;
            chartAcknowledge.Series[seriesName].Label = "#VALY";
            for (int n = 0; n < categoryArray.Length; n++)
            {
                chartAcknowledge.Series[seriesName].Points.AddXY(categoryArray[n].analyst, categoryArray[n].overdueRequestCount); //.AddXY(categoryArray[n].analyst, categoryArray[n].overdueRequestCount);              
            }

        }



        private void chkIncludeAllWorkflow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkIncludeAllWorkflow.Checked == true)
            {
                addErrorsAndReruns();
            }

            else
            {
                removeErrorsAndReruns();
            }


            populateWorkflowCategory(); // populate combobox with the type of workflow

            wfStatusPopulated = false; // reset value in the workflowstatus listbox
            lstStatus.Items.Clear();
            populateWorkflowStatus("Status");

            wfCatagoryPopulated = false; // reset value in the workflow category request listbox
            lstCategory.Items.Clear();
            populateWorkflowType("Request Type");
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            addFieldsToErrorsReruns();
        }



        //int btnShowFieldPanelCountClicks;
        private void btnShowFieldPanel_Click(object sender, EventArgs e)
        {
            if (panelFieldSelections.Visible == true)
            {
                panelFieldSelections.Visible = false;
                btnShowFieldPanel.Text = "Show Settings >>";
                //  btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanEast;
            }

            else
            {
                panelFieldSelections.Visible = true;
                btnShowFieldPanel.Text = "Hide Settings <<";
                //  btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanWest;
            }

            // panelFieldSelectionsVisible = true;
        }

        private void chklstTransitionFields_SelectedIndexChanged(object sender, EventArgs e)
        {

            showHideFieldsFromCheckedList(ref chklstTransitionFields, ref dgvTransitions);
            /* for (int i = 0; i < chklstTransitionFields.Items.Count; i++)
             {
                
                 if (chklstTransitionFields.GetItemCheckState(i) != CheckState.Checked)
                 {
                     dgvTransitions.Columns[i].Visible = false;
                 }
                 else
                 {
                     dgvTransitions.Columns[i].Visible = true;
                 }
             } */
        }

        private void showHideFieldsFromCheckedList(ref CheckedListBox myCheckedListBox, ref DataGridView myDataGridView)
        {
            for (int i = 0; i < myCheckedListBox.Items.Count; i++)
            {

                if (myCheckedListBox.GetItemCheckState(i) != CheckState.Checked)
                {
                    myDataGridView.Columns[i].Visible = false;
                }
                else
                {
                    myDataGridView.Columns[i].Visible = true;
                }
            }
        }
        private void loadExcelSettings(string myWorksheet, ref CheckedListBox myCheckedListBox, ref System.Windows.Forms.CheckBox myCheckBox)
        {
            if (myCheckBox.Checked == true)
            {
                Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                String xlFilePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MySettings.xlsx";

                Excel.Workbook workbook = app.Workbooks.Open(xlFilePath, ReadOnly: true);
                app.DisplayAlerts = false;
                Excel.Worksheet worksheet = workbook.Worksheets[myWorksheet];

                long fullRow = worksheet.Rows.Count;
                long fullCol = worksheet.Columns.Count;
                int lastRow = worksheet.Cells[fullRow, 1].End(Excel.XlDirection.xlUp).Row;
                int lastCol = worksheet.Cells[1, fullCol].End(Excel.XlDirection.xlToLeft).Column;
                string lastCell = "C" + lastCol;
                Excel.Range range = null;
                range = worksheet.get_Range("A3", "C" + lastRow);

                object[,] x = (object[,])range.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);

                for (int i = 0; i < myCheckedListBox.Items.Count; i++)
                {

                    myCheckedListBox.SetItemChecked(i, false);
                    for (int j = 0; j < lastRow - 2; j++)
                    {
                        if (myCheckedListBox.Items[i].Equals(x[j + 1, 1].ToString()) && x[j + 1, 3].ToString() != "n")
                        {
                            myCheckedListBox.SetItemChecked(i, true);
                            myCheckedListBox.SetSelected(i, true);
                            break;
                        }
                    }
                }
                app.Quit();
                Marshal.ReleaseComObject(app);
                GC.Collect();
                GC.WaitForPendingFinalizers();
                MessageBox.Show("Required fields loaded from your settings file");
            }
        }

        private void chkPreselectedTransitionFields_CheckedChanged(object sender, EventArgs e)
        {
            loadExcelSettings("TransitionSettings", ref chklstTransitionFields, ref chkPreselectedTransitionFields);
        }

        private void saveExcelSettings(string settingsSheet, ref CheckedListBox myCheckedListBox)
        {
            Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            String xlFilePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MySettings.xlsx";

            Excel.Workbook workbook = app.Workbooks.Open(xlFilePath);
            app.DisplayAlerts = false;
            Excel.Worksheet worksheet = workbook.Worksheets[settingsSheet];

            long fullRow = worksheet.Rows.Count;
            long fullCol = worksheet.Columns.Count;
            int lastRow = worksheet.Cells[fullRow, 1].End(Excel.XlDirection.xlUp).Row;
            int lastCol = worksheet.Cells[1, fullCol].End(Excel.XlDirection.xlToLeft).Column;
            string lastCell = "C" + lastCol;
            Excel.Range range = null;
            range = worksheet.get_Range("A3", "C" + lastRow);

            object[,] x = (object[,])range.get_Value(Excel.XlRangeValueDataType.xlRangeValueDefault);

            for (int i = 0; i < myCheckedListBox.Items.Count; i++) // looping inside the checklist
            {
                for (int j = 0; j < lastRow - 2; j++)//looping inside the array
                {

                    if (myCheckedListBox.Items[i].ToString().Equals(x[j + 1, 1].ToString()))
                    {
                        worksheet.Cells[j + 3, 3] = myCheckedListBox.GetItemCheckState(i) == 0 ? "n" : "y";
                        break;
                    }
                }
            }

            workbook.Close(true, Type.Missing, Type.Missing);

            app.Quit();
            Marshal.ReleaseComObject(app);
            GC.Collect();
            GC.WaitForPendingFinalizers();

            MessageBox.Show("Report settings have been saved");
        }

        // Save Transition spreadsheet settings
        private void btnSaveTransitionSettings_Click(object sender, EventArgs e)
        {
            saveExcelSettings("TransitionSettings", ref chklstTransitionFields);
        }

        private void chkTransitionTeam_CheckedChanged(object sender, EventArgs e)
        {
            selectYourTeam(ref  lstTransitionAnalyst, ref chkTransitionTeam);
        }

        private void selectYourTeam(ref System.Windows.Forms.ListBox myListBox, ref System.Windows.Forms.CheckBox myChkBox)
        {
            if (myChkBox.Checked)
            {
                string[] lines = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MyTeam.txt");
                myListBox.SelectedIndex = -1;
                foreach (string line in lines)
                {
                    int index = myListBox.FindString(line, -1);
                    if (index != -1)
                    {
                        // Select the found item:
                        myListBox.SetSelected(index, true);
                    }
                }
            }
        }


        private void cmbAcknowledgementSLA_ValueChanged(object sender, EventArgs e)
        {
        }

        private void rbTotalReportCount_CheckedChanged(object sender, EventArgs e)
        {
            populateSummaryGrid();
            buildBarChartCatalogue("Datasource", "Datasource");
        }


        private void btnEnterPassword_Click(object sender, EventArgs e)
        {
            if (txtPassword.Text == "13zXotm")
            {
                cmbAcknowledgementSLA.Enabled = true;
                cmbAcknowledgementOtherSLA.Enabled = true;
                txtPassword.Visible = false;
                btnEnterPassword.Visible = false;
            }
            else
            {
                MessageBox.Show("You are not authorized to change these inputs");
                txtPassword.Visible = false;
                btnEnterPassword.Visible = false;
            }
        }

        // enable password for unlocking the number spinner
        private void label8_Click(object sender, EventArgs e)
        {
            txtPassword.Visible = true;
            btnEnterPassword.Visible = true;
        }

        private void btnExpandCatalogueFilter_Click(object sender, EventArgs e)
        {
            tsbRefreshData.Visible = true;
            if (splitContainerFilters.Visible == true)
            {
                splitContainerFilters.Visible = false;
                btnExpandCatalogueFilter.Text = "Expand Filters >>";
                btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanEast;
            }

            else
            {
                splitContainerFilters.BringToFront();
                splitContainerFilters.Visible = true;
                btnExpandCatalogueFilter.Text = "Collapse Filters <<";
                btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanWest;

            }
        }

        private void btnExpandCatalogueFilter_MouseHover(object sender, EventArgs e)
        {
            if (splitContainerFilters.Visible == true)
            {

                btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanWest;
            }

            else
            {
                btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanEast;
            }
        }

        private void btnShowFieldPanel_MouseHover(object sender, EventArgs e)
        {
            /*if (panelFieldSelections.Visible == true)
            {
                btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanWest;               
            }
            else
            {
                btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanEast;
            } */
        }

        private void lstReportStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnSelection();
            // buildAreaChart();
        }

        private void lstDeploymentTool_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnSelection();
            //  buildAreaChart();
        }

        private void lstDataSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnSelection();
            //   buildAreaChart();
        }

        private void browseExcelSources(string folderPath, System.Windows.Forms.TextBox myTextBox)
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            //openFileDialog1.InitialDirectory = @"\\maple.fg.rbc.com\data\Toronto\wrkgrp\wrkgrp11\Shared Services Reporting Centre";
            openFileDialog1.InitialDirectory = folderPath;
            openFileDialog1.Filter = "Excel Files|*.xlsx; *.xls; *.xlsm; *.xlsb";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (myStream)
                        {
                            //txtTransitionPath.Text = openFileDialog1.FileName;
                            myTextBox.Text = openFileDialog1.FileName;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }

            }
        }
        private void tbnBrowseTransition_Click(object sender, EventArgs e)
        {
            browseExcelSources(@"\\maple.fg.rbc.com\data\Toronto\wrkgrp\wrkgrp11\Shared Services Reporting Centre", txtTransitionPath);
        }

        // UPDATED REFRESH 
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            //manageProgrssBar("start");
            clsServer oSPServer = null;

            foreach (KeyValuePair<string, clsDataGridView> entry in dicDataGridViews)
            {
                entry.Value.ExecuteCAMLQuery(tsslNoOfItems, tsslStatus);
            }
            // manageProgrssBar("finish");

        }

        private void lstFrequency_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterOnSelection();
            //   buildAreaChart();      

        }

        private void rbEffortRequired_CheckedChanged(object sender, EventArgs e)
        {
            populateWorflowCharts();
        }

        private void rbRequestCategory_CheckedChanged(object sender, EventArgs e)
        {
            populateWorflowCharts();
        }


        private void getExcelFilePath(string excelSheetName, string partialName, ref System.Windows.Forms.TextBox myTxtBox, ref System.Windows.Forms.CheckBox myCheckBox)
        {
            if (myCheckBox.Checked == true)
            {
                //string currYear = DateTime.Today.Year.ToString();            

                //partialName = "Transition Assessment Summary";
                Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                String xlFilePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MySettings.xlsx";
                Excel.Workbook workbook = app.Workbooks.Open(xlFilePath, ReadOnly: true);
                Excel.Worksheet worksheet = workbook.Worksheets[excelSheetName];
                app.DisplayAlerts = false;

                string initialDir = worksheet.Cells[2, 2].Value;
                //MessageBox.Show(initialDir);
                DirectoryInfo hdDirectoryInWhichToSearch = new DirectoryInfo(initialDir);

                FileInfo[] filesInDir = hdDirectoryInWhichToSearch.GetFiles("*" + partialName + "*.*");
                // txtTransitionPath.Text = filesInDir[0].FullName.ToString();
                myTxtBox.Text = filesInDir[0].FullName.ToString();
                app.Quit();
                Marshal.ReleaseComObject(app);
                GC.Collect();
                GC.WaitForPendingFinalizers();

            }
        }


        private void chkGuessFilePathRollover_CheckedChanged(object sender, EventArgs e)
        {
            getExcelFilePath("RolloverSettings", "Rollover", ref txtRolloverPath, ref chkGuessFilePathRollover);
        }

        private void chkGuessFilePath_CheckedChanged(object sender, EventArgs e)
        {
            getExcelFilePath("TransitionSettings", "Transition Assessment Summary", ref txtTransitionPath, ref chkGuessFilePath);
        }

        private void chartCategory_MouseMove(object sender, MouseEventArgs e)
        {
            /*  HitTestResult result = chartCategory.HitTest(e.X, e.Y);
              if (result.ChartElementType == ChartElementType.DataPoint)
              {
                  var selectedValue = chartCategory.Series[0].Points[result.PointIndex].YValues[0];
                  MessageBox.Show(selectedValue.ToString());
              } */
        }

        // string selectedValue = null;
        string KPIvalue = "";
        private void dgvKPI_CellContextMenuStripNeeded(object sender, DataGridViewCellContextMenuStripNeededEventArgs e)
        {
            cmsMetrics.Tag = e.RowIndex;
            cmsMetrics.Visible = true;

            // if (((System.Data.DataTable)dgvKPI.DataSource).DefaultView[e.RowIndex][e.ColumnIndex] != null && 
            //    ((System.Data.DataTable)dgvKPI.DataSource).DefaultView[e.RowIndex][e.ColumnIndex] != " ")
            //{
            string columnName = dgvKPI.Columns[e.ColumnIndex].Name;
            KPIvalue = ((System.Data.DataTable)dgvKPI.DataSource).DefaultView[e.RowIndex][e.ColumnIndex].ToString();
            MessageBox.Show(KPIvalue);
            if (KPIvalue != null && KPIvalue != "")
            {
                tsmiEquals.Text = KPIvalue;
                tsmiNotEquals.Text = KPIvalue;
            }
            else
            {
                tsmiEquals.Text = "null";
                tsmiNotEquals.Text = "null";
            }
        }



        // filtering from the context menu strip
        string testvalue = "";
        string columnName = "";
        private void dgvTest_CellContextMenuStripNeeded(object sender, DataGridViewCellContextMenuStripNeededEventArgs e)
        {
            cmsMetrics.Tag = e.RowIndex;
            cmsMetrics.Visible = true;


            //  if (((System.Data.DataTable)dgvTest.DataSource).DefaultView[e.RowIndex][e.ColumnIndex] != null)
            // {            
            testvalue = ((System.Data.DataTable)dgvTest.DataSource).DefaultView[e.RowIndex][e.ColumnIndex].ToString();
            if (testvalue != null & testvalue != "")
            {
                tsmiEquals.Text = testvalue;
                tsmiNotEquals.Text = testvalue;
            }
            else
            {
                tsmiEquals.Text = "null";
                tsmiNotEquals.Text = "null";
            }
            columnName = dgvTest.Columns[e.ColumnIndex].Name;
        }

        private void tsmiEquals_Click(object sender, EventArgs e)
        {
            if (testvalue == "null")
            {
                string filter1 = string.Format("[" + columnName + "] ='{0}'", "");
                // string filter1 = string.Format("[" + columnName + "] ='{0}'", null);
                (dgvTest.DataSource as System.Data.DataTable).DefaultView.RowFilter = filter1;
            }
            else
            {
                string filter1 = string.Format("[" + columnName + "] ='{0}'", testvalue);
                (dgvTest.DataSource as System.Data.DataTable).DefaultView.RowFilter = filter1;
            }
            buildDaysLeftAgingCharts();
            buildOverdueAcknowledgementChart();
            createWorkflowAdditionalFields();
            updateKPITextBoxes();

        }

        private void tsmiNotEquals_Click(object sender, EventArgs e)
        {
            string filter1 = string.Format("[" + columnName + "] <>'{0}'", testvalue);
            (dgvTest.DataSource as System.Data.DataTable).DefaultView.RowFilter = filter1;
            buildDaysLeftAgingCharts();
            buildOverdueAcknowledgementChart();
            createWorkflowAdditionalFields();
            updateKPITextBoxes();
        }

        private void tsmiClearKPIFilter_Click(object sender, EventArgs e)
        {
            (dgvTest.DataSource as System.Data.DataTable).DefaultView.RowFilter = string.Empty;
            buildDaysLeftAgingCharts();
            buildOverdueAcknowledgementChart();
            createWorkflowAdditionalFields();
            updateKPITextBoxes();
        }

        // Clear all listboxes. Update array with new listboxes as necessary
        private void clearAllListBoxes()
        {
            // listbox array to efficiently loop through all remaining listboxes
            System.Windows.Forms.ListBox[] myListBoxArray = {lstEmployees, lstRelationshipManager, chlstPlatform, lstReportStatus, lstFrequency, lstGvDays,
                                                              lstDeploymentTool, lstDataSource, lstTeamManager, lstCategory, lstStatus }; // can't add listboxes from another tab
            clearListBoxSelection(ref myListBoxArray);
        }

        public void selectSavedFilter()
        {
            clearAllListBoxes();
            string[] lines = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\DefaultSettings.txt");
            string[] splitLine;
            foreach (string line in lines)
            {
                splitLine = line.Split('|');
                if (splitLine[0] == cmbSavedFilters.SelectedItem.ToString())
                {
                    setDefaultSettings(splitLine[1], splitLine[2]);
                }
            }
        }

        // Clear selection in the listboxes specified in the array
        private void clearListBoxSelection(ref System.Windows.Forms.ListBox[] myListBoxArray)
        {
            foreach (System.Windows.Forms.ListBox lst in myListBoxArray)
            {
                lst.ClearSelected();
            }
        }
        private void setDefaultSettings(string listboxName, string selectedValue)
        {
            // listbox array to efficiently loop through all remaining listboxes
            System.Windows.Forms.ListBox[] myListBoxArray = {lstEmployees, lstRelationshipManager, chlstPlatform, lstReportStatus, lstFrequency, lstGvDays,
                                                              lstDeploymentTool, lstDataSource, lstTeamManager, lstCategory, lstStatus }; // can't add listboxes from another tab

            // clearListBoxSelection(ref myListBoxArray);
            // select all items on the list 
            foreach (System.Windows.Forms.ListBox lst in myListBoxArray)
            {

                if (lst.Name == listboxName)
                {
                    //Debug.Print(lst.Name);
                    for (int i = 0; i < lst.Items.Count; i++)
                    {
                        if (lst.Items[i].ToString() == selectedValue)
                        {

                            lst.SetSelected(i, true);
                        }
                    }
                }
            }
        }

        private void btnShowRolloverFieldPanel_Click(object sender, EventArgs e)
        {
            if (panelRollover.Visible == true)
            {
                panelRollover.Visible = false;
                btnShowRolloverFieldPanel.Text = "Show Settings >>";
            }
            else
            {
                panelRollover.Visible = true;
                btnShowRolloverFieldPanel.Text = "Hide Settings <<";
            }
        }

        private void chkRolloverTeam_CheckedChanged(object sender, EventArgs e)
        {
            selectYourTeam(ref lstRolloverAnalyst, ref chkRolloverTeam);
        }

        private void tbnBrowseRollover_Click(object sender, EventArgs e)
        {
            browseExcelSources(@"\\maple.fg.rbc.com\data\Toronto\wrkgrp\wrkgrp11\Shared Services Reporting Centre", txtRolloverPath);
        }

        private void btnSaveRolloverSettings_Click(object sender, EventArgs e)
        {
            saveExcelSettings("RolloverSettings", ref chklstRolloverFields);
        }

        private void chkPreselectedRolloverFields_CheckedChanged(object sender, EventArgs e)
        {
            loadExcelSettings("RolloverSettings", ref chklstRolloverFields, ref chkPreselectedRolloverFields);
            // loadExcelSettings("TransitionSettings", ref chklstTransitionFields); 
        }

        private void chklstRolloverFields_SelectedIndexChanged(object sender, EventArgs e)
        {
            showHideFieldsFromCheckedList(ref chklstRolloverFields, ref dgvRolloverDashBoard);
        }

        // event handler responsible for change in the Filter combo box
        private void cmbSavedFilters_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (cmbSavedFilters.SelectedItem.ToString() == "<ALL>" || cmbSavedFilters.SelectedItem.ToString() == "<TEAM>")  // If filter "<ALL>" is selected, then we don't refer to the extranal filter reference file
            {
                // select default fiscal period - from the eginning of the prior fiscal year                
                DateTime currentFiscPeriod = new DateTime(DateTime.Today.AddYears(-1).Year, 11, 1);
                rbFrom.Checked = true;
                dateTimePicker1.Value = currentFiscPeriod;
                //chCalculateKPI.Checked = true;
                clearAllListBoxes();
                selectFromFilter();


                //Console.WriteLine(cmbSavedFilters.SelectedItem.ToString());
            }
            else   // in all other cases, we extract filters from the external filter file based on the filter name selected from combobox
            {
                // Console.WriteLine(cmbSavedFilters.SelectedItem.ToString());
                selectSavedFilter();
            }
            // remove frocus from the filter combobox after value is changed so that user does not move the mouse accidentally and changes the filter
            //lstEmployees.Focus(); 

        }

        // remove saved filter
        private void btnRemoveFilter_Click(object sender, EventArgs e)
        {
            if (cmbSavedFilters.SelectedIndex < 0) // if nothing is selected in combobox 
            {
                MessageBox.Show("You need to select a filter to delete.");
                return;
            }
            if (cmbSavedFilters.SelectedItem.ToString().Equals("<ALL>")) // user not allowed to delete filter "<ALL>"
            {
                MessageBox.Show("You cannot delete or update the default filter '<ALL>'. You can only delete/update custom filters that you had saved.");
            }
            else if (cmbSavedFilters.SelectedItem.ToString().Equals("<TEAM>")) // user not allowed to delete filter "<ALL>"
            {
                MessageBox.Show("You can only update the '<TEAM>' filter. You can only delete custom filters that you had saved.");
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure that you want to remove the selected filter?", "Delete Filter", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    /* if (cmbSavedFilters.SelectedItem.ToString().Equals("<TEAM>")) // clear the Team File content
                     {
                         string teamFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MyTeam.txt";
                         System.IO.File.WriteAllText(teamFile, string.Empty);
                         cmbSavedFilters.Items.Remove(cmbSavedFilters.SelectedItem.ToString());
                         positionAndResizeFilterBox(false);                       
                     } 
                     else */
                    {
                        overwriteSavedFiltersFile();
                        cmbSavedFilters.Items.Remove(cmbSavedFilters.SelectedItem.ToString());
                        positionAndResizeFilterBox(false);
                    }

                }
            }

        }

        // Overwrite the files storing saved filters. Overwrite is needed when filter(s) need to be deleted
        private void overwriteSavedFiltersFile()
        {
            List<string> myList = new List<string>();

            string[] lines = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\DefaultSettings.txt");
            string[] splitLine;
            foreach (string line in lines) // check each line in the text file storing filters and do not add lines that relate to the filter being deleted
            {
                splitLine = line.Split('|');
                if (splitLine[0] != cmbSavedFilters.SelectedItem.ToString())
                {
                    myList.Add(line);
                }
            }
            overwriteDefaultSettings(ref myList); // write changes back to the file
        }

        // increase/reduce the size of objects on the form when new filter input box is visible/invisible
        private void positionAndResizeFilterBox(bool expand)
        {
            if (expand)
            {
               // groupBox3.Size = new Size(247, 123);
                txtFilterName.Visible = true;
              //  btnExpandCatalogueFilter.Location = new System.Drawing.Point(9, 135);
            }
            else
            {
                txtFilterName.Visible = false;
              //  groupBox3.Size = new Size(247, 100);
               // btnExpandCatalogueFilter.Location = new System.Drawing.Point(9, 112);
            }
        }

        private void btnAddFilter_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Please select values for your filter from below listboxes,provide the name of the filter in texbox below and click 'Save'.");
            positionAndResizeFilterBox(true); // expand the size of objects on the form when new filter input box is visible

        }


        private void rbBetween_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Enabled = true;
            dateTimePicker2.Enabled = true;
            chkIncludeAllDates.Checked = false;
            refreshWorkflow();
        }

        private void rbBefore_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Enabled = false;
            dateTimePicker2.Enabled = true;
            chkIncludeAllDates.Checked = false;
            refreshWorkflow();
        }

        private void rbFrom_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Enabled = true;
            dateTimePicker2.Enabled = false;
            chkIncludeAllDates.Checked = false;
            refreshWorkflow();
        }

        private void chkIncludeAllDates_CheckedChanged(object sender, EventArgs e)
        {
            refreshWorkflow();
            /* if (chkIncludeAllDates.Checked)
             {
                 dateTimePicker1.Enabled = false;
                 dateTimePicker2.Enabled = false;
                 filterOnSelection();
                 populateWorflowCharts(); 
             }
             else
             {
                 dateTimePicker1.Enabled = false;
                 dateTimePicker2.Enabled = false;
             } */
        }

        // Open help file
        private void goToHelpMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] pathToHtmlFile = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\HelpFile.txt");
            foreach (string line in pathToHtmlFile)
            {
                System.Diagnostics.Process.Start(line);
            }
        }

        private void btnSaveTeam_Click(object sender, EventArgs e)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\MyTeam.txt"))
            {
                String strItem = "";
                if (lstEmployees.SelectedItems.Count == 0)
                {
                    MessageBox.Show("You need to select team members in the list below");
                    return;
                }
                foreach (var item in lstEmployees.SelectedItems)
                {
                    strItem = item.ToString();
                    file.WriteLine(strItem);
                }
            }
            MessageBox.Show("Your team members have been saved. Check 'Load team' any time to filter your team on the list");
        }

        private void txtFilterName_DoubleClick(object sender, EventArgs e)
        {
            positionAndResizeFilterBox(false);
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // refreshWorkflow();
        }

        private void refreshWorkflow()
        {
            // ensure that some date is selected before applying a dynamic filter on the workflow to prevent exceptions
            if (chkIncludeAllDates.Checked || rbBetween.Checked || rbBefore.Checked || rbFrom.Checked)
            {
                // if 'Include all dates' otion is checked, disable datetime picker, otherwise check which radio button
                // is checked and enable/disable accordingly
                if (chkIncludeAllDates.Checked)
                {
                    dateTimePicker1.Enabled = false;
                    dateTimePicker2.Enabled = false;
                    rbBetween.Checked = false;
                    rbBefore.Checked = false;
                    rbFrom.Checked = false;
                }
                else if (rbBefore.Checked)
                {
                    dateTimePicker2.Enabled = true;
                }
                else if (rbFrom.Checked)
                {
                    dateTimePicker1.Enabled = true;
                }
                else
                {
                    dateTimePicker1.Enabled = true;
                    dateTimePicker2.Enabled = true;
                }


                // refresh the datagrid view for Workflow based on the selections
                filterOnSelection();
                populateWorflowCharts();

                //refresh KPIs automatically is such option is selected
                if (chCalculateKPI.Checked)
                {
                    refreshKpi();
                }
            }

        }
        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            //refreshWorkflow();
        }

        private void chCalculateKPI_CheckedChanged(object sender, EventArgs e)
        {
            if (chCalculateKPI.Checked)
            {
                refreshKpi();
            }

        }

        private void dateTimePicker2_CloseUp(object sender, EventArgs e)
        {
            refreshWorkflow();
        }

        private void dateTimePicker1_CloseUp(object sender, EventArgs e)
        {
            refreshWorkflow();
        }

        // checlbox event  
        private void chkShowOverdueOnly_CheckedChanged(object sender, EventArgs e)
        {
            filterOnOverdueAcknowledgement();
        }

        // display only overdue acknowledgements in the KPI table
        private void filterOnOverdueAcknowledgement()
        {
            if (chkShowOverdueOnly.Checked)
            {
                // string filter1 = string.Format("[" + columnName + "] ='{0}'", "");
                string filter1 = string.Format("[Acknowledgement overdue bucket] <>'{0}'", "");
                (dgvTest.DataSource as System.Data.DataTable).DefaultView.RowFilter = filter1;
            }
            else
            {
                (dgvTest.DataSource as System.Data.DataTable).DefaultView.RowFilter = string.Empty;
            }
        }

        private void btnUpdateFilter_Click(object sender, EventArgs e)
        {
            if (cmbSavedFilters.SelectedIndex < 0 || cmbSavedFilters.SelectedItem.ToString() == "" || cmbSavedFilters.SelectedItem.ToString() == null) // if nothing is selected in combobox 
            {
                MessageBox.Show("You need to select a filter  from dropdown menu to update.");
                return;
            }           
            else if (cmbSavedFilters.SelectedItem.ToString().Equals("<ALL>")) // ALL filter can neither be deleted not updated as it's a special predefined filter.
            {
                MessageBox.Show("You cannot update a predefined filter '<ALL>'.You can update <TEAM> and other custom filters.");
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure that you want to overwrite the selected filter?", "Overwrite Filter", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    if (cmbSavedFilters.SelectedItem.ToString().Equals("<TEAM>")) // update predefined filter TEAM
                    {
                        saveTeamMembers();
                    }
                    else // update all other custom filters
                    {
                        overwriteSavedFiltersFile();
                        saveDefaultSettings(true);
                        MessageBox.Show("Filter has been updated");
                    }

                }
            }
        }

        private void chkIncludeAllDates_CheckStateChanged(object sender, EventArgs e)
        {
            refreshWorkflow();
        }

        // filter Report Catalogue with the keywords provided in a Textbox
        string keywordFilterCatalogue; // 2 global variables representing 
        string keywordFilterWorkflow;
        private void filterFromTextBox(string selectedField, ref DataGridView myDataGrid, ref System.Windows.Forms.TextBox myTextBox, string myOperator, string keywordTable)
        {           
     
            //string outputInfo = "";
            string[] keyWords = myTextBox.Text.Split('|');
            //reset filters
            keywordFilterCatalogue = null;
            keywordFilterCatalogue = string.Format("[" + selectedField + "]  LIKE'{0}'", ""); // selectedField is a global variable. Represents field name selected fro, combobox. Updated when combobox value is changed
            keywordFilterWorkflow = null;
            keywordFilterWorkflow = string.Format("[" + selectedField + "]  LIKE'{0}'", ""); 
            foreach (string word in keyWords)
            {
                if (keywordTable == "workflow") // update keywordFilterWorkflow if workflow table is to be filtered from the keyword
                {
                    keywordFilterWorkflow += string.Format(" OR [" + selectedField + "] " + myOperator + "'%{0}%'", word);                   
                }
                else // otherwise update report catalogue with the keyword filter 
                {
                    keywordFilterCatalogue += string.Format(" OR [" + selectedField + "] " + myOperator + "'%{0}%'", word);  
                }
            }
           // (myDataGrid.DataSource as System.Data.DataTable).DefaultView.RowFilter = keywordFilter;
           // Console.WriteLine(keywordFilterWorkflow);
        }
               
        private void txtSearchCatalogue_TextChanged(object sender, EventArgs e)
        {
            if (cmbFieldFilterReportCatalogue.SelectedIndex < 0) // if nothing is selected in combobox 
            {
                MessageBox.Show("You need to select a field to search");
                return;
            }
            string myOperator = "LIKE";
            filterFromTextBox(selectedCatalogueField, ref dgvResourcing, ref txtSearchCatalogue, myOperator, "catalogue");
            filterOnSelection();
        }

        private void txtSearchWorkflow_TextChanged(object sender, EventArgs e)
        {
            if (cmbFieldFilterWorkflow.SelectedIndex < 0) // if nothing is selected in combobox 
            {
                MessageBox.Show("You need to select a field to search");
                return;
            }
            string myOperator = "LIKE";
            filterFromTextBox(selectedWorkflowField, ref dgvResourcingWorkflow, ref txtSearchWorkflow, myOperator, "workflow");
            filterOnSelection();
        }

        // Read field names from Report Catalogue and populate the combobox cmbFieldFilterReportCatalogue with those names
        private void ReaddataGridViewColumns(ref DataGridView myDataGrid, ref System.Windows.Forms.ComboBox myCmb)
        {
            foreach (DataGridViewColumn column in myDataGrid.Columns)
            {
                myCmb.Items.Add(column.HeaderText);                  
            }
        }

       string selectedCatalogueField; 
       private void cmbFieldFilterReportCatalogue_SelectionChangeCommitted(object sender, EventArgs e)
       {
           selectedCatalogueField = cmbFieldFilterReportCatalogue.GetItemText(cmbFieldFilterReportCatalogue.SelectedItem);
           
       }
       string selectedWorkflowField; 
       private void cmbFieldFilterWorkflow_SelectionChangeCommitted(object sender, EventArgs e)
       {
           selectedWorkflowField = cmbFieldFilterWorkflow.GetItemText(cmbFieldFilterWorkflow.SelectedItem);
       }

       private void button1_Click_1(object sender, EventArgs e)
       {
           string strConnection = @"Data Source=SE120819\IN01;Initial Catalog=FMSR;Integrated Security=True";
           SqlConnection con = new SqlConnection(strConnection);
           SqlCommand sqlCmd = new SqlCommand();
           sqlCmd.Connection = con;
           sqlCmd.CommandType = CommandType.Text;
           sqlCmd.CommandText = "SELECT name FROM sys.databases ;"; 
           SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);

           System.Data.DataTable myDataTable = new System.Data.DataTable();
           sqlDataAdap.Fill(myDataTable);
           cmbDatabaseName.DataSource = myDataTable;
           cmbDatabaseName.DisplayMember = "name";
           cmbDatabaseName.ValueMember = "name";
           //cmbDatabaseName.DisplayMember = 

          // cmbDatabaseName.DisplayMember = ;
           // populate table from FDM
          /* string strConnection = @"Data Source=SE120819\IN01;Initial Catalog=FMSR;Integrated Security=True";
           SqlConnection con = new SqlConnection(strConnection);

           SqlCommand sqlCmd = new SqlCommand();
           sqlCmd.Connection = con;
           sqlCmd.CommandType = CommandType.Text;
           sqlCmd.CommandText = "Select top 100 * FROM gl_balances";
           SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);

           System.Data.DataTable dtRecord = new System.Data.DataTable();
           sqlDataAdap.Fill(dtRecord);
           dgvFDM.DataSource = dtRecord; */
       }

       private void cmbDatabaseName_SelectionChangeCommitted(object sender, EventArgs e)
       {
           string databaseName = cmbDatabaseName.GetItemText(cmbDatabaseName.SelectedItem);
           string strConnection = @"Data Source=SE120819\IN01;Initial Catalog=FMSR;Integrated Security=True";
           SqlConnection con = new SqlConnection(strConnection);
           SqlCommand sqlCmd = new SqlCommand();
           sqlCmd.Connection = con;
           sqlCmd.CommandType = CommandType.Text;
           sqlCmd.CommandText = "USE " + databaseName + "; SELECT name+'-T' AS name FROM sys.tables UNION ALL SELECT name+'-V' AS name FROM sys.views;";
          
           SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);  
          
           System.Data.DataTable myDataTable = new System.Data.DataTable();
           sqlDataAdap.Fill(myDataTable);
           lstTableName.DataSource = myDataTable;
           lstTableName.DisplayMember = "name";
           lstTableName.ValueMember = "name"; 
       }

       private void lstTableName_SelectedIndexChanged(object sender, EventArgs e)
       {
          string databaseName = cmbDatabaseName.GetItemText(cmbDatabaseName.SelectedItem);
          string tableName = lstTableName.GetItemText(lstTableName.SelectedItem);
          tableName = tableName.Substring(0, tableName.Length - 2);
          // Console.WriteLine("TB name: " + tableName);
          // MessageBox.Show(tableName);
           string strConnection = @"Data Source=SE120819\IN01;Initial Catalog=FMSR;Integrated Security=True";
           SqlConnection con = new SqlConnection(strConnection);
           SqlCommand sqlCmd = new SqlCommand();
           sqlCmd.Connection = con;
           sqlCmd.CommandType = CommandType.Text;
           //sqlCmd.CommandText = "USE " + databaseName + "; SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = left('" + tableName + "', len(" + tableName + ")-2))";
           sqlCmd.CommandText = "USE " + databaseName + "; SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" + tableName + "'";
           SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);

           System.Data.DataTable myDataTable = new System.Data.DataTable();
           sqlDataAdap.Fill(myDataTable);
           dgvFDM.DataSource = myDataTable;         
       }

       private void chkSelectAll_CheckedChanged(object sender, EventArgs e)
       {
           selectAllOrTopNDataMart();
       }

       private void lstTableName_DoubleClick(object sender, EventArgs e)
       {
           /*string databaseName = cmbDatabaseName.GetItemText(cmbDatabaseName.SelectedItem);
           string tableName = lstTableName.GetItemText(lstTableName.SelectedItem);
           // Console.WriteLine("TB name: " + tableName);
           string strConnection = @"Data Source=SE120819\IN01;Initial Catalog=FMSR;Integrated Security=True";
           SqlConnection con = new SqlConnection(strConnection);
           SqlCommand sqlCmd = new SqlCommand();
           sqlCmd.Connection = con;
           sqlCmd.CommandType = CommandType.Text;
           //sqlCmd.CommandText = "USE " + databaseName + "; SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = left('" + tableName + "', len(" + tableName + ")-2))";
           sqlCmd.CommandText = "USE " + databaseName + "; SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" + tableName + "'";
           SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);

           System.Data.DataTable myDataTable = new System.Data.DataTable();
           sqlDataAdap.Fill(myDataTable);
           dgvFDM.DataSource = myDataTable; */     
       }

       private void selectAllOrTopNDataMart()
       {
           string databaseName = cmbDatabaseName.GetItemText(cmbDatabaseName.SelectedItem);
           string tableName = lstTableName.GetItemText(lstTableName.SelectedItem);
           tableName = tableName.Substring(0, tableName.Length - 2);
           if (chkSelectAll.Checked)
           {
               string strConnection = @"Data Source=SE120819\IN01;Initial Catalog=FMSR;Integrated Security=True";
               SqlConnection con = new SqlConnection(strConnection);
               SqlCommand sqlCmd = new SqlCommand();
               sqlCmd.Connection = con;
               sqlCmd.CommandType = CommandType.Text;
               //sqlCmd.CommandText = "USE " + databaseName + "; SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = left('" + tableName + "', len(" + tableName + ")-2))";
               sqlCmd.CommandText = "USE " + databaseName + " SELECT * FROM " + tableName + " ";
               SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);
               System.Data.DataTable myDataTable = new System.Data.DataTable();
               sqlDataAdap.Fill(myDataTable);
               dgvFDM.DataSource = myDataTable;
           }
           else if (chkTopN.Checked && cmbSelectTopN.SelectedIndex >-1)
           {
               string topn = cmbSelectTopN.GetItemText(cmbSelectTopN.SelectedItem);               
               string strConnection = @"Data Source=SE120819\IN01;Initial Catalog=FMSR;Integrated Security=True";
               SqlConnection con = new SqlConnection(strConnection);
               SqlCommand sqlCmd = new SqlCommand();
               sqlCmd.Connection = con;
               sqlCmd.CommandType = CommandType.Text;
               //sqlCmd.CommandText = "USE " + databaseName + "; SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = left('" + tableName + "', len(" + tableName + ")-2))";
               sqlCmd.CommandText = "USE " + databaseName + " SELECT TOP " + topn + " * FROM " + tableName + " ";
               SqlDataAdapter sqlDataAdap = new SqlDataAdapter(sqlCmd);
               System.Data.DataTable myDataTable = new System.Data.DataTable();
               sqlDataAdap.Fill(myDataTable);
               dgvFDM.DataSource = myDataTable;
           }
       }
       private void chkTopN_CheckedChanged(object sender, EventArgs e)
       {
           selectAllOrTopNDataMart();
       }

       private void cmbSelectTopN_SelectionChangeCommitted(object sender, EventArgs e)
       {
           selectAllOrTopNDataMart();
       }

       private void openProductionFolder(string filepath)
       {
           
           //string filepath = dgvResourcing.CurrentCell.Value.ToString(); 

           // beginning prefix for slashes preceeding server name i.e. \\
           string beginningPrefix;
           int splitStartPosition;
           if (filepath.Substring(0, 2) == @"\\")
           {
               beginningPrefix = @"\\";
               splitStartPosition = 2;
           }
           else if (filepath.Substring(0, 2) != @"\\" && filepath.Substring(0, 1) == @"\")
           {
               beginningPrefix = @"\";
               splitStartPosition = 1;
           }
           else
           {
               beginningPrefix = "";
               splitStartPosition = 0;
           }

           // split folder path by slash
           string[] parsedPath = filepath.Substring(splitStartPosition, filepath.Length - splitStartPosition).Split('\\');

           string reAssembledPath = "";
           string previousCorrectPath = "";
           int strLength;

           int i = 0;
           foreach (string splitLine in parsedPath)
           {
               strLength = splitLine.Length;
               if (strLength > 0 && splitLine[0] == '<' && splitLine[strLength - 1] == '>')
               {
                   parsedPath[i] = findPeriod(splitLine);
               }

               if (i == 0)
                   reAssembledPath += beginningPrefix + parsedPath[i];
               else
                   reAssembledPath += "\\" + parsedPath[i];
               Console.WriteLine("AAA " + reAssembledPath);
               i++;
               // do something if path is incorrect
               if (checkFolderPath(reAssembledPath) == 0) // first folder \\maple.fg.rbc.com is returned as INVALID PATH. INVESTIGATE!!!
               {
                   // Console.WriteLine("VALID PATH" + reAssembledPath);
                   previousCorrectPath = reAssembledPath; // store previous correct network path. If then next subfloder is wrong, then we will open path up to the previously valid folder
                   // Process.Start(filepath);
               }
               else
               {
                   Console.WriteLine("INVALID PATH: " + reAssembledPath); // WORK HERE ON MONDAY
                   //break; // break the loop if one of the subfolders is invalid
               }
           }
           // int errorNum = checkFolderPath(filepath);
           // Console.WriteLine(errorNum + " error num" + " path: " + reAssembledPath + "Parsed path length" + parsedPath.Length); 
           Console.WriteLine("Last valid path: " + previousCorrectPath);
           Process.Start(previousCorrectPath);
       }
       private void dgvResourcing_CellContentClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
       {
           //string filepath = dgvResourcing.CurrentCell.OwningRow.Cells["Report Production Folder"].Value.ToString(); 
           //string filepath = dgvResourcing.CurrentCell.Value.ToString(); 
          // openProductionFolder(filepath);
           // beginning prefix for slashes preceeding server name i.e. \\
          /* string beginningPrefix;
           int splitStartPosition;
           if (filepath.Substring(0, 2) == @"\\")
           {
               beginningPrefix = @"\\";
               splitStartPosition = 2;
           }
           else if (filepath.Substring(0, 2) != @"\\" && filepath.Substring(0, 1) == @"\")
           {
               beginningPrefix = @"\";
               splitStartPosition = 1;
           }
           else
           {
               beginningPrefix = "";
               splitStartPosition = 0;
           }

           // split folder path by slash
           string[] parsedPath = filepath.Substring(splitStartPosition, filepath.Length - splitStartPosition).Split('\\');

           string reAssembledPath = "";
           string previousCorrectPath = "";
           int strLength;
          
           int i = 0;
           foreach(string splitLine in parsedPath)
           {             
             strLength = splitLine.Length;          
             if (strLength > 0 && splitLine[0] == '<' && splitLine[strLength - 1] == '>') 
             {                 
                  parsedPath[i] = findPeriod(splitLine);
             }

             if (i == 0)
                 reAssembledPath += beginningPrefix + parsedPath[i];
             else
                 reAssembledPath += "\\" + parsedPath[i];
             Console.WriteLine("AAA " + reAssembledPath);
             i++;
              // do something if path is incorrect
             if (checkFolderPath(reAssembledPath) == 0) // first folder \\maple.fg.rbc.com is returned as INVALID PATH. INVESTIGATE!!!
             {
                // Console.WriteLine("VALID PATH" + reAssembledPath);
                 previousCorrectPath = reAssembledPath; // store previous correct network path. If then next subfloder is wrong, then we will open path up to the previously valid folder
                 // Process.Start(filepath);
             }
             else
             {
                 Console.WriteLine("INVALID PATH: "+reAssembledPath); // WORK HERE ON MONDAY
                 //break; // break the loop if one of the subfolders is invalid
             }             
           }          
          // int errorNum = checkFolderPath(filepath);
          // Console.WriteLine(errorNum + " error num" + " path: " + reAssembledPath + "Parsed path length" + parsedPath.Length); 
           Console.WriteLine("Last valid path: " + previousCorrectPath);
           Process.Start(previousCorrectPath); */
       }

        private string findPeriod(string placeholderPeriod)
        {
           // current calendar year and month. Bring it back to the calling method outside of the loop, otherwise it iwll be redeclared multiple times
           int currentMonth = Convert.ToInt32(DateTime.Now.AddMonths(-1).Month.ToString()); // need to subtract one month as we are working on the previous month-end
           int currentYear =  Convert.ToInt32(DateTime.Now.Year.ToString());
           //Console.WriteLine("Current month: " + currentMonth);
                 
           // current fiscal year
           int currentFiscalYear;           
           currentFiscalYear = currentMonth > 10 ? currentFiscalYear = currentYear + 1 : currentFiscalYear = currentYear;
           // deal with the fiscal months
           int currentFiscalMonth;
           if (currentMonth > 10 )
           {
               currentFiscalMonth = (currentMonth+2)%12; // calculate current fiscal month based om the current calendar month
           }
           else
           {
               currentFiscalMonth = currentMonth;
           }

          string myPeriod = "";

          switch (placeholderPeriod)
           {
               case "<FM>":
                   myPeriod = Convert.ToString(currentFiscalMonth);    
                   break;
               case "<CM>":
                   myPeriod = Convert.ToString(currentMonth);
                   break;
               case "<FY>":
                   myPeriod = Convert.ToString(currentFiscalYear);
                   break;
               case "<CY>":
                   myPeriod = Convert.ToString(currentYear);
                   break;
               case "<CQ>":
                   myPeriod = Convert.ToString(System.Math.Ceiling(currentMonth/3.00));
                   break;
               case "<FQ>":
                   myPeriod = Convert.ToString(System.Math.Ceiling(currentFiscalMonth / 3.00));
                   break;
               default:
                   break;
           }

           //Console.WriteLine("My period: " + myPeriod + " calendar quarter: " + Convert.ToString(System.Math.Ceiling(currentMonth / 3.00)) + "fiscal quarter: " + Convert.ToString(System.Math.Ceiling(currentFiscalMonth / 3.00)));
  
          // return myPeriod;

           string[] lines = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\periodRef.txt");
           string[] splitLine;
           int lineCount = lines.Count();
           string finalPeriodValue = "";
           int i = 0;
           foreach (string line in lines)
           {
               if (placeholderPeriod == "<CY>")
               {
                   finalPeriodValue = Convert.ToString(currentYear);
               }
               else if (placeholderPeriod == "<FY>")
               {
                   finalPeriodValue = Convert.ToString(currentFiscalYear);
               }
               else
               {
                   splitLine = line.Split('|');
                   if (splitLine[0] == placeholderPeriod && splitLine[1] == myPeriod)
                   {
                       finalPeriodValue = splitLine[2];                       
                       break;
                   }
               }          
               i++;
           }
          // Console.WriteLine("FINAL PERIOD: "+finalPeriodValue);
           return finalPeriodValue;
       }
        private int checkFolderPath(string filepath)
        {
            int n = 0;
            //Console.WriteLine("Checkfolderpath: " + filepath);
            try
            {
               if (Directory.Exists(filepath))
               {
                  // Console.WriteLine("Folder valid " + filepath);
                   return 0;
                   // Process.Start(filepath);
               }
               else
               {
                    return  1; // return Error when folder does not exist
               }
                //Process.Start(filepath);

            }
            catch
            {
                MessageBox.Show("Incorrect path or access is not granted");
                return -1; // return all other kinds of errors
            }
            return n;
        }

        // populate EPM Server list from the text file in Config folder
       string[,] cubeViewName;  // store cube name and view name in the 2d array
       private void populateEPMServerList()
       {
           string[] lines = System.IO.File.ReadAllLines(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Config\EPMServers.txt");
           string[] splitLine;
           int serverCount = lines.Count();
           cubeViewName = new string[serverCount,2];
           int i = 0;
           foreach (string line in lines)
           {
               splitLine = line.Split('|');           
               chkEPMCubes.Items.Add(splitLine[0]);
               cubeViewName[i, 0] = splitLine[1];
               cubeViewName[i, 1] = splitLine[2];
               //Console.WriteLine(cubeViewName[i, 0] + " " + cubeViewName[i, 1]);
              // chkEPMCubes.SetItemChecked(i, true);
               i++;
           }

       }

        private void loadEPMStatus()
       {
           string serverName, cubeName, viewName;
           TM1API.TM1AdminServer asCurrent = new TM1API.TM1AdminServer("uavvl1pha.fg.rbc.com;uavvl2pha.fg.rbc.com;uavvl3pha.fg.rbc.com;uavvl4pha.fg.rbc.com", "tm1adminserver");
           TM1API.TM1Server myServer = null;

           // dataset holding the TM1 data
           DataSet ds = new DataSet();
           ds.Tables.Add("TM1DataTable");

           ds.Tables.Add("TM1DataTable2"); // table for GV

           ds.Tables["TM1DataTable"].Columns.Add("Server");
           ds.Tables["TM1DataTable"].Columns.Add("Scenario");

           ds.Tables["TM1DataTable2"].Columns.Add("Server"); // for GV
           ds.Tables["TM1DataTable2"].Columns.Add("Control measures");
           bool columnsAdded = false;

            // loop through each EPM cube selected in the checked listbox
           for (int j = 0; j < chkEPMCubes.Items.Count; j++)
           {
               if (chkEPMCubes.GetItemCheckState(j) == CheckState.Checked) // if item is selected in the checkbox, then connect to that cube
               {
                   serverName = chkEPMCubes.Items[j].ToString(); // cube, server and view names come from the text file
                   cubeName = cubeViewName[j, 0];
                   viewName = cubeViewName[j, 1];
                   
                   try
                   {
                       myServer = asCurrent.Servers[serverName].LoginUsingCAMNamespace("maple", txtEPMUserName.Text, txtEPMPassword.Text); // password and login come from text boxes
                       TM1API.TM1CubeCollection myCubes = myServer.Cubes;
                      
                       TM1API.TM1Cube myCube = myCubes[cubeName];
                       TM1API.TM1Cube myCube2 = myCubes["control"]; // for GV

                       TM1API.TM1View view = myCube.PublicViews[viewName];
                       TM1API.TM1View view2 = myCube2.PublicViews["default"]; // view to get the GV#

                       TM1API.TM1DataTable data =  view.DataTable;
                       TM1API.TM1DataTable data2 = view2.DataTable;  // table for the gv day

                       int ColumnCount = view.ColumnTable.Rows[0].Cells.Count;
                       int RowCount =    view.RowTable.Rows.Count;
                       int ColumnCount2 = view2.ColumnTable.Rows[0].Cells.Count; // for GV days
                       int RowCount2 =    view2.RowTable.Rows.Count;

                       // Loop through the columns and add the names of the column elements to the Table.
                       if (!columnsAdded)
                       {
                           for (int i = 0; i < ColumnCount; i++)
                           {
                               // Create a new Column in the DataTable by getting the Column header from the TM1 View.
                               ds.Tables["TM1DataTable"].Columns.Add(view.ColumnTable.Rows[0].Cells[i].Value);                             
                           }
                           columnsAdded = true;
                       }                     

                       // Get the rows and thier data and bind them to the columns for the Server update status.
                       for (int y = 0; y < RowCount; y++)
                       {
                           DataRow rowNew = ds.Tables["TM1DataTable"].NewRow();
                           rowNew["Server"] = serverName;
                           rowNew["Scenario"] = view.RowTable.Rows[y].Cells[0].Value;
                           // Get the first row in the TM1DataTable
                           TM1API.TM1DataRow Row = data.Rows[y];
                           int a = 2;
                           // Now I loop through the TM1Rows and retrive their values 1 row at a time.
                           foreach (TM1API.TM1DataCell cell in Row.Cells)
                           {
                               // bind the cell value to the first column, second column, etc...
                               rowNew[a] = cell.Value;
                               a++;
                           }
                           // The row now has values... Add it to the Table. 
                           ds.Tables["TM1DataTable"].Rows.Add(rowNew);
                           // Go back and add all the rows until you hit the last row.
                       }

                       // Get rows and information for GV
                       string gvday = "";
                       for (int y = 0; y < RowCount2; y++)
                       {                      
                           if (view2.RowTable.Rows[y].Cells[0].Value.ToString() == "Version")
                           {                             
                               gvday = data2.Rows[y].Cells[0].Value.ToString();                               
                               break; // exit loop as soon as we find GV #
                           }                          
                       }
                       dgvEPMServerStatus.DataSource = ds.Tables["TM1DataTable"];                    
                       txtCurrentGVNumber.Text = "Current day: \n"+gvday;
                   }

                   catch (TM1API.TM1LoginFailureException ex)
                   {
                       MessageBox.Show(ex.Message);
                       return;
                   }
               } // end for loop
           } // end if
       }
       private void btnConnectEPM_Click(object sender, EventArgs e)
       {
           loadEPMStatus();
          /* string serverName, cubeName, viewName;
           TM1API.TM1AdminServer asCurrent = new TM1API.TM1AdminServer("uavvl1pha.fg.rbc.com;uavvl2pha.fg.rbc.com;uavvl3pha.fg.rbc.com;uavvl4pha.fg.rbc.com", "tm1adminserver");
           TM1API.TM1Server myServer = null;

           // dataset holding the TM1 data
           DataSet ds = new DataSet();
           ds.Tables.Add("TM1DataTable");

           ds.Tables.Add("TM1DataTable2"); // table for GV

           ds.Tables["TM1DataTable"].Columns.Add("Server");
           ds.Tables["TM1DataTable"].Columns.Add("Scenario");

           ds.Tables["TM1DataTable2"].Columns.Add("Server"); // for GV
           ds.Tables["TM1DataTable2"].Columns.Add("Control measures");
           bool columnsAdded = false;

           for (int j = 0; j < chkEPMCubes.Items.Count; j++)
           {
           if (chkEPMCubes.GetItemCheckState(j) == CheckState.Checked)
           {

               serverName = chkEPMCubes.Items[j].ToString();
               cubeName = cubeViewName[j, 0];
               viewName = cubeViewName[j, 1];
             

           try
           {
               myServer = asCurrent.Servers[serverName].LoginUsingCAMNamespace("maple", txtEPMUserName.Text, txtEPMPassword.Text);
               TM1API.TM1CubeCollection myCubes = myServer.Cubes;
               TM1API.TM1Cube myCube = myCubes[cubeName];

               TM1API.TM1Cube myCube2 = myCubes["control"]; // for GV

               TM1API.TM1View view = myCube.PublicViews[viewName];
               
               TM1API.TM1View view2 = myCube2.PublicViews["default"]; // view to get the GV#

               TM1API.TM1DataTable data = view.DataTable;
               TM1API.TM1DataTable data2 = view2.DataTable;  // table for the gv day
            
               int ColumnCount = view.ColumnTable.Rows[0].Cells.Count;
               int RowCount = view.RowTable.Rows.Count;

               int ColumnCount2 = view2.ColumnTable.Rows[0].Cells.Count; // for GV days
               int RowCount2 = view2.RowTable.Rows.Count;
             
               // Loop through the columns and add the names of the column elements to the Table.
               if (!columnsAdded)
               {
                   for (int i = 0; i < ColumnCount; i++)
                   {
                       // Create a new Column in the DataTable by getting the Column header from the TM1 View.
                       ds.Tables["TM1DataTable"].Columns.Add(view.ColumnTable.Rows[0].Cells[i].Value);

                      // ds.Tables["TM1DataTable2"].Columns.Add(view2.ColumnTable.Rows[0].Cells[i].Value); // for GV
                   }
                   columnsAdded = true;
                }

               // for GV
               for (int i = 0; i < ColumnCount2; i++)
               {
                   // Create a new Column in the DataTable by getting the Column header from the TM1 View.
                   ds.Tables["TM1DataTable2"].Columns.Add(view2.ColumnTable.Rows[0].Cells[i].Value);

                   // ds.Tables["TM1DataTable2"].Columns.Add(view2.ColumnTable.Rows[0].Cells[i].Value); // for GV
               }

               // Columnm Headers are created. Now get the rows and thier data and bind them to the columns.
               for (int y = 0; y < RowCount; y++)
               {
                   DataRow rowNew = ds.Tables["TM1DataTable"].NewRow();
                   rowNew["Server"] = serverName;
                   rowNew["Scenario"] = view.RowTable.Rows[y].Cells[0].Value;
                   // Get the first row in the TM1DataTable
                   TM1API.TM1DataRow Row = data.Rows[y];
                   int a = 2;
                   // Now I loop through the TM1Rows and retrive their values 1 row at a time.
                   foreach (TM1API.TM1DataCell cell in Row.Cells)
                   {
                       // bind the cell value to the first column, second column, etc...
                       rowNew[a] = cell.Value;
                       a++;
                   }
                   // The row is now has values... Add it to the Table. 
                   ds.Tables["TM1DataTable"].Rows.Add(rowNew);
                   // Go back and add all the rows until you hit the last row.
               }

               // for GV
               string gvday = "";
               for (int y = 0; y < RowCount2; y++)
               {
                   DataRow rowNew = ds.Tables["TM1DataTable2"].NewRow();
                   rowNew["Server"] = serverName;
                   rowNew["Control measures"] = view2.RowTable.Rows[y].Cells[0].Value;
                 if(view2.RowTable.Rows[y].Cells[0].Value.ToString() == "Version")
                 {
                    // TM1API.TM1DataRow Row2 = data2.Rows[y];
                    // string gvday = data2.Rows[y].Cells[1].Value.ToString();
                     gvday = data2.Rows[y].Cells[0].Value.ToString();
                     Console.WriteLine(gvday);
                     break;
                         
                 }
                   // Get the first row in the TM1DataTable
                   TM1API.TM1DataRow Row = data2.Rows[y];
                   int a = 2;
                   // Now I loop through the TM1Rows and retrive their values 1 row at a time.
                   foreach (TM1API.TM1DataCell cell in Row.Cells)
                   {
                       // bind the cell value to the first column, second column, etc...
                       rowNew[a] = cell.Value;
                     //  Console.WriteLine("Value " +rowNew[a].ToString());
                       a++;
                   }
                   // The row is now has values... Add it to the Table. 
                   ds.Tables["TM1DataTable2"].Rows.Add(rowNew);
                   // Go back and add all the rows until you hit the last row.
               }
               dgvEPMServerStatus.DataSource = ds.Tables["TM1DataTable"];
               dgvEPMInfo.DataSource = ds.Tables["TM1DataTable2"];

               int rowCounter = dgvEPMInfo.Rows.Count-3;
               string currentGV = dgvEPMInfo.Rows[12].Cells["value"].Value.ToString(); //rowCounter-1
               //Console.WriteLine(rowCounter);
               txtCurrentGVNumber.Text = gvday;
           }
         
           catch (TM1API.TM1LoginFailureException ex)
           {
               MessageBox.Show(ex.Message);
               return;
           }
           } // end for loop
           } // end if
      */ }
       
       private void populateSchedule(ref DataRow newRow, int catalogueRowNum, string gvNum, ref System.Data.DataTable mySchedule)
       {
           string dueTime = dgvResourcing.Rows[catalogueRowNum].Cells["Delivery Date Time"].Value.ToString();
           string processTime = String.IsNullOrEmpty(dgvResourcing.Rows[catalogueRowNum].Cells["Processing Time"].Value.ToString()) ? "GV0@0" : dgvResourcing.Rows[catalogueRowNum].Cells["Processing Time"].Value.ToString();
           
           // if setup time is null or empty (frequently it is), then make it 0
           string setUpTime = String.IsNullOrEmpty(dgvResourcing.Rows[catalogueRowNum].Cells["Setup Time"].Value.ToString()) ? "GV0@0" : dgvResourcing.Rows[catalogueRowNum].Cells["Setup Time"].Value.ToString();          
           string reportNum = dgvResourcing.Rows[catalogueRowNum].Cells["Report Number"].Value.ToString();
           string timeRequired = "";
           string[] splitDueDateGV = dueTime.Split(';');
           string[] splitProcessingTimeGV = processTime.Split(';');
           string[] splitSetUpTimeGV = setUpTime.Split(';');
          

           for (int i = 0; i < splitDueDateGV.Length; i++)
           {
               string[] splitTime = splitDueDateGV[i].Split('@');
               string[] splitProcessingTime;             

               // FOR Processing time: ensure no out of bound error happens when gv due time is in sharepoing for a gv day, but processing time for that gv is not provided
               if (splitDueDateGV.Length > splitProcessingTimeGV.Length)
               {
                   splitProcessingTime = splitProcessingTimeGV[splitProcessingTimeGV.Length - 1].Split('@');
               }
               else
               {
                   splitProcessingTime = splitProcessingTimeGV[i].Split('@');
               }
               // For set up time, process is not the same as for the processing time as set up time may not occur on every GV. Hence, we use a different function below called "findSetUpTime"            

               for (int j = 1; j < splitTime.Length; j++ )
               {                   
                   if (gvNum.Trim() == splitTime[0].Trim())
                   {
                      string[] splitTimeIntraday = splitTime[j].Split('&'); 
                      
                      for(int k = 0; k< splitTimeIntraday.Length; k++)
                      {
                          // do calculation based on machine time or processing time
                          if(rbProcTime.Checked)
                          {
                              timeRequired = splitProcessingTime[j];
                              //Console.WriteLine("Processing tme: " + timeRequired);
                          }
                          else if (rbSetUp.Checked)
                          {
                              timeRequired = findSetUpTime(ref splitSetUpTimeGV, gvNum.Trim());
                              //Console.WriteLine("Set up time: " + timeRequired);
                          }
                          else
                          {                             
                              timeRequired = Convert.ToString(Convert.ToDouble(splitProcessingTime[j]) + Convert.ToDouble(findSetUpTime(ref splitSetUpTimeGV, gvNum.Trim())));
                          }

                          int[] myStartEndTime = findReportStartingTime(timeRequired, splitTimeIntraday[k]); // get required start and end time
                          drawTimeSlot(myStartEndTime, catalogueRowNum, ref newRow);                       
                      }                      
                   }                       
               }              
           }       
       }

       // find set up time for a current GV (if any). Set up time is different from Machine time because for every GV run, we have a machine time, which is not the case for set up time
       private string findSetUpTime(ref string[] setUpTimArr, string gvDay)
       {
           string setUpTime = "0";
           string[] splitSetUpTime;
           if (setUpTimArr.Length == 0)
           {
               setUpTime = "0";
           }
           else
           {
               for (int i = 0; i < setUpTimArr.Length; i++)
               {
                   splitSetUpTime = setUpTimArr[i].Split('@');
                   for (int j = 1; j < splitSetUpTime.Length; j++)
                   {
                        if (gvDay ==  splitSetUpTime[0].Trim())
                        {
                            setUpTime = splitSetUpTime[1].Trim();                          
                            return setUpTime;
                        }
                   }                  
               }           
           }          
           return setUpTime;
       }
        // 2 arrayst holding number of minutes occupied with report runs and total number of reports. Both arrays will be used to populate stats in the hourly summy datagrid view
       int[] minuteStats, reportCountStats;
       private void drawTimeSlot(int[] timeSlots, int rowNum, ref DataRow newRow)
       {       
           // declare arrays to store total minutes by hour and total number of reports by hour          
           int minuteCounter, reportCounter;

           //Console.WriteLine("row number: " + rowNum + "size of grid : " + tbpgMySchedule.Rows.Count);
           string startTimeFilling = "", tempStr = ""; ;
           int currentHour = timeSlots[0];

           // case when report has to be started in the previous hour (or several hours back) from the hour it is due
           if(timeSlots[0] < timeSlots[2])
           {
               while (currentHour <= timeSlots[2])
               {
                   reportCounter = 0;
                   minuteCounter = 0;
                   startTimeFilling = ""; // reset the cell filling when we move to the next hour column
                   for (int i = 0; i < 60; i++)
                   {
                       // need exception in case there are 2 reports where for example, 1 report ends at 10:15 and for the same report another intraday run starts at 10:30. We need to ensure that the time span from 10 to 10:15 is not wiped out by case 1 below
                       if (currentHour == timeSlots[0] && i < timeSlots[1]) // if current hr = start hour and current min < start minute 
                       {
                           int j = 0;
                           if (newRow[3 + currentHour].ToString().Length == 0 ) // when the cell is epmty
                           {
                               startTimeFilling += " ";
                               //Console.WriteLine("Case 1 Row number: " + rowNum + " current hr: " + currentHour + " i : " + i + " timeslot 0 " + timeSlots[0] + "timeslot 2: " + timeSlots[2] + " length of the cell: " + newRow[3 + currentHour].ToString().Length + " start time filling: " + startTimeFilling);
                           }
                           else // when cell is non-empty and we want to preserve the content Ex: 10-10:15 time slot exits and another report run (intraday) starts at 10:45, then algorithm would overwrite it if this logic doesn't exist 
                           {
                               tempStr = newRow[3 + currentHour].ToString();                               
                               while (tempStr[j] == '|')
                               {
                                   //Console.WriteLine("Case 1.1 Row number: " + rowNum + " current hr: " + currentHour + " i : " + i + " j" + j + " timeslot 0 " + timeSlots[0] + "timeslot 2: " + timeSlots[2] + " length of the cell: " + newRow[3 + currentHour].ToString().Length + " start time filling: " + startTimeFilling);
                                   startTimeFilling += "|";
                                   minuteCounter++;
                                   j++;
                                   i++;
                               }                              
                           }                          
                       }                           
                       else if (currentHour == timeSlots[0] && i >= timeSlots[1]) // if current hr = start hr and current minute > start minute
                       {
                           startTimeFilling += "|";
                           minuteCounter++;
                           //Console.WriteLine("Case 2 Row number: " + rowNum + " current hr: " + currentHour + " i : " + i + " timeslot 1 " + timeSlots[1] + "timeslot 2: " + timeSlots[2] + " start time filling: " + startTimeFilling);
                       }
                       else if (currentHour == timeSlots[2] && i < timeSlots[3])  // if current hr = due hour and current min < due min
                       {
                           startTimeFilling += "|";
                           minuteCounter++;
                           //Console.WriteLine("Case 3 Row number: " + rowNum + " current hr: " + currentHour + " i : " + i + " timeslot 3 " + timeSlots[3] + " start time filling: " + startTimeFilling);
                       }
                       else if (currentHour < timeSlots[2] && currentHour > timeSlots[0]) // if current hr < due hr  AND current hr > start hr (when report is ran for several hours nad current hour is inbetween start and end hours, we just fill the entire hour with | )
                       {
                           startTimeFilling += "|";
                           minuteCounter++;
                           //Console.WriteLine("Case 4 Row number: " + rowNum + " current hr: " + currentHour + " i : " + i + " timeslot 0 " + timeSlots[0] + " start time filling: " + startTimeFilling);
                       }
                       else
                       {
                           startTimeFilling += " ";
                           //Console.WriteLine("Case else Row number: " + rowNum + " current hr: " + currentHour + " i : " + i + " timeslot 0 " + timeSlots[0] + "timeslot 2: " + timeSlots[2] + " start time filling: " + startTimeFilling);
                       }
                          
                   }
                   // store total minutes in the array
                   minuteStats[currentHour] += minuteCounter;
                   //reportCounter++;
                   reportCountStats[currentHour]++;

                   newRow[3+currentHour] = startTimeFilling;
                   currentHour++;

                   

               }
           }
               // case when start and end time are within the same hour
           else if(timeSlots[0] == timeSlots[2])
           {
               minuteCounter = 0;
               startTimeFilling = ""; // reset the cell filling when we move to the next hour column
               for (int i = 0; i < 60; i++)
               {
                   if (i < timeSlots[1])
                   {
                       startTimeFilling += " ";
                   }
                   else if (i >= timeSlots[1] && i < timeSlots[3])
                   {
                       startTimeFilling += "|";
                       minuteCounter++;
                   }
                   else
                   {
                       startTimeFilling += " ";
                   }
               }
               newRow[3 + currentHour] = startTimeFilling;
               // store total minutes in the array
               minuteStats[currentHour] += minuteCounter;
               reportCountStats[currentHour]++;
           }

           
         /*  for (int i = 0; i < 60; i++ )
           {
               if (i < timeSlots[1])
                   startTimeFilling += " ";
               else
                   startTimeFilling += "|";
           }
           
           newRow[timeSlots[0] + 3] = startTimeFilling;

           startTimeFilling = "";
           for (int i = 1; i < 60; i++)
           {               
                   startTimeFilling += " ";               
           }

           newRow[timeSlots[2] + 3] = startTimeFilling; */
          
          
         //  Console.WriteLine(timeSlots[0] + " | " + timeSlots[2]);

          
       }
        
        /* Report start time algorithm: 
        1. Split hours and minutes; Multiply hours by 60 and ADD minutes -> get total minutes
        2. Multiple machine time by 60 -> get total minutes
        3. Subtract 2) from 1) -> get starting time in minutes
        4. Find modulo of 3) -> due time (minutes component)
        5. Subtract 4) from 3)
        6. Divide 5) by 60
        */
       private int[] findReportStartingTime(string processTime, string dueTime)
       {
           string finishHrsStr = "", finishMinsStr = "";
           int finishHrsInt, finishMinsInt;
           string[] splitTime = dueTime.Split(':');
         
          
           // substiture EOD with 5PM
           if(dueTime.Trim() == "EOD")
           {
               finishHrsStr = "17";
               finishMinsStr = "00";
           }
           else
           {
               finishHrsStr = splitTime[0];
               // address a situation when due time in sharepoint is entered simply as an hout due (11AM vs 11:00AM).
               if(splitTime.Length == 1)               
                   finishMinsStr = "0:00";               
               else
                   finishMinsStr = splitTime[1];               
               //finishHrsStr = dueTime.Split(':')[0];
               //finishMinsStr = dueTime.Split(':')[1];
           }         

          // Console.WriteLine(finishHrsStr + " : " + finishMinsStr);
           finishHrsInt = Convert.ToInt32(new String(finishHrsStr.Where(Char.IsDigit).ToArray()));
           finishMinsInt = Convert.ToInt32(new String(finishMinsStr.Where(Char.IsDigit).ToArray()));

           // make adjustement if time is expressed in AM/PM         
           if ((dueTime.Contains("PM") || dueTime.Contains("pm")) && finishHrsInt < 12)
           {
               finishHrsInt+= 12;
           }          

           //convert due time hours to mins and add minutes
           int totalMinutesDueTime = finishHrsInt * 60 + finishMinsInt;
           // convert machine time into minutes
          
           int totalRequiredMins = Convert.ToInt32(60*Convert.ToDouble(processTime));           
           int totalMinutesBeforeStart = totalMinutesDueTime - totalRequiredMins;          

           int startTimeMinutes = totalMinutesBeforeStart % 60;
           int startTimeHours = (totalMinutesBeforeStart-startTimeMinutes)/60;

           int[] reportStartTime = {startTimeHours, startTimeMinutes, finishHrsInt, finishMinsInt};        
           //Console.WriteLine("Start time: " + reportStartTime[0] + ":" + reportStartTime[1] + " finish time" + reportStartTime[2] + " : " + reportStartTime[3]);
           return reportStartTime;
       }


       private void button1_Click_3(object sender, EventArgs e)
       {
           calculateReportSchedule();          
       }

       private void populateChecklistFilter(string levelOfDetails)
       {
         
           if (levelOfDetails == "summary")
           {
               chklstSheduleFields.Items.Clear();
               chklstSheduleFields.Items.Add("Hour");
               chklstSheduleFields.Items.Add("Total Minutes");
               chklstSheduleFields.Items.Add("Number of Reports"); 
           }
           else
           {
               chklstSheduleFields.Items.Clear();
               chklstSheduleFields.Items.Add("GV");
               chklstSheduleFields.Items.Add("Preparer");
               chklstSheduleFields.Items.Add("Report");

               for (int i = 0; i < 24; i++)
               {
                   chklstSheduleFields.Items.Add(i + ":00 ");
               }
           }
       }

       private void calculateReportSchedule()
       {
           tbpgMySchedule.DataSource = null;
           tbpgMySchedule.Rows.Clear();

           System.Data.DataTable mySchedule = new System.Data.DataTable();
           mySchedule.Columns.Add(new DataColumn("GV", typeof(string)));
           mySchedule.Columns.Add(new DataColumn("Preparer", typeof(string)));
           mySchedule.Columns.Add(new DataColumn("Report", typeof(string)));          

           // initialize 2 arrays holding high-level stats for hourly statistics on total minutes and total reports
           minuteStats = new int[24];
           reportCountStats = new int[24];
           // create time columns
           for (int i = 0; i < 24; i++)
           {
               mySchedule.Columns.Add(new DataColumn(i + ":00 ", typeof(string)));              
           }

           int j = 0;
           DataRow newRow;

           //string selectedEmployee, selectedDay;
           foreach (Object selectedDay in lstGvDays.SelectedItems)
           {
               for (int i = 0; i < dgvResourcing.Rows.Count; i++)
               {                  
                   if (dgvResourcing.Rows[i].Cells["Delivery Date Time"].Value.ToString().IndexOf(selectedDay.ToString()) > -1)
                   {
                       newRow = mySchedule.NewRow();
                       newRow[0] = selectedDay.ToString();
                       newRow[1] = dgvResourcing.Rows[i].Cells["Preparer"].Value.ToString();
                       newRow[2] = dgvResourcing.Rows[i].Cells["Report Number"].Value.ToString();
                       populateSchedule(ref newRow, i, Convert.ToString(selectedDay), ref mySchedule);
                       mySchedule.Rows.Add(newRow);
                   }
               }
           }

           if (cmbSheduleDetailLevel.SelectedIndex == 0)  //detailed schedule
           {
               tbpgMySchedule.DataSource = mySchedule;
               //formatHighRiskReports();
               tbpgMySchedule.Columns[2].Frozen = true;
               populateChecklistFilter("details");
           }
           else if(cmbSheduleDetailLevel.SelectedIndex ==  1) // summarized schedule (1 line per preparer)
           {
               // redo and later just consolidate from the datatable, not datagrid view.
               tbpgMySchedule.DataSource = mySchedule;              
               populateChecklistFilter("details");             
               consolidateRunTimes();
               tbpgMySchedule.Columns[1].Frozen = true;
           }
           else  // high-level summary showing hours, number of reports and total minutes only
           {
               populateHourlyStats();
               populateChecklistFilter("summary");
           }
           
           populateFieldNamesCheckBox();                 
         
       }

        // populate datagridview with high-level summary statistics
       private void populateHourlyStats()
       {
           System.Data.DataTable myHourlySummary = new System.Data.DataTable();
           DataRow newRow;

           myHourlySummary.Columns.Add(new DataColumn("Hour", typeof(int)));
           myHourlySummary.Columns.Add(new DataColumn("Total Minutes", typeof(int)));
           myHourlySummary.Columns.Add(new DataColumn("Number of Reports", typeof(int)));

           for (int i = 0; i < minuteStats.Length; i++)
           {
               newRow = myHourlySummary.NewRow();
               newRow[0] = i;
               newRow[1] = minuteStats[i];
               newRow[2] = reportCountStats[i];
               myHourlySummary.Rows.Add(newRow);
           }
           tbpgMySchedule.DataSource = myHourlySummary;
            
           
       }
        
       // format EUC report cells
       private void formatHighRiskReports()
       {
           //tbpgMySchedule.Rows[1].Cells["Report"].Style.ForeColor = Color.Red;
       }

       private void btnShowHideHours_MouseHover(object sender, EventArgs e)
       {
           hideUnhideFieldFilter();
       }

       bool fieldFilterApplied;
       private void hideUnhideFieldFilter()
       {
           if (!fieldFilterApplied) // unhide the checklist
           {
               btnShowHideHours.Text = "Show/Hide Hours ↑";
               chklstSheduleFields.Visible = true;
               fieldFilterApplied = true;
           }
           else // hide the checklist
           {
               btnShowHideHours.Text = "Show/Hide Hours ↓";
               chklstSheduleFields.Visible = false;
               fieldFilterApplied = false;
              // displaySelectedFields();
           }
       }      

     

       private void chklstSheduleFields_MouseLeave(object sender, EventArgs e)
       {
           hideUnhideFieldFilter();
       }

       private void chklstSheduleFields_SelectedIndexChanged(object sender, EventArgs e)
       {
           for (int i = 0; i < chklstSheduleFields.Items.Count; i++)
           {
              
               if (chklstSheduleFields.GetItemCheckState(i) != CheckState.Checked)
               {
                   tbpgMySchedule.Columns[i].Visible = false;
               }
               else
               {
                   tbpgMySchedule.Columns[i].Visible = true;                   
               }
           }
       }


       private void populateFieldNamesCheckBox()
       {

           string[] hiddenFields = {"0:00","1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00", "19:00", "20:00", "21:00", "22:00", "23:00", "24:00" };  // array of fields to be hidden by default
          
           int i = 0;
           
           foreach (DataGridViewColumn column in tbpgMySchedule.Columns)
           {

               
               if (!hiddenFields.Contains(column.Name.ToString().Trim()))
               {                                  
                   chklstSheduleFields.SetItemCheckState(i, CheckState.Checked);
                   
               }
               else
               {
                   tbpgMySchedule.Columns[i].Visible = false;
               }

               if(i>2)
                    colorDataGridViewCell(i);
             
               i++;
           }
       }
        // change forecolor of columns containing report times to red
        private void colorDataGridViewCell(int colNum)
        {            
            foreach (DataGridViewRow row in tbpgMySchedule.Rows)
            {
                tbpgMySchedule.Rows[row.Index].Cells[colNum].Style.ForeColor = Color.Red;
            }
        }
       

        private void consolidateRunTimes()
        {          

            System.Data.DataTable mySchedule = new System.Data.DataTable();
            mySchedule.Columns.Add(new DataColumn("GV", typeof(string)));
            mySchedule.Columns.Add(new DataColumn("Preparer", typeof(string)));

            // initialize 2 arrays holding high-level stats for hourly statistics on total minutes and total reports
            minuteStats = new int[24];
            reportCountStats = new int[24];
            // create time columns
           
            
            for (int i = 0; i < 24; i++)
            {
                mySchedule.Columns.Add(new DataColumn(i + ":00 ", typeof(string)));
            }

            DataRow newRow;



            // get unique list of GV names
            string[] gvDays = tbpgMySchedule.Rows
              .Cast<DataGridViewRow>()
              .Where(row => !row.IsNewRow)
              .Where(col => col.Cells[0].Value.ToString() != null)
              .Where(col => col.Cells[0].Value.ToString() != "")
              .Select(row => Convert.ToString(row.Cells[0].Value.ToString())).ToArray();


            var gvUniqueDays = from p in gvDays
                                       group p by p into g
                                       select g.Key;

            // loop through each GV day
            foreach (var gv in gvUniqueDays)
            {
                // get unique list of preparers' names
                    string[] preparersNames = tbpgMySchedule.Rows
                      .Cast<DataGridViewRow>()
                      .Where(row => !row.IsNewRow)
                      .Where(col => col.Cells[1].Value.ToString() != null)
                      .Where(col => col.Cells[1].Value.ToString() != "")
                      .Select(row => Convert.ToString(row.Cells[1].Value.ToString())).ToArray();

                    var preparersUniqueNames = from p in preparersNames
                                               group p by p into g
                                               select g.Key;

                    int nameCounter= 0;            
                    // loop through each individual
                    foreach (var name in preparersUniqueNames)
                    {                      
                        nameCounter++;
                        newRow = mySchedule.NewRow();               

                        // loop through each hour
                        for (int k = 3; k < 27; k++)
                        {
                            string currentHour = "";
                            string myStr = "";
                            bool blank;

                            string[] reportRunArray = tbpgMySchedule.Rows
                            .Cast<DataGridViewRow>()
                            .Where(row => !row.IsNewRow)
                            .Where(col => col.Cells[k].Value.ToString() != null)
                            .Where(col => col.Cells[k].Value.ToString() != "")
                            .Where(col => col.Cells[0].Value.ToString() == gv)
                            .Where(col => col.Cells[1].Value.ToString() == name)
                            .Select(row => Convert.ToString(row.Cells[k].Value.ToString())).ToArray();
               
                            // loop though each of the 60 minute characters represented by |
                            for (int j = 0; j < 60; j++)
                            {
                                blank = true;
                                // loop through each record
                                for (int i = 0; i < reportRunArray.Length; i++)
                                {
                                    currentHour = reportRunArray[i].ToString();
                                    //Console.WriteLine("gv: " + gv + " name: " + name + " k value" + k + " i value: " + i + " current hr: " + currentHour);
                                    if (currentHour[j] == '|')
                                    {
                                        myStr += "|";
                                        blank = false;
                                        break;
                                    }
                                }
                                if (blank)
                                    myStr += " ";
                            }
                            newRow[k-1] = myStr;
                           // tbpgMySchedule.Rows[nameCounter].Cells[k].Value = myStr;
                   
                        }
                        newRow[0] = gv;
                        newRow[1] = name;
                        mySchedule.Rows.Add(newRow);
                    }
            }
            tbpgMySchedule.DataSource = mySchedule;
            
        }



        private System.Data.DataTable createScheduleTable()
        {
            System.Data.DataTable mySchedule = new System.Data.DataTable();
           // mySchedule.Columns.Add(new DataColumn("GV", typeof(string)));
            mySchedule.Columns.Add(new DataColumn("Preparer", typeof(string)));
          

            // initialize 2 arrays holding high-level stats for hourly statistics on total minutes and total reports
            minuteStats = new int[24];
            reportCountStats = new int[24];
            // create time columns
            for (int i = 0; i < 24; i++)
            {
                mySchedule.Columns.Add(new DataColumn(i + ":00 ", typeof(string)));
            }

            return mySchedule;
           // int j = 0;
           // DataRow newRow;

            //string selectedEmployee, selectedDay;
            /*foreach (Object selectedDay in lstGvDays.SelectedItems)
            {
                for (int i = 0; i < dgvResourcing.Rows.Count; i++)
                {
                    if (dgvResourcing.Rows[i].Cells["Delivery Date Time"].Value.ToString().IndexOf(selectedDay.ToString()) > -1)
                    {
                        newRow = mySchedule.NewRow();
                        newRow[0] = selectedDay.ToString();
                        newRow[1] = dgvResourcing.Rows[i].Cells["Preparer"].Value.ToString();
                        newRow[2] = dgvResourcing.Rows[i].Cells["Report Number"].Value.ToString();
                        populateSchedule(ref newRow, i, Convert.ToString(selectedDay), ref mySchedule);
                        mySchedule.Rows.Add(newRow);
                    }
                }
            } */
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Console.WriteLine(tbpgMySchedule.Columns[13].Width); 
            for(int i = 0; i< 24; i++)
            {
                tbpgMySchedule.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None; 
                tbpgMySchedule.Columns[i].Width += 10;
            }
        }

        private void btnKeywordSearch_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This functionality is in development");
        }
    }
}

