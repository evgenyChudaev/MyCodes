﻿namespace myFSSRS_SharePoint_Viewer
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cmsDatagrid = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiOpenSpForm = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiEditSPForm = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNewSPForm = new System.Windows.Forms.ToolStripMenuItem();
            this.tssEmail = new System.Windows.Forms.ToolStripSeparator();
            this.tsmiDatagridEmail = new System.Windows.Forms.ToolStripMenuItem();
            this.questionForReportContactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiDataGridEmailValidate = new System.Windows.Forms.ToolStripMenuItem();
            this.openProductionFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.imglIcons = new System.Windows.Forms.ImageList(this.components);
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslNoOfItems = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExportToExcel = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExportCurrentList = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExportAllListsInView = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exceptionFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMILatestExceptionFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExceptionFileListing = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goToHelpMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbRefreshData = new System.Windows.Forms.ToolStripButton();
            this.tbpgReportCatalogue = new System.Windows.Forms.TabPage();
            this.tbctlReportCatalogue = new System.Windows.Forms.TabControl();
            this.tbpgResourcing = new System.Windows.Forms.TabPage();
            this.txtFilterName = new System.Windows.Forms.TextBox();
            this.panelSharepointLoadProgress = new System.Windows.Forms.Panel();
            this.txtLoadProgress = new System.Windows.Forms.TextBox();
            this.pgbLoadSharepointData = new System.Windows.Forms.ProgressBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.splitContainerFilters = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.lstDataSource = new System.Windows.Forms.ListBox();
            this.lstDeploymentTool = new System.Windows.Forms.ListBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lstTeamManager = new System.Windows.Forms.ListBox();
            this.chlstPlatform = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lstRelationshipManager = new System.Windows.Forms.ListBox();
            this.Platform = new System.Windows.Forms.Label();
            this.lstReportStatus = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnUpdateFilter = new System.Windows.Forms.Button();
            this.cmbSavedFilters = new System.Windows.Forms.ComboBox();
            this.btnRemoveFilter = new System.Windows.Forms.Button();
            this.btnAddFilter = new System.Windows.Forms.Button();
            this.btnLoadDefaultSettings = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.btnExpandCatalogueFilter = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lstGvDays = new System.Windows.Forms.ListBox();
            this.rbTotalReportCount = new System.Windows.Forms.RadioButton();
            this.lstFrequency = new System.Windows.Forms.ListBox();
            this.rbDataSource = new System.Windows.Forms.RadioButton();
            this.rbDeploymentTools = new System.Windows.Forms.RadioButton();
            this.rbSetupTime = new System.Windows.Forms.RadioButton();
            this.dgvResourcing = new System.Windows.Forms.DataGridView();
            this.rbRptCount = new System.Windows.Forms.RadioButton();
            this.rbProcessTime = new System.Windows.Forms.RadioButton();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lstEmployees = new System.Windows.Forms.ListBox();
            this.dgvSummaryView = new System.Windows.Forms.DataGridView();
            this.txtSearchCatalogue = new System.Windows.Forms.TextBox();
            this.cmbFieldFilterReportCatalogue = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tbpgResourcingWorkflow = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.cmbFieldFilterWorkflow = new System.Windows.Forms.ComboBox();
            this.txtSearchWorkflow = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chartPlatform = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartCategory = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartStatus = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.rbEffortRequired = new System.Windows.Forms.RadioButton();
            this.rbRequestCategory = new System.Windows.Forms.RadioButton();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.dgvResourcingWorkflow = new System.Windows.Forms.DataGridView();
            this.lstStatus = new System.Windows.Forms.ListBox();
            this.lstCategory = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.rbBetween = new System.Windows.Forms.RadioButton();
            this.rbBefore = new System.Windows.Forms.RadioButton();
            this.rbFrom = new System.Windows.Forms.RadioButton();
            this.chkIncludeAllWorkflow = new System.Windows.Forms.CheckBox();
            this.chkIncludeAllDates = new System.Windows.Forms.CheckBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbpgKPI = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvTest = new System.Windows.Forms.DataGridView();
            this.cmsMetrics = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiFilterEquals = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiEquals = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiFilterNotEquals = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNotEquals = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiClearKPIFilter = new System.Windows.Forms.ToolStripMenuItem();
            this.lbNoResultsDaysOutstanding = new System.Windows.Forms.Label();
            this.lbNoResultsDaysLeft = new System.Windows.Forms.Label();
            this.chartDaysLeft = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartDaysOutstanding = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lbNoResultsAcknowledgement = new System.Windows.Forms.Label();
            this.btnEnterPassword = new System.Windows.Forms.Button();
            this.dgvKPI = new System.Windows.Forms.DataGridView();
            this.chartAcknowledge = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOverdueAcknowledge = new System.Windows.Forms.TextBox();
            this.txtTotalItems = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chkShowOverdueOnly = new System.Windows.Forms.CheckBox();
            this.chCalculateKPI = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbAcknowledgementOtherSLA = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbAcknowledgementSLA = new System.Windows.Forms.NumericUpDown();
            this.btn_CalcKPI = new System.Windows.Forms.Button();
            this.tbpgWorkday = new System.Windows.Forms.TabPage();
            this.cmbSheduleDetailLevel = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rbProcTime = new System.Windows.Forms.RadioButton();
            this.rbBoth = new System.Windows.Forms.RadioButton();
            this.rbSetUp = new System.Windows.Forms.RadioButton();
            this.chklstSheduleFields = new System.Windows.Forms.CheckedListBox();
            this.btnShowHideHours = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tbpgMySchedule = new System.Windows.Forms.DataGridView();
            this.lstTransitionAnalyst = new System.Windows.Forms.ListBox();
            this.btnLoadTransitionSpreadsheet = new System.Windows.Forms.Button();
            this.dgvTransitions = new System.Windows.Forms.DataGridView();
            this.requestSubmissionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database4DataSet = new myFSSRS_SharePoint_Viewer.Database4DataSet();
            this.tbctlMain = new System.Windows.Forms.TabControl();
            this.tbclTransition = new System.Windows.Forms.TabPage();
            this.tbclExcel = new System.Windows.Forms.TabControl();
            this.tbDashboardRollover = new System.Windows.Forms.TabPage();
            this.chkRolloverTeam = new System.Windows.Forms.CheckBox();
            this.btnShowRolloverFieldPanel = new System.Windows.Forms.Button();
            this.btnLoadRollover = new System.Windows.Forms.Button();
            this.lstRolloverAnalyst = new System.Windows.Forms.ListBox();
            this.panelRollover = new System.Windows.Forms.Panel();
            this.chkGuessFilePathRollover = new System.Windows.Forms.CheckBox();
            this.btnSaveRolloverSettings = new System.Windows.Forms.Button();
            this.chkPreselectedRolloverFields = new System.Windows.Forms.CheckBox();
            this.tbnBrowseRollover = new System.Windows.Forms.Button();
            this.txtRolloverPath = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.chklstRolloverFields = new System.Windows.Forms.CheckedListBox();
            this.dgvRolloverDashBoard = new System.Windows.Forms.DataGridView();
            this.tbclTransitions = new System.Windows.Forms.TabPage();
            this.chkTransitionTeam = new System.Windows.Forms.CheckBox();
            this.btnShowFieldPanel = new System.Windows.Forms.Button();
            this.panelFieldSelections = new System.Windows.Forms.Panel();
            this.chkGuessFilePath = new System.Windows.Forms.CheckBox();
            this.btnSaveTransitionSettings = new System.Windows.Forms.Button();
            this.chkPreselectedTransitionFields = new System.Windows.Forms.CheckBox();
            this.tbnBrowseTransition = new System.Windows.Forms.Button();
            this.txtTransitionPath = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.chklstTransitionFields = new System.Windows.Forms.CheckedListBox();
            this.dgvETActive = new System.Windows.Forms.DataGridView();
            this.dgvRAActive = new System.Windows.Forms.DataGridView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnKeywordSearch = new System.Windows.Forms.Button();
            this.cmbFieldFilterFDM = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.txtFDMKeyword = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cmbSelectTopN = new System.Windows.Forms.ComboBox();
            this.chkTopN = new System.Windows.Forms.CheckBox();
            this.chkSelectAll = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.lstTableName = new System.Windows.Forms.ListBox();
            this.cmbDatabaseName = new System.Windows.Forms.ComboBox();
            this.tbnSearchFDM = new System.Windows.Forms.Button();
            this.dgvFDM = new System.Windows.Forms.DataGridView();
            this.tbclEPM = new System.Windows.Forms.TabPage();
            this.tbEPMServerStatus = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label28 = new System.Windows.Forms.Label();
            this.txtCurrentGVNumber = new System.Windows.Forms.TextBox();
            this.chkEPMCubes = new System.Windows.Forms.CheckedListBox();
            this.dgvEPMServerStatus = new System.Windows.Forms.DataGridView();
            this.txtEPMUserName = new System.Windows.Forms.TextBox();
            this.btnConnectEPM = new System.Windows.Forms.Button();
            this.txtEPMPassword = new System.Windows.Forms.TextBox();
            this.lbuserName = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dsSharePointViewer = new myFSSRS_SharePoint_Viewer.dsSharePointViewer();
            this.dtRSActiveBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.request_SubmissionTableAdapter = new myFSSRS_SharePoint_Viewer.Database4DataSetTableAdapters.Request_SubmissionTableAdapter();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.btnRefresh = new System.Windows.Forms.ToolStripButton();
            this.toolTipAddFilter = new System.Windows.Forms.ToolTip(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.cmsDatagrid.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tbpgReportCatalogue.SuspendLayout();
            this.tbctlReportCatalogue.SuspendLayout();
            this.tbpgResourcing.SuspendLayout();
            this.panelSharepointLoadProgress.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.splitContainerFilters.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResourcing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummaryView)).BeginInit();
            this.tbpgResourcingWorkflow.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartPlatform)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResourcingWorkflow)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.tbpgKPI.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).BeginInit();
            this.cmsMetrics.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDaysLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartDaysOutstanding)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKPI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAcknowledge)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbAcknowledgementOtherSLA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbAcknowledgementSLA)).BeginInit();
            this.tbpgWorkday.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbpgMySchedule)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransitions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestSubmissionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet)).BeginInit();
            this.tbctlMain.SuspendLayout();
            this.tbclTransition.SuspendLayout();
            this.tbclExcel.SuspendLayout();
            this.tbDashboardRollover.SuspendLayout();
            this.panelRollover.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolloverDashBoard)).BeginInit();
            this.tbclTransitions.SuspendLayout();
            this.panelFieldSelections.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvETActive)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRAActive)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFDM)).BeginInit();
            this.tbclEPM.SuspendLayout();
            this.tbEPMServerStatus.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEPMServerStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSharePointViewer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtRSActiveBindingSource)).BeginInit();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmsDatagrid
            // 
            this.cmsDatagrid.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsDatagrid.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.tssEmail,
            this.tsmiDatagridEmail,
            this.tsmiDataGridEmailValidate,
            this.openProductionFolderToolStripMenuItem});
            this.cmsDatagrid.Name = "cmsRSActive";
            this.cmsDatagrid.Size = new System.Drawing.Size(237, 106);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiOpenSpForm,
            this.tsmiEditSPForm,
            this.tsmiNewSPForm});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(236, 24);
            this.toolStripMenuItem3.Text = "SharePoint";
            // 
            // tsmiOpenSpForm
            // 
            this.tsmiOpenSpForm.Name = "tsmiOpenSpForm";
            this.tsmiOpenSpForm.Size = new System.Drawing.Size(199, 26);
            this.tsmiOpenSpForm.Text = "Open Form";
            this.tsmiOpenSpForm.Click += new System.EventHandler(this.tsmiOpenSpForm_Click);
            // 
            // tsmiEditSPForm
            // 
            this.tsmiEditSPForm.Name = "tsmiEditSPForm";
            this.tsmiEditSPForm.Size = new System.Drawing.Size(199, 26);
            this.tsmiEditSPForm.Text = "Edit Form";
            this.tsmiEditSPForm.Click += new System.EventHandler(this.tsmiEditSPForm_Click);
            // 
            // tsmiNewSPForm
            // 
            this.tsmiNewSPForm.Name = "tsmiNewSPForm";
            this.tsmiNewSPForm.Size = new System.Drawing.Size(199, 26);
            this.tsmiNewSPForm.Text = "Create New Form";
            this.tsmiNewSPForm.Click += new System.EventHandler(this.tsmiNewSPForm_Click);
            // 
            // tssEmail
            // 
            this.tssEmail.Name = "tssEmail";
            this.tssEmail.Size = new System.Drawing.Size(233, 6);
            // 
            // tsmiDatagridEmail
            // 
            this.tsmiDatagridEmail.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.questionForReportContactToolStripMenuItem});
            this.tsmiDatagridEmail.Name = "tsmiDatagridEmail";
            this.tsmiDatagridEmail.Size = new System.Drawing.Size(236, 24);
            this.tsmiDatagridEmail.Text = "Email";
            // 
            // questionForReportContactToolStripMenuItem
            // 
            this.questionForReportContactToolStripMenuItem.Name = "questionForReportContactToolStripMenuItem";
            this.questionForReportContactToolStripMenuItem.Size = new System.Drawing.Size(272, 26);
            this.questionForReportContactToolStripMenuItem.Text = "Question For Report Contact";
            // 
            // tsmiDataGridEmailValidate
            // 
            this.tsmiDataGridEmailValidate.Name = "tsmiDataGridEmailValidate";
            this.tsmiDataGridEmailValidate.Size = new System.Drawing.Size(236, 24);
            this.tsmiDataGridEmailValidate.Text = "Validate Recipients";
            // 
            // openProductionFolderToolStripMenuItem
            // 
            this.openProductionFolderToolStripMenuItem.Name = "openProductionFolderToolStripMenuItem";
            this.openProductionFolderToolStripMenuItem.Size = new System.Drawing.Size(236, 24);
            this.openProductionFolderToolStripMenuItem.Text = "Open Production Folder";
            // 
            // imglIcons
            // 
            this.imglIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglIcons.ImageStream")));
            this.imglIcons.TransparentColor = System.Drawing.Color.Transparent;
            this.imglIcons.Images.SetKeyName(0, "Refresh Load 24.png");
            this.imglIcons.Images.SetKeyName(1, "Refresh Load 24 bright.png");
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslNoOfItems,
            this.toolStripStatusLabel1,
            this.tsslStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 835);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1594, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslNoOfItems
            // 
            this.tsslNoOfItems.Name = "tsslNoOfItems";
            this.tsslNoOfItems.Size = new System.Drawing.Size(0, 20);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(48, 20);
            this.toolStripStatusLabel1.Text = "Items:";
            // 
            // tsslStatus
            // 
            this.tsslStatus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.tsslStatus.Name = "tsslStatus";
            this.tsslStatus.Size = new System.Drawing.Size(1526, 20);
            this.tsslStatus.Spring = true;
            this.tsslStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // menuStrip1
            // 
            this.menuStrip1.AutoSize = false;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.exceptionFileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(1594, 30);
            this.menuStrip1.Stretch = false;
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiExportToExcel,
            this.toolStripSeparator1,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // tsmiExportToExcel
            // 
            this.tsmiExportToExcel.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiExportCurrentList,
            this.tsmiExportAllListsInView});
            this.tsmiExportToExcel.Name = "tsmiExportToExcel";
            this.tsmiExportToExcel.Size = new System.Drawing.Size(186, 26);
            this.tsmiExportToExcel.Text = "Export To Excel";
            // 
            // tsmiExportCurrentList
            // 
            this.tsmiExportCurrentList.Name = "tsmiExportCurrentList";
            this.tsmiExportCurrentList.Size = new System.Drawing.Size(196, 26);
            this.tsmiExportCurrentList.Text = "Current List";
            this.tsmiExportCurrentList.Click += new System.EventHandler(this.tsmiExportCurrentList_Click);
            // 
            // tsmiExportAllListsInView
            // 
            this.tsmiExportAllListsInView.Name = "tsmiExportAllListsInView";
            this.tsmiExportAllListsInView.Size = new System.Drawing.Size(196, 26);
            this.tsmiExportAllListsInView.Text = "All Lists In {View}";
            this.tsmiExportAllListsInView.Click += new System.EventHandler(this.tsmiExportAllLists_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(183, 6);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(186, 26);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // exceptionFileToolStripMenuItem
            // 
            this.exceptionFileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMILatestExceptionFile,
            this.tsmiExceptionFileListing});
            this.exceptionFileToolStripMenuItem.Name = "exceptionFileToolStripMenuItem";
            this.exceptionFileToolStripMenuItem.Size = new System.Drawing.Size(113, 26);
            this.exceptionFileToolStripMenuItem.Text = "Exception File";
            // 
            // TSMILatestExceptionFile
            // 
            this.TSMILatestExceptionFile.Name = "TSMILatestExceptionFile";
            this.TSMILatestExceptionFile.Size = new System.Drawing.Size(159, 26);
            this.TSMILatestExceptionFile.Text = "Current File";
            this.TSMILatestExceptionFile.ToolTipText = "Retrieves the most recent modified Exception File.";
            this.TSMILatestExceptionFile.Click += new System.EventHandler(this.TSMILatestExceptionFile_Click);
            // 
            // tsmiExceptionFileListing
            // 
            this.tsmiExceptionFileListing.Name = "tsmiExceptionFileListing";
            this.tsmiExceptionFileListing.Size = new System.Drawing.Size(159, 26);
            this.tsmiExceptionFileListing.Text = "File Listing";
            this.tsmiExceptionFileListing.ToolTipText = "Retrieves a listing of Exception Files.";
            this.tsmiExceptionFileListing.Click += new System.EventHandler(this.tsmiExceptionFileListing_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.goToHelpMenuToolStripMenuItem});
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.helpToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(53, 26);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // goToHelpMenuToolStripMenuItem
            // 
            this.goToHelpMenuToolStripMenuItem.Name = "goToHelpMenuToolStripMenuItem";
            this.goToHelpMenuToolStripMenuItem.Size = new System.Drawing.Size(166, 26);
            this.goToHelpMenuToolStripMenuItem.Text = "User manual";
            this.goToHelpMenuToolStripMenuItem.Click += new System.EventHandler(this.goToHelpMenuToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.AllowMerge = false;
            this.toolStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbRefreshData});
            this.toolStrip1.Location = new System.Drawing.Point(2246, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(4, 0, 1, 0);
            this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip1.Size = new System.Drawing.Size(140, 30);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "tsRefreshData";
            // 
            // tsbRefreshData
            // 
            this.tsbRefreshData.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tsbRefreshData.Image = ((System.Drawing.Image)(resources.GetObject("tsbRefreshData.Image")));
            this.tsbRefreshData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tsbRefreshData.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRefreshData.Name = "tsbRefreshData";
            this.tsbRefreshData.Size = new System.Drawing.Size(118, 27);
            this.tsbRefreshData.Text = "Refresh Data";
            this.tsbRefreshData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.tsbRefreshData.Visible = false;
            this.tsbRefreshData.Click += new System.EventHandler(this.tsbRefreshData_Click);
            // 
            // tbpgReportCatalogue
            // 
            this.tbpgReportCatalogue.Controls.Add(this.tbctlReportCatalogue);
            this.tbpgReportCatalogue.Location = new System.Drawing.Point(4, 25);
            this.tbpgReportCatalogue.Margin = new System.Windows.Forms.Padding(4);
            this.tbpgReportCatalogue.Name = "tbpgReportCatalogue";
            this.tbpgReportCatalogue.Padding = new System.Windows.Forms.Padding(4);
            this.tbpgReportCatalogue.Size = new System.Drawing.Size(1838, 767);
            this.tbpgReportCatalogue.TabIndex = 0;
            this.tbpgReportCatalogue.Tag = "tbctlReportCatalogue";
            this.tbpgReportCatalogue.Text = "Sharepoint";
            this.tbpgReportCatalogue.UseVisualStyleBackColor = true;
            // 
            // tbctlReportCatalogue
            // 
            this.tbctlReportCatalogue.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbctlReportCatalogue.ContextMenuStrip = this.cmsDatagrid;
            this.tbctlReportCatalogue.Controls.Add(this.tbpgResourcing);
            this.tbctlReportCatalogue.Controls.Add(this.tbpgResourcingWorkflow);
            this.tbctlReportCatalogue.Controls.Add(this.tbpgKPI);
            this.tbctlReportCatalogue.Controls.Add(this.tbpgWorkday);
            this.tbctlReportCatalogue.ItemSize = new System.Drawing.Size(49, 20);
            this.tbctlReportCatalogue.Location = new System.Drawing.Point(4, 4);
            this.tbctlReportCatalogue.Margin = new System.Windows.Forms.Padding(4);
            this.tbctlReportCatalogue.Name = "tbctlReportCatalogue";
            this.tbctlReportCatalogue.SelectedIndex = 0;
            this.tbctlReportCatalogue.Size = new System.Drawing.Size(1834, 759);
            this.tbctlReportCatalogue.TabIndex = 0;
            this.tbctlReportCatalogue.SelectedIndexChanged += new System.EventHandler(this.tbctlReportCatalogue_SelectedIndexChanged);
            // 
            // tbpgResourcing
            // 
            this.tbpgResourcing.AutoScroll = true;
            this.tbpgResourcing.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tbpgResourcing.Controls.Add(this.splitContainerFilters);
            this.tbpgResourcing.Controls.Add(this.txtFilterName);
            this.tbpgResourcing.Controls.Add(this.panelSharepointLoadProgress);
            this.tbpgResourcing.Controls.Add(this.groupBox3);
            this.tbpgResourcing.Controls.Add(this.label9);
            this.tbpgResourcing.Controls.Add(this.btnExpandCatalogueFilter);
            this.tbpgResourcing.Controls.Add(this.label12);
            this.tbpgResourcing.Controls.Add(this.label11);
            this.tbpgResourcing.Controls.Add(this.lstGvDays);
            this.tbpgResourcing.Controls.Add(this.rbTotalReportCount);
            this.tbpgResourcing.Controls.Add(this.lstFrequency);
            this.tbpgResourcing.Controls.Add(this.rbDataSource);
            this.tbpgResourcing.Controls.Add(this.rbDeploymentTools);
            this.tbpgResourcing.Controls.Add(this.rbSetupTime);
            this.tbpgResourcing.Controls.Add(this.dgvResourcing);
            this.tbpgResourcing.Controls.Add(this.rbRptCount);
            this.tbpgResourcing.Controls.Add(this.rbProcessTime);
            this.tbpgResourcing.Controls.Add(this.chart1);
            this.tbpgResourcing.Controls.Add(this.lstEmployees);
            this.tbpgResourcing.Controls.Add(this.dgvSummaryView);
            this.tbpgResourcing.Controls.Add(this.txtSearchCatalogue);
            this.tbpgResourcing.Controls.Add(this.cmbFieldFilterReportCatalogue);
            this.tbpgResourcing.Controls.Add(this.label20);
            this.tbpgResourcing.Controls.Add(this.label19);
            this.tbpgResourcing.Location = new System.Drawing.Point(4, 24);
            this.tbpgResourcing.Name = "tbpgResourcing";
            this.tbpgResourcing.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgResourcing.Size = new System.Drawing.Size(1826, 731);
            this.tbpgResourcing.TabIndex = 2;
            this.tbpgResourcing.Tag = "dgvResourcing";
            this.tbpgResourcing.Text = "Report Catalog";
            // 
            // txtFilterName
            // 
            this.txtFilterName.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txtFilterName.Location = new System.Drawing.Point(12, 107);
            this.txtFilterName.Name = "txtFilterName";
            this.txtFilterName.Size = new System.Drawing.Size(210, 22);
            this.txtFilterName.TabIndex = 67;
            this.txtFilterName.Visible = false;
            this.txtFilterName.DoubleClick += new System.EventHandler(this.txtFilterName_DoubleClick);
            // 
            // panelSharepointLoadProgress
            // 
            this.panelSharepointLoadProgress.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelSharepointLoadProgress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelSharepointLoadProgress.Controls.Add(this.txtLoadProgress);
            this.panelSharepointLoadProgress.Controls.Add(this.pgbLoadSharepointData);
            this.panelSharepointLoadProgress.Location = new System.Drawing.Point(784, 175);
            this.panelSharepointLoadProgress.Name = "panelSharepointLoadProgress";
            this.panelSharepointLoadProgress.Size = new System.Drawing.Size(423, 99);
            this.panelSharepointLoadProgress.TabIndex = 67;
            // 
            // txtLoadProgress
            // 
            this.txtLoadProgress.BackColor = System.Drawing.Color.AntiqueWhite;
            this.txtLoadProgress.Location = new System.Drawing.Point(13, 57);
            this.txtLoadProgress.Name = "txtLoadProgress";
            this.txtLoadProgress.Size = new System.Drawing.Size(393, 22);
            this.txtLoadProgress.TabIndex = 1;
            // 
            // pgbLoadSharepointData
            // 
            this.pgbLoadSharepointData.ForeColor = System.Drawing.Color.Chartreuse;
            this.pgbLoadSharepointData.Location = new System.Drawing.Point(13, 16);
            this.pgbLoadSharepointData.Name = "pgbLoadSharepointData";
            this.pgbLoadSharepointData.Size = new System.Drawing.Size(393, 35);
            this.pgbLoadSharepointData.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnUpdateFilter);
            this.groupBox3.Controls.Add(this.cmbSavedFilters);
            this.groupBox3.Controls.Add(this.btnRemoveFilter);
            this.groupBox3.Controls.Add(this.btnAddFilter);
            this.groupBox3.Controls.Add(this.btnLoadDefaultSettings);
            this.groupBox3.Location = new System.Drawing.Point(9, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(213, 100);
            this.groupBox3.TabIndex = 66;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Saved filters";
            // 
            // splitContainerFilters
            // 
            this.splitContainerFilters.Controls.Add(this.label14);
            this.splitContainerFilters.Controls.Add(this.lstDataSource);
            this.splitContainerFilters.Controls.Add(this.lstDeploymentTool);
            this.splitContainerFilters.Controls.Add(this.label15);
            this.splitContainerFilters.Controls.Add(this.label6);
            this.splitContainerFilters.Controls.Add(this.lstTeamManager);
            this.splitContainerFilters.Controls.Add(this.chlstPlatform);
            this.splitContainerFilters.Controls.Add(this.label10);
            this.splitContainerFilters.Controls.Add(this.lstRelationshipManager);
            this.splitContainerFilters.Controls.Add(this.Platform);
            this.splitContainerFilters.Controls.Add(this.lstReportStatus);
            this.splitContainerFilters.Controls.Add(this.label13);
            this.splitContainerFilters.Location = new System.Drawing.Point(228, 27);
            this.splitContainerFilters.Name = "splitContainerFilters";
            this.splitContainerFilters.Size = new System.Drawing.Size(550, 836);
            this.splitContainerFilters.TabIndex = 68;
            this.splitContainerFilters.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(268, 458);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 17);
            this.label14.TabIndex = 63;
            this.label14.Text = "Deployment Tool";
            // 
            // lstDataSource
            // 
            this.lstDataSource.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstDataSource.FormattingEnabled = true;
            this.lstDataSource.ItemHeight = 16;
            this.lstDataSource.Location = new System.Drawing.Point(267, 17);
            this.lstDataSource.Name = "lstDataSource";
            this.lstDataSource.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDataSource.Size = new System.Drawing.Size(267, 436);
            this.lstDataSource.TabIndex = 55;
            this.lstDataSource.SelectedIndexChanged += new System.EventHandler(this.lstDataSource_SelectedIndexChanged);
            // 
            // lstDeploymentTool
            // 
            this.lstDeploymentTool.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstDeploymentTool.FormattingEnabled = true;
            this.lstDeploymentTool.ItemHeight = 16;
            this.lstDeploymentTool.Location = new System.Drawing.Point(271, 473);
            this.lstDeploymentTool.Name = "lstDeploymentTool";
            this.lstDeploymentTool.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDeploymentTool.Size = new System.Drawing.Size(263, 164);
            this.lstDeploymentTool.TabIndex = 59;
            this.lstDeploymentTool.SelectedIndexChanged += new System.EventHandler(this.lstDeploymentTool_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(268, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(87, 17);
            this.label15.TabIndex = 62;
            this.label15.Text = "Data Source";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(9, 573);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 17);
            this.label6.TabIndex = 65;
            this.label6.Text = "Team Manager";
            // 
            // lstTeamManager
            // 
            this.lstTeamManager.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstTeamManager.FormattingEnabled = true;
            this.lstTeamManager.ItemHeight = 16;
            this.lstTeamManager.Location = new System.Drawing.Point(8, 593);
            this.lstTeamManager.Name = "lstTeamManager";
            this.lstTeamManager.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstTeamManager.Size = new System.Drawing.Size(249, 228);
            this.lstTeamManager.Sorted = true;
            this.lstTeamManager.TabIndex = 64;
            this.lstTeamManager.SelectedIndexChanged += new System.EventHandler(this.lstTeamManager_SelectedIndexChanged);
            // 
            // chlstPlatform
            // 
            this.chlstPlatform.BackColor = System.Drawing.Color.NavajoWhite;
            this.chlstPlatform.FormattingEnabled = true;
            this.chlstPlatform.ItemHeight = 16;
            this.chlstPlatform.Location = new System.Drawing.Point(8, 33);
            this.chlstPlatform.Name = "chlstPlatform";
            this.chlstPlatform.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.chlstPlatform.Size = new System.Drawing.Size(253, 372);
            this.chlstPlatform.Sorted = true;
            this.chlstPlatform.TabIndex = 27;
            this.chlstPlatform.SelectedIndexChanged += new System.EventHandler(this.chlstPlatform_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(9, 402);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 17);
            this.label10.TabIndex = 61;
            this.label10.Text = "Report Status";
            // 
            // lstRelationshipManager
            // 
            this.lstRelationshipManager.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstRelationshipManager.FormattingEnabled = true;
            this.lstRelationshipManager.ItemHeight = 16;
            this.lstRelationshipManager.Location = new System.Drawing.Point(271, 659);
            this.lstRelationshipManager.Name = "lstRelationshipManager";
            this.lstRelationshipManager.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstRelationshipManager.Size = new System.Drawing.Size(263, 164);
            this.lstRelationshipManager.TabIndex = 58;
            this.lstRelationshipManager.SelectedIndexChanged += new System.EventHandler(this.lstRelationshipManager_SelectedIndexChanged);
            // 
            // Platform
            // 
            this.Platform.AutoSize = true;
            this.Platform.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Platform.ForeColor = System.Drawing.Color.Red;
            this.Platform.Location = new System.Drawing.Point(9, 5);
            this.Platform.Name = "Platform";
            this.Platform.Size = new System.Drawing.Size(65, 17);
            this.Platform.TabIndex = 60;
            this.Platform.Text = "Platform*";
            this.toolTipAddFilter.SetToolTip(this.Platform, "This filter is shared with the Workflow");
            // 
            // lstReportStatus
            // 
            this.lstReportStatus.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstReportStatus.FormattingEnabled = true;
            this.lstReportStatus.ItemHeight = 16;
            this.lstReportStatus.Location = new System.Drawing.Point(8, 422);
            this.lstReportStatus.Name = "lstReportStatus";
            this.lstReportStatus.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstReportStatus.Size = new System.Drawing.Size(252, 148);
            this.lstReportStatus.TabIndex = 57;
            this.lstReportStatus.SelectedIndexChanged += new System.EventHandler(this.lstReportStatus_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(268, 640);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(146, 17);
            this.label13.TabIndex = 62;
            this.label13.Text = "Relationship manager";
            // 
            // btnUpdateFilter
            // 
            this.btnUpdateFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdateFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F);
            this.btnUpdateFilter.ForeColor = System.Drawing.Color.Red;
            this.btnUpdateFilter.Location = new System.Drawing.Point(43, 55);
            this.btnUpdateFilter.Name = "btnUpdateFilter";
            this.btnUpdateFilter.Size = new System.Drawing.Size(35, 35);
            this.btnUpdateFilter.TabIndex = 70;
            this.btnUpdateFilter.Text = "✍";
            this.toolTipAddFilter.SetToolTip(this.btnUpdateFilter, "Update/Overwrite the filter");
            this.btnUpdateFilter.UseVisualStyleBackColor = true;
            this.btnUpdateFilter.Click += new System.EventHandler(this.btnUpdateFilter_Click);
            // 
            // cmbSavedFilters
            // 
            this.cmbSavedFilters.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSavedFilters.ForeColor = System.Drawing.Color.Black;
            this.cmbSavedFilters.FormattingEnabled = true;
            this.cmbSavedFilters.Location = new System.Drawing.Point(6, 25);
            this.cmbSavedFilters.Name = "cmbSavedFilters";
            this.cmbSavedFilters.Size = new System.Drawing.Size(197, 24);
            this.cmbSavedFilters.Sorted = true;
            this.cmbSavedFilters.TabIndex = 64;
            this.cmbSavedFilters.Text = "---Select saved filter here---";
            this.cmbSavedFilters.SelectionChangeCommitted += new System.EventHandler(this.cmbSavedFilters_SelectionChangeCommitted);
            // 
            // btnRemoveFilter
            // 
            this.btnRemoveFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRemoveFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnRemoveFilter.ForeColor = System.Drawing.Color.Red;
            this.btnRemoveFilter.Location = new System.Drawing.Point(80, 55);
            this.btnRemoveFilter.Name = "btnRemoveFilter";
            this.btnRemoveFilter.Size = new System.Drawing.Size(35, 35);
            this.btnRemoveFilter.TabIndex = 68;
            this.btnRemoveFilter.Text = "✘";
            this.toolTipAddFilter.SetToolTip(this.btnRemoveFilter, "Remove selected filter");
            this.btnRemoveFilter.UseVisualStyleBackColor = true;
            this.btnRemoveFilter.Click += new System.EventHandler(this.btnRemoveFilter_Click);
            // 
            // btnAddFilter
            // 
            this.btnAddFilter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFilter.ForeColor = System.Drawing.Color.ForestGreen;
            this.btnAddFilter.Location = new System.Drawing.Point(6, 55);
            this.btnAddFilter.Name = "btnAddFilter";
            this.btnAddFilter.Size = new System.Drawing.Size(35, 35);
            this.btnAddFilter.TabIndex = 65;
            this.btnAddFilter.Text = "✚";
            this.toolTipAddFilter.SetToolTip(this.btnAddFilter, "Add a new filter");
            this.btnAddFilter.UseVisualStyleBackColor = true;
            this.btnAddFilter.Click += new System.EventHandler(this.btnAddFilter_Click);
            // 
            // btnLoadDefaultSettings
            // 
            this.btnLoadDefaultSettings.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLoadDefaultSettings.BackColor = System.Drawing.Color.Transparent;
            this.btnLoadDefaultSettings.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoadDefaultSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadDefaultSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnLoadDefaultSettings.ForeColor = System.Drawing.Color.ForestGreen;
            this.btnLoadDefaultSettings.Location = new System.Drawing.Point(148, 55);
            this.btnLoadDefaultSettings.Name = "btnLoadDefaultSettings";
            this.btnLoadDefaultSettings.Size = new System.Drawing.Size(55, 35);
            this.btnLoadDefaultSettings.TabIndex = 63;
            this.btnLoadDefaultSettings.Text = "✔";
            this.btnLoadDefaultSettings.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.toolTipAddFilter.SetToolTip(this.btnLoadDefaultSettings, "Save new filter");
            this.btnLoadDefaultSettings.UseVisualStyleBackColor = false;
            this.btnLoadDefaultSettings.Click += new System.EventHandler(this.btnLoadDefaultSettings_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(6, 175);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(122, 17);
            this.label9.TabIndex = 59;
            this.label9.Text = "Report preparers*";
            this.toolTipAddFilter.SetToolTip(this.label9, "This filter is shared with the Workflow");
            // 
            // btnExpandCatalogueFilter
            // 
            this.btnExpandCatalogueFilter.Cursor = System.Windows.Forms.Cursors.PanEast;
            this.btnExpandCatalogueFilter.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnExpandCatalogueFilter.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightCoral;
            this.btnExpandCatalogueFilter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnExpandCatalogueFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExpandCatalogueFilter.ForeColor = System.Drawing.Color.Red;
            this.btnExpandCatalogueFilter.Location = new System.Drawing.Point(9, 135);
            this.btnExpandCatalogueFilter.Name = "btnExpandCatalogueFilter";
            this.btnExpandCatalogueFilter.Size = new System.Drawing.Size(213, 37);
            this.btnExpandCatalogueFilter.TabIndex = 58;
            this.btnExpandCatalogueFilter.Text = "Expand Filters >>";
            this.btnExpandCatalogueFilter.UseVisualStyleBackColor = true;
            this.btnExpandCatalogueFilter.Click += new System.EventHandler(this.btnExpandCatalogueFilter_Click);
            this.btnExpandCatalogueFilter.MouseHover += new System.EventHandler(this.btnExpandCatalogueFilter_MouseHover);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 439);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 17);
            this.label12.TabIndex = 61;
            this.label12.Text = "GV day";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(4, 658);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 17);
            this.label11.TabIndex = 60;
            this.label11.Text = "Frequency";
            // 
            // lstGvDays
            // 
            this.lstGvDays.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstGvDays.FormattingEnabled = true;
            this.lstGvDays.ItemHeight = 16;
            this.lstGvDays.Items.AddRange(new object[] {
            "<ALL>",
            "GV0",
            "GV1",
            "GV2",
            "GV3",
            "GV4",
            "GV5",
            "GV6",
            "GV7",
            "GV8",
            "GV9",
            "GV10",
            "GV11",
            "GV12",
            "GV13",
            "GV14",
            "GV15",
            "Quarterly",
            "Semi-Annual",
            "Weekly",
            "20th Calendar Day",
            "2nd Week",
            "3rd Week",
            "Annual",
            "Before End of Month",
            "Bi-Weekly",
            "Daily"});
            this.lstGvDays.Location = new System.Drawing.Point(6, 459);
            this.lstGvDays.Name = "lstGvDays";
            this.lstGvDays.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstGvDays.Size = new System.Drawing.Size(216, 196);
            this.lstGvDays.TabIndex = 45;
            this.lstGvDays.SelectedIndexChanged += new System.EventHandler(this.lstGvDays_SelectedIndexChanged);
            // 
            // rbTotalReportCount
            // 
            this.rbTotalReportCount.AutoSize = true;
            this.rbTotalReportCount.Location = new System.Drawing.Point(551, 559);
            this.rbTotalReportCount.Name = "rbTotalReportCount";
            this.rbTotalReportCount.Size = new System.Drawing.Size(209, 21);
            this.rbTotalReportCount.TabIndex = 55;
            this.rbTotalReportCount.TabStop = true;
            this.rbTotalReportCount.Text = "Total report count by person";
            this.rbTotalReportCount.UseVisualStyleBackColor = true;
            this.rbTotalReportCount.CheckedChanged += new System.EventHandler(this.rbTotalReportCount_CheckedChanged);
            // 
            // lstFrequency
            // 
            this.lstFrequency.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstFrequency.FormattingEnabled = true;
            this.lstFrequency.ItemHeight = 16;
            this.lstFrequency.Location = new System.Drawing.Point(6, 678);
            this.lstFrequency.Name = "lstFrequency";
            this.lstFrequency.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstFrequency.Size = new System.Drawing.Size(216, 148);
            this.lstFrequency.Sorted = true;
            this.lstFrequency.TabIndex = 56;
            this.lstFrequency.SelectedIndexChanged += new System.EventHandler(this.lstFrequency_SelectedIndexChanged);
            // 
            // rbDataSource
            // 
            this.rbDataSource.AutoSize = true;
            this.rbDataSource.Location = new System.Drawing.Point(265, 559);
            this.rbDataSource.Name = "rbDataSource";
            this.rbDataSource.Size = new System.Drawing.Size(108, 21);
            this.rbDataSource.TabIndex = 54;
            this.rbDataSource.Text = "Data Source";
            this.rbDataSource.UseVisualStyleBackColor = true;
            this.rbDataSource.CheckedChanged += new System.EventHandler(this.rbDataSource_CheckedChanged);
            // 
            // rbDeploymentTools
            // 
            this.rbDeploymentTools.AutoSize = true;
            this.rbDeploymentTools.Location = new System.Drawing.Point(407, 559);
            this.rbDeploymentTools.Name = "rbDeploymentTools";
            this.rbDeploymentTools.Size = new System.Drawing.Size(138, 21);
            this.rbDeploymentTools.TabIndex = 53;
            this.rbDeploymentTools.Text = "Deployment tools";
            this.rbDeploymentTools.UseVisualStyleBackColor = true;
            this.rbDeploymentTools.CheckedChanged += new System.EventHandler(this.rbDeploymentTools_CheckedChanged);
            // 
            // rbSetupTime
            // 
            this.rbSetupTime.AutoSize = true;
            this.rbSetupTime.Location = new System.Drawing.Point(538, 346);
            this.rbSetupTime.Name = "rbSetupTime";
            this.rbSetupTime.Size = new System.Drawing.Size(101, 21);
            this.rbSetupTime.TabIndex = 51;
            this.rbSetupTime.Text = "Setup Time";
            this.rbSetupTime.UseVisualStyleBackColor = true;
            this.rbSetupTime.CheckedChanged += new System.EventHandler(this.rbSetupTime_CheckedChanged);
            // 
            // dgvResourcing
            // 
            this.dgvResourcing.AllowUserToAddRows = false;
            this.dgvResourcing.AllowUserToDeleteRows = false;
            this.dgvResourcing.AllowUserToOrderColumns = true;
            this.dgvResourcing.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResourcing.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvResourcing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResourcing.ContextMenuStrip = this.cmsDatagrid;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvResourcing.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvResourcing.Location = new System.Drawing.Point(228, 55);
            this.dgvResourcing.Name = "dgvResourcing";
            this.dgvResourcing.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResourcing.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvResourcing.RowHeadersVisible = false;
            this.dgvResourcing.RowTemplate.Height = 24;
            this.dgvResourcing.Size = new System.Drawing.Size(919, 285);
            this.dgvResourcing.TabIndex = 44;
            this.dgvResourcing.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResourcing_CellContentClick);
            this.dgvResourcing.CellContextMenuStripNeeded += new System.Windows.Forms.DataGridViewCellContextMenuStripNeededEventHandler(this.dgv_CellContextMenuStripNeeded);
            // 
            // rbRptCount
            // 
            this.rbRptCount.AutoSize = true;
            this.rbRptCount.Location = new System.Drawing.Point(407, 347);
            this.rbRptCount.Name = "rbRptCount";
            this.rbRptCount.Size = new System.Drawing.Size(111, 21);
            this.rbRptCount.TabIndex = 31;
            this.rbRptCount.Text = "Report count";
            this.rbRptCount.UseVisualStyleBackColor = true;
            this.rbRptCount.CheckedChanged += new System.EventHandler(this.rbRptCount_CheckedChanged);
            // 
            // rbProcessTime
            // 
            this.rbProcessTime.AutoSize = true;
            this.rbProcessTime.Checked = true;
            this.rbProcessTime.Location = new System.Drawing.Point(265, 347);
            this.rbProcessTime.Name = "rbProcessTime";
            this.rbProcessTime.Size = new System.Drawing.Size(134, 21);
            this.rbProcessTime.TabIndex = 30;
            this.rbProcessTime.TabStop = true;
            this.rbProcessTime.Text = "Processing TIme";
            this.rbProcessTime.UseVisualStyleBackColor = true;
            this.rbProcessTime.CheckedChanged += new System.EventHandler(this.rbProcessTime_CheckedChanged);
            // 
            // chart1
            // 
            this.chart1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chart1.BackColor = System.Drawing.Color.Transparent;
            this.chart1.BackSecondaryColor = System.Drawing.Color.Transparent;
            this.chart1.BorderlineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorTickMark.Enabled = false;
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.AxisY.MajorTickMark.Enabled = false;
            chartArea1.BackColor = System.Drawing.Color.Transparent;
            chartArea1.BorderColor = System.Drawing.Color.Transparent;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Cursor = System.Windows.Forms.Cursors.Default;
            legend1.BackColor = System.Drawing.Color.Transparent;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(228, 586);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            this.chart1.Size = new System.Drawing.Size(903, 253);
            this.chart1.TabIndex = 18;
            this.chart1.Text = "chart1";
            // 
            // lstEmployees
            // 
            this.lstEmployees.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstEmployees.FormattingEnabled = true;
            this.lstEmployees.ItemHeight = 16;
            this.lstEmployees.Location = new System.Drawing.Point(7, 192);
            this.lstEmployees.Name = "lstEmployees";
            this.lstEmployees.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstEmployees.Size = new System.Drawing.Size(215, 244);
            this.lstEmployees.Sorted = true;
            this.lstEmployees.TabIndex = 6;
            this.lstEmployees.SelectedIndexChanged += new System.EventHandler(this.lstEmployees_SelectedIndexChanged);
            // 
            // dgvSummaryView
            // 
            this.dgvSummaryView.AllowUserToAddRows = false;
            this.dgvSummaryView.AllowUserToDeleteRows = false;
            this.dgvSummaryView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSummaryView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvSummaryView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSummaryView.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvSummaryView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvSummaryView.Location = new System.Drawing.Point(228, 374);
            this.dgvSummaryView.Name = "dgvSummaryView";
            this.dgvSummaryView.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSummaryView.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvSummaryView.RowHeadersVisible = false;
            this.dgvSummaryView.RowTemplate.Height = 24;
            this.dgvSummaryView.Size = new System.Drawing.Size(919, 180);
            this.dgvSummaryView.TabIndex = 3;
            // 
            // txtSearchCatalogue
            // 
            this.txtSearchCatalogue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchCatalogue.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearchCatalogue.Location = new System.Drawing.Point(592, 27);
            this.txtSearchCatalogue.Name = "txtSearchCatalogue";
            this.txtSearchCatalogue.Size = new System.Drawing.Size(555, 22);
            this.txtSearchCatalogue.TabIndex = 69;
            this.toolTipAddFilter.SetToolTip(this.txtSearchCatalogue, "Enter keyword(s). Multiple keywords have to be seperated by | (pipe)");
            this.txtSearchCatalogue.TextChanged += new System.EventHandler(this.txtSearchCatalogue_TextChanged);
            // 
            // cmbFieldFilterReportCatalogue
            // 
            this.cmbFieldFilterReportCatalogue.FormattingEnabled = true;
            this.cmbFieldFilterReportCatalogue.Location = new System.Drawing.Point(228, 25);
            this.cmbFieldFilterReportCatalogue.Name = "cmbFieldFilterReportCatalogue";
            this.cmbFieldFilterReportCatalogue.Size = new System.Drawing.Size(298, 24);
            this.cmbFieldFilterReportCatalogue.TabIndex = 70;
            this.cmbFieldFilterReportCatalogue.Text = "---Select field for a keyword search---";
            this.toolTipAddFilter.SetToolTip(this.cmbFieldFilterReportCatalogue, "Select field and type keyword in the input box on the right. This filter works in" +
        "dependntly of the filters to the left");
            this.cmbFieldFilterReportCatalogue.SelectionChangeCommitted += new System.EventHandler(this.cmbFieldFilterReportCatalogue_SelectionChangeCommitted);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(225, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(116, 17);
            this.label20.TabIndex = 72;
            this.label20.Text = "Field to search in";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(589, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(132, 17);
            this.label19.TabIndex = 71;
            this.label19.Text = "Keywords to search";
            // 
            // tbpgResourcingWorkflow
            // 
            this.tbpgResourcingWorkflow.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tbpgResourcingWorkflow.Controls.Add(this.label21);
            this.tbpgResourcingWorkflow.Controls.Add(this.label22);
            this.tbpgResourcingWorkflow.Controls.Add(this.cmbFieldFilterWorkflow);
            this.tbpgResourcingWorkflow.Controls.Add(this.txtSearchWorkflow);
            this.tbpgResourcingWorkflow.Controls.Add(this.panel1);
            this.tbpgResourcingWorkflow.Controls.Add(this.label18);
            this.tbpgResourcingWorkflow.Controls.Add(this.label17);
            this.tbpgResourcingWorkflow.Controls.Add(this.dgvResourcingWorkflow);
            this.tbpgResourcingWorkflow.Controls.Add(this.lstStatus);
            this.tbpgResourcingWorkflow.Controls.Add(this.lstCategory);
            this.tbpgResourcingWorkflow.Controls.Add(this.groupBox1);
            this.tbpgResourcingWorkflow.Location = new System.Drawing.Point(4, 24);
            this.tbpgResourcingWorkflow.Name = "tbpgResourcingWorkflow";
            this.tbpgResourcingWorkflow.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgResourcingWorkflow.Size = new System.Drawing.Size(1826, 731);
            this.tbpgResourcingWorkflow.TabIndex = 3;
            this.tbpgResourcingWorkflow.Tag = "dgvResourcingWorkflow";
            this.tbpgResourcingWorkflow.Text = "Workflow";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(273, 3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(116, 17);
            this.label21.TabIndex = 76;
            this.label21.Text = "Field to search in";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(640, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(132, 17);
            this.label22.TabIndex = 75;
            this.label22.Text = "Keywords to search";
            // 
            // cmbFieldFilterWorkflow
            // 
            this.cmbFieldFilterWorkflow.FormattingEnabled = true;
            this.cmbFieldFilterWorkflow.Location = new System.Drawing.Point(271, 22);
            this.cmbFieldFilterWorkflow.Name = "cmbFieldFilterWorkflow";
            this.cmbFieldFilterWorkflow.Size = new System.Drawing.Size(319, 24);
            this.cmbFieldFilterWorkflow.TabIndex = 74;
            this.cmbFieldFilterWorkflow.Text = "---Select field for a keyword search---";
            this.toolTipAddFilter.SetToolTip(this.cmbFieldFilterWorkflow, "Select field and type keyword in the input box on the right. This filter works in" +
        "dependntly of the filters to the left");
            this.cmbFieldFilterWorkflow.SelectionChangeCommitted += new System.EventHandler(this.cmbFieldFilterWorkflow_SelectionChangeCommitted);
            // 
            // txtSearchWorkflow
            // 
            this.txtSearchWorkflow.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchWorkflow.BackColor = System.Drawing.SystemColors.Window;
            this.txtSearchWorkflow.Location = new System.Drawing.Point(643, 24);
            this.txtSearchWorkflow.Name = "txtSearchWorkflow";
            this.txtSearchWorkflow.Size = new System.Drawing.Size(1177, 22);
            this.txtSearchWorkflow.TabIndex = 73;
            this.toolTipAddFilter.SetToolTip(this.txtSearchWorkflow, "Enter keyword(s). Multiple keywords have to be seperated by | (pipe)");
            this.txtSearchWorkflow.TextChanged += new System.EventHandler(this.txtSearchWorkflow_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.chartPlatform);
            this.panel1.Controls.Add(this.chartCategory);
            this.panel1.Controls.Add(this.chartStatus);
            this.panel1.Controls.Add(this.rbEffortRequired);
            this.panel1.Controls.Add(this.rbRequestCategory);
            this.panel1.Location = new System.Drawing.Point(12, 465);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1811, 260);
            this.panel1.TabIndex = 56;
            // 
            // chartPlatform
            // 
            this.chartPlatform.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartPlatform.BackColor = System.Drawing.Color.Transparent;
            chartArea2.AxisX.MajorGrid.Enabled = false;
            chartArea2.BackColor = System.Drawing.Color.Transparent;
            chartArea2.Name = "ChartArea1";
            this.chartPlatform.ChartAreas.Add(chartArea2);
            this.chartPlatform.Cursor = System.Windows.Forms.Cursors.SizeAll;
            legend2.BackColor = System.Drawing.Color.Transparent;
            legend2.IsTextAutoFit = false;
            legend2.LegendItemOrder = System.Windows.Forms.DataVisualization.Charting.LegendItemOrder.SameAsSeriesOrder;
            legend2.Name = "Legend1";
            legend2.TextWrapThreshold = 40;
            this.chartPlatform.Legends.Add(legend2);
            this.chartPlatform.Location = new System.Drawing.Point(1372, 23);
            this.chartPlatform.Name = "chartPlatform";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series1.YValuesPerPoint = 2;
            this.chartPlatform.Series.Add(series1);
            this.chartPlatform.Size = new System.Drawing.Size(428, 234);
            this.chartPlatform.TabIndex = 46;
            this.chartPlatform.Text = "chart2";
            // 
            // chartCategory
            // 
            this.chartCategory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.chartCategory.BackColor = System.Drawing.Color.Transparent;
            this.chartCategory.BorderlineColor = System.Drawing.Color.Transparent;
            this.chartCategory.BorderSkin.PageColor = System.Drawing.Color.Transparent;
            chartArea3.AxisX.MajorGrid.Enabled = false;
            chartArea3.AxisY.MajorGrid.Enabled = false;
            chartArea3.BackColor = System.Drawing.Color.Transparent;
            chartArea3.BorderColor = System.Drawing.Color.Transparent;
            chartArea3.BorderWidth = 0;
            chartArea3.Name = "ChartArea1";
            this.chartCategory.ChartAreas.Add(chartArea3);
            this.chartCategory.Cursor = System.Windows.Forms.Cursors.SizeAll;
            legend3.BackColor = System.Drawing.Color.Transparent;
            legend3.Name = "Legend1";
            this.chartCategory.Legends.Add(legend3);
            this.chartCategory.Location = new System.Drawing.Point(3, 50);
            this.chartCategory.Name = "chartCategory";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            series2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.BrightPastel;
            this.chartCategory.Series.Add(series2);
            this.chartCategory.Size = new System.Drawing.Size(479, 207);
            this.chartCategory.TabIndex = 47;
            this.chartCategory.Text = "chart3";
            this.chartCategory.MouseMove += new System.Windows.Forms.MouseEventHandler(this.chartCategory_MouseMove);
            // 
            // chartStatus
            // 
            this.chartStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartStatus.BackColor = System.Drawing.Color.Transparent;
            this.chartStatus.BorderSkin.BackColor = System.Drawing.Color.Transparent;
            chartArea4.BackColor = System.Drawing.Color.Transparent;
            chartArea4.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea4.BackSecondaryColor = System.Drawing.Color.Transparent;
            chartArea4.Name = "ChartArea1";
            this.chartStatus.ChartAreas.Add(chartArea4);
            this.chartStatus.Cursor = System.Windows.Forms.Cursors.SizeAll;
            legend4.BackColor = System.Drawing.Color.Transparent;
            legend4.Name = "Legend1";
            this.chartStatus.Legends.Add(legend4);
            this.chartStatus.Location = new System.Drawing.Point(502, 23);
            this.chartStatus.Name = "chartStatus";
            this.chartStatus.Size = new System.Drawing.Size(850, 234);
            this.chartStatus.TabIndex = 48;
            this.chartStatus.Text = "chart4";
            // 
            // rbEffortRequired
            // 
            this.rbEffortRequired.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rbEffortRequired.AutoSize = true;
            this.rbEffortRequired.Location = new System.Drawing.Point(262, 23);
            this.rbEffortRequired.Name = "rbEffortRequired";
            this.rbEffortRequired.Size = new System.Drawing.Size(234, 21);
            this.rbEffortRequired.TabIndex = 53;
            this.rbEffortRequired.TabStop = true;
            this.rbEffortRequired.Text = "Effort (hrs) by Request Category";
            this.rbEffortRequired.UseVisualStyleBackColor = true;
            this.rbEffortRequired.CheckedChanged += new System.EventHandler(this.rbEffortRequired_CheckedChanged);
            // 
            // rbRequestCategory
            // 
            this.rbRequestCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rbRequestCategory.AutoSize = true;
            this.rbRequestCategory.Location = new System.Drawing.Point(3, 23);
            this.rbRequestCategory.Name = "rbRequestCategory";
            this.rbRequestCategory.Size = new System.Drawing.Size(254, 21);
            this.rbRequestCategory.TabIndex = 52;
            this.rbRequestCategory.TabStop = true;
            this.rbRequestCategory.Text = "# of Instances by Request Category";
            this.rbRequestCategory.UseVisualStyleBackColor = true;
            this.rbRequestCategory.CheckedChanged += new System.EventHandler(this.rbRequestCategory_CheckedChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(9, 307);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 17);
            this.label18.TabIndex = 55;
            this.label18.Text = "Request status";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 152);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 17);
            this.label17.TabIndex = 54;
            this.label17.Text = "Request category";
            // 
            // dgvResourcingWorkflow
            // 
            this.dgvResourcingWorkflow.AllowUserToAddRows = false;
            this.dgvResourcingWorkflow.AllowUserToDeleteRows = false;
            this.dgvResourcingWorkflow.AllowUserToOrderColumns = true;
            this.dgvResourcingWorkflow.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvResourcingWorkflow.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResourcingWorkflow.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvResourcingWorkflow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResourcingWorkflow.ContextMenuStrip = this.cmsDatagrid;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvResourcingWorkflow.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvResourcingWorkflow.Location = new System.Drawing.Point(271, 52);
            this.dgvResourcingWorkflow.Name = "dgvResourcingWorkflow";
            this.dgvResourcingWorkflow.ReadOnly = true;
            this.dgvResourcingWorkflow.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvResourcingWorkflow.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvResourcingWorkflow.RowHeadersVisible = false;
            this.dgvResourcingWorkflow.RowTemplate.Height = 24;
            this.dgvResourcingWorkflow.Size = new System.Drawing.Size(1549, 407);
            this.dgvResourcingWorkflow.TabIndex = 51;
            this.dgvResourcingWorkflow.CellContextMenuStripNeeded += new System.Windows.Forms.DataGridViewCellContextMenuStripNeededEventHandler(this.dgv_CellContextMenuStripNeeded);
            // 
            // lstStatus
            // 
            this.lstStatus.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstStatus.FormattingEnabled = true;
            this.lstStatus.ItemHeight = 16;
            this.lstStatus.Location = new System.Drawing.Point(12, 327);
            this.lstStatus.Name = "lstStatus";
            this.lstStatus.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstStatus.Size = new System.Drawing.Size(256, 132);
            this.lstStatus.TabIndex = 50;
            this.lstStatus.SelectedIndexChanged += new System.EventHandler(this.lstStatus_SelectedIndexChanged);
            // 
            // lstCategory
            // 
            this.lstCategory.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstCategory.FormattingEnabled = true;
            this.lstCategory.ItemHeight = 16;
            this.lstCategory.Location = new System.Drawing.Point(12, 172);
            this.lstCategory.Name = "lstCategory";
            this.lstCategory.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstCategory.Size = new System.Drawing.Size(256, 132);
            this.lstCategory.TabIndex = 49;
            this.lstCategory.SelectedIndexChanged += new System.EventHandler(this.lstCategory_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.flowLayoutPanel1);
            this.groupBox1.Controls.Add(this.chkIncludeAllWorkflow);
            this.groupBox1.Controls.Add(this.chkIncludeAllDates);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(259, 143);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Worflow filters";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel1.Controls.Add(this.rbBetween);
            this.flowLayoutPanel1.Controls.Add(this.rbBefore);
            this.flowLayoutPanel1.Controls.Add(this.rbFrom);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 74);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(241, 26);
            this.flowLayoutPanel1.TabIndex = 23;
            // 
            // rbBetween
            // 
            this.rbBetween.AutoSize = true;
            this.rbBetween.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rbBetween.ForeColor = System.Drawing.Color.Red;
            this.rbBetween.Location = new System.Drawing.Point(3, 3);
            this.rbBetween.Name = "rbBetween";
            this.rbBetween.Size = new System.Drawing.Size(83, 21);
            this.rbBetween.TabIndex = 22;
            this.rbBetween.TabStop = true;
            this.rbBetween.Text = "Between";
            this.toolTipAddFilter.SetToolTip(this.rbBetween, "Select starting and ending dates above");
            this.rbBetween.UseVisualStyleBackColor = true;
            this.rbBetween.CheckedChanged += new System.EventHandler(this.rbBetween_CheckedChanged);
            // 
            // rbBefore
            // 
            this.rbBefore.AutoSize = true;
            this.rbBefore.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rbBefore.ForeColor = System.Drawing.Color.Red;
            this.rbBefore.Location = new System.Drawing.Point(92, 3);
            this.rbBefore.Name = "rbBefore";
            this.rbBefore.Size = new System.Drawing.Size(71, 21);
            this.rbBefore.TabIndex = 21;
            this.rbBefore.TabStop = true;
            this.rbBefore.Text = "Before";
            this.toolTipAddFilter.SetToolTip(this.rbBefore, "Select ending date from the \'To\' date picker");
            this.rbBefore.UseVisualStyleBackColor = true;
            this.rbBefore.CheckedChanged += new System.EventHandler(this.rbBefore_CheckedChanged);
            // 
            // rbFrom
            // 
            this.rbFrom.AutoSize = true;
            this.rbFrom.Checked = true;
            this.rbFrom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rbFrom.ForeColor = System.Drawing.Color.Red;
            this.rbFrom.Location = new System.Drawing.Point(169, 3);
            this.rbFrom.Name = "rbFrom";
            this.rbFrom.Size = new System.Drawing.Size(59, 21);
            this.rbFrom.TabIndex = 20;
            this.rbFrom.TabStop = true;
            this.rbFrom.Text = "After";
            this.toolTipAddFilter.SetToolTip(this.rbFrom, "Select starting date from the \'From\' date picker");
            this.rbFrom.UseVisualStyleBackColor = true;
            this.rbFrom.CheckedChanged += new System.EventHandler(this.rbFrom_CheckedChanged);
            // 
            // chkIncludeAllWorkflow
            // 
            this.chkIncludeAllWorkflow.AutoSize = true;
            this.chkIncludeAllWorkflow.Location = new System.Drawing.Point(12, 116);
            this.chkIncludeAllWorkflow.Name = "chkIncludeAllWorkflow";
            this.chkIncludeAllWorkflow.Size = new System.Drawing.Size(162, 21);
            this.chkIncludeAllWorkflow.TabIndex = 19;
            this.chkIncludeAllWorkflow.Text = "Include reruns/errors";
            this.chkIncludeAllWorkflow.UseVisualStyleBackColor = true;
            this.chkIncludeAllWorkflow.CheckedChanged += new System.EventHandler(this.chkIncludeAllWorkflow_CheckedChanged);
            // 
            // chkIncludeAllDates
            // 
            this.chkIncludeAllDates.AutoSize = true;
            this.chkIncludeAllDates.Location = new System.Drawing.Point(121, 105);
            this.chkIncludeAllDates.Name = "chkIncludeAllDates";
            this.chkIncludeAllDates.Size = new System.Drawing.Size(132, 21);
            this.chkIncludeAllDates.TabIndex = 18;
            this.chkIncludeAllDates.Text = "Include all dates";
            this.chkIncludeAllDates.UseVisualStyleBackColor = true;
            this.chkIncludeAllDates.Visible = false;
            this.chkIncludeAllDates.CheckStateChanged += new System.EventHandler(this.chkIncludeAllDates_CheckStateChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(68, 23);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(185, 22);
            this.dateTimePicker1.TabIndex = 13;
            this.dateTimePicker1.CloseUp += new System.EventHandler(this.dateTimePicker1_CloseUp);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(68, 46);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(185, 22);
            this.dateTimePicker2.TabIndex = 14;
            this.dateTimePicker2.CloseUp += new System.EventHandler(this.dateTimePicker2_CloseUp);
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 17);
            this.label4.TabIndex = 15;
            this.label4.Text = "From:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 17);
            this.label3.TabIndex = 16;
            this.label3.Text = "To:";
            // 
            // tbpgKPI
            // 
            this.tbpgKPI.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tbpgKPI.Controls.Add(this.panel2);
            this.tbpgKPI.Controls.Add(this.txtPassword);
            this.tbpgKPI.Controls.Add(this.lbNoResultsAcknowledgement);
            this.tbpgKPI.Controls.Add(this.btnEnterPassword);
            this.tbpgKPI.Controls.Add(this.dgvKPI);
            this.tbpgKPI.Controls.Add(this.chartAcknowledge);
            this.tbpgKPI.Controls.Add(this.label5);
            this.tbpgKPI.Controls.Add(this.label2);
            this.tbpgKPI.Controls.Add(this.txtOverdueAcknowledge);
            this.tbpgKPI.Controls.Add(this.txtTotalItems);
            this.tbpgKPI.Controls.Add(this.groupBox2);
            this.tbpgKPI.Location = new System.Drawing.Point(4, 24);
            this.tbpgKPI.Name = "tbpgKPI";
            this.tbpgKPI.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgKPI.Size = new System.Drawing.Size(1826, 731);
            this.tbpgKPI.TabIndex = 5;
            this.tbpgKPI.Tag = "tbpgTransitions";
            this.tbpgKPI.Text = "Metrics";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.dgvTest);
            this.panel2.Controls.Add(this.lbNoResultsDaysOutstanding);
            this.panel2.Controls.Add(this.lbNoResultsDaysLeft);
            this.panel2.Controls.Add(this.chartDaysLeft);
            this.panel2.Controls.Add(this.chartDaysOutstanding);
            this.panel2.Location = new System.Drawing.Point(16, 192);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1424, 533);
            this.panel2.TabIndex = 22;
            // 
            // dgvTest
            // 
            this.dgvTest.AllowUserToAddRows = false;
            this.dgvTest.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTest.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvTest.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTest.ContextMenuStrip = this.cmsMetrics;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTest.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvTest.Location = new System.Drawing.Point(3, 3);
            this.dgvTest.Name = "dgvTest";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTest.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvTest.RowHeadersVisible = false;
            this.dgvTest.RowTemplate.Height = 24;
            this.dgvTest.Size = new System.Drawing.Size(1418, 292);
            this.dgvTest.TabIndex = 18;
            this.dgvTest.CellContextMenuStripNeeded += new System.Windows.Forms.DataGridViewCellContextMenuStripNeededEventHandler(this.dgvTest_CellContextMenuStripNeeded);
            // 
            // cmsMetrics
            // 
            this.cmsMetrics.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmsMetrics.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiFilterEquals,
            this.tsmiFilterNotEquals,
            this.tsmiClearKPIFilter});
            this.cmsMetrics.Name = "cmsMetrics";
            this.cmsMetrics.Size = new System.Drawing.Size(180, 76);
            // 
            // tsmiFilterEquals
            // 
            this.tsmiFilterEquals.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiEquals});
            this.tsmiFilterEquals.Name = "tsmiFilterEquals";
            this.tsmiFilterEquals.Size = new System.Drawing.Size(179, 24);
            this.tsmiFilterEquals.Text = "Equals";
            // 
            // tsmiEquals
            // 
            this.tsmiEquals.Name = "tsmiEquals";
            this.tsmiEquals.Size = new System.Drawing.Size(153, 26);
            this.tsmiEquals.Text = "Your value";
            this.tsmiEquals.Click += new System.EventHandler(this.tsmiEquals_Click);
            // 
            // tsmiFilterNotEquals
            // 
            this.tsmiFilterNotEquals.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiNotEquals});
            this.tsmiFilterNotEquals.Name = "tsmiFilterNotEquals";
            this.tsmiFilterNotEquals.Size = new System.Drawing.Size(179, 24);
            this.tsmiFilterNotEquals.Text = "Does not equal";
            // 
            // tsmiNotEquals
            // 
            this.tsmiNotEquals.Name = "tsmiNotEquals";
            this.tsmiNotEquals.Size = new System.Drawing.Size(121, 26);
            this.tsmiNotEquals.Text = "Value";
            this.tsmiNotEquals.Click += new System.EventHandler(this.tsmiNotEquals_Click);
            // 
            // tsmiClearKPIFilter
            // 
            this.tsmiClearKPIFilter.Name = "tsmiClearKPIFilter";
            this.tsmiClearKPIFilter.Size = new System.Drawing.Size(179, 24);
            this.tsmiClearKPIFilter.Text = "Clear Filter";
            this.tsmiClearKPIFilter.Click += new System.EventHandler(this.tsmiClearKPIFilter_Click);
            // 
            // lbNoResultsDaysOutstanding
            // 
            this.lbNoResultsDaysOutstanding.AutoSize = true;
            this.lbNoResultsDaysOutstanding.BackColor = System.Drawing.Color.White;
            this.lbNoResultsDaysOutstanding.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNoResultsDaysOutstanding.ForeColor = System.Drawing.Color.Red;
            this.lbNoResultsDaysOutstanding.Location = new System.Drawing.Point(594, 415);
            this.lbNoResultsDaysOutstanding.Name = "lbNoResultsDaysOutstanding";
            this.lbNoResultsDaysOutstanding.Size = new System.Drawing.Size(333, 25);
            this.lbNoResultsDaysOutstanding.TabIndex = 20;
            this.lbNoResultsDaysOutstanding.Text = "Nothing to display/No active requests";
            // 
            // lbNoResultsDaysLeft
            // 
            this.lbNoResultsDaysLeft.AutoSize = true;
            this.lbNoResultsDaysLeft.BackColor = System.Drawing.Color.White;
            this.lbNoResultsDaysLeft.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNoResultsDaysLeft.ForeColor = System.Drawing.Color.Red;
            this.lbNoResultsDaysLeft.Location = new System.Drawing.Point(52, 400);
            this.lbNoResultsDaysLeft.Name = "lbNoResultsDaysLeft";
            this.lbNoResultsDaysLeft.Size = new System.Drawing.Size(333, 25);
            this.lbNoResultsDaysLeft.TabIndex = 19;
            this.lbNoResultsDaysLeft.Text = "Nothing to display/No active requests";
            // 
            // chartDaysLeft
            // 
            this.chartDaysLeft.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.chartDaysLeft.BackColor = System.Drawing.Color.Transparent;
            chartArea5.AxisX.MajorGrid.Enabled = false;
            chartArea5.AxisY.MajorGrid.Enabled = false;
            chartArea5.BackColor = System.Drawing.Color.Transparent;
            chartArea5.Name = "ChartArea1";
            this.chartDaysLeft.ChartAreas.Add(chartArea5);
            legend5.BackColor = System.Drawing.Color.Transparent;
            legend5.Name = "Legend1";
            this.chartDaysLeft.Legends.Add(legend5);
            this.chartDaysLeft.Location = new System.Drawing.Point(3, 311);
            this.chartDaysLeft.Name = "chartDaysLeft";
            this.chartDaysLeft.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.EarthTones;
            series3.ChartArea = "ChartArea1";
            series3.Color = System.Drawing.Color.DarkOrange;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.chartDaysLeft.Series.Add(series3);
            this.chartDaysLeft.Size = new System.Drawing.Size(454, 219);
            this.chartDaysLeft.TabIndex = 12;
            this.chartDaysLeft.Text = "chart3";
            // 
            // chartDaysOutstanding
            // 
            this.chartDaysOutstanding.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.chartDaysOutstanding.BackColor = System.Drawing.Color.Transparent;
            chartArea6.AxisX.MajorGrid.Enabled = false;
            chartArea6.AxisY.MajorGrid.Enabled = false;
            chartArea6.BackColor = System.Drawing.Color.Transparent;
            chartArea6.Name = "ChartArea1";
            this.chartDaysOutstanding.ChartAreas.Add(chartArea6);
            legend6.BackColor = System.Drawing.Color.Transparent;
            legend6.Name = "Legend1";
            this.chartDaysOutstanding.Legends.Add(legend6);
            this.chartDaysOutstanding.Location = new System.Drawing.Point(724, 311);
            this.chartDaysOutstanding.Name = "chartDaysOutstanding";
            this.chartDaysOutstanding.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.EarthTones;
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chartDaysOutstanding.Series.Add(series4);
            this.chartDaysOutstanding.Size = new System.Drawing.Size(461, 219);
            this.chartDaysOutstanding.TabIndex = 13;
            this.chartDaysOutstanding.Text = "chart4";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(1529, 39);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(166, 22);
            this.txtPassword.TabIndex = 16;
            this.txtPassword.Visible = false;
            // 
            // lbNoResultsAcknowledgement
            // 
            this.lbNoResultsAcknowledgement.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbNoResultsAcknowledgement.AutoSize = true;
            this.lbNoResultsAcknowledgement.BackColor = System.Drawing.Color.White;
            this.lbNoResultsAcknowledgement.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbNoResultsAcknowledgement.ForeColor = System.Drawing.Color.Red;
            this.lbNoResultsAcknowledgement.Location = new System.Drawing.Point(1447, 390);
            this.lbNoResultsAcknowledgement.Name = "lbNoResultsAcknowledgement";
            this.lbNoResultsAcknowledgement.Size = new System.Drawing.Size(379, 20);
            this.lbNoResultsAcknowledgement.TabIndex = 21;
            this.lbNoResultsAcknowledgement.Text = "Nothing to display/No overdue acknowledgements";
            // 
            // btnEnterPassword
            // 
            this.btnEnterPassword.Location = new System.Drawing.Point(1701, 36);
            this.btnEnterPassword.Name = "btnEnterPassword";
            this.btnEnterPassword.Size = new System.Drawing.Size(75, 23);
            this.btnEnterPassword.TabIndex = 15;
            this.btnEnterPassword.Text = "Submit";
            this.btnEnterPassword.UseVisualStyleBackColor = true;
            this.btnEnterPassword.Visible = false;
            this.btnEnterPassword.Click += new System.EventHandler(this.btnEnterPassword_Click);
            // 
            // dgvKPI
            // 
            this.dgvKPI.AllowUserToAddRows = false;
            this.dgvKPI.AllowUserToDeleteRows = false;
            this.dgvKPI.AllowUserToOrderColumns = true;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvKPI.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvKPI.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvKPI.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvKPI.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dgvKPI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKPI.ContextMenuStrip = this.cmsMetrics;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvKPI.DefaultCellStyle = dataGridViewCellStyle15;
            this.dgvKPI.Location = new System.Drawing.Point(1401, 62);
            this.dgvKPI.Name = "dgvKPI";
            this.dgvKPI.ReadOnly = true;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvKPI.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvKPI.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.dgvKPI.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvKPI.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvKPI.RowTemplate.Height = 24;
            this.dgvKPI.Size = new System.Drawing.Size(51, 43);
            this.dgvKPI.TabIndex = 10;
            this.dgvKPI.Tag = "dgvTransitions";
            this.dgvKPI.Visible = false;
            this.dgvKPI.CellContextMenuStripNeeded += new System.Windows.Forms.DataGridViewCellContextMenuStripNeededEventHandler(this.dgvKPI_CellContextMenuStripNeeded);
            // 
            // chartAcknowledge
            // 
            this.chartAcknowledge.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartAcknowledge.BackColor = System.Drawing.Color.Transparent;
            chartArea7.AxisX.MajorGrid.Enabled = false;
            chartArea7.AxisY.MajorGrid.Enabled = false;
            chartArea7.BackColor = System.Drawing.Color.Transparent;
            chartArea7.Name = "ChartArea1";
            this.chartAcknowledge.ChartAreas.Add(chartArea7);
            legend7.BackColor = System.Drawing.Color.Transparent;
            legend7.Name = "Legend1";
            this.chartAcknowledge.Legends.Add(legend7);
            this.chartAcknowledge.Location = new System.Drawing.Point(1446, 24);
            this.chartAcknowledge.Name = "chartAcknowledge";
            this.chartAcknowledge.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.chartAcknowledge.Series.Add(series5);
            this.chartAcknowledge.Size = new System.Drawing.Size(369, 701);
            this.chartAcknowledge.TabIndex = 14;
            this.chartAcknowledge.Text = "chart2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(681, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(245, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Overdue Acknowledgements";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(475, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Total WF items";
            // 
            // txtOverdueAcknowledge
            // 
            this.txtOverdueAcknowledge.BackColor = System.Drawing.Color.AntiqueWhite;
            this.txtOverdueAcknowledge.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtOverdueAcknowledge.Location = new System.Drawing.Point(685, 51);
            this.txtOverdueAcknowledge.Multiline = true;
            this.txtOverdueAcknowledge.Name = "txtOverdueAcknowledge";
            this.txtOverdueAcknowledge.ReadOnly = true;
            this.txtOverdueAcknowledge.Size = new System.Drawing.Size(241, 92);
            this.txtOverdueAcknowledge.TabIndex = 5;
            this.txtOverdueAcknowledge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtTotalItems
            // 
            this.txtTotalItems.BackColor = System.Drawing.Color.AntiqueWhite;
            this.txtTotalItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotalItems.Location = new System.Drawing.Point(452, 51);
            this.txtTotalItems.Multiline = true;
            this.txtTotalItems.Name = "txtTotalItems";
            this.txtTotalItems.ReadOnly = true;
            this.txtTotalItems.Size = new System.Drawing.Size(178, 92);
            this.txtTotalItems.TabIndex = 4;
            this.txtTotalItems.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chkShowOverdueOnly);
            this.groupBox2.Controls.Add(this.chCalculateKPI);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.cmbAcknowledgementOtherSLA);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cmbAcknowledgementSLA);
            this.groupBox2.Controls.Add(this.btn_CalcKPI);
            this.groupBox2.Location = new System.Drawing.Point(16, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(404, 180);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "KPI parameters";
            // 
            // chkShowOverdueOnly
            // 
            this.chkShowOverdueOnly.AutoSize = true;
            this.chkShowOverdueOnly.ForeColor = System.Drawing.Color.Red;
            this.chkShowOverdueOnly.Location = new System.Drawing.Point(23, 103);
            this.chkShowOverdueOnly.Name = "chkShowOverdueOnly";
            this.chkShowOverdueOnly.Size = new System.Drawing.Size(287, 21);
            this.chkShowOverdueOnly.TabIndex = 23;
            this.chkShowOverdueOnly.Text = "Only display overdue acknowledgements";
            this.chkShowOverdueOnly.UseVisualStyleBackColor = true;
            this.chkShowOverdueOnly.CheckedChanged += new System.EventHandler(this.chkShowOverdueOnly_CheckedChanged);
            // 
            // chCalculateKPI
            // 
            this.chCalculateKPI.AutoSize = true;
            this.chCalculateKPI.ForeColor = System.Drawing.Color.Red;
            this.chCalculateKPI.Location = new System.Drawing.Point(23, 81);
            this.chCalculateKPI.Name = "chCalculateKPI";
            this.chCalculateKPI.Size = new System.Drawing.Size(270, 21);
            this.chCalculateKPI.TabIndex = 5;
            this.chCalculateKPI.Text = "Refresh KPIs automatically all the time";
            this.toolTipAddFilter.SetToolTip(this.chCalculateKPI, "If this option is checked, no need to press \'Refresh KPIs\' button after worflow f" +
        "ilter update.");
            this.chCalculateKPI.UseVisualStyleBackColor = true;
            this.chCalculateKPI.CheckedChanged += new System.EventHandler(this.chCalculateKPI_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(149, 61);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(236, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Hours for acknowledgmenet - Errors";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // cmbAcknowledgementOtherSLA
            // 
            this.cmbAcknowledgementOtherSLA.Enabled = false;
            this.cmbAcknowledgementOtherSLA.Location = new System.Drawing.Point(23, 56);
            this.cmbAcknowledgementOtherSLA.Name = "cmbAcknowledgementOtherSLA";
            this.cmbAcknowledgementOtherSLA.Size = new System.Drawing.Size(120, 22);
            this.cmbAcknowledgementOtherSLA.TabIndex = 4;
            this.cmbAcknowledgementOtherSLA.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(149, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Hours for acknowledgmenet - Workflow";
            // 
            // cmbAcknowledgementSLA
            // 
            this.cmbAcknowledgementSLA.Enabled = false;
            this.cmbAcknowledgementSLA.Location = new System.Drawing.Point(23, 31);
            this.cmbAcknowledgementSLA.Name = "cmbAcknowledgementSLA";
            this.cmbAcknowledgementSLA.Size = new System.Drawing.Size(120, 22);
            this.cmbAcknowledgementSLA.TabIndex = 1;
            this.cmbAcknowledgementSLA.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // btn_CalcKPI
            // 
            this.btn_CalcKPI.Location = new System.Drawing.Point(23, 130);
            this.btn_CalcKPI.Name = "btn_CalcKPI";
            this.btn_CalcKPI.Size = new System.Drawing.Size(362, 44);
            this.btn_CalcKPI.TabIndex = 2;
            this.btn_CalcKPI.Text = "Refresh KPIs ";
            this.btn_CalcKPI.UseVisualStyleBackColor = true;
            this.btn_CalcKPI.Click += new System.EventHandler(this.btn_CalcKPI_Click);
            // 
            // tbpgWorkday
            // 
            this.tbpgWorkday.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tbpgWorkday.Controls.Add(this.cmbSheduleDetailLevel);
            this.tbpgWorkday.Controls.Add(this.groupBox7);
            this.tbpgWorkday.Controls.Add(this.chklstSheduleFields);
            this.tbpgWorkday.Controls.Add(this.btnShowHideHours);
            this.tbpgWorkday.Controls.Add(this.button1);
            this.tbpgWorkday.Controls.Add(this.tbpgMySchedule);
            this.tbpgWorkday.Location = new System.Drawing.Point(4, 24);
            this.tbpgWorkday.Name = "tbpgWorkday";
            this.tbpgWorkday.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgWorkday.Size = new System.Drawing.Size(1826, 731);
            this.tbpgWorkday.TabIndex = 6;
            this.tbpgWorkday.Tag = "tbpgMySchedule";
            this.tbpgWorkday.Text = "Workday";
            // 
            // cmbSheduleDetailLevel
            // 
            this.cmbSheduleDetailLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSheduleDetailLevel.FormattingEnabled = true;
            this.cmbSheduleDetailLevel.Items.AddRange(new object[] {
            "Detailed",
            "Consolidated",
            "Summarized"});
            this.cmbSheduleDetailLevel.Location = new System.Drawing.Point(8, 68);
            this.cmbSheduleDetailLevel.Name = "cmbSheduleDetailLevel";
            this.cmbSheduleDetailLevel.Size = new System.Drawing.Size(249, 24);
            this.cmbSheduleDetailLevel.TabIndex = 8;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rbProcTime);
            this.groupBox7.Controls.Add(this.rbBoth);
            this.groupBox7.Controls.Add(this.rbSetUp);
            this.groupBox7.Location = new System.Drawing.Point(276, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(200, 95);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Basis of calculation";
            // 
            // rbProcTime
            // 
            this.rbProcTime.AutoSize = true;
            this.rbProcTime.Checked = true;
            this.rbProcTime.Location = new System.Drawing.Point(6, 21);
            this.rbProcTime.Name = "rbProcTime";
            this.rbProcTime.Size = new System.Drawing.Size(134, 21);
            this.rbProcTime.TabIndex = 4;
            this.rbProcTime.TabStop = true;
            this.rbProcTime.Text = "Processing Time";
            this.rbProcTime.UseVisualStyleBackColor = true;
            // 
            // rbBoth
            // 
            this.rbBoth.AutoSize = true;
            this.rbBoth.Location = new System.Drawing.Point(6, 62);
            this.rbBoth.Name = "rbBoth";
            this.rbBoth.Size = new System.Drawing.Size(58, 21);
            this.rbBoth.TabIndex = 6;
            this.rbBoth.Text = "Both";
            this.rbBoth.UseVisualStyleBackColor = true;
            // 
            // rbSetUp
            // 
            this.rbSetUp.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.rbSetUp.AutoSize = true;
            this.rbSetUp.Location = new System.Drawing.Point(6, 41);
            this.rbSetUp.Name = "rbSetUp";
            this.rbSetUp.Size = new System.Drawing.Size(101, 21);
            this.rbSetUp.TabIndex = 5;
            this.rbSetUp.Text = "Setup Time";
            this.rbSetUp.UseVisualStyleBackColor = true;
            // 
            // chklstSheduleFields
            // 
            this.chklstSheduleFields.BackColor = System.Drawing.Color.AntiqueWhite;
            this.chklstSheduleFields.CheckOnClick = true;
            this.chklstSheduleFields.FormattingEnabled = true;
            this.chklstSheduleFields.Location = new System.Drawing.Point(1280, 107);
            this.chklstSheduleFields.Name = "chklstSheduleFields";
            this.chklstSheduleFields.Size = new System.Drawing.Size(244, 599);
            this.chklstSheduleFields.TabIndex = 0;
            this.chklstSheduleFields.Visible = false;
            this.chklstSheduleFields.SelectedIndexChanged += new System.EventHandler(this.chklstSheduleFields_SelectedIndexChanged);
            this.chklstSheduleFields.MouseLeave += new System.EventHandler(this.chklstSheduleFields_MouseLeave);
            // 
            // btnShowHideHours
            // 
            this.btnShowHideHours.BackColor = System.Drawing.Color.Transparent;
            this.btnShowHideHours.Cursor = System.Windows.Forms.Cursors.PanSouth;
            this.btnShowHideHours.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowHideHours.ForeColor = System.Drawing.Color.Red;
            this.btnShowHideHours.Location = new System.Drawing.Point(1280, 62);
            this.btnShowHideHours.Name = "btnShowHideHours";
            this.btnShowHideHours.Size = new System.Drawing.Size(244, 42);
            this.btnShowHideHours.TabIndex = 2;
            this.btnShowHideHours.Text = "Show/Hide Hours ↓";
            this.btnShowHideHours.UseVisualStyleBackColor = false;
            this.btnShowHideHours.MouseHover += new System.EventHandler(this.btnShowHideHours_MouseHover);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(8, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(249, 40);
            this.button1.TabIndex = 1;
            this.button1.Text = "Refresh ↻";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // tbpgMySchedule
            // 
            this.tbpgMySchedule.AllowUserToAddRows = false;
            this.tbpgMySchedule.AllowUserToDeleteRows = false;
            this.tbpgMySchedule.AllowUserToResizeColumns = false;
            this.tbpgMySchedule.AllowUserToResizeRows = false;
            this.tbpgMySchedule.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.tbpgMySchedule.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.tbpgMySchedule.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tbpgMySchedule.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbpgMySchedule.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical;
            this.tbpgMySchedule.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tbpgMySchedule.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.tbpgMySchedule.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.Padding = new System.Windows.Forms.Padding(0, 0, 1, 1);
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.tbpgMySchedule.DefaultCellStyle = dataGridViewCellStyle18;
            this.tbpgMySchedule.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.tbpgMySchedule.GridColor = System.Drawing.Color.Gray;
            this.tbpgMySchedule.Location = new System.Drawing.Point(6, 107);
            this.tbpgMySchedule.Margin = new System.Windows.Forms.Padding(0);
            this.tbpgMySchedule.Name = "tbpgMySchedule";
            this.tbpgMySchedule.ReadOnly = true;
            this.tbpgMySchedule.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.Black;
            this.tbpgMySchedule.RowsDefaultCellStyle = dataGridViewCellStyle19;
            this.tbpgMySchedule.RowTemplate.Height = 24;
            this.tbpgMySchedule.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tbpgMySchedule.Size = new System.Drawing.Size(1518, 590);
            this.tbpgMySchedule.TabIndex = 0;
            // 
            // lstTransitionAnalyst
            // 
            this.lstTransitionAnalyst.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lstTransitionAnalyst.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstTransitionAnalyst.FormattingEnabled = true;
            this.lstTransitionAnalyst.ItemHeight = 16;
            this.lstTransitionAnalyst.Location = new System.Drawing.Point(7, 122);
            this.lstTransitionAnalyst.Name = "lstTransitionAnalyst";
            this.lstTransitionAnalyst.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstTransitionAnalyst.Size = new System.Drawing.Size(257, 612);
            this.lstTransitionAnalyst.Sorted = true;
            this.lstTransitionAnalyst.TabIndex = 10;
            this.lstTransitionAnalyst.SelectedIndexChanged += new System.EventHandler(this.lstTransitionAnalyst_SelectedIndexChanged);
            // 
            // btnLoadTransitionSpreadsheet
            // 
            this.btnLoadTransitionSpreadsheet.ForeColor = System.Drawing.Color.Red;
            this.btnLoadTransitionSpreadsheet.Location = new System.Drawing.Point(6, 6);
            this.btnLoadTransitionSpreadsheet.Name = "btnLoadTransitionSpreadsheet";
            this.btnLoadTransitionSpreadsheet.Size = new System.Drawing.Size(258, 42);
            this.btnLoadTransitionSpreadsheet.TabIndex = 9;
            this.btnLoadTransitionSpreadsheet.Text = "Load Transition";
            this.btnLoadTransitionSpreadsheet.UseVisualStyleBackColor = true;
            this.btnLoadTransitionSpreadsheet.Click += new System.EventHandler(this.btnLoadTransitionSpreadsheet_Click_1);
            // 
            // dgvTransitions
            // 
            this.dgvTransitions.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTransitions.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvTransitions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTransitions.DefaultCellStyle = dataGridViewCellStyle21;
            this.dgvTransitions.Location = new System.Drawing.Point(269, 6);
            this.dgvTransitions.Name = "dgvTransitions";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTransitions.RowHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvTransitions.RowHeadersVisible = false;
            this.dgvTransitions.RowTemplate.Height = 24;
            this.dgvTransitions.Size = new System.Drawing.Size(1536, 730);
            this.dgvTransitions.StandardTab = true;
            this.dgvTransitions.TabIndex = 8;
            this.dgvTransitions.Tag = "dgvTransitions";
            // 
            // requestSubmissionBindingSource
            // 
            this.requestSubmissionBindingSource.DataMember = "Request Submission";
            this.requestSubmissionBindingSource.DataSource = this.database4DataSet;
            // 
            // database4DataSet
            // 
            this.database4DataSet.DataSetName = "Database4DataSet";
            this.database4DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbctlMain
            // 
            this.tbctlMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbctlMain.Controls.Add(this.tbpgReportCatalogue);
            this.tbctlMain.Controls.Add(this.tbclTransition);
            this.tbctlMain.Controls.Add(this.tabPage1);
            this.tbctlMain.Controls.Add(this.tbclEPM);
            this.tbctlMain.Location = new System.Drawing.Point(19, 34);
            this.tbctlMain.Margin = new System.Windows.Forms.Padding(4);
            this.tbctlMain.Name = "tbctlMain";
            this.tbctlMain.SelectedIndex = 0;
            this.tbctlMain.Size = new System.Drawing.Size(1846, 796);
            this.tbctlMain.TabIndex = 0;
            this.tbctlMain.Tag = "dgvRAActive";
            this.tbctlMain.SelectedIndexChanged += new System.EventHandler(this.tbctlMain_SelectedIndexChanged);
            // 
            // tbclTransition
            // 
            this.tbclTransition.Controls.Add(this.tbclExcel);
            this.tbclTransition.Location = new System.Drawing.Point(4, 25);
            this.tbclTransition.Name = "tbclTransition";
            this.tbclTransition.Padding = new System.Windows.Forms.Padding(3);
            this.tbclTransition.Size = new System.Drawing.Size(1838, 767);
            this.tbclTransition.TabIndex = 4;
            this.tbclTransition.Tag = "dgvRAActive";
            this.tbclTransition.Text = "Excel Datasources";
            this.tbclTransition.UseVisualStyleBackColor = true;
            // 
            // tbclExcel
            // 
            this.tbclExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbclExcel.Controls.Add(this.tbDashboardRollover);
            this.tbclExcel.Controls.Add(this.tbclTransitions);
            this.tbclExcel.Location = new System.Drawing.Point(3, 0);
            this.tbclExcel.Name = "tbclExcel";
            this.tbclExcel.SelectedIndex = 0;
            this.tbclExcel.Size = new System.Drawing.Size(1821, 845);
            this.tbclExcel.TabIndex = 3;
            this.tbclExcel.Tag = "tbclExcel";
            // 
            // tbDashboardRollover
            // 
            this.tbDashboardRollover.AutoScroll = true;
            this.tbDashboardRollover.Controls.Add(this.chkRolloverTeam);
            this.tbDashboardRollover.Controls.Add(this.btnShowRolloverFieldPanel);
            this.tbDashboardRollover.Controls.Add(this.btnLoadRollover);
            this.tbDashboardRollover.Controls.Add(this.lstRolloverAnalyst);
            this.tbDashboardRollover.Controls.Add(this.panelRollover);
            this.tbDashboardRollover.Controls.Add(this.dgvRolloverDashBoard);
            this.tbDashboardRollover.Location = new System.Drawing.Point(4, 25);
            this.tbDashboardRollover.Name = "tbDashboardRollover";
            this.tbDashboardRollover.Padding = new System.Windows.Forms.Padding(3);
            this.tbDashboardRollover.Size = new System.Drawing.Size(1813, 816);
            this.tbDashboardRollover.TabIndex = 1;
            this.tbDashboardRollover.Text = "Rollover dashboard";
            this.tbDashboardRollover.UseVisualStyleBackColor = true;
            // 
            // chkRolloverTeam
            // 
            this.chkRolloverTeam.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.chkRolloverTeam.AutoSize = true;
            this.chkRolloverTeam.Location = new System.Drawing.Point(7, 100);
            this.chkRolloverTeam.Name = "chkRolloverTeam";
            this.chkRolloverTeam.Size = new System.Drawing.Size(136, 21);
            this.chkRolloverTeam.TabIndex = 26;
            this.chkRolloverTeam.Text = "Select your team";
            this.chkRolloverTeam.UseVisualStyleBackColor = true;
            this.chkRolloverTeam.CheckedChanged += new System.EventHandler(this.chkRolloverTeam_CheckedChanged);
            // 
            // btnShowRolloverFieldPanel
            // 
            this.btnShowRolloverFieldPanel.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnShowRolloverFieldPanel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnShowRolloverFieldPanel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightCoral;
            this.btnShowRolloverFieldPanel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnShowRolloverFieldPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowRolloverFieldPanel.ForeColor = System.Drawing.Color.Red;
            this.btnShowRolloverFieldPanel.Location = new System.Drawing.Point(7, 54);
            this.btnShowRolloverFieldPanel.Name = "btnShowRolloverFieldPanel";
            this.btnShowRolloverFieldPanel.Size = new System.Drawing.Size(257, 40);
            this.btnShowRolloverFieldPanel.TabIndex = 24;
            this.btnShowRolloverFieldPanel.Text = "Hide Settings <<";
            this.btnShowRolloverFieldPanel.UseVisualStyleBackColor = true;
            this.btnShowRolloverFieldPanel.Click += new System.EventHandler(this.btnShowRolloverFieldPanel_Click);
            // 
            // btnLoadRollover
            // 
            this.btnLoadRollover.ForeColor = System.Drawing.Color.Red;
            this.btnLoadRollover.Location = new System.Drawing.Point(6, 6);
            this.btnLoadRollover.Name = "btnLoadRollover";
            this.btnLoadRollover.Size = new System.Drawing.Size(258, 42);
            this.btnLoadRollover.TabIndex = 21;
            this.btnLoadRollover.Text = "Load Rollover";
            this.btnLoadRollover.UseVisualStyleBackColor = true;
            this.btnLoadRollover.Click += new System.EventHandler(this.btnLoadRollover_Click);
            // 
            // lstRolloverAnalyst
            // 
            this.lstRolloverAnalyst.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lstRolloverAnalyst.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstRolloverAnalyst.FormattingEnabled = true;
            this.lstRolloverAnalyst.ItemHeight = 16;
            this.lstRolloverAnalyst.Location = new System.Drawing.Point(6, 122);
            this.lstRolloverAnalyst.Name = "lstRolloverAnalyst";
            this.lstRolloverAnalyst.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstRolloverAnalyst.Size = new System.Drawing.Size(257, 612);
            this.lstRolloverAnalyst.Sorted = true;
            this.lstRolloverAnalyst.TabIndex = 22;
            this.lstRolloverAnalyst.SelectedIndexChanged += new System.EventHandler(this.lstRolloverAnalyst_SelectedIndexChanged);
            // 
            // panelRollover
            // 
            this.panelRollover.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelRollover.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRollover.Controls.Add(this.chkGuessFilePathRollover);
            this.panelRollover.Controls.Add(this.btnSaveRolloverSettings);
            this.panelRollover.Controls.Add(this.chkPreselectedRolloverFields);
            this.panelRollover.Controls.Add(this.tbnBrowseRollover);
            this.panelRollover.Controls.Add(this.txtRolloverPath);
            this.panelRollover.Controls.Add(this.label16);
            this.panelRollover.Controls.Add(this.chklstRolloverFields);
            this.panelRollover.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelRollover.ForeColor = System.Drawing.Color.Red;
            this.panelRollover.Location = new System.Drawing.Point(269, 3);
            this.panelRollover.Name = "panelRollover";
            this.panelRollover.Size = new System.Drawing.Size(1541, 731);
            this.panelRollover.TabIndex = 23;
            // 
            // chkGuessFilePathRollover
            // 
            this.chkGuessFilePathRollover.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkGuessFilePathRollover.AutoSize = true;
            this.chkGuessFilePathRollover.Location = new System.Drawing.Point(260, 75);
            this.chkGuessFilePathRollover.Name = "chkGuessFilePathRollover";
            this.chkGuessFilePathRollover.Size = new System.Drawing.Size(145, 21);
            this.chkGuessFilePathRollover.TabIndex = 25;
            this.chkGuessFilePathRollover.Text = "Guess the filepath";
            this.chkGuessFilePathRollover.UseVisualStyleBackColor = true;
            this.chkGuessFilePathRollover.CheckedChanged += new System.EventHandler(this.chkGuessFilePathRollover_CheckedChanged);
            // 
            // btnSaveRolloverSettings
            // 
            this.btnSaveRolloverSettings.Location = new System.Drawing.Point(542, 75);
            this.btnSaveRolloverSettings.Name = "btnSaveRolloverSettings";
            this.btnSaveRolloverSettings.Size = new System.Drawing.Size(107, 38);
            this.btnSaveRolloverSettings.TabIndex = 24;
            this.btnSaveRolloverSettings.Text = "Save settings";
            this.btnSaveRolloverSettings.UseVisualStyleBackColor = true;
            this.btnSaveRolloverSettings.Click += new System.EventHandler(this.btnSaveRolloverSettings_Click);
            // 
            // chkPreselectedRolloverFields
            // 
            this.chkPreselectedRolloverFields.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkPreselectedRolloverFields.AutoSize = true;
            this.chkPreselectedRolloverFields.Location = new System.Drawing.Point(19, 75);
            this.chkPreselectedRolloverFields.Name = "chkPreselectedRolloverFields";
            this.chkPreselectedRolloverFields.Size = new System.Drawing.Size(220, 21);
            this.chkPreselectedRolloverFields.TabIndex = 22;
            this.chkPreselectedRolloverFields.Text = "Include only preselected fields";
            this.chkPreselectedRolloverFields.UseVisualStyleBackColor = true;
            this.chkPreselectedRolloverFields.CheckedChanged += new System.EventHandler(this.chkPreselectedRolloverFields_CheckedChanged);
            // 
            // tbnBrowseRollover
            // 
            this.tbnBrowseRollover.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tbnBrowseRollover.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbnBrowseRollover.ForeColor = System.Drawing.Color.Red;
            this.tbnBrowseRollover.Image = ((System.Drawing.Image)(resources.GetObject("tbnBrowseRollover.Image")));
            this.tbnBrowseRollover.Location = new System.Drawing.Point(1175, 49);
            this.tbnBrowseRollover.Name = "tbnBrowseRollover";
            this.tbnBrowseRollover.Size = new System.Drawing.Size(43, 41);
            this.tbnBrowseRollover.TabIndex = 21;
            this.tbnBrowseRollover.UseVisualStyleBackColor = true;
            this.tbnBrowseRollover.Click += new System.EventHandler(this.tbnBrowseRollover_Click);
            // 
            // txtRolloverPath
            // 
            this.txtRolloverPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRolloverPath.Location = new System.Drawing.Point(19, 46);
            this.txtRolloverPath.Name = "txtRolloverPath";
            this.txtRolloverPath.Size = new System.Drawing.Size(1150, 23);
            this.txtRolloverPath.TabIndex = 20;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 23);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(206, 17);
            this.label16.TabIndex = 19;
            this.label16.Text = "Transition Spreadsheet filepath";
            // 
            // chklstRolloverFields
            // 
            this.chklstRolloverFields.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.chklstRolloverFields.CheckOnClick = true;
            this.chklstRolloverFields.FormattingEnabled = true;
            this.chklstRolloverFields.Location = new System.Drawing.Point(19, 119);
            this.chklstRolloverFields.Name = "chklstRolloverFields";
            this.chklstRolloverFields.Size = new System.Drawing.Size(1199, 582);
            this.chklstRolloverFields.TabIndex = 18;
            this.chklstRolloverFields.SelectedIndexChanged += new System.EventHandler(this.chklstRolloverFields_SelectedIndexChanged);
            // 
            // dgvRolloverDashBoard
            // 
            this.dgvRolloverDashBoard.AllowUserToAddRows = false;
            this.dgvRolloverDashBoard.AllowUserToDeleteRows = false;
            this.dgvRolloverDashBoard.AllowUserToOrderColumns = true;
            this.dgvRolloverDashBoard.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRolloverDashBoard.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRolloverDashBoard.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dgvRolloverDashBoard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Red;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRolloverDashBoard.DefaultCellStyle = dataGridViewCellStyle24;
            this.dgvRolloverDashBoard.Location = new System.Drawing.Point(269, 6);
            this.dgvRolloverDashBoard.Name = "dgvRolloverDashBoard";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRolloverDashBoard.RowHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvRolloverDashBoard.RowHeadersVisible = false;
            this.dgvRolloverDashBoard.RowTemplate.Height = 24;
            this.dgvRolloverDashBoard.Size = new System.Drawing.Size(1538, 728);
            this.dgvRolloverDashBoard.StandardTab = true;
            this.dgvRolloverDashBoard.TabIndex = 28;
            this.dgvRolloverDashBoard.Tag = "dgvTransitions";
            // 
            // tbclTransitions
            // 
            this.tbclTransitions.Controls.Add(this.chkTransitionTeam);
            this.tbclTransitions.Controls.Add(this.btnShowFieldPanel);
            this.tbclTransitions.Controls.Add(this.panelFieldSelections);
            this.tbclTransitions.Controls.Add(this.btnLoadTransitionSpreadsheet);
            this.tbclTransitions.Controls.Add(this.lstTransitionAnalyst);
            this.tbclTransitions.Controls.Add(this.dgvTransitions);
            this.tbclTransitions.Controls.Add(this.dgvETActive);
            this.tbclTransitions.Controls.Add(this.dgvRAActive);
            this.tbclTransitions.Location = new System.Drawing.Point(4, 25);
            this.tbclTransitions.Name = "tbclTransitions";
            this.tbclTransitions.Padding = new System.Windows.Forms.Padding(3);
            this.tbclTransitions.Size = new System.Drawing.Size(1813, 816);
            this.tbclTransitions.TabIndex = 0;
            this.tbclTransitions.Text = "Transitions";
            this.tbclTransitions.UseVisualStyleBackColor = true;
            // 
            // chkTransitionTeam
            // 
            this.chkTransitionTeam.AutoSize = true;
            this.chkTransitionTeam.Location = new System.Drawing.Point(7, 100);
            this.chkTransitionTeam.Name = "chkTransitionTeam";
            this.chkTransitionTeam.Size = new System.Drawing.Size(136, 21);
            this.chkTransitionTeam.TabIndex = 25;
            this.chkTransitionTeam.Text = "Select your team";
            this.chkTransitionTeam.UseVisualStyleBackColor = true;
            this.chkTransitionTeam.CheckedChanged += new System.EventHandler(this.chkTransitionTeam_CheckedChanged);
            // 
            // btnShowFieldPanel
            // 
            this.btnShowFieldPanel.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnShowFieldPanel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnShowFieldPanel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightCoral;
            this.btnShowFieldPanel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnShowFieldPanel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowFieldPanel.ForeColor = System.Drawing.Color.Red;
            this.btnShowFieldPanel.Location = new System.Drawing.Point(6, 54);
            this.btnShowFieldPanel.Name = "btnShowFieldPanel";
            this.btnShowFieldPanel.Size = new System.Drawing.Size(257, 40);
            this.btnShowFieldPanel.TabIndex = 20;
            this.btnShowFieldPanel.Text = "Hide Settings <<";
            this.btnShowFieldPanel.UseVisualStyleBackColor = true;
            this.btnShowFieldPanel.Click += new System.EventHandler(this.btnShowFieldPanel_Click);
            this.btnShowFieldPanel.MouseHover += new System.EventHandler(this.btnShowFieldPanel_MouseHover);
            // 
            // panelFieldSelections
            // 
            this.panelFieldSelections.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelFieldSelections.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelFieldSelections.Controls.Add(this.chkGuessFilePath);
            this.panelFieldSelections.Controls.Add(this.btnSaveTransitionSettings);
            this.panelFieldSelections.Controls.Add(this.chkPreselectedTransitionFields);
            this.panelFieldSelections.Controls.Add(this.tbnBrowseTransition);
            this.panelFieldSelections.Controls.Add(this.txtTransitionPath);
            this.panelFieldSelections.Controls.Add(this.label7);
            this.panelFieldSelections.Controls.Add(this.chklstTransitionFields);
            this.panelFieldSelections.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelFieldSelections.ForeColor = System.Drawing.Color.Red;
            this.panelFieldSelections.Location = new System.Drawing.Point(268, 6);
            this.panelFieldSelections.Name = "panelFieldSelections";
            this.panelFieldSelections.Size = new System.Drawing.Size(1537, 730);
            this.panelFieldSelections.TabIndex = 19;
            // 
            // chkGuessFilePath
            // 
            this.chkGuessFilePath.AutoSize = true;
            this.chkGuessFilePath.Location = new System.Drawing.Point(260, 84);
            this.chkGuessFilePath.Name = "chkGuessFilePath";
            this.chkGuessFilePath.Size = new System.Drawing.Size(145, 21);
            this.chkGuessFilePath.TabIndex = 25;
            this.chkGuessFilePath.Text = "Guess the filepath";
            this.chkGuessFilePath.UseVisualStyleBackColor = true;
            this.chkGuessFilePath.CheckedChanged += new System.EventHandler(this.chkGuessFilePath_CheckedChanged);
            // 
            // btnSaveTransitionSettings
            // 
            this.btnSaveTransitionSettings.Location = new System.Drawing.Point(584, 84);
            this.btnSaveTransitionSettings.Name = "btnSaveTransitionSettings";
            this.btnSaveTransitionSettings.Size = new System.Drawing.Size(106, 39);
            this.btnSaveTransitionSettings.TabIndex = 24;
            this.btnSaveTransitionSettings.Text = "Save settings";
            this.btnSaveTransitionSettings.UseVisualStyleBackColor = true;
            this.btnSaveTransitionSettings.Click += new System.EventHandler(this.btnSaveTransitionSettings_Click);
            // 
            // chkPreselectedTransitionFields
            // 
            this.chkPreselectedTransitionFields.AutoSize = true;
            this.chkPreselectedTransitionFields.Location = new System.Drawing.Point(19, 84);
            this.chkPreselectedTransitionFields.Name = "chkPreselectedTransitionFields";
            this.chkPreselectedTransitionFields.Size = new System.Drawing.Size(220, 21);
            this.chkPreselectedTransitionFields.TabIndex = 22;
            this.chkPreselectedTransitionFields.Text = "Include only preselected fields";
            this.chkPreselectedTransitionFields.UseVisualStyleBackColor = true;
            this.chkPreselectedTransitionFields.CheckedChanged += new System.EventHandler(this.chkPreselectedTransitionFields_CheckedChanged);
            // 
            // tbnBrowseTransition
            // 
            this.tbnBrowseTransition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tbnBrowseTransition.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbnBrowseTransition.ForeColor = System.Drawing.Color.Red;
            this.tbnBrowseTransition.Image = ((System.Drawing.Image)(resources.GetObject("tbnBrowseTransition.Image")));
            this.tbnBrowseTransition.Location = new System.Drawing.Point(1191, 55);
            this.tbnBrowseTransition.Name = "tbnBrowseTransition";
            this.tbnBrowseTransition.Size = new System.Drawing.Size(40, 40);
            this.tbnBrowseTransition.TabIndex = 21;
            this.tbnBrowseTransition.UseVisualStyleBackColor = true;
            this.tbnBrowseTransition.Click += new System.EventHandler(this.tbnBrowseTransition_Click);
            // 
            // txtTransitionPath
            // 
            this.txtTransitionPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTransitionPath.Location = new System.Drawing.Point(19, 55);
            this.txtTransitionPath.Name = "txtTransitionPath";
            this.txtTransitionPath.Size = new System.Drawing.Size(1166, 23);
            this.txtTransitionPath.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(206, 17);
            this.label7.TabIndex = 19;
            this.label7.Text = "Transition Spreadsheet filepath";
            // 
            // chklstTransitionFields
            // 
            this.chklstTransitionFields.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.chklstTransitionFields.CheckOnClick = true;
            this.chklstTransitionFields.FormattingEnabled = true;
            this.chklstTransitionFields.Location = new System.Drawing.Point(19, 129);
            this.chklstTransitionFields.Name = "chklstTransitionFields";
            this.chklstTransitionFields.Size = new System.Drawing.Size(1212, 582);
            this.chklstTransitionFields.TabIndex = 18;
            this.chklstTransitionFields.SelectedIndexChanged += new System.EventHandler(this.chklstTransitionFields_SelectedIndexChanged);
            // 
            // dgvETActive
            // 
            this.dgvETActive.AllowUserToAddRows = false;
            this.dgvETActive.AllowUserToDeleteRows = false;
            this.dgvETActive.AllowUserToOrderColumns = true;
            this.dgvETActive.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvETActive.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvETActive.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvETActive.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvETActive.ContextMenuStrip = this.cmsDatagrid;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvETActive.DefaultCellStyle = dataGridViewCellStyle27;
            this.dgvETActive.Location = new System.Drawing.Point(1765, 20);
            this.dgvETActive.Margin = new System.Windows.Forms.Padding(4);
            this.dgvETActive.Name = "dgvETActive";
            this.dgvETActive.ReadOnly = true;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvETActive.RowHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvETActive.RowHeadersVisible = false;
            this.dgvETActive.Size = new System.Drawing.Size(44, 26);
            this.dgvETActive.TabIndex = 2;
            this.dgvETActive.Visible = false;
            // 
            // dgvRAActive
            // 
            this.dgvRAActive.AllowUserToAddRows = false;
            this.dgvRAActive.AllowUserToDeleteRows = false;
            this.dgvRAActive.AllowUserToOrderColumns = true;
            this.dgvRAActive.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRAActive.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRAActive.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvRAActive.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRAActive.ContextMenuStrip = this.cmsDatagrid;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRAActive.DefaultCellStyle = dataGridViewCellStyle30;
            this.dgvRAActive.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvRAActive.Location = new System.Drawing.Point(1760, 6);
            this.dgvRAActive.Margin = new System.Windows.Forms.Padding(4);
            this.dgvRAActive.Name = "dgvRAActive";
            this.dgvRAActive.ReadOnly = true;
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle31.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle31.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRAActive.RowHeadersDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvRAActive.RowHeadersVisible = false;
            this.dgvRAActive.Size = new System.Drawing.Size(46, 26);
            this.dgvRAActive.TabIndex = 1;
            this.dgvRAActive.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.lstTableName);
            this.tabPage1.Controls.Add(this.cmbDatabaseName);
            this.tabPage1.Controls.Add(this.tbnSearchFDM);
            this.tabPage1.Controls.Add(this.dgvFDM);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1838, 767);
            this.tabPage1.TabIndex = 5;
            this.tabPage1.Tag = "dgvFDM";
            this.tabPage1.Text = "Finance Datamart";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnKeywordSearch);
            this.groupBox5.Controls.Add(this.cmbFieldFilterFDM);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.txtFDMKeyword);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Location = new System.Drawing.Point(472, 18);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(948, 133);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Search by keyword";
            // 
            // btnKeywordSearch
            // 
            this.btnKeywordSearch.Location = new System.Drawing.Point(856, 35);
            this.btnKeywordSearch.Name = "btnKeywordSearch";
            this.btnKeywordSearch.Size = new System.Drawing.Size(86, 85);
            this.btnKeywordSearch.TabIndex = 10;
            this.btnKeywordSearch.Text = "Search";
            this.btnKeywordSearch.UseVisualStyleBackColor = true;
            this.btnKeywordSearch.Click += new System.EventHandler(this.btnKeywordSearch_Click);
            // 
            // cmbFieldFilterFDM
            // 
            this.cmbFieldFilterFDM.FormattingEnabled = true;
            this.cmbFieldFilterFDM.Location = new System.Drawing.Point(89, 36);
            this.cmbFieldFilterFDM.Name = "cmbFieldFilterFDM";
            this.cmbFieldFilterFDM.Size = new System.Drawing.Size(340, 24);
            this.cmbFieldFilterFDM.TabIndex = 8;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 39);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 17);
            this.label25.TabIndex = 9;
            this.label25.Text = "Field name";
            // 
            // txtFDMKeyword
            // 
            this.txtFDMKeyword.Location = new System.Drawing.Point(89, 69);
            this.txtFDMKeyword.Multiline = true;
            this.txtFDMKeyword.Name = "txtFDMKeyword";
            this.txtFDMKeyword.Size = new System.Drawing.Size(761, 48);
            this.txtFDMKeyword.TabIndex = 5;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(6, 69);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(79, 17);
            this.label24.TabIndex = 7;
            this.label24.Text = "Keyword(s)";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cmbSelectTopN);
            this.groupBox4.Controls.Add(this.chkTopN);
            this.groupBox4.Controls.Add(this.chkSelectAll);
            this.groupBox4.Location = new System.Drawing.Point(332, 18);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(134, 133);
            this.groupBox4.TabIndex = 12;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Search all";
            // 
            // cmbSelectTopN
            // 
            this.cmbSelectTopN.FormattingEnabled = true;
            this.cmbSelectTopN.Items.AddRange(new object[] {
            "100",
            "1000",
            "10000",
            "100000"});
            this.cmbSelectTopN.Location = new System.Drawing.Point(6, 88);
            this.cmbSelectTopN.Name = "cmbSelectTopN";
            this.cmbSelectTopN.Size = new System.Drawing.Size(111, 24);
            this.cmbSelectTopN.TabIndex = 13;
            this.cmbSelectTopN.SelectionChangeCommitted += new System.EventHandler(this.cmbSelectTopN_SelectionChangeCommitted);
            // 
            // chkTopN
            // 
            this.chkTopN.AutoSize = true;
            this.chkTopN.Location = new System.Drawing.Point(6, 61);
            this.chkTopN.Name = "chkTopN";
            this.chkTopN.Size = new System.Drawing.Size(111, 21);
            this.chkTopN.TabIndex = 12;
            this.chkTopN.Text = "Select top(n)";
            this.chkTopN.UseVisualStyleBackColor = true;
            this.chkTopN.CheckedChanged += new System.EventHandler(this.chkTopN_CheckedChanged);
            // 
            // chkSelectAll
            // 
            this.chkSelectAll.AutoSize = true;
            this.chkSelectAll.Location = new System.Drawing.Point(6, 32);
            this.chkSelectAll.Name = "chkSelectAll";
            this.chkSelectAll.Size = new System.Drawing.Size(87, 21);
            this.chkSelectAll.TabIndex = 10;
            this.chkSelectAll.Text = "Select all";
            this.chkSelectAll.UseVisualStyleBackColor = true;
            this.chkSelectAll.CheckedChanged += new System.EventHandler(this.chkSelectAll_CheckedChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 104);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 17);
            this.label26.TabIndex = 11;
            this.label26.Text = "Table names";
            // 
            // lstTableName
            // 
            this.lstTableName.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstTableName.FormattingEnabled = true;
            this.lstTableName.ItemHeight = 16;
            this.lstTableName.Location = new System.Drawing.Point(6, 124);
            this.lstTableName.Name = "lstTableName";
            this.lstTableName.Size = new System.Drawing.Size(320, 628);
            this.lstTableName.TabIndex = 4;
            this.lstTableName.SelectedIndexChanged += new System.EventHandler(this.lstTableName_SelectedIndexChanged);
            this.lstTableName.DoubleClick += new System.EventHandler(this.lstTableName_DoubleClick);
            // 
            // cmbDatabaseName
            // 
            this.cmbDatabaseName.FormattingEnabled = true;
            this.cmbDatabaseName.Location = new System.Drawing.Point(6, 76);
            this.cmbDatabaseName.Name = "cmbDatabaseName";
            this.cmbDatabaseName.Size = new System.Drawing.Size(320, 24);
            this.cmbDatabaseName.TabIndex = 3;
            this.cmbDatabaseName.SelectionChangeCommitted += new System.EventHandler(this.cmbDatabaseName_SelectionChangeCommitted);
            // 
            // tbnSearchFDM
            // 
            this.tbnSearchFDM.Location = new System.Drawing.Point(6, 18);
            this.tbnSearchFDM.Name = "tbnSearchFDM";
            this.tbnSearchFDM.Size = new System.Drawing.Size(320, 46);
            this.tbnSearchFDM.TabIndex = 1;
            this.tbnSearchFDM.Text = "Connect to FMSR";
            this.tbnSearchFDM.UseVisualStyleBackColor = true;
            this.tbnSearchFDM.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // dgvFDM
            // 
            this.dgvFDM.AllowUserToAddRows = false;
            this.dgvFDM.AllowUserToDeleteRows = false;
            this.dgvFDM.AllowUserToOrderColumns = true;
            this.dgvFDM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFDM.Location = new System.Drawing.Point(332, 157);
            this.dgvFDM.Name = "dgvFDM";
            this.dgvFDM.ReadOnly = true;
            this.dgvFDM.RowHeadersVisible = false;
            this.dgvFDM.RowTemplate.Height = 24;
            this.dgvFDM.Size = new System.Drawing.Size(1467, 595);
            this.dgvFDM.TabIndex = 0;
            // 
            // tbclEPM
            // 
            this.tbclEPM.BackColor = System.Drawing.Color.White;
            this.tbclEPM.Controls.Add(this.tbEPMServerStatus);
            this.tbclEPM.Location = new System.Drawing.Point(4, 25);
            this.tbclEPM.Name = "tbclEPM";
            this.tbclEPM.Padding = new System.Windows.Forms.Padding(3);
            this.tbclEPM.Size = new System.Drawing.Size(1838, 767);
            this.tbclEPM.TabIndex = 6;
            this.tbclEPM.Tag = "dgvRAActive";
            this.tbclEPM.Text = "EPM";
            // 
            // tbEPMServerStatus
            // 
            this.tbEPMServerStatus.Controls.Add(this.tabPage2);
            this.tbEPMServerStatus.Controls.Add(this.tabPage3);
            this.tbEPMServerStatus.Location = new System.Drawing.Point(3, 0);
            this.tbEPMServerStatus.Name = "tbEPMServerStatus";
            this.tbEPMServerStatus.SelectedIndex = 0;
            this.tbEPMServerStatus.Size = new System.Drawing.Size(1829, 761);
            this.tbEPMServerStatus.TabIndex = 7;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.txtCurrentGVNumber);
            this.tabPage2.Controls.Add(this.chkEPMCubes);
            this.tabPage2.Controls.Add(this.dgvEPMServerStatus);
            this.tabPage2.Controls.Add(this.txtEPMUserName);
            this.tabPage2.Controls.Add(this.btnConnectEPM);
            this.tabPage2.Controls.Add(this.txtEPMPassword);
            this.tabPage2.Controls.Add(this.lbuserName);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1821, 732);
            this.tabPage2.TabIndex = 0;
            this.tabPage2.Tag = "dgvRAActive";
            this.tabPage2.Text = "Server Status";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(3, 169);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(86, 17);
            this.label28.TabIndex = 9;
            this.label28.Text = "Pick cube(s)";
            // 
            // txtCurrentGVNumber
            // 
            this.txtCurrentGVNumber.BackColor = System.Drawing.Color.AntiqueWhite;
            this.txtCurrentGVNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCurrentGVNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentGVNumber.ForeColor = System.Drawing.Color.Red;
            this.txtCurrentGVNumber.Location = new System.Drawing.Point(6, 139);
            this.txtCurrentGVNumber.Name = "txtCurrentGVNumber";
            this.txtCurrentGVNumber.ReadOnly = true;
            this.txtCurrentGVNumber.Size = new System.Drawing.Size(189, 20);
            this.txtCurrentGVNumber.TabIndex = 8;
            // 
            // chkEPMCubes
            // 
            this.chkEPMCubes.BackColor = System.Drawing.Color.NavajoWhite;
            this.chkEPMCubes.CheckOnClick = true;
            this.chkEPMCubes.FormattingEnabled = true;
            this.chkEPMCubes.Location = new System.Drawing.Point(6, 190);
            this.chkEPMCubes.Name = "chkEPMCubes";
            this.chkEPMCubes.Size = new System.Drawing.Size(189, 531);
            this.chkEPMCubes.TabIndex = 7;
            // 
            // dgvEPMServerStatus
            // 
            this.dgvEPMServerStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEPMServerStatus.Location = new System.Drawing.Point(204, 21);
            this.dgvEPMServerStatus.Name = "dgvEPMServerStatus";
            this.dgvEPMServerStatus.ReadOnly = true;
            this.dgvEPMServerStatus.RowHeadersVisible = false;
            this.dgvEPMServerStatus.RowTemplate.Height = 24;
            this.dgvEPMServerStatus.Size = new System.Drawing.Size(1611, 698);
            this.dgvEPMServerStatus.TabIndex = 0;
            this.dgvEPMServerStatus.Tag = "dgvFDM";
            // 
            // txtEPMUserName
            // 
            this.txtEPMUserName.Location = new System.Drawing.Point(3, 21);
            this.txtEPMUserName.Name = "txtEPMUserName";
            this.txtEPMUserName.Size = new System.Drawing.Size(189, 22);
            this.txtEPMUserName.TabIndex = 1;
            // 
            // btnConnectEPM
            // 
            this.btnConnectEPM.Location = new System.Drawing.Point(6, 94);
            this.btnConnectEPM.Name = "btnConnectEPM";
            this.btnConnectEPM.Size = new System.Drawing.Size(192, 39);
            this.btnConnectEPM.TabIndex = 3;
            this.btnConnectEPM.Text = "Connect to EPM";
            this.btnConnectEPM.UseVisualStyleBackColor = true;
            this.btnConnectEPM.Click += new System.EventHandler(this.btnConnectEPM_Click);
            // 
            // txtEPMPassword
            // 
            this.txtEPMPassword.Location = new System.Drawing.Point(6, 66);
            this.txtEPMPassword.Name = "txtEPMPassword";
            this.txtEPMPassword.PasswordChar = '*';
            this.txtEPMPassword.Size = new System.Drawing.Size(192, 22);
            this.txtEPMPassword.TabIndex = 2;
            // 
            // lbuserName
            // 
            this.lbuserName.AutoSize = true;
            this.lbuserName.Location = new System.Drawing.Point(3, 3);
            this.lbuserName.Name = "lbuserName";
            this.lbuserName.Size = new System.Drawing.Size(73, 17);
            this.lbuserName.TabIndex = 5;
            this.lbuserName.Text = "Username";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(6, 46);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(69, 17);
            this.label27.TabIndex = 6;
            this.label27.Text = "Password";
            // 
            // tabPage3
            // 
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1821, 732);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dsSharePointViewer
            // 
            this.dsSharePointViewer.DataSetName = "dsSharePointViewer";
            this.dsSharePointViewer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dtRSActiveBindingSource
            // 
            this.dtRSActiveBindingSource.DataMember = "dtRSActive";
            this.dtRSActiveBindingSource.DataSource = this.dsSharePointViewer;
            // 
            // request_SubmissionTableAdapter
            // 
            this.request_SubmissionTableAdapter.ClearBeforeFill = true;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // toolStrip2
            // 
            this.toolStrip2.AllowMerge = false;
            this.toolStrip2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.toolStrip2.AutoSize = false;
            this.toolStrip2.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnRefresh});
            this.toolStrip2.Location = new System.Drawing.Point(1987, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Padding = new System.Windows.Forms.Padding(4, 0, 1, 0);
            this.toolStrip2.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStrip2.Size = new System.Drawing.Size(185, 30);
            this.toolStrip2.TabIndex = 4;
            this.toolStrip2.Text = "tsRefreshData";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRefresh.Image = ((System.Drawing.Image)(resources.GetObject("btnRefresh.Image")));
            this.btnRefresh.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRefresh.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(118, 27);
            this.btnRefresh.Text = "Refresh Data";
            this.btnRefresh.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // toolTipAddFilter
            // 
            this.toolTipAddFilter.AutoPopDelay = 1500;
            this.toolTipAddFilter.InitialDelay = 500;
            this.toolTipAddFilter.IsBalloon = true;
            this.toolTipAddFilter.ReshowDelay = 100;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1594, 860);
            this.Controls.Add(this.toolStrip2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.tbctlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "myFSSRS SharePoint Viewer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Shown += new System.EventHandler(this.frmMain_Shown);
            this.cmsDatagrid.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tbpgReportCatalogue.ResumeLayout(false);
            this.tbctlReportCatalogue.ResumeLayout(false);
            this.tbpgResourcing.ResumeLayout(false);
            this.tbpgResourcing.PerformLayout();
            this.panelSharepointLoadProgress.ResumeLayout(false);
            this.panelSharepointLoadProgress.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.splitContainerFilters.ResumeLayout(false);
            this.splitContainerFilters.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResourcing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSummaryView)).EndInit();
            this.tbpgResourcingWorkflow.ResumeLayout(false);
            this.tbpgResourcingWorkflow.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartPlatform)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResourcingWorkflow)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.tbpgKPI.ResumeLayout(false);
            this.tbpgKPI.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTest)).EndInit();
            this.cmsMetrics.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartDaysLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartDaysOutstanding)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKPI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartAcknowledge)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbAcknowledgementOtherSLA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbAcknowledgementSLA)).EndInit();
            this.tbpgWorkday.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbpgMySchedule)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransitions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.requestSubmissionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database4DataSet)).EndInit();
            this.tbctlMain.ResumeLayout(false);
            this.tbclTransition.ResumeLayout(false);
            this.tbclExcel.ResumeLayout(false);
            this.tbDashboardRollover.ResumeLayout(false);
            this.tbDashboardRollover.PerformLayout();
            this.panelRollover.ResumeLayout(false);
            this.panelRollover.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRolloverDashBoard)).EndInit();
            this.tbclTransitions.ResumeLayout(false);
            this.tbclTransitions.PerformLayout();
            this.panelFieldSelections.ResumeLayout(false);
            this.panelFieldSelections.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvETActive)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRAActive)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFDM)).EndInit();
            this.tbclEPM.ResumeLayout(false);
            this.tbEPMServerStatus.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEPMServerStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSharePointViewer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtRSActiveBindingSource)).EndInit();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel tsslNoOfItems;
        private System.Windows.Forms.ToolStripStatusLabel tsslStatus;
        private System.Windows.Forms.ImageList imglIcons;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbRefreshData;
        private System.Windows.Forms.ToolStripMenuItem exceptionFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TSMILatestExceptionFile;
        private System.Windows.Forms.ToolStripMenuItem tsmiExceptionFileListing;
        private System.Windows.Forms.ContextMenuStrip cmsDatagrid;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem tsmiOpenSpForm;
        private System.Windows.Forms.ToolStripMenuItem tsmiEditSPForm;
        private System.Windows.Forms.ToolStripSeparator tssEmail;
        private System.Windows.Forms.ToolStripMenuItem tsmiDatagridEmail;
        private System.Windows.Forms.ToolStripMenuItem questionForReportContactToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiExportToExcel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem tsmiNewSPForm;
        private System.Windows.Forms.ToolStripMenuItem tsmiExportCurrentList;
        private System.Windows.Forms.ToolStripMenuItem tsmiExportAllListsInView;
        private System.Windows.Forms.TabPage tbpgReportCatalogue;
        private System.Windows.Forms.TabControl tbctlMain;
        private System.Windows.Forms.TabControl tbctlReportCatalogue;
        private System.Windows.Forms.TabPage tbpgResourcing;
        private System.Windows.Forms.ListBox lstEmployees;
        private System.Windows.Forms.DataGridView dgvSummaryView;
        private System.Windows.Forms.TabPage tbpgResourcingWorkflow;
        private System.Windows.Forms.BindingSource dtRSActiveBindingSource;
        private dsSharePointViewer dsSharePointViewer;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.ListBox chlstPlatform;
        private System.Windows.Forms.RadioButton rbRptCount;
        private System.Windows.Forms.RadioButton rbProcessTime;
        private System.Windows.Forms.ListBox lstStatus;
        private System.Windows.Forms.ListBox lstCategory;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartStatus;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartCategory;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartPlatform;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgvResourcing;
        private System.Windows.Forms.DataGridView dgvResourcingWorkflow;
        private System.Windows.Forms.CheckBox chkIncludeAllDates;
        private System.Windows.Forms.ListBox lstGvDays;
        private Database4DataSet database4DataSet;
        private System.Windows.Forms.BindingSource requestSubmissionBindingSource;
        private Database4DataSetTableAdapters.Request_SubmissionTableAdapter request_SubmissionTableAdapter;
        private System.Windows.Forms.ListBox lstTransitionAnalyst;
        private System.Windows.Forms.Button btnLoadTransitionSpreadsheet;
        private System.Windows.Forms.DataGridView dgvTransitions;
        private System.Windows.Forms.RadioButton rbSetupTime;
        private System.Windows.Forms.RadioButton rbDataSource;
        private System.Windows.Forms.RadioButton rbDeploymentTools;
        private System.Windows.Forms.TabPage tbpgKPI;
        private System.Windows.Forms.NumericUpDown cmbAcknowledgementSLA;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_CalcKPI;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTotalItems;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDaysOutstanding;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDaysLeft;
        private System.Windows.Forms.DataGridView dgvKPI;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtOverdueAcknowledge;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartAcknowledge;
        private System.Windows.Forms.CheckBox chkIncludeAllWorkflow;
        private System.Windows.Forms.TabPage tbclTransition;
        private System.Windows.Forms.DataGridView dgvETActive;
        private System.Windows.Forms.DataGridView dgvRAActive;
        private System.Windows.Forms.TabControl tbclExcel;
        private System.Windows.Forms.TabPage tbclTransitions;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panelFieldSelections;
        private System.Windows.Forms.CheckedListBox chklstTransitionFields;
        private System.Windows.Forms.Button btnShowFieldPanel;
        private System.Windows.Forms.CheckBox chkPreselectedTransitionFields;
        private System.Windows.Forms.Button tbnBrowseTransition;
        private System.Windows.Forms.TextBox txtTransitionPath;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSaveTransitionSettings;
        private System.Windows.Forms.CheckBox chkTransitionTeam;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown cmbAcknowledgementOtherSLA;
        private System.Windows.Forms.RadioButton rbTotalReportCount;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnEnterPassword;
        private System.Windows.Forms.Button btnExpandCatalogueFilter;
        private System.Windows.Forms.ListBox lstDeploymentTool;
        private System.Windows.Forms.ListBox lstRelationshipManager;
        private System.Windows.Forms.ListBox lstFrequency;
        private System.Windows.Forms.ListBox lstDataSource;
        private System.Windows.Forms.ListBox lstReportStatus;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton btnRefresh;
        private System.Windows.Forms.RadioButton rbEffortRequired;
        private System.Windows.Forms.RadioButton rbRequestCategory;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label Platform;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chkGuessFilePath;
        private System.Windows.Forms.ContextMenuStrip cmsMetrics;
        private System.Windows.Forms.ToolStripMenuItem tsmiFilterEquals;
        private System.Windows.Forms.ToolStripMenuItem tsmiFilterNotEquals;
        private System.Windows.Forms.ToolStripMenuItem tsmiEquals;
        private System.Windows.Forms.ToolStripMenuItem tsmiNotEquals;
        private System.Windows.Forms.DataGridView dgvTest;
        private System.Windows.Forms.ToolStripMenuItem tsmiClearKPIFilter;
        private System.Windows.Forms.Label lbNoResultsAcknowledgement;
        private System.Windows.Forms.Label lbNoResultsDaysOutstanding;
        private System.Windows.Forms.Label lbNoResultsDaysLeft;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox lstTeamManager;
        private System.Windows.Forms.Button btnLoadDefaultSettings;
        private System.Windows.Forms.TabPage tbDashboardRollover;
        private System.Windows.Forms.Button btnShowRolloverFieldPanel;
        private System.Windows.Forms.Button btnLoadRollover;
        private System.Windows.Forms.ListBox lstRolloverAnalyst;
        private System.Windows.Forms.Panel panelRollover;
        private System.Windows.Forms.CheckBox chkGuessFilePathRollover;
        private System.Windows.Forms.Button btnSaveRolloverSettings;
        private System.Windows.Forms.CheckBox chkPreselectedRolloverFields;
        private System.Windows.Forms.Button tbnBrowseRollover;
        private System.Windows.Forms.TextBox txtRolloverPath;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckedListBox chklstRolloverFields;
        private System.Windows.Forms.CheckBox chkRolloverTeam;
        private System.Windows.Forms.DataGridView dgvRolloverDashBoard;
        private System.Windows.Forms.ComboBox cmbSavedFilters;
        private System.Windows.Forms.Button btnAddFilter;
        private System.Windows.Forms.TextBox txtFilterName;
        private System.Windows.Forms.Button btnRemoveFilter;
        private System.Windows.Forms.ToolTip toolTipAddFilter;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goToHelpMenuToolStripMenuItem;
        private System.Windows.Forms.RadioButton rbBetween;
        private System.Windows.Forms.RadioButton rbBefore;
        private System.Windows.Forms.RadioButton rbFrom;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panelSharepointLoadProgress;
        private System.Windows.Forms.TextBox txtLoadProgress;
        private System.Windows.Forms.ProgressBar pgbLoadSharepointData;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox chCalculateKPI;
        private System.Windows.Forms.Button btnUpdateFilter;
        private System.Windows.Forms.CheckBox chkShowOverdueOnly;
        private System.Windows.Forms.Panel splitContainerFilters;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtSearchCatalogue;
        private System.Windows.Forms.ComboBox cmbFieldFilterReportCatalogue;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbFieldFilterWorkflow;
        private System.Windows.Forms.TextBox txtSearchWorkflow;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dgvFDM;
        private System.Windows.Forms.Button tbnSearchFDM;
        private System.Windows.Forms.ListBox lstTableName;
        private System.Windows.Forms.ComboBox cmbDatabaseName;
        private System.Windows.Forms.TextBox txtFDMKeyword;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbFieldFilterFDM;
        private System.Windows.Forms.CheckBox chkSelectAll;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ComboBox cmbSelectTopN;
        private System.Windows.Forms.CheckBox chkTopN;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnKeywordSearch;
        private System.Windows.Forms.ToolStripMenuItem tsmiDataGridEmailValidate;
        private System.Windows.Forms.ToolStripMenuItem openProductionFolderToolStripMenuItem;
        private System.Windows.Forms.TabPage tbclEPM;
        private System.Windows.Forms.TextBox txtEPMUserName;
        private System.Windows.Forms.TextBox txtEPMPassword;
        private System.Windows.Forms.DataGridView dgvEPMServerStatus;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button btnConnectEPM;
        private System.Windows.Forms.Label lbuserName;
        private System.Windows.Forms.TabControl tbEPMServerStatus;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.CheckedListBox chkEPMCubes;
        private System.Windows.Forms.TextBox txtCurrentGVNumber;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TabPage tbpgWorkday;
        private System.Windows.Forms.DataGridView tbpgMySchedule;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnShowHideHours;
        private System.Windows.Forms.RadioButton rbSetUp;
        private System.Windows.Forms.RadioButton rbProcTime;
        private System.Windows.Forms.CheckedListBox chklstSheduleFields;
        private System.Windows.Forms.ComboBox cmbSheduleDetailLevel;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rbBoth;
    }
}

