﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFSSRS_SharePoint_Viewer.AppData
{
    class workflowItem
    {
        public int itemId;
        String reportNumber, preparerName;
        double estimatedHrsNew, estimatedHrsChange, estimatedHrsOther;



    }
}
