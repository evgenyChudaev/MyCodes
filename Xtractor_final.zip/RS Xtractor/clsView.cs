﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SP = Microsoft.SharePoint.Client;

namespace myFSSRS_SharePoint_Viewer
{
    class clsSPView
    {
        private string sName;
        private int nId;
        private string sCAMLQuery;

        public clsSPView(string Name, int Id, string CAMLQuery)
        {
            sName = Name;
            nId = Id;
            sCAMLQuery = CAMLQuery;
        }

        public string Name
        {
            get { return sName; }
        }

        public int Id
        {
            get { return nId; }
        }

        public string CAMLQuery
        {
            get { return sCAMLQuery; }
        }
    }
}
