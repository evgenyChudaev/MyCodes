﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SP = Microsoft.SharePoint.Client;

namespace myFSSRS_SharePoint_Viewer
{

    class clsSite
    {

        Dictionary<string, clsList> dicSites = new Dictionary<string, clsList>();

        public enum SiteErrorCode
        {
            emNoError,
            emCouldNotConnect
        };

        clsServer m_ParentServer = null;
        internal clsServer ParentServer {get { return m_ParentServer; }}

        string m_SitePath = null;
        string m_SiteName = null;
        SP.Web m_SPSite = null;
        public SP.Web SPSite {get { return m_SPSite; }}

        SP.ClientContext m_SPClientContext = null;
        public SP.ClientContext SPClientContext { get { return m_SPClientContext; }}
        
        bool m_Connected = false;
        public bool Connected {get { return m_Connected; }}

        int m_CurrentUserId = 0;
        SiteErrorCode m_ErrorCode = 0;

        string m_ErrorMessage = null;

        public string ErrorMessage
        {
            get { return m_ErrorMessage; }
            set { m_ErrorMessage = value; }
        }

        public SiteErrorCode ErrorCode
        {
            get { return m_ErrorCode; }
        }

        public clsSite(string SiteName, string SitePath, clsServer ParentServer)
        {
            m_ParentServer = ParentServer;
            m_SitePath = SitePath;
            m_SiteName = SiteName;
        }

        internal bool Connect(ToolStripStatusLabel StatusLabel)
        {
            StatusLabel.Text = "Connecting To Report Catalogue Site...";

            m_SPClientContext = new SP.ClientContext(m_ParentServer.URL + m_SitePath);
            m_SPSite = m_SPClientContext.Web;
            m_SPClientContext.Load(m_SPSite, website => website.CurrentUser, website => website.Title);

            try
            {
                m_SPClientContext.ExecuteQuery();
            }
            catch (System.Net.WebException exWeb)
            {
                m_ErrorCode = SiteErrorCode.emCouldNotConnect;
                m_ErrorMessage = String.Format("Could not connect to site: {0}.", m_SiteName);

                StatusLabel.Text = "";
                return false;
            }

            m_ErrorCode = 0;
            m_ErrorMessage = null;
            m_CurrentUserId = m_SPSite.CurrentUser.Id;
            m_Connected = true;

            StatusLabel.Text = "";
            return true;
        }

        public int UserId
        {
            get
            {
                return m_CurrentUserId;
            }
        }

        public clsList AddList(string Name, string ListName)
        {
            clsList oList = new clsList(Name, ListName, this);
            dicSites.Add(Name, oList);

            return oList;
        }
    }
}
