﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SP = Microsoft.SharePoint.Client;

namespace myFSSRS_SharePoint_Viewer
{
    class clsDataGridView
    {
        Dictionary<string, clsColumn> dicColumns = new Dictionary<string, clsColumn>();

        // accessor for columns collection
        internal Dictionary<string, clsColumn> Columns 
        {
            get { return dicColumns; }
        }


        Dictionary<string, clsEmailChoice> dicEmailChoices = new Dictionary<string, clsEmailChoice>();
        
        // accessor for email choice
        internal Dictionary<string, clsEmailChoice> EmailChoices
        {
            get { return dicEmailChoices; }
        }


        bool m_OpenNewForm = false;
        
        //accessor for boolean checking if new form is open
        public bool OpenNewForm{get { return m_OpenNewForm; }}

        string m_CAML = null;

        // accessor for CAML
        public string CAML{get { return m_CAML; }}

        bool m_QueryExecuted = false;

        DataGridView m_DataGridView = null;

        // accessor for DataGridView
        public DataGridView DataGridView {get { return m_DataGridView; }}
        
        // accessor for the name of the DataGridView
        public string Name{get {return m_DataGridView.Name; }}

        clsList m_ParentList = null;
        internal clsList ParentList {get { return m_ParentList; }}

        SP.ListItemCollection m_ListItems = null;

        // Is that an instantiation of the ListItemCollection class??? Seems like an initializer list to me
        // that's actually the the accessor method for the property named ListItems
        public SP.ListItemCollection ListItems { get { return m_ListItems; } }

        // constructor for the class clsDataGridView
        public clsDataGridView(DataGridView dgvTarget, string CAML, clsList ParentList)
        {
            m_DataGridView = dgvTarget;
            m_CAML = CAML;
            m_ParentList = ParentList;
        }


        public bool ExecuteCAMLQuery(ToolStripLabel tsslNoOfItems, ToolStripLabel tsslStatus)
        {

            tsslStatus.Text = "Retrieving Items...";

            // allows application to handle other events. 
            //WIthout it all other events would be placed in a queue while form process an event
           
            Application.DoEvents(); 

            SP.CamlQuery oCamlQuery = new SP.CamlQuery();
            // ViewXML property of CAML QUERY allows filtering of CAML Query object based on specific criteria
            oCamlQuery.ViewXml = m_CAML; //m_CAML was passed as a parameter from the clsList class
            // get data from the CAML query
            m_ListItems = m_ParentList.SPList.GetItems(oCamlQuery); // returns a collection of items from the list
            m_ParentList.ParentSite.SPClientContext.Load(m_ListItems); //m_ParentList was passed as a parameter from the clsList class as a copy of the object of that class
            m_ParentList.ParentSite.SPClientContext.ExecuteQuery();


            DataTable dtTarget = new DataTable();
            DataColumn dcTarget = null;

            // dirColumns is a collection of columns
            foreach (clsColumn oColumn in dicColumns.Values)
            {
                dcTarget = new DataColumn();
                dcTarget.ColumnName = oColumn.DTCName;
                dtTarget.Columns.Add(dcTarget);
            }

            // why is this not within a loop
            dcTarget = new DataColumn();
            dcTarget.ColumnName = "ListItemID";
            dtTarget.Columns.Add(dcTarget);


            // check every element of the SP list
            foreach( SP.ListItem oListItem in m_ListItems )
            {
                DataRow drTarget = dtTarget.NewRow();  //create new row
                // loop through each column in columns collection dicColumns
                foreach (clsColumn oColumn in dicColumns.Values)
                {
                    if (oColumn.SPName != "")
                    {  // if column type = user
                        if (oColumn.SPType == "User")
                        {
                            SP.FieldUserValue oUser = ((SP.FieldUserValue)oListItem[oColumn.SPName]);
                            if (oUser != null)
                                drTarget[oColumn.DTCName] = oUser.LookupValue;
                        } // if column type = multi-user
                        else if (oColumn.SPType == "MultiUser")
                        {
                            SP.FieldUserValue[] oUsers = ((SP.FieldUserValue[])oListItem[oColumn.SPName]);
                            if (oUsers != null)
                            {
                                foreach(SP.FieldUserValue oUser in oUsers)
                                    drTarget[oColumn.DTCName] += oUser.LookupValue + "; ";

                                drTarget[oColumn.DTCName] = drTarget[oColumn.DTCName].ToString().TrimEnd(';',' ');
                            }
                        } // if column type -= multi-choice
                        else if (oColumn.SPType == "MultiChoice")
                        {
                            var vMultiChoiceItems = oListItem[oColumn.SPName];
                            if (vMultiChoiceItems != null)
                                drTarget[oColumn.DTCName] = String.Join("; ", (string[])oListItem[oColumn.SPName]);
                        } // if column type = Date/Time
                        else if (oColumn.SPType == "DateTime")
                        {
                            var sDateTime = oListItem[oColumn.SPName];
                            if (sDateTime != null)
                            {
                                drTarget[oColumn.DTCName] = DateTime.Parse(sDateTime.ToString()).ToLocalTime().ToString();
                            }
                        } // if column type = Date/Time
                        else if (oColumn.SPType == "Date")
                        {
                            var sDateTime = oListItem[oColumn.SPName];
                            if (sDateTime != null)
                            {
                                drTarget[oColumn.DTCName] = DateTime.Parse(sDateTime.ToString()).ToShortDateString();
                            }
                        }
                        else
                            drTarget[oColumn.DTCName] = oListItem[oColumn.SPName];
                    }  // if column type is calculated
                    else if (oColumn.SPType.StartsWith("DTCalculated:"))
                    {
                        if (oColumn.SPType.EndsWith("DetermineProcessingTimes"))
                            drTarget[oColumn.DTCName] = DetermineProcessingTimes(oListItem);
                        else if (oColumn.SPType.EndsWith("DetermineDeliveryDeadlines"))
                            drTarget[oColumn.DTCName] = DetermineDeliveryDeadlines(oListItem);
                        else if (oColumn.SPType.EndsWith("DetermineSetupTimes")) // Added by Evgeny to include set up times 
                            drTarget[oColumn.DTCName] = DetermineSetupTimes(oListItem);
                    }
                }

                drTarget["ListItemID"] = oListItem.Id;
                dtTarget.Rows.Add(drTarget); // add rows to the target data table 
            } // end of the last outer loop

            m_DataGridView.AutoGenerateColumns = false;
            m_DataGridView.DataSource = dtTarget; // specifying the datasource for the datagridview as target table above

            // toolstrip?
            tsslStatus.Text = "";
            tsslNoOfItems.Text = dtTarget.Rows.Count.ToString();
            return true;

        }

        // adding columns to the datagrid
        public void AddColumn(string DTCName, string DGHeaderText, int DGColumnWidth, string SPName, string SPType, bool Visible)
        {
            // constructor for clsColumn class
            clsColumn oColumn = new clsColumn(DTCName, DGHeaderText, DGColumnWidth, SPName, SPType, Visible, this);
            dicColumns.Add(oColumn.DTCName, oColumn);
        }

        // adding email choice to the collection named dicEmailChoices
        public void AddEmailChoice(string MenuOption, string MessageOptionColumn, string Subject, string To, string CC, Dictionary<string, string> MessageBody)
        {
            Console.WriteLine(MenuOption + " " + MessageOptionColumn);
            clsEmailChoice oEmailChoice = new clsEmailChoice(MenuOption, MessageOptionColumn, Subject, To, CC, MessageBody, this);
            dicEmailChoices.Add(oEmailChoice.MenuOption, oEmailChoice);
        }

        public void SetMenuOptions(string OpenNewForm)
        {
            if (OpenNewForm == "True")
                m_OpenNewForm = true;
        }

        private string DetermineDeliveryDeadlines(SP.ListItem oListItem)
        {
            string sDeadlines = "";
            object sDeadlineTime = null;

            // in C# ref indicates a a value passed by reference.
            // oListItem[column name] - corresponds to the actual names of columns in the sharepoint 
            // Since sDeadlines is passed by ref, it's modified within GetDeadlineDates method
            // and DetermineDeliveryDeadlines then works on the modified variable
            GetDeadlineDates(oListItem["GV0_x0020_Deadline_x0020_Time"], "GV0", ref sDeadlines);
            GetDeadlineDates(oListItem["GV1_x0020_Deadline_x0020_Time"], "GV1", ref sDeadlines);
            GetDeadlineDates(oListItem["GV2_x0020_Deadline_x0020_Time"], "GV2", ref sDeadlines);
            GetDeadlineDates(oListItem["GV3_x0020_Deadline_x0020_Time"], "GV3", ref sDeadlines);
            GetDeadlineDates(oListItem["GV4_x0020_Deadline_x0020_Time"], "GV4", ref sDeadlines);
            GetDeadlineDates(oListItem["GV5_x0020_Deadline_x0020_Time"], "GV5", ref sDeadlines);
            GetDeadlineDates(oListItem["GV6_x0020_Deadline_x0020_Time"], "GV6", ref sDeadlines);
            GetDeadlineDates(oListItem["GV7_x0020_Deadline_x0020_Time"], "GV7", ref sDeadlines);
            GetDeadlineDates(oListItem["GV8_x0020_Deadline_x0020_Time"], "GV8", ref sDeadlines);
            GetDeadlineDates(oListItem["GV9_x0020_Deadline_x0020_Time"], "GV9", ref sDeadlines);
            GetDeadlineDates(oListItem["GV10_x0020_Deadline_x0020_Time"], "GV10", ref sDeadlines);
            GetDeadlineDates(oListItem["GV11_x0020_Deadline_x0020_Time"], "GV11", ref sDeadlines);
            GetDeadlineDates(oListItem["GV12_x0020_Deadline_x0020_Time"], "GV12", ref sDeadlines);
            GetDeadlineDates(oListItem["GV13_x0020_Deadline_x0020_Time"], "GV13", ref sDeadlines);
            GetDeadlineDates(oListItem["GV14_x0020_Deadline_x0020_Time"], "GV14", ref sDeadlines);
            GetDeadlineDates(oListItem["GV15_x0020_Deadline_x0020_Time"], "GV15", ref sDeadlines);
            
            GetDeadlineDates(oListItem["_x0032_nd_x0020_Week_x0020_Deadl"], "2nd Week", ref sDeadlines);
            GetDeadlineDates(oListItem["_x0033_rd_x0020_Week_x0020_Deadl"], "3rd Week", ref sDeadlines);
            GetDeadlineDates(oListItem["_x0032_0th_x0020_Calendar_x0020_"], "20th Day", ref sDeadlines);
            GetDeadlineDates(oListItem["Daily_x0020_Deadline_x0020_Time"], "Daily", ref sDeadlines);
            GetDeadlineDates(oListItem["Weekly_x0020_Deadline_x0020_Time"], "Weekly", ref sDeadlines);
            GetDeadlineDates(oListItem["Bi_x002d_Weekly_x0020_Deadline_x"], "Bi-Weekly", ref sDeadlines);
            GetDeadlineDates(oListItem["Before_x0020_End_x0020_of_x0020_"], "Before EOM", ref sDeadlines);
            GetDeadlineDates(oListItem["Annual_x0020_Deadline_x0020_Time"], "Annual", ref sDeadlines);
            GetDeadlineDates(oListItem["Semi_x002d_Annual_x0020_Deadline"], "Semi-Annual", ref sDeadlines);
            GetDeadlineDates(oListItem["Quarterly_x0020_Deadline_x0020_T"], "Quarterly", ref sDeadlines);

            if (sDeadlines.Length > 0)
                sDeadlines = sDeadlines.Remove(sDeadlines.Length - 2);

            return sDeadlines;
        }

        // in C# ref indicates a a value passed by reference
        // this method creates values for DeliveryDate/Time column in the tool
        // Since sDeadlines is passed by ref, it's modified within GetDeadlineDates method
        // and DetermineDeliveryDeadlines then works on the modified variable
        private static void GetDeadlineDates(object oDeadlineTimeValue, string sDeadlinePeriod, ref string sDeadlines)
        {
            string sDeadlineTime = "";

            sDeadlineTime = Convert.ToString(oDeadlineTimeValue);
            if (sDeadlineTime != "")
                sDeadlines += sDeadlinePeriod + " @ " + sDeadlineTime + "; ";
        }


        // processing time column for reports
        private string DetermineProcessingTimes(SP.ListItem oListItem)
        {
            string sProcessingTimes = "";

            GetProcessingTime(oListItem["GV0_x0020_Processing_x0020_Time_"], "GV0", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV1_x0020_Processing_x0020_Time_"], "GV1", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV2_x0020_Processing_x0020_Time_"], "GV2", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV3_x0020_Processing_x0020_Time_"], "GV3", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV4_x0020_Processing_x0020_Time_"], "GV4", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV5_x0020_Processing_x0020_Time_"], "GV5", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV6_x0020_Processing_x0020_Time_"], "GV6", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV7_x0020_Processing_x0020_Time_"], "GV7", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV8_x0020_Processing_x0020_Time_"], "GV8", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV9_x0020_Processing_x0020_Time_"], "GV9", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV10_x0020_Processing_x0020_Time"], "GV10", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV11_x0020_Processing_x0020_Time"], "GV11", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV12_x0020_Processing_x0020_Time"], "GV12", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV13_x0020_Processing_x0020_Time"], "GV13", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV14_x0020_Processing_x0020_Time"], "GV14", ref sProcessingTimes);
            GetProcessingTime(oListItem["GV15_x0020_Processing_x0020_Time"], "GV15", ref sProcessingTimes);
            GetProcessingTime(oListItem["_x0032_nd_x0020_Week_x0020_Proce"], "2nd Week", ref sProcessingTimes);
            GetProcessingTime(oListItem["_x0033_rd_x0020_Week_x0020_Proce"], "3rd Week", ref sProcessingTimes);
            GetProcessingTime(oListItem["_x0032_0th_x0020_Calendar_x0020_1"], "20th Day", ref sProcessingTimes);
            GetProcessingTime(oListItem["Daily_x0020_Processing_x0020_Tim"], "Daily", ref sProcessingTimes);
            GetProcessingTime(oListItem["Weekly_x0020_Processing_x0020_Ti"], "Weekly", ref sProcessingTimes);
            GetProcessingTime(oListItem["Bi_x002d_weekly_x0020_Processing"], "Bi-Weekly", ref sProcessingTimes);
            GetProcessingTime(oListItem["Before_x0020_End_x0020_of_x0020_1"], "Before EOM", ref sProcessingTimes);
            GetProcessingTime(oListItem["Annual_x0020_Processing_x0020_Ti"], "Annual", ref sProcessingTimes);
            GetProcessingTime(oListItem["Semi_x002d_Annual_x0020_Processi"], "Semi-Annual", ref sProcessingTimes);
            GetProcessingTime(oListItem["Quarterly_x0020_Processing_x0020"], "Quarterly", ref sProcessingTimes); 

            if (sProcessingTimes.Length > 0)
                sProcessingTimes = sProcessingTimes.Remove(sProcessingTimes.Length - 2);

            return sProcessingTimes;
        }

        private static void GetProcessingTime(object oProcessingTimeValue, string sProcessingPeriod, ref string sProcessingTimes)
        {
            string sProcessingTime = "";

            sProcessingTime = Convert.ToString(oProcessingTimeValue);
            if (sProcessingTime != "" && sProcessingTime != "0")            
                sProcessingTimes += sProcessingPeriod + " @ " + sProcessingTime.ToString() + "; ";
        }


        private static void GetSetupTime(object oSetupTimeValue, string sSetupPeriod, ref string sSetupTimes)
        {
            string sSetupTime = "";

            sSetupTime = Convert.ToString(oSetupTimeValue);
            if (sSetupTime != "" && sSetupTime != "0")
                sSetupTimes += sSetupPeriod + " @ " + sSetupTime.ToString() + "; ";
        }

        private string DetermineSetupTimes(SP.ListItem oListItem)
        {
            string sSetupTimes = "";
          
            GetSetupTime(oListItem["GV0_x0020_Setup_x0020_Time_x0020"], "GV0", ref sSetupTimes);
            GetSetupTime(oListItem["GV1_x0020_Setup_x0020_Time_x0020"], "GV1", ref sSetupTimes);
            GetSetupTime(oListItem["GV2_x0020_Setup_x0020_Time_x0020"], "GV2", ref sSetupTimes);
            GetSetupTime(oListItem["GV3_x0020_Setup_x0020_Time_x0020"], "GV3", ref sSetupTimes);
            GetSetupTime(oListItem["GV4_x0020_Setup_x0020_Time_x0020"], "GV4", ref sSetupTimes);
            GetSetupTime(oListItem["GV5_x0020_Setup_x0020_Time_x0020"], "GV5", ref sSetupTimes);
            GetSetupTime(oListItem["GV6_x0020_Setup_x0020_Time_x0020"], "GV6", ref sSetupTimes);
            GetSetupTime(oListItem["GV7_x0020_Setup_x0020_Time_x0020"], "GV7", ref sSetupTimes);
            GetSetupTime(oListItem["GV8_x0020_Setup_x0020_Time_x0020"], "GV8", ref sSetupTimes);
            GetSetupTime(oListItem["GV9_x0020_Setup_x0020_Time_x0020"], "GV9", ref sSetupTimes);
            GetSetupTime(oListItem["GV10_x0020_Setup_x0020_Time_x002"], "GV10", ref sSetupTimes);
            GetSetupTime(oListItem["GV11_x0020_Setup_x0020_Time_x002"], "GV11", ref sSetupTimes);
            GetSetupTime(oListItem["GV12_x0020_Setup_x0020_Time_x002"], "GV12", ref sSetupTimes);
            GetSetupTime(oListItem["GV13_x0020_Setup_x0020_Time_x002"], "GV13", ref sSetupTimes);
            GetSetupTime(oListItem["GV14_x0020_Setup_x0020_Time_x002"], "GV14", ref sSetupTimes);
            GetSetupTime(oListItem["GV15_x0020_Setup_x0020_Time_x002"], "GV15", ref sSetupTimes);       
            GetProcessingTime(oListItem["_x0032_nd_x0020_Week_x0020_Setup"], "2nd Week", ref sSetupTimes);
            GetProcessingTime(oListItem["_x0033_rd_x0020_Week_x0020_Setup"], "3rd Week", ref sSetupTimes);            
            GetProcessingTime(oListItem["_x0032_0th_x0020_Calendar_x0020_0"], "20th Day", ref sSetupTimes);
            GetProcessingTime(oListItem["Daily_x0020_Setup_x0020_Time_x00"], "Daily", ref sSetupTimes);
            GetProcessingTime(oListItem["Weekly_x0020_Setup_x0020_Time_x0"], "Weekly", ref sSetupTimes);
            GetProcessingTime(oListItem["Bi_x002d_Weekly_x0020_Setup_x002"], "Bi-Weekly", ref sSetupTimes);
            GetProcessingTime(oListItem["Before_x0020_End_x0020_of_x0020_1"], "Before EOM", ref sSetupTimes);
            GetProcessingTime(oListItem["Annual_x0020_Setup_x0020_Time_x0"], "Annual", ref sSetupTimes);
            GetProcessingTime(oListItem["Semi_x002d_Annual_x0020_Setup_x0"], "Semi-Annual", ref sSetupTimes);
            GetProcessingTime(oListItem["Quarterly_x0020_Setup_x0020_Time"], "Quarterly", ref sSetupTimes); 

            if (sSetupTimes.Length > 0)
                sSetupTimes = sSetupTimes.Remove(sSetupTimes.Length - 2);

            return sSetupTimes;
        }

    }
}
