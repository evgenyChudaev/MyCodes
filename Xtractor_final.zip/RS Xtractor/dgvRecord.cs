﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFSSRS_SharePoint_Viewer
{
    class dgvRecord
    {
        public int id;
        public String name, report, gvString, gvTime, frequency, gvSetupTime;
        public String[] gvDates, setupTime;
        public double gv0 = 0 ,gv1 = 0, gv2 = 0, gv3 = 0, gv4 = 0, gv5 = 0, gv6 = 0, gv7 = 0, gv8 = 0, gv9 = 0, gv10 = 0, gv11 = 0, gv12 = 0, gv13 = 0,
                      gv14 = 0, gv15 = 0, week2 = 0, week3 = 0, day20 = 0, daily = 0, weekly = 0, bi_weekly = 0, before_EOM = 0, annual = 0,
                      semi_annual = 0, quarterly = 0,
                      gv0_setup = 0, gv1_setup = 0, gv2_setup = 0, gv3_setup = 0, gv4_setup = 0, gv5_setup = 0, gv6_setup = 0, gv7_setup = 0, gv8_setup, gv9_setup, gv10_setup,
                      gv11_setup, gv12_setup, gv13_setup, gv14_setup, gv15_setup, week2_setup, week3_setup, day20_setup, daily_setup, weekly_setup, bi_weekly_setup,
                      before_EOM_setup, annual_setup, semi_annual_setup, quarterly_setup,
                      gv0_setup2 = 0, gv1_setup2 = 0, gv2_setup2 = 0, gv3_setup2 = 0, gv4_setup2 = 0, gv5_setup2 = 0, gv6_setup2 = 0, gv7_setup2 = 0, gv8_setup2, gv9_setup2, gv10_setup2,
                      gv11_setup2, gv12_setup2, gv13_setup2, gv14_setup2, gv15_setup2, week2_setup2, week3_setup2, day20_setup2, daily_setup2, weekly_setup2, bi_weekly_setup2,
                      before_EOM_setup2, annual_setup2, semi_annual_setup2, quarterly_setup2;


        // 1st constructor for report catalogue. Last integer parameter is only used for distinguishing 2 constructors.
        public dgvRecord(int id, String name, String report, String gvString, String gvTime, String frequency, String setupTime, int recType)
        {
            this.id = id;
            this.name = name;
            this.report = report;
            this.gvString = gvString;
            this.gvTime = gvTime;
            this.frequency = frequency;
            this.gvSetupTime = setupTime;
           // 
            extractGvDays2(gvString, "count");
            extractGvDays2(gvTime, "processing");
            extractGvDays2(setupTime, "setup");
           // extractGvDays2(gvTime, "setup");
        }

        // 2nd constructor for things other than reort catalogue
        public dgvRecord(int id, String name, String report, String gvString, String gvTime, String frequency, String setupTime)
        {
            this.id = id;
            this.name = name;
            this.report = report;
            this.gvString = gvString;
            this.gvTime = gvTime;
            this.frequency = frequency;
            this.gvSetupTime = setupTime;
            // extractGvDays2(gvString, "proc");
            // extractGvDays2(setupTime, "setup");
            //extractGvDays2(gvTime, "setup");
        }
        
        public static bool isNullOrEmpty(string value)
        {
            bool result = value == null || value == String.Empty;
            return result;
        }

        public void extractGvDays2(String myStr, String process) // use regex later 
        {
           
                String[] split1 = myStr.Split(';'); // split out the first segment - GV Date & Due time
                String[] split2 = new String[split1.Length];
            
           
            String timeGV = "", strGV = "";
            int i = 0;

            foreach (String str in split1)  // extract the gv date and discard the time
            {
                String[] leng = split1[i].Split('@');
                if (leng.Length == 1)
                {
                    strGV = "0";
                }
           

                if (process == "count")
                {
                    strGV = isNullOrEmpty(split1[i].Split('@')[0].Trim()) ? "0" : split1[i].Split('@')[0].Trim(); // time
                   
                }
                else if (process == "processing" || process == "setup")
                {
                    strGV = isNullOrEmpty(split1[i].Split('@')[0].Trim()) ? "0" : split1[i].Split('@')[0].Trim(); // Report count for each GV day
                    timeGV = isNullOrEmpty(split1[i].Split('@')[0].Trim()) ? "0" : split1[i].Split('@')[1].Trim(); // GV #                    
                }       
               
                
                i++;
                if (process.Equals("count"))  // updating variables for processing times
                {
                    int gvTime = 1;                    
                    switch (strGV)
                    {
                        case "GV0": gv0 = gvTime; break;
                        case "GV1": gv1 = gvTime; break;
                        case "GV2": gv2 = gvTime; break;
                        case "GV3": gv3 = gvTime; break;
                        case "GV4": gv4 = gvTime; break;
                        case "GV5": gv5 = gvTime; break;
                        case "GV6": gv6 = gvTime; break;
                        case "GV7": gv7 = gvTime; break;
                        case "GV8": gv8 = gvTime; break;
                        case "GV9": gv9 = gvTime; break;
                        case "GV10": gv10 = gvTime; break;
                        case "GV11": gv11 = gvTime; break;
                        case "GV12": gv12 = gvTime; break;
                        case "GV13": gv13 = gvTime; break;
                        case "GV14": gv14 = gvTime; break;
                        case "GV15": gv15 = gvTime; break;
                        case "2nd Week": week2 = gvTime; break;
                        case "3rd Week": week3 = gvTime; break;
                        case "20th Day": day20 = gvTime; break;
                        case "Daily": daily = gvTime; break;
                        case "Weekly": weekly = gvTime; break;
                        case "Bi-Weekly": bi_weekly = gvTime; break;
                        case "Before EOM": before_EOM = gvTime; break;
                        case "Annual": annual = gvTime; break;
                        case "Semi-Annual": semi_annual = gvTime; break;
                        case "Quarterly": quarterly = gvTime; break;
                        default: break;
                    }
                    gvDates = split2;
                }

                else if (process.Equals("processing"))  // updating variables for setup times
                {

                    double gvSetupTime = Double.Parse(timeGV);                    
                    switch (strGV)
                    {
                        case "GV0": gv0_setup = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV1": gv1_setup = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV2": gv2_setup = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV3": gv3_setup = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV4": gv4_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV5": gv5_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV6": gv6_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV7": gv7_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV8": gv8_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV9": gv9_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV10": gv10_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV11": gv11_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV12": gv12_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV13": gv13_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV14": gv14_setup = Math.Round(gvSetupTime, 2); break;
                        case "GV15": gv15_setup = Math.Round(gvSetupTime, 2); break;
                        case "2nd Week": week2_setup = Math.Round(gvSetupTime, 2); break;
                        case "3rd Week": week3_setup = Math.Round(gvSetupTime, 2); break;
                        case "20th Day": day20_setup = Math.Round(gvSetupTime, 2); break;
                        case "Daily": daily_setup = Math.Round(gvSetupTime, 2); break;
                        case "Weekly": weekly_setup = Math.Round(gvSetupTime, 2); break;
                        case "Bi-Weekly": bi_weekly_setup = Math.Round(gvSetupTime, 2); break;
                        case "Before EOM": before_EOM_setup = Math.Round(gvSetupTime, 2); break;
                        case "Annual": annual_setup = Math.Round(gvSetupTime, 2); break;
                        case "Semi-Annual": semi_annual_setup = Math.Round(gvSetupTime, 2); break;
                        case "Quarterly": quarterly_setup = Math.Round(gvSetupTime, 2); break; 
                        default: break;
                    }
                    gvDates = split2;
                    setupTime = split2;
                }
                else if (process.Equals("setup"))  // updating variables for setup times
                {
                    double gvSetupTime = Double.Parse(timeGV);
                    switch (strGV)
                    {
                        case "GV0": gv0_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV1": gv1_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV2": gv2_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV3": gv3_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV4": gv4_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV5": gv5_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV6": gv6_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV7": gv7_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV8": gv8_setup2 = double.Parse(gvSetupTime.ToString("#.##")); break;
                        case "GV9": gv9_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "GV10": gv10_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "GV11": gv11_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "GV12": gv12_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "GV13": gv13_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "GV14": gv14_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "GV15": gv15_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "2nd Week": week2_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "3rd Week": week3_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "20th Day": day20_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "Daily": daily_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "Weekly": weekly_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "Bi-Weekly": bi_weekly_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "Before EOM": before_EOM_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "Annual": annual_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "Semi-Annual": semi_annual_setup2 = Math.Round(gvSetupTime, 2); break;
                        case "Quarterly": quarterly_setup2 = Math.Round(gvSetupTime, 2); break;
                        default: break;
                    }
                    gvDates = split2;
                    setupTime = split2;
                }

            }

        }

        public void extractGvDays(String myStr, String process) // use regex later 
        {
            String[] split1 = myStr.Split(';'); // split out the first segment - GV Date & Proces/Setup time
            String[] split2 = new String[split1.Length];
            String timeGV = "", strGV = "";
            int i = 0;
           
            foreach(String str in split1)  // extract the gv date and discard the time
            {
               
                timeGV = isNullOrEmpty(split1[i].Split('@')[0].Trim())? "0": split1[i].Split('@')[0].Trim(); // time
              

                String[] leng = split1[i].Split('@');
                if(leng.Length == 1)
                {
                    strGV = "0";
                }
                else
                {
                   // strGV = isNullOrEmpty(split1[i].Split('@')[1].Trim()) ? "0" : split1[i].Split('@')[1].Trim(); // GV #
                    strGV = isNullOrEmpty(split1[i].Split('@')[0].Trim()) ? "0" : split1[i].Split('@')[0].Trim(); // GV #
                  //  Console.WriteLine(strGV);
                }           
                
                
                split2[i] = strGV;              
                i++;
                double gvTime = 1.00;//Double.Parse(timeGV);
              //  Console.WriteLine(strGV);
                if (process.Equals("proc"))  // updating variables for processing times
                {
                     switch(strGV)
                    {
                        
                        case "GV1": gv1 = gvTime; break;
                        case "GV2": gv2 = gvTime; break;
                        case "GV3": gv3 = gvTime; break;
                        case "GV4": gv4 = gvTime; break;
                        case "GV5": gv5 = gvTime; break;
                        case "GV6": gv6 = gvTime; break;
                        case "GV7": gv7 = gvTime; break;
                        case "GV8": gv8 = gvTime; break;
                        case "GV9": gv9 = gvTime; break;
                        case "GV10": gv10 = gvTime; break;
                        case "GV11": gv11 = gvTime; break;
                        case "GV12": gv12 = gvTime; break;
                        case "GV13": gv13 = gvTime; break;
                        case "GV14": gv14 = gvTime; break;
                        case "GV15": gv15 = gvTime; break;
                        case "2nd Week": week2 = gvTime; break;
                        case "3rd Week": week3 = gvTime; break;
                        case "20th Day": day20 = gvTime; break;
                        case "Daily": daily = gvTime; break;
                        case "Weekly": weekly = gvTime; break;
                        case "Bi-Weekly": bi_weekly = gvTime; break;
                        case "Before EOM": before_EOM = gvTime; break;
                        case "Annual": annual = gvTime; break;
                        case "Semi-Annual": semi_annual = gvTime; break;
                        case "Quarterly": quarterly = gvTime; break;
                        default: break;
                    }
                     gvDates = split2;
                }               
          
                else  // updating variables for setup times
                {
                    switch (strGV)
                    {
                        case "GV1": gv1 = gvTime; break;
                        case "GV2": gv2 = gvTime; break;
                        case "GV3": gv3 = gvTime; break;
                        case "GV4": gv4 = gvTime; break;
                        case "GV5": gv5 = gvTime; break;
                        case "GV6": gv6 = gvTime; break;
                        case "GV7": gv7 = gvTime; break;
                        case "GV8": gv8 = gvTime; break;
                        case "GV9": gv9 = gvTime; break;
                        case "GV10": gv10 = gvTime; break;
                        case "GV11": gv11 = gvTime; break;
                        case "GV12": gv12 = gvTime; break;
                        case "GV13": gv13 = gvTime; break;
                        case "GV14": gv14 = gvTime; break;
                        case "GV15": gv15 = gvTime; break;
                        case "2nd Week": week2 = gvTime; break;
                        case "3rd Week": week3 = gvTime; break;
                        case "20th Day": day20 = gvTime; break;
                        case "Daily": daily = gvTime; break;
                        case "Weekly": weekly = gvTime; break;
                        case "Bi-Weekly": bi_weekly = gvTime; break;
                        case "Before EOM": before_EOM = gvTime; break;
                        case "Annual": annual = gvTime; break;
                        case "Semi-Annual": semi_annual = gvTime; break;
                        case "Quarterly": quarterly = gvTime; break;
                        default: break;
                    }
                    gvDates = split2;
                    setupTime = split2;
                } 
              
            }
                       
        }



    }
}
