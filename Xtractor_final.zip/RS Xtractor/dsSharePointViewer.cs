﻿namespace myFSSRS_SharePoint_Viewer
{


    public partial class dsSharePointViewer
    {
    }
}
namespace myFSSRS_SharePoint_Viewer {
    
    
    public partial class dsSharePointViewer {
    }
}
