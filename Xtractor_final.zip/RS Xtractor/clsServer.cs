﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFSSRS_SharePoint_Viewer
{
    class clsServer
    {
        string m_URL = null;
        Dictionary<string, clsSite> dicSites = new Dictionary<string,clsSite>();

        public string URL
        {
            get { return m_URL; }
        }

        public clsServer(string URL)
        {
            m_URL = URL;
        }

        public clsSite AddSite(string SiteName, string SitePath)
        {
            clsSite oSPSite = new clsSite(SiteName, SitePath, this);
            dicSites.Add(SiteName, oSPSite);

            return oSPSite;
        }
    }
}
