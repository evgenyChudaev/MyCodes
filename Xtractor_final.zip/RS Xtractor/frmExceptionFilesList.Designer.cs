﻿namespace myFSSRS_SharePoint_Viewer
{
    partial class frmExceptionFilesList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxExceptionFiles = new System.Windows.Forms.ListBox();
            this.butOpen = new System.Windows.Forms.Button();
            this.butCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbxExceptionFiles
            // 
            this.lbxExceptionFiles.DisplayMember = "Name";
            this.lbxExceptionFiles.FormattingEnabled = true;
            this.lbxExceptionFiles.Location = new System.Drawing.Point(13, 13);
            this.lbxExceptionFiles.Name = "lbxExceptionFiles";
            this.lbxExceptionFiles.Size = new System.Drawing.Size(259, 277);
            this.lbxExceptionFiles.TabIndex = 0;
            this.lbxExceptionFiles.ValueMember = "Name";
            // 
            // butOpen
            // 
            this.butOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butOpen.Location = new System.Drawing.Point(116, 296);
            this.butOpen.Name = "butOpen";
            this.butOpen.Size = new System.Drawing.Size(75, 23);
            this.butOpen.TabIndex = 2;
            this.butOpen.Text = "Open";
            this.butOpen.UseVisualStyleBackColor = true;
            this.butOpen.Click += new System.EventHandler(this.butOpen_Click);
            // 
            // butCancel
            // 
            this.butCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butCancel.Location = new System.Drawing.Point(197, 296);
            this.butCancel.Name = "butCancel";
            this.butCancel.Size = new System.Drawing.Size(75, 23);
            this.butCancel.TabIndex = 3;
            this.butCancel.Text = "Cancel";
            this.butCancel.UseVisualStyleBackColor = true;
            this.butCancel.Click += new System.EventHandler(this.butCancel_Click);
            // 
            // frmExceptionFilesList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.butCancel;
            this.ClientSize = new System.Drawing.Size(284, 325);
            this.Controls.Add(this.butCancel);
            this.Controls.Add(this.butOpen);
            this.Controls.Add(this.lbxExceptionFiles);
            this.Name = "frmExceptionFilesList";
            this.Text = "Exception Files";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button butOpen;
        private System.Windows.Forms.Button butCancel;
        public System.Windows.Forms.ListBox lbxExceptionFiles;

    }
}