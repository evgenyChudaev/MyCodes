﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFSSRS_SharePoint_Viewer
{
    class clsColumns
    {
        enum SharePointFieldType
        {
            ftText = 0,
            ftChoice = 1
        }

        string m_spField = null;

        // accessor for Sharepoit Field
        public string SPField
        {
            get { return m_spField; }
        }

        string m_dtColumn = null;

        // accessor for Sharepoit Field
        public string DTColumn
        {
            get { return m_dtColumn; }
        }

        SharePointFieldType m_spType = SharePointFieldType.ftText;
      
        // accessor for Sharepoit Field type
        public SharePointFieldType SPType
        {
            get { return m_spType; }
        }

        // constructor for clsColumns class
        public clsColumns(string SPField, SharePointFieldType ftField, string DTColumn)
        {
            m_spField = SPField;
            m_spType = ftField;
            m_dtColumn = DTColumn;
        }

    }
}
