﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SP = Microsoft.SharePoint.Client;

namespace myFSSRS_SharePoint_Viewer
{
    class clsList
    {
        //collection of DataGridViews
        Dictionary<string, clsDataGridView> dicDataGridViews = new Dictionary<string, clsDataGridView>();
        
        clsSite m_ParentSite = null;
        internal clsSite ParentSite {get { return m_ParentSite; }}

        bool m_Connected = false;
        public bool Connected {get { return m_Connected; }}

		string m_Name = null;
		string m_SPListName = null;

        SP.List m_SPList = null;
        public SP.List SPList {get { return m_SPList; }}

        string m_DisplayFormURL = null;
        public string DisplayFormURL {get { return m_DisplayFormURL; }}

        string m_EditFormURL = null;
        public string EditFormURL {get { return m_EditFormURL; }}

        string m_NewFormURL = null;
        public string NewFormURL { get { return m_NewFormURL; } }

        internal Dictionary<string, clsDataGridView> DataGridViews
        {
            get
            {
                return dicDataGridViews;
            }
        }

        // constructor for the clsList class
        public clsList(string Name, string SPListName, clsSite ParentSite)
		{
			m_Name = Name;
			m_SPListName = SPListName;
            m_ParentSite = ParentSite;
		}

        public bool Connect()
        {
            m_SPList = m_ParentSite.SPSite.Lists.GetByTitle(m_SPListName);
            m_ParentSite.SPClientContext.Load(m_SPList, list => list.DefaultDisplayFormUrl, list => list.DefaultEditFormUrl, list => list.DefaultNewFormUrl);
            m_ParentSite.SPClientContext.ExecuteQuery();

            m_DisplayFormURL = m_SPList.DefaultDisplayFormUrl;
            m_EditFormURL = m_SPList.DefaultEditFormUrl;
            m_NewFormURL = m_SPList.DefaultNewFormUrl;
            m_Connected = true;
            return true;
        }

        // ASK MICHAEL CHARRON SEEMS LIKE A CIRCULAR REFERENCE 
        // (list is created in class clsColumn, which is created by clsDataGridView, which is created by clsList
        internal clsDataGridView AddDataGridView(DataGridView dgvTarget, string CAML)
        {
            clsDataGridView oDataGridView = new clsDataGridView(dgvTarget, CAML, this);

            //MessageBox.Show("Target Name : " + dgvTarget.Name);
            // add new DataGridview to the collection dicDataGridViews
            dicDataGridViews.Add(dgvTarget.Name, oDataGridView);

            return oDataGridView; // return object of clsDataGridView class
        }
    }

}
