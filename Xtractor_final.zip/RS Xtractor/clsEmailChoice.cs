﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFSSRS_SharePoint_Viewer
{
    class clsEmailChoice
    {
        string m_MenuOption = null;
        public string MenuOption
        {
            get { return m_MenuOption; }
        }

        string m_Subject = null;
        public string Subject
        {
            get { return m_Subject; }
        }
        
        string m_To = null;
        public string To
        {
            get { return m_To; }
        }
        
        string m_CC = null;
        public string CC
        {
            get { return m_CC; }
        }

        string m_RequestType = null;
        public string RequestType
        {
            get { return m_RequestType; }
        }

        public string GetMessageBody()
        {
            return GetMessageBody(""); 
        }

        Dictionary<string, string> m_MessageBodies = null;
        public string GetMessageBody(string MessageOption)
        {
            return "<basefont face='arial, verdana, sans-serif' size='2'>" + m_MessageBodies[MessageOption].Replace("\r\n", "").Replace("\t", "");
        }

        string m_MessageOptionColumn = null;
        public string MessageOptionColumn
        {
            get { return m_MessageOptionColumn; }
        }


        clsDataGridView m_DataGridView = null;
        // constructor for the clsEmailChoice class
        public clsEmailChoice(string MenuOption, string MessageOptionColumn, string Subject, string To, string CC, Dictionary<string, string> MessageBodies, clsDataGridView oDataGridView)
        {
            m_MenuOption = MenuOption;
            m_MessageOptionColumn = MessageOptionColumn;
            m_Subject = Subject;
            m_To = To;
            m_CC = CC;
            m_RequestType = RequestType;
            m_MessageBodies = MessageBodies;
            m_DataGridView = oDataGridView;
        }
    }
}
