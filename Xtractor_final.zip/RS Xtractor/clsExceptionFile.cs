﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myFSSRS_SharePoint_Viewer
{
    class clsExceptionFile
    {
        string m_URN = null;
        public string URN
        {
            get { return m_URN; }
        }
        
        string m_FileFilter = null;
        public string FileFilter
        {
            get { return m_FileFilter; }
        }

        public clsExceptionFile(string URN, string FileFilter)
        {
            m_URN = URN;
            m_FileFilter = FileFilter;
        }
    }
}
