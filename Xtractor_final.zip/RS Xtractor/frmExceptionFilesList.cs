﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myFSSRS_SharePoint_Viewer
{
    public partial class frmExceptionFilesList : Form
    {
        public frmExceptionFilesList()
        {
            InitializeComponent();
        }

        private void butCancel_Click(object sender, EventArgs e)
        {
            lbxExceptionFiles.SelectedIndex = -1;
        }

        private void butOpen_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
