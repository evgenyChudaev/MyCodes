﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication14
{
    public partial class loginPage : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=SSRC\DEV2008,2301;Initial Catalog=LSSTracker;User ID=lssTrackerApp;Password=Qazwsx184!");
        public loginPage()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {           
            frmMain mainForm = new frmMain();
            mainForm.Focus();
            //mainForm.
            //mainForm.tbpgMain.SelectedIndex = 0;
            this.Close();            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string userName = txtLogin.Text.Trim();
            string pw = txtPassword.Text.Trim();
            gvbind("extractAdminCredentials", userName, pw);

        }

        protected void gvbind(string sp_name, string myLogin, string myPw)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn);

            if (sp_name == "extractAdminCredentials")  // extractAdminCredentials SP has 2 parameters unlike other
            {
                //Response.Write("<script>alert('Inside gvBind1"+ sp_name+", " +myLogin + ", " + myPw + "');</script>");
                cmd.Parameters.AddWithValue("@myLogin", myLogin);
                cmd.Parameters.AddWithValue("@myPw", myPw);
            }
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();

            if (ds.Tables[0].Rows.Count > 0)
            {

               
                frmMain.loadAdminData = true; // update static variable in frmMain class to indicate that admin data can be loaded
                this.Close();

               /* if (sp_name == "extractAdminCredentials")
                {
                    //id01.Visible = false; // hide the modal form
                    gvbind("extractAdminData", myLogin, myPw); // call gvbind recursively with different parameters to load data into the admin table on successful login attempt
                }
                else // successful attempt -> user has been identified as admin and is allowed to proceed. Data is loaded to admin tables
                {
                    this.Close();
                    frmMain.loadAdminData = true; // update static variable in frmMain class to indicate that admin data can be loaded
                    //dgvSuperuserList.DataSource = ds;

                    //gvAdmins.DataSource = ds;
                    //gvAdmins.DataBind();
                } */
            }
        }
    }
}
