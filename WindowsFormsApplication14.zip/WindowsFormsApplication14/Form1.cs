﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Windows.Forms.DataVisualization.Charting;
//using Microsoft.Office.Interop.Outlook;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic.FileIO;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;


namespace WindowsFormsApplication14
{

    public partial class frmMain : Form
    {
        public static string myUserId;
        public static bool updatedRecord = false;
        public static bool loadAdminData = false;
        private bool isDataLoaded = false;
        string versionNumber = "1.1";  // update version number every time new application version is released.
        SqlConnection conn = new SqlConnection(@"Data Source=SSRC\DEV2008,2301;Initial Catalog=LSSTracker;User ID=lssTrackerApp;Password=Qazwsx184!");
        bool fieldFilterApplied;
        string selectedIndividuals = "";
        public frmMain()
        {

            InitializeComponent();
        }

        // Check version validity/status in the database. 
        private int checkVersionNumber(string version)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("checkVersion", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@myVersion", version);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();

            if (ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0]["version_status"].ToString() == "inactive")
                {
                    MessageBox.Show("This application version has been discontonued. Please obtain a valid version and try again.");
                    return -1;

                }
            }
            else
            {
                MessageBox.Show("This application version is not valid. Please obtain a valid version and try again.");
                return -1;
            }
            return 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chkBoxFieldList.Visible = false;
            fieldFilterApplied = false;

            if (checkVersionNumber(versionNumber) < 0)   // check if version number being used is still valid
            {
                this.Close(); // if version is invalid, close the application
                return;
            }


            checkUserDetails();
            myUserId = txtUserID.Text;
            //this.lssReferenceTableAdapter.Fill(this.lSSTrackerDataSet11.lssReference);

            // do population later
            //  populateReferenceData("extractReferenceData", "team_name");
            // populateReferenceData("extractReferenceData", "benefit_ImprovementType");

            startForm();

            // Add 2 new button columns

            addGridViewFields("dataGridViewDeleteButton", "Delete", "Delete");
            addGridViewFields("dataGridViewEditButton", "Edit", "Edit");

            getLastRefreshTime();
            populateFieldNamesCheckBox();
            //populateFieldFilter();
            // flag to indicate that the form data is loaded. Needed for drilldown only to distinguish initial load from subsequent loads
            isDataLoaded = true;
            updateFooter();
        }

        private void updateFooter()
        {
            lbDgvRecordCount.Text = "Number of records: " + gvImprovements.RowCount.ToString();
        }

        private void populateFieldNamesCheckBox()
        {
            string[] hiddenFields = { "recordId", "Time loaded to DB", "RPA/RDA", "TM1", "MS Office", ".NET", "SQL Server", "CDM", "Other tool", "Other tool details" };  // array of fields to be hidden by default
            string[] excludeFromFilterFields = { "Completion Date", "recordId", "Time loaded to DB", "Time entered", "dataGridViewEditButton", "dataGridViewDeleteButton" };
            int i = 0;
            chkBoxFieldList.Items.Clear();
            foreach (DataGridViewColumn column in gvImprovements.Columns)
            {
                if (!excludeFromFilterFields.Contains(column.Name.ToString())) // check if field is in the array of fields not to be included in the filter
                {
                    cmbFieldFilter.Items.Add(column.Name.ToString()); // add fieldNames to the field filter combobox
                }
                chkBoxFieldList.Items.Add(column.Name.ToString());

                if (!hiddenFields.Contains(column.Name.ToString()))
                {
                    chkBoxFieldList.SetItemCheckState(i, CheckState.Checked);

                }
                else
                {
                    gvImprovements.Columns[i].Visible = false;
                }

                i++;
            }
        }

        private void getLastRefreshTime()
        {
            string lastDate;
            //fieldNameDatabase
            conn.Open();
            SqlCommand cmd = new SqlCommand("getLastUpdatedDate", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@myVersion", version);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            lastDate = ds.Tables[0].Rows[0][0].ToString();
            txtToolstringRefreshStatus.Text = "Last upload: " + lastDate;
            //getLastUpdatedDate
        }

        private void startForm()
        {
            authenticateUser("checkAdmins", txtUserID.Text); // first step is to check whether current user is admin        

            myHeadDistance = headDistance - 1;
            myDistinguishedName = myPrincipalName;

            // default values for calendar


            makeDefaultSelections();
            createCharts();
        }

        DataSet ds; // small dataset to hold 1 record (if user is admin) and no records if user is not admin
        bool privilegedUser = false, adminUser = false; //,  directorUser = false, regularUser =false; 
        string mgrName, userFullName, userDistinguishedName;
        int myHeadDistance;
        string myDistinguishedName;
        int drillDownUpCounter = 0;

        protected void createCharts()
        {
            if (privilegedUser) // if user is in admin table (provileged user),then...
            {
                if (adminUser) // for admins/superusers show all records (clause where 1=1)
                {
                    Bindchart("bar", "improvementType", "fieldCount", "GetCharDataAdmin", "1", "1", emplNum, userFullName);
                    Bindchart("pie", "benefitType", "fieldCount", "GetCharDataAdmin", "1", "1", emplNum, userFullName);
                    //  createAreaChart("timeSeriesAdmin", "1", "1");
                }
                else // for directors and other privilged users show records related to their group only (FSS etc.)
                {
                    Bindchart("bar", "improvementType", "fieldCount", "GetCharDataAdmin", "team", "\'" + ds.Tables[0].Rows[0]["userGroup"].ToString() + "\'", emplNum, userFullName);
                    Bindchart("pie", "benefitType", "fieldCount", "GetCharDataAdmin", "team", "\'" + ds.Tables[0].Rows[0]["userGroup"].ToString() + "\'", emplNum, userFullName);
                    //createAreaChart("timeSeriesAdmin", "team", "\'" + ds.Tables[0].Rows[0]["userGroup"].ToString() + "\'");
                }

            }
            else // if user is not admin, extract information for non-managers and if user is manager, also extract information for the manager
            {
                /*  if(isDataLoaded)  // call different procesures when the chart is loaded first time and subsequently. After charts are loaded once, we have names of peoples to be used in drilldown
                  {
                      Bindchart("bar", "improvementType", "fieldCount", "GetCharDataNonAdminDrillDown", "level" + myHeadDistance, "\'" + myDistinguishedName + "\'", emplNum, userFullName);
                      Bindchart("pie", "benefitType", "fieldCount", "GetCharDataNonAdminDrillDown", "level" + myHeadDistance, "\'" + myDistinguishedName + "\'", emplNum, userFullName);
                      Bindchart("team", "team", "fieldCount", "GetCharDataNonAdminDrillDown", "level" + myHeadDistance, "\'" + myDistinguishedName + "\'", emplNum, userFullName);
                  } */
                // myDistinguishedName, myHeadDistance
                Bindchart("bar", "improvementType", "fieldCount", "GetCharDataNonAdmin", "level" + myHeadDistance, "\'" + myDistinguishedName + "\'", emplNum, userFullName);
                Bindchart("pie", "benefitType", "fieldCount", "GetCharDataNonAdmin", "level" + myHeadDistance, "\'" + myDistinguishedName + "\'", emplNum, userFullName);
                Bindchart("team", "team", "fieldCount", "GetCharDataNonAdmin", "level" + myHeadDistance, "\'" + myDistinguishedName + "\'", emplNum, userFullName);
                createAreaChart("timeSeriesNonAdmin", emplNum, "\'" + userFullName + "\'");
                //Console.WriteLine("level" + myHeadDistance + "\'" + myDistinguishedName + "\'"+ emplNum+ userFullName);
            }

            // select all values in the list of people for drill down
            lstDrillDownOn.BeginUpdate();
            for (int i = 0; i < lstDrillDownOn.Items.Count; i++)
                lstDrillDownOn.SetSelected(i, true);
            lstDrillDownOn.EndUpdate();

        }

        private void createAreaChart(string sp_name, string emplNum, string emplName)
        {
            lstDrillDownOn.Items.Clear(); //clear drilldown listbox

            DataTable ChartData = null;
            // ChartData = connectNQuery("na", ref ChartData, sp_name, "level" + (myHeadDistance- drillDownUpCounter), "level" + myHeadDistance, "\'"+myDistinguishedName+"\'"); // here emplName is unneccessary, sp should be modified so it can be deleted ot changed to something else
            ChartData = connectNQuery("na", ref ChartData, sp_name, "level" + (myHeadDistance - drillDownUpCounter), "level" + myHeadDistance, "\'" + myDistinguishedName + "\'"); // here emplName is unneccessary, sp should be modified so it can be deleted ot changed to something else

            if (ChartData.Rows.Count == 0)
            {
                return;
            }
            if (ChartData.Rows[0][0].ToString() == null || ChartData.Rows[0][0].ToString() == "") // exit gracefully if series name is null (lowest hierarchy is reached)
            {
                return;
            }
            // clear old chart series
            while (chartSeries.Series.Count > 0)
            {
                chartSeries.Series.RemoveAt(0);
            }


            String seriesName = "";
            for (int i = 0; i < ChartData.Rows.Count; i++)          // rows
            {
                seriesName = ChartData.Rows[i][0].ToString(); // person's name here
                lstDrillDownOn.Items.Add(seriesName);

                // result.Properties["manager"][0].ToString().Split(',')[0] + ',' + result.Properties["manager"][0].ToString().Split(',')[1];
                if (seriesName != "null" && seriesName != "na" && seriesName != null && seriesName != "")
                {
                    seriesName = seriesName.Split(',')[0] + ',' + seriesName.Split(',')[1];
                }

                seriesName = seriesName.Replace("CN=", "").Replace("\\", "");
                chartSeries.Series.Add(seriesName);
                //  lstDrillDownOn.Items.Add(seriesName);  // populate drilldown listbox

                chartSeries.Series[seriesName].XValueMember = ChartData.Rows[i][0].ToString();
                for (int j = 1; j < ChartData.Columns.Count; j++)  // columns
                {
                    chartSeries.Series[seriesName].Points.AddXY(ChartData.Columns[j].ToString(), ChartData.Rows[i][j].ToString());

                    chartSeries.Series[seriesName].ChartType = SeriesChartType.StackedArea;
                }
            }
            //chartSeries.Height = 300;
            //chartSeries.Width = 1500;
            chartSeries.ChartAreas[0].AxisX.IsMarginVisible = false;
        }



        private void Bindchart(string chartName, string groupingField, string fieldCount, string procedureName, string criteria1, string criteria2, string emplNum, string emplName)
        {
            DataTable ChartData = null;
            ChartData = connectNQuery(groupingField, ref ChartData, procedureName, "level" + (myHeadDistance - drillDownUpCounter), criteria1, criteria2);

            //storing total rows count to loop on each Record   
            string[] XPointMember = new string[ChartData.Rows.Count];
            int[] YPointMember = new int[ChartData.Rows.Count];

            //  Console.WriteLine("rows count in chart data: " +ChartData.Rows.Count);
            for (int count = 0; count < ChartData.Rows.Count; count++)
            {
                //storing Values for X axis   
                XPointMember[count] = ChartData.Rows[count][groupingField].ToString();
                //storing values for Y Axis   
                YPointMember[count] = Convert.ToInt32(ChartData.Rows[count][fieldCount]);
            }

            Chart myChart = null;
            switch (chartName)
            {
                case "bar":
                    myChart = chartImprovementType;
                    myChart.Series[0].ChartType = SeriesChartType.Column;
                    myChart.Series[0].IsVisibleInLegend = false;

                    //myChart.Height = 400;
                    //myChart.Width = 400;
                    break;
                case "team":
                    myChart = chartContributor;
                    myChart.Series[0].ChartType = SeriesChartType.Column;
                    myChart.Series[0].IsVisibleInLegend = false;
                    // myChart.Height = 400;
                    //myChart.Width = 400;
                    //myChart.Legends["legend1"]. = "#VALY";
                    break;
                case "pie":
                    myChart = chartTeams;
                    myChart.Series[0].ChartType = SeriesChartType.Doughnut;

                    //myChart.Height = 400;
                    //myChart.Width = 400;
                    break;

                default:
                    break;
            }

            myChart.Series[0].Label = "#VALY";
            myChart.Series[0].Points.DataBindXY(XPointMember, YPointMember);
            //myChart.Series[0].IsVisibleInLegend = false;
            //myChart.Series[0].BorderWidth = 10;
            myChart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            myChart.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
        }

        private DataTable connectNQuery(string groupingField, ref DataTable ChartData, string procedureName, string detailLevel, string criteria1, string criteria2)
        {
            string[] mySelections = checkListBoxSelections(); // determine selections on listboxes

            //we can drill down on individual selected after the data is already loaded as before that we don't have individuals' names for the initial level

            //selectedIndividuals = ""; // @"CN=Jewett\, Keith,OU=Developer,OU=RBC Bank,OU=Accounts,DC=maple,DC=fg,DC=rbc,DC=com";
            // if (isDataLoaded)
           // Console.WriteLine("SELECTED INDIVIDUALS: " + selectedIndividuals + " level of details" + detailLevel);

            conn.Open();
            SqlCommand com = new SqlCommand(procedureName, conn);
            com.Parameters.AddWithValue("@fieldname", groupingField);
            com.Parameters.AddWithValue("@teamNames", mySelections[0]);
            com.Parameters.AddWithValue("@improvementTypes", mySelections[1]);
            com.Parameters.AddWithValue("@levelOfDetail", detailLevel);
            com.Parameters.AddWithValue("@startDate", mySelections[2]);
            com.Parameters.AddWithValue("@endDate", mySelections[3]);
            com.Parameters.AddWithValue("@periods", mySelections[5]);
            com.Parameters.AddWithValue("@searchField", criteria1);
            com.Parameters.AddWithValue("@searchCriteria", criteria2);
            com.Parameters.AddWithValue("@individualsSelected", selectedIndividuals);


            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            //   Console.WriteLine("group field: " + groupingField + " teamNames" + mySelections[0] + "improvement types " + mySelections[1], " level of details" + detailLevel + " start Date " + mySelections[2] + " end date: " + mySelections[3] + " Periods " + mySelections[5], " searchField " + criteria1 + "search Cruteria " + criteria2);
            // Console.WriteLine( " XXXX level of details" + detailLevel + " start Date " + mySelections[2] + " end date: " + mySelections[3] + " Periods " + mySelections[5], " searchField " + criteria1 + "search Cruteria " + criteria2);
            ChartData = ds.Tables[0];
            conn.Close();
            return ChartData;
        }


        private string[] checkListBoxSelections()
        {
            // determine all improvement types & teams selected
            string[] listBoxSelections = new string[6];

            string selectedImprovementTypes = "";
            string selectedTeams = "";
            // string selectedIndividuals = "";

            // Improvements selected
            foreach (var item in lstImprovementType.SelectedItems)
            {
                selectedImprovementTypes += "'" + item.ToString() + "'" + ",";
            }

            // teams selected
            foreach (var item in lstTeam.SelectedItems)
            {
                selectedTeams += "'" + item.ToString() + "'" + ",";
            }

            // Console.WriteLine("SELECTED TEAMS: " + selectedTeams);
            DateTime fromDate = calFrom.Value.AddDays(-1);
            DateTime toDate = calTo.Value.AddDays(1);
            string startDate = fromDate.ToString("yyyy-MM-dd");
            string endDate = toDate.ToString("yyyy-MM-dd");
            string detailLevel = ""; // cmbDetailLevel.SelectedValue.ToString();


            // create a string of all periods in scope to be used as a parameter for field names in dynamic SQL
            DateTime next;
            next = calFrom.Value;
            string nextPeriod = "";
            string concatPeriods = "";
            while (next <= calTo.Value)
            {
                nextPeriod = next.Year.ToString() + "-" + next.Month.ToString();
                next = next.AddMonths(1);
                concatPeriods += "\"" + nextPeriod + "\"" + ",";
            }

            selectedTeams = selectedTeams.Substring(0, selectedTeams.Length - 1);
            selectedImprovementTypes = selectedImprovementTypes.Substring(0, selectedImprovementTypes.Length - 1);
            // selectedIndividuals = selectedIndividuals.Substring(0, selectedIndividuals.Length - 1);
            concatPeriods = concatPeriods.Substring(0, concatPeriods.Length - 1);
            // populate array of strings with selected items
            listBoxSelections[0] = selectedTeams;
            listBoxSelections[1] = selectedImprovementTypes;
            listBoxSelections[2] = startDate;
            listBoxSelections[3] = endDate;
            listBoxSelections[4] = detailLevel;
            listBoxSelections[5] = concatPeriods;
            //  listBoxSelections[6] = selectedIndividuals;
            return listBoxSelections;
        }


        protected void gvbind(string fieldName, string filter, string emplNum, string sp_name)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn);
            cmd.Parameters.AddWithValue("@fieldName", fieldName.Trim());
            cmd.Parameters.AddWithValue("@filterParam", filter.Trim());
            cmd.Parameters.AddWithValue("@emplNumber", emplNum.Trim());
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            System.Data.DataTable myDataTable = new System.Data.DataTable();
            da.Fill(myDataTable);
            //Console.WriteLine("field: " + fieldName + " filter: " + filter + " sp name: " + sp_name);
            gvImprovements.DataSource = myDataTable;
            conn.Close();
            // add delete/edit buttons on the main datagridview       

        }

        // add additional fields/controls to the gridview
        private void addGridViewFields(string btnName, string headerText, string buttonText)
        {
            var dgvButton = new DataGridViewButtonColumn();
            dgvButton.Name = btnName;
            dgvButton.HeaderText = headerText;
            dgvButton.Text = buttonText;
            dgvButton.UseColumnTextForButtonValue = true;
            this.gvImprovements.Columns.Add(dgvButton);
        }

        private void gvImprovements_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            //if click is on new row or header row
            if (e.RowIndex == gvImprovements.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == gvImprovements.Columns["dataGridViewEditButton"].Index)
            {
                string teamName, benefitType, improvementType, frequencyTime, frequency, certificationType, details, recordId, estEffort, completionDate, certMemo;

                //teamName = "FSS";
                //Put some logic here, for example to remove row from your binding list.
                //MessageBox.Show("Record to be edited");
                teamName = gvImprovements.CurrentCell.OwningRow.Cells["Team"].Value.ToString();   //.Rows[e.RowIndex].Cells["Team"].Value.ToString();
                benefitType = gvImprovements.CurrentCell.OwningRow.Cells["Type of savings"].Value.ToString();
                improvementType = gvImprovements.CurrentCell.OwningRow.Cells["Improvement Type"].Value.ToString();
                frequencyTime = gvImprovements.CurrentCell.OwningRow.Cells["Savings per frequency"].Value.ToString();
                frequency = gvImprovements.CurrentCell.OwningRow.Cells["Activity frequency"].Value.ToString();
                // MessageBox.Show(frequency);
                certificationType = gvImprovements.CurrentCell.OwningRow.Cells["Purpose of improvement"].Value.ToString();
                details = gvImprovements.CurrentCell.OwningRow.Cells["Comments"].Value.ToString();
                recordId = gvImprovements.CurrentCell.OwningRow.Cells["recordId"].Value.ToString();               
                estEffort = gvImprovements.CurrentCell.OwningRow.Cells["Work Effort"].Value.ToString();
                completionDate = gvImprovements.CurrentCell.OwningRow.Cells["Completion Date"].Value.ToString();
                certMemo = gvImprovements.CurrentCell.OwningRow.Cells["Brief Summary: old and improved process"].Value.ToString();

                frmEdit editForm = new frmEdit(teamName, benefitType, improvementType, frequencyTime, frequency, certificationType, details, recordId, estEffort, completionDate, certMemo);

                editForm.ShowDialog();
                // this.Close(); 
                // this.Refresh();
                if (updatedRecord)
                {
                    startForm();
                    //MessageBox.Show("AAAA");
                }
                updatedRecord = false;

            }
            else if (e.ColumnIndex == gvImprovements.Columns["dataGridViewDeleteButton"].Index)
            {
                //Put some logic here, for example to remove row from your binding list.
                //MessageBox.Show("Record to be deleted");
                //MessageBox.Show(gvImprovements.CurrentCell.OwningRow.Cells["RecordID"].Value.ToString()); 

                //gvImprovements.Rows.RemoveAt(gvImprovements.CurrentCell.RowIndex); //.CurrentCell.OwningRow.Cells.De;
                confirmDelete(gvImprovements.CurrentCell.OwningRow.Cells["recordId"].Value.ToString());

            }
            //this.Close();

        }

        public static void refreshGridView()
        {
            // authenticateUser("checkAdmins", myUserId); // first step is to check whether current user is admin        
        }



        protected void authenticateUser(string sp_name, string userParam)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn); // 2 types of stored procedures exist:  1. for admins, 2. for managers and non-managers

            if (sp_name == "checkAdmins")  // initial case - check if user is admin
            {
                cmd.Parameters.AddWithValue("@myUserId", userParam);
            }

            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();

            string name = txtGivenName.Text;
            string userId = txtUserID.Text;
            if (ds.Tables[0].Rows.Count > 0) // if user is in admin table,then...
            {
                if (ds.Tables[0].Rows[0]["userRole"].ToString() == "Admin" || ds.Tables[0].Rows[0]["userRole"].ToString() == "Superuser")
                    gvbind("1", "1", userId, "extractTrackerDataAdmin"); // Case ADMIN: extract all records for the admin user, no filters applied. NOTE 1=1 is always true, so all records will be extracted                                                              
                else // case director
                    gvbind("team", "\'" + ds.Tables[0].Rows[0]["userGroup"].ToString() + "\'", userId, "extractTrackerDataAdmin");
            }
            else // if user is not admin, extract information for non-managers and is user is manager, also extract information for the manager
            {

                string levelNum = Convert.ToString(headDistance - 1);
                //MessageBox.Show("levelNo " + levelNum + "myPrincName " + myPrincipalName);
                gvbind("level" + levelNum, "\'" + myPrincipalName + "\'", userId, "extractTrackerDataHierarchically");
                //  gvbind("level" + levelNum, "\'" + myPrincipalName + "\'", userId, "getTrackerDataHierarchically");  // temp stored procedure to always show Keith's view to whoever uses the tool
            }
        }

        string emplNum;
        string myPrincipalName = "";
        string chainOfCommand = "";
        int headDistance = 0;
        string mgrTrail = "";
        string mgrLoginName = "";
        string[] domains = { "maple", "oak", "pine", "palm", "birch", "fg", "forest", "gem" };
        LinkedList<string> myDomailList;
        LinkedList<string> myHierarchyList;
        string[] myHierarchy;
        private void checkUserDetails()
        {
            myDomailList = new LinkedList<string>(domains);
            myHierarchy = new string[11];

            //string userId = "309228997";//Denys
            //string userId = "123014441";//Ena
            // string userId = "846495133";//Robin
            // string userId = "804561751"; //Shyam
            //string userId = "806711172"; // Ali                         // string userId = Environment.UserName.ToString();

            //string userId = "858072507"; // Keith
          //  string userId = "858072507"; // Keith
            string userId = "858072507"; // Keith
            // string userId = Environment.UserName.ToString();
            emplNum = Environment.UserName.ToString();
            emplNum = "858072507";
           
            myDomailList = new LinkedList<string>(domains);


            txtUserID.Text = userId;
            string account = userId;//userId;
            string mgrName = "";

            //DirectoryEntry entry = new DirectoryEntry();
            SearchResult result = null;
            myHierarchyList = new LinkedList<string>(); // initialize list to store hierarchies
            foreach (string element in myDomailList)
            {
                DirectoryEntry entry = new DirectoryEntry("LDAP://" + element);
                DirectorySearcher search = new DirectorySearcher(entry);

                // specify the search filter
                search.Filter = "(&(objectClass=user)(anr=" + account + "))";
                // specify which property values to return in the search
                search.PropertiesToLoad.Add("displayName");   // first name
                search.PropertiesToLoad.Add("sn");          // last name
                search.PropertiesToLoad.Add("cn");
                search.PropertiesToLoad.Add("manager");        // smtp mail address
                search.PropertiesToLoad.Add("department");
                search.PropertiesToLoad.Add("mail");
                //search.PropertiesToLoad.Add("userprincipalname");
                search.PropertiesToLoad.Add("distinguishedname");
                // search.PropertiesToLoad.Add("samaccountname");
                // perform the search         
                result = search.FindOne();


                if (result == null) // == null)
                {
                    if (element == "gem") //exception when all domains are checked and noresult has been returned
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    myPrincipalName = result.Properties["distinguishedname"][0].ToString();
                    myHierarchyList.AddFirst(myPrincipalName);
                    //txtDetails.Text = result.Properties["distinguishedname"][0].ToString();
                    headDistance++;

                    mgrName = result.Properties["manager"][0].ToString();
                    //mgrTrail += mgrName + " | ";
                    //myHierarchyList.AddFirst(mgrName);
                    //  myHierarchy[0] = mgrName;
                    txtManagerName.Text = mgrName;
                    txtEmail.Text = result.Properties["mail"][0].ToString();
                    //txtEmail.Text = result.Properties["distinguishedname"][0].ToString();
                    txtUserDepartment.Text = result.Properties["department"][0].ToString();
                    txtGivenName.Text = result.Properties["cn"][0].ToString();
                    myHierarchy[headDistance] = mgrName;
                    myHierarchyList.AddFirst(mgrName);
                    headDistance++;
                    readEntireAD(mgrName);
                    break;
                }
            }

            // hierarchy list has to be populated for all 11 poistions if there are less than 10 elements, then fill those elements with "null"
            if (myHierarchyList.Count < 11)
            {
                int firstEmptyElement = myHierarchyList.Count;
                for (int i = firstEmptyElement; i < 11; i++)
                {
                    //   myHierarchyList.AddLast("null"); // save null as string as null parameter cannot be passed to the database
                    myHierarchyList.AddLast(myPrincipalName);
                }
            }

        }

        int recurCounter = 0;
        private void readEntireAD(string mgrName)
        {
            myDomailList = new LinkedList<string>(domains);
            SearchResult result = null;
            int domanCount = myDomailList.Count;

            foreach (string element in myDomailList)
            {
                string path = "LDAP://" + element;
                //init a directory entry
                DirectoryEntry entry = new DirectoryEntry(path);
                DirectorySearcher search = new DirectorySearcher(entry);
                // specify the search filter
                search.Filter = "(&(objectClass=user)(distinguishedname=" + mgrName + "))";
                search.PropertiesToLoad.Add("manager");
                search.PropertiesToLoad.Add("userprincipalname");
                //search.PropertiesToLoad.Add("objectguid");
                search.PropertiesToLoad.Add("CN");
                result = search.FindOne();
                if (result == null) // == null)
                {
                    if (element == "birch") //exception when all domains are checked and noresult has been returned
                    // if (recurCounter == domains.Count())
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    // mgrName = result.Properties["manager"][0].ToString();    
                    mgrName = result.Properties["manager"][0].ToString();
                    chainOfCommand += result.Properties["cn"][0].ToString() + " -> ";
                    //mgrLoginName = result.Properties["userprincipalname"][0].ToString();
                    //mgrTrail += mgrName + " | ";
                    myHierarchyList.AddFirst(mgrName); // add managers' hierarchy to the list
                    myHierarchy[headDistance] = mgrName; // add managers' hierarchy to the array
                    headDistance++;
                    break;
                }

            }

            if (result.Properties["manager"][0].ToString() == @"CN=McKay\, David,OU=Developer,OU=RBC Bank,OU=Accounts,DC=maple,DC=fg,DC=rbc,DC=com" || headDistance > 15) // base case
            {
                chainOfCommand = chainOfCommand.Substring(0, chainOfCommand.Length - 3);
                //txtDetails.Text = chainOfCommand;// show who the original user reports to all the way up to senior leadership
                return;
            }
            //txtDetails.Text = result.Properties["distinguishedname"][0].ToString() + " " + f;
            recurCounter++;
            readEntireAD(mgrName);
        }

        private void populateReferenceData(string sp_name, string fieldName)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn);
            cmd.Parameters.AddWithValue("@fieldName", fieldName.Trim());
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            System.Data.DataTable myDataTable = new System.Data.DataTable();
            da.Fill(myDataTable);


            if (fieldName == "team_name")
            {
                for (int i = 0; i < myDataTable.Rows.Count; i++)
                {
                    //listView1.Items.Add(dt);
                    //lstTeam.Items.Add(myDataTable.Rows[i].ToString());
                    lstTeam.Items.Add(myDataTable.Rows[i][0].ToString());
                }
                //lstTeam.DataSource = myDataTable;
                //lstTeam.DisplayMember = myDataTable.Columns[0].ColumnName;
                //lstTeam.ValueMember = myDataTable.Columns[0].ColumnName;
            }
            else if (fieldName == "benefit_ImprovementType")
            {
                for (int i = 0; i < myDataTable.Rows.Count; i++)
                {
                    //listView1.Items.Add(dt);
                    //lstTeam.Items.Add(myDataTable.Rows[i].ToString());
                    lstImprovementType.Items.Add(myDataTable.Rows[i][0].ToString());
                }
                //lstImprovementType.DataSource = myDataTable;
                //lstImprovementType.DisplayMember = myDataTable.Columns[0].ColumnName;
                //lstImprovementType.ValueMember = myDataTable.Columns[0].ColumnName;
            }


            conn.Close();

        }

        private void makeDefaultSelections()
        {
            int year = (DateTime.Now.Month == 11 || DateTime.Now.Month == 12) ? DateTime.Now.Year : DateTime.Now.Year - 1;
            DateTime date = new DateTime(year, 11, 1);
            calFrom.Value = date;
            //calFrom.Value = date;
            //DateTime todayDate = DateTime.Today;   //new DateTime(2018, 11, 1); //DateTime.Now.Date;
            // Console.WriteLine(todayDate);
            //  calTo.Value = todayDate;

            lstTeam.BeginUpdate();
            for (int i = 0; i < lstTeam.Items.Count; i++)
                lstTeam.SetSelected(i, true);
            lstTeam.EndUpdate();

            lstImprovementType.BeginUpdate();
            for (int i = 0; i < lstImprovementType.Items.Count; i++)
                lstImprovementType.SetSelected(i, true);
            lstImprovementType.EndUpdate();

            lstDrillDownOn.BeginUpdate();
            for (int i = 0; i < lstDrillDownOn.Items.Count; i++)
                lstDrillDownOn.SetSelected(i, true);
            lstDrillDownOn.EndUpdate();

        }
        string[] previousSet, currentSet;
        private void btnDrilldown_Click(object sender, EventArgs e)
        {
            /*  HashSet<string> previousSet = new HashSet<string>();
              HashSet<string> currentSet = new HashSet<string>();

              previousSet.Add("A");
              previousSet.Add("B");
              previousSet.Add("C");

              currentSet.Add("A");
              currentSet.Add("B");
              currentSet.Add("D"); 
              MessageBox.Show(previousSet.SetEquals(currentSet)+ " ");*/


            previousSet = new string[lstDrillDownOn.Items.Count];
            lstDrillDownOn.Items.CopyTo(previousSet, 0);


            // DELETE  FROM HERE
            selectedIndividuals = "";
            if (isDataLoaded)
            {
                foreach (var item in lstDrillDownOn.SelectedItems)
                {    // if(item.ToString() != "")
                    //  {
                    selectedIndividuals += "'" + item.ToString() + "'" + ",";
                    //  }

                    // Console.WriteLine("SELECTED INDIVIDUALS: " + selectedIndividuals);
                }
                //  if (selectedIndividuals.Length > 0)
                selectedIndividuals = selectedIndividuals.Substring(0, selectedIndividuals.Length - 1);
                //Console.WriteLine(selectedIndividuals);
            }

            //     Console.WriteLine("SELECTED INDIVIDUALS: " + selectedIndividuals);
            // UNTIL HERE LATER


            if (myHeadDistance - drillDownUpCounter >= 10)
            {
                btnDrilldown.Enabled = false;
                MessageBox.Show("You've reached the most detailed level possible. You cannot drill down further.");
                return;
            }
            if (drillDownUpCounter <= 0)
            {
                btnDrillup.Enabled = true;
            }
            //MessageBox.Show("Level: "+ (myHeadDistance - drillDownUpCounter));
            drillDownUpCounter--;
            createCharts();

            // ensure that user cannt drill down further the last level
            currentSet = new string[lstDrillDownOn.Items.Count];
            lstDrillDownOn.Items.CopyTo(currentSet, 0);
            IEnumerable<string> thirdSet = currentSet.Except(previousSet);

            // Console.WriteLine(previousSet.Except(currentSet).ToString();

            // Console.WriteLine("Printing differences: ");
            // foreach(string s in thirdSet)
            if (thirdSet.Count() == 0)
            {
                btnDrilldown.Enabled = false;
                MessageBox.Show("You've reached the most detailed level possible. You cannot drill down further.");

                /*   Console.WriteLine("Printing differences: ");
                   Console.WriteLine(thirdSet.Count());
                   foreach(string s in thirdSet)
                       Console.WriteLine(s); */
            }

        }

        private void btnDrillup_Click(object sender, EventArgs e)
        {
            if (myHeadDistance - drillDownUpCounter < 10)
            {
                btnDrilldown.Enabled = true;
            }
            if (drillDownUpCounter >= 0)
            {
                btnDrillup.Enabled = false;
                MessageBox.Show("You've reached the highest level allowed. You cannot drill up further.");
                return;
            }
            //MessageBox.Show("Level: " + (myHeadDistance - drillDownUpCounter) + "head sitance:" + myHeadDistance + "drillUp : " + drillDownUpCounter);

            drillDownUpCounter++;
            createCharts();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            loginPage loginForm = new loginPage();
            loginForm.ShowDialog();
        }

        private void txtSearchKeyword_TextChanged(object sender, EventArgs e)
        {
            if (cmbFieldFilter.SelectedIndex < 0) // if nothing is selected in combobox 
            {
                MessageBox.Show("You need to select a field to search");
                return;
            }
            string myOperator = "LIKE";
            filterFromTextBox(selectedCatalogueField, ref gvImprovements, ref txtSearchKeyword, myOperator, "catalogue");
            //Console.WriteLine("FILTER CATALOGUE: " + keywordFilterCatalogue);
            filterOnSelection();
        }

        string keywordFilterCatalogue; // 2 global variables representing 
        string keywordFilterWorkflow;
        private void filterFromTextBox(string selectedField, ref DataGridView myDataGrid, ref System.Windows.Forms.TextBox myTextBox, string myOperator, string keywordTable)
        {

            //string outputInfo = "";
            string[] keyWords = myTextBox.Text.Split('|');
            //reset filters
            keywordFilterCatalogue = null;
            keywordFilterCatalogue = string.Format("[" + selectedField + "]  LIKE'{0}'", ""); // selectedField is a global variable. Represents field name selected fro, combobox. Updated when combobox value is changed
            keywordFilterWorkflow = null;
            keywordFilterWorkflow = string.Format("[" + selectedField + "]  LIKE'{0}'", "");
            foreach (string word in keyWords)
            {
                if (keywordTable == "workflow") // update keywordFilterWorkflow if workflow table is to be filtered from the keyword
                {
                    keywordFilterWorkflow += string.Format(" OR [" + selectedField + "] " + myOperator + "'%{0}%'", word);
                }
                else // otherwise update report catalogue with the keyword filter 
                {
                    keywordFilterCatalogue += string.Format(" OR [" + selectedField + "] " + myOperator + "'%{0}%'", word);
                }
            }
            //Console.WriteLine(keywordFilterCatalogue);

        }

        string selectedCatalogueField;
        private void cmbFieldFilter_SelectionChangeCommitted(object sender, EventArgs e)
        {
            selectedCatalogueField = cmbFieldFilter.GetItemText(cmbFieldFilter.SelectedItem);
        }

        private void filterOnSelection()
        {
            List<string> myFilterList = new List<string>();
            DateTime dt = calFrom.Value;
            DateTime dt2 = calTo.Value;

            string dateFilter = "";
            if (rbBetween.Checked)
            {
                dateFilter = string.Format("[Time entered] >='{0}' AND [Time entered] <='{1}' ", dt, dt2);
            }
            else if (rbBefore.Checked)
            {
                dateFilter = string.Format("[Time entered] <='{0}' ", dt2);
            }
            else if (rbAfter.Checked)
            {
                dateFilter = string.Format("[Time entered] >='{0}' ", dt);
            }
            else
            {
                dateFilter = string.Format("[Time entered] >='{0}' ", DateTime.Today.AddYears(-1));
            }


            if (txtSearchKeyword.Text == "" | txtSearchKeyword.Text == null)
            {
                //return;
                //keywordFilterCatalogue = rowFilter8;
                keywordFilterCatalogue = dateFilter;
            }

            myFilterList.Add(dateFilter);
            myFilterList.Add(keywordFilterCatalogue);  // also add keyword filter to the filter list to make sure it's correlated with other filters
            // concatenating individual filters into a combined Report Catalogue filter
            string finalFilter = "";
            //Console.WriteLine("FINAL FILTER: " + keywordFilterCatalogue);
            // Concatenating filters into a workflow filter

            if (myFilterList.Count > 0)
            {
                foreach (string filter in myFilterList)
                {
                    finalFilter += "(" + filter + ") AND";
                }

                finalFilter = finalFilter.Substring(0, finalFilter.Length - 4);
                //Console.WriteLine("FINAL FILTER: " + finalFilter);
            }


            if (finalFilter.Length > 0)
            {
                (gvImprovements.DataSource as System.Data.DataTable).DefaultView.RowFilter = finalFilter;
            }

            updateFooter();
        }

        private void btnClearFilter_Click(object sender, EventArgs e)
        {
            (gvImprovements.DataSource as System.Data.DataTable).DefaultView.RowFilter = string.Empty;
        }

        private void rbBetween_CheckedChanged(object sender, EventArgs e)
        {
            calFrom.Enabled = true;
            calTo.Enabled = true;

        }

        private void rbBefore_CheckedChanged(object sender, EventArgs e)
        {
            calFrom.Enabled = false;
            calTo.Enabled = true;
        }

        private void rbAfter_CheckedChanged(object sender, EventArgs e)
        {
            calFrom.Enabled = true;
            calTo.Enabled = false;
        }

        private void calFrom_ValueChanged(object sender, EventArgs e)
        {
            filterOnSelection();
        }

        private void calTo_ValueChanged(object sender, EventArgs e)
        {
            filterOnSelection();
        }

        private void tbpgAdmin_Enter(object sender, EventArgs e)
        {
            loginPage loginForm = new loginPage();
            loginForm.ShowDialog();
            if (loadAdminData)
            {
                // load data into tables on the admin tab
                loadAdminDataTables("extractAdminData", ref dgvSuperuserList);
                loadAdminDataTables("extractVersionNumber", ref dgvVersionControl);
                loadAdminDataTables("extractReference", ref dgvReferenceData);
                loadAdminDataTables("extractDatabaseUpdateHistory", ref dgvRefreshLog);

            }
            else
            {
                tbpgMain.SelectedIndex = 0; // if user navagates away from the admin tab, programs takes user to the first tab
            }
        }
        // extract data for tables on admin tab
        private void loadAdminDataTables(string sp_name, ref DataGridView myDataGrid)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            myDataGrid.DataSource = ds.Tables[0];
        }

        private void contactSupportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /* OutlookApp outlookApp = new OutlookApp();
             MailItem mailItem = outlookApp.CreateItem(OlItemType.olMailItem);
             mailItem.Subject = "This is the subject";
             mailItem.HTMLBody = "<html><body>This is the <strong>funky</strong> message body</body></html>";

             //Set a high priority to the message
             mailItem.Importance = OlImportance.olImportanceHigh; */

            sendEMailThroughOUTLOOK();
        }

        //method to send email to outlook
        public void sendEMailThroughOUTLOOK()
        {
            try
            {
                Outlook.Application olApp = new Outlook.Application();
                Outlook.MailItem olMailItem = olMailItem = (Outlook.MailItem)olApp.CreateItem(Outlook.OlItemType.olMailItem);

                // recepient of the email, cc & subject
                // olMailItem.To = drvSource[oEmailChoice.To].ToString(); 
                olMailItem.To = "evgeny.chudaev@rbc.com;tse.robin@rbc.com;joshua.h.zhang@rbc.com";

                /// if (oEmailChoice.CC != "")
                // olMailItem.CC = drvSource[oEmailChoice.CC].ToString();
                olMailItem.Subject = "LSS Tracker tool support";
                olMailItem.Display();
                olMailItem.HTMLBody = "Something" + olMailItem.HTMLBody;
                olMailItem.Display(true);
            }//end of try block
            catch (Exception ex)
            {
            }//end of catch
        }//end of Email Method


        private void confirmDelete(string deleteId)
        {
            //string confirmValue = Request.Form["confirm_value"];
            DialogResult deleteDialog = MessageBox.Show("Are you sure you want to delete this record?", "Delete record", MessageBoxButtons.YesNo);
            if (deleteDialog == DialogResult.Yes)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("deleteTrackerData", conn);
                cmd.Parameters.AddWithValue("@recordDeleted", deleteId);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                conn.Close();
                gvImprovements.Rows.RemoveAt(gvImprovements.CurrentCell.RowIndex);
                //authenticateUser("checkAdmins", txtUserID.Text);
                MessageBox.Show("Record deleted");
                updateFooter();
            }
            else
            {
                // do something else later (if need be)
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            createCharts();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void createCurrentMomthReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // MessageBox.Show("Function not yet implemented for this version");
            exportData("extractTeamPivot");
        }

        // export data to MS Word file format - NOT USED
        private void exportData(string sp_name)
        {
            string folderPath = folderDialogWindow();

            if (folderPath == "") // return if user does not select a folder
                return;

            string outputText = "";
            int month, year;
            month = DateTime.Now.Month;
            year = DateTime.Now.Year;
            string startDate = calFrom.Value.ToString("yyyy-MM-dd");
            string endDate = calTo.Value.ToString("yyyy-MM-dd");


            conn.Open();
            SqlCommand com = new SqlCommand(sp_name, conn);

            if (sp_name == "extractTeamPivot") // when extracting data for current month
            {
                com.Parameters.AddWithValue("@month", month);
                com.Parameters.AddWithValue("@year", year);
                //  outputText = "Statistics for the period of " + year + "-" + month;
                outputText = " for the period of " + year + "-" + month;
            }
            else                           // extracting data for a date range specified in the calendar
            {
                com.Parameters.AddWithValue("@startDate", startDate);
                com.Parameters.AddWithValue("@endDate", endDate);
                // outputText = "Statistics for the period between " + startDate + " and " + endDate;
                outputText = " for the period between " + startDate + " and " + endDate;
            }

            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();


            DataTable myTable = ds.Tables[0];
            ExportToExcel(ref myTable, folderPath + @"\LSS_Tracker_Statistics" + outputText + ".xlsx", outputText);
        }

        private string folderDialogWindow()
        {
            string folderName = "";
            using (var folderDialog = new FolderBrowserDialog())
            {
                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    folderName = folderDialog.SelectedPath;
                }
            }
            return folderName;
        }


        public static void ExportToExcel(ref System.Data.DataTable DataTable, string ExcelFilePath, string periodName)
        {
            try
            {
                int ColumnsCount;

                if (DataTable == null || (ColumnsCount = DataTable.Columns.Count) == 0)
                    throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();
                Excel.Workbooks.Add();

                // single worksheet
                Microsoft.Office.Interop.Excel._Worksheet Worksheet = Excel.ActiveSheet;

                object[] Header = new object[ColumnsCount];

                // column headings               
                for (int i = 0; i < ColumnsCount; i++)
                {
                    Header[i] = DataTable.Columns[i].ColumnName;
                }

                Microsoft.Office.Interop.Excel.Range HeaderRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, ColumnsCount]));
                HeaderRange.Value = Header;
                HeaderRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                HeaderRange.Font.Bold = true;


                // DataCells
                int RowsCount = DataTable.Rows.Count;

                object[,] Cells = new object[RowsCount, ColumnsCount];

                for (int i = 0; i < ColumnsCount; i++)
                {

                    for (int j = 0; j < RowsCount; j++)
                    {
                        Cells[j, i] = DataTable.Rows[j][i];
                    }
                }




                Worksheet.Cells[1, 1].Value = "Report generated " + periodName;
                Worksheet.Cells[1, 1].Font.Italic = true;

                if (RowsCount == 0)
                {
                    Worksheet.Cells[3, 1].Value = "No results";
                }
                else
                {
                    Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[RowsCount + 2, ColumnsCount])).Value = Cells;
                }


                Worksheet.Columns.AutoFit();

                // check fielpath
                if (ExcelFilePath != null && ExcelFilePath != "")
                {
                    try
                    {
                        Worksheet.SaveAs(ExcelFilePath);
                        Excel.Quit();
                        MessageBox.Show("Report saved!");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                            + ex.Message);
                    }
                }
                else    // no filepath is given
                {
                    Excel.Visible = true;
                }

                Marshal.FinalReleaseComObject(Worksheet);
                Marshal.FinalReleaseComObject(HeaderRange);
                Marshal.FinalReleaseComObject(Excel);
            }
            catch (Exception ex)
            {
                throw new Exception("ExportToExcel: \n" + ex.Message);
            }

        }


        private void createReportForSelectedDatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("The report will be generated for a date range specified in the date range filter on the main form. Click  'Yes' to process; 'No' to cancel. ", "Save report", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                exportData("extractTeamPivotSpecificDates");
            }
            else if (dialogResult == DialogResult.No)
            {
                //do nothing
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filePath = txtCSVFilePath.Text;
            GetDataTabletFromCSVFile(filePath);
            getDataMapping();

        }

        private void getDataMapping()
        {
            //fieldNameDatabase
            conn.Open();
            SqlCommand cmd = new SqlCommand("extractMappingData", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@myVersion", version);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            dgvFieldMapping.DataSource = ds.Tables[0];
        }

        DataTable csvData;
        private void GetDataTabletFromCSVFile(string csv_file_path)
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "," });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        //MessageBox.Show(column);

                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
                dgvCSVUpload.DataSource = csvData;
                // InsertDataIntoSQLServerUsingSQLBulkCopy(csvData);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        private void InsertDataIntoSQLServerUsingSQLBulkCopy(ref DataGridView myDataGrid, string destinationTableName)
        {


            DataTable exportTable = new DataTable();
            exportTable = (myDataGrid.DataSource as System.Data.DataTable).DefaultView.ToTable(); // export default view (filtered view) of datagridView  // (DataTable)dgvCSVUpload.DataSource;
            conn.Open();
            using (SqlBulkCopy s = new SqlBulkCopy(conn))
            {
                s.DestinationTableName = destinationTableName;
                s.WriteToServer(exportTable);
            }
            conn.Close();
        }

        private string browseFile()
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            string fPath = "";

            openFileDialog1.Filter = "CSV Files|*.csv";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (myStream)
                        {
                            fPath = openFileDialog1.FileName.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }

            }
            return fPath;
        }

        private void btnExportToSqlServer_Click(object sender, EventArgs e)
        {
            InsertDataIntoSQLServerUsingSQLBulkCopy(ref dgvCSVUpload, "lsstrackerData");
            updateRefreshTime();
            getLastRefreshTime();
            MessageBox.Show("Database updated!");
        }

        // Update last refresh time in the database
        private void updateRefreshTime()
        {
            int recordCount = dgvCSVUpload.Rows.Count;
            conn.Open();
            SqlCommand cmd = new SqlCommand("addUpdateHistoryData", conn);
            cmd.Parameters.AddWithValue("@recordCount", recordCount);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            txtCSVFilePath.Text = browseFile();
        }


        private void startADSearch()
        {
            readActiveDirectoryByEmail("joshua.h.zhang@rbc.com");
        }



        int myDistanceToHead;
        int myCounter;
        LinkedList<string> myHierarchyListCSV;
        string[] myHierarchyCSV;
        string chainOfCommandCSV, myManagerName, myDepartment, myFullName;

        private void readActiveDirectoryByEmail(string email)
        {
            string myDistNameCSV = "";
            myDistanceToHead = 0;
            myCounter = 0;
            chainOfCommandCSV = "";
            myHierarchyListCSV = new LinkedList<string>(); // initialize list to store hierarchies
            myHierarchyCSV = new string[11];
            myDomailList = new LinkedList<string>(domains);
            SearchResult result = null;
            int domanCount = myDomailList.Count;

            foreach (string element in myDomailList)
            {
                string path = "LDAP://" + element;
                //init a directory entry
                DirectoryEntry entry = new DirectoryEntry(path);
                DirectorySearcher search = new DirectorySearcher(entry);
                // specify the search filter
                search.Filter = "(&(objectClass=user)(mail=" + email + "))";               
                search.PropertiesToLoad.Add("manager");
                search.PropertiesToLoad.Add("userprincipalname");
                search.PropertiesToLoad.Add("department");
                search.PropertiesToLoad.Add("distinguishedname");
                search.PropertiesToLoad.Add("displayName");
                //search.PropertiesToLoad.Add("objectguid");
                search.PropertiesToLoad.Add("CN");
                result = search.FindOne();
                if (result == null) // == null)
                {
                    if (element == "birch") //exception when all domains are checked and noresult has been returned                   
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    myDistNameCSV = result.Properties["distinguishedname"][0].ToString();
                    myUserId = result.Properties["userprincipalname"][0].ToString().Substring(0, 9);
                    myDepartment = result.Properties["department"][0].ToString();
                    myManagerName = result.Properties["manager"][0].ToString();
                    myFullName = result.Properties["displayName"][0].ToString();
                    chainOfCommandCSV += result.Properties["cn"][0].ToString() + " -> ";

                    myHierarchyListCSV.AddFirst(myDistNameCSV); // add managers' hierarchy to the list
                    myDistanceToHead++;
                    myHierarchyListCSV.AddFirst(myManagerName);
                    myDistanceToHead++;

                    //myHierarchyCSV[myDistanceToHead] = myManagerName; // add managers' hierarchy to the array. TO DELETE
                    //myDistanceToHead++;

                    readActiveDirectoryRecurByManagerName(myManagerName);

                    break;
                }
            }

            // hierarchy list has to be populated for all 11 poistions if there are less than 10 elements, then fill those elements with "null"
            if (myHierarchyListCSV.Count < 11)
            {
                int firstEmptyElement = myHierarchyListCSV.Count;
                for (int i = firstEmptyElement; i < 11; i++)
                {
                    myHierarchyListCSV.AddLast(myDistNameCSV);
                    //myHierarchyListCSV.AddLast("null"); // save null as string as null parameter cannot be passed to the database
                }
            }


            //  Console.WriteLine(chainOfCommandCSV + " _ " + result.Properties["userprincipalname"][0].ToString());
        }

        private void readActiveDirectoryRecurByManagerName(string mgrName)
        {
            myDomailList = new LinkedList<string>(domains);
            SearchResult result = null;
            string myDistNameCSV = "";

            foreach (string element in myDomailList)
            {
                string path = "LDAP://" + element;
                //init a directory entry
                DirectoryEntry entry = new DirectoryEntry(path);
                DirectorySearcher search = new DirectorySearcher(entry);
                // specify the search filter
                search.Filter = "(&(objectClass=user)(distinguishedname=" + mgrName + "))";
                search.PropertiesToLoad.Add("manager");
                search.PropertiesToLoad.Add("userprincipalname");
                search.PropertiesToLoad.Add("distinguishedname");
                search.PropertiesToLoad.Add("CN");
                result = search.FindOne();
                if (result == null) // == null)
                {
                    if (element == "birch") //exception when all domains are checked and noresult has been returned                   
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    // myDistNameCSV = result.Properties["distinguishedname"][0].ToString();                    
                    mgrName = result.Properties["manager"][0].ToString();
                    chainOfCommandCSV += result.Properties["cn"][0].ToString() + " -> ";
                    //myHierarchyListCSV.AddFirst(myDistNameCSV);

                    // myHierarchyListCSV.AddFirst(mgrName); // add managers' hierarchy to the list
                    // myDistanceToHead++; 
                    myHierarchyListCSV.AddFirst(mgrName);
                    //myHierarchyCSV[myDistanceToHead] = mgrName; // add managers' hierarchy to the array. DELETE ARRAY LATER 
                    myDistanceToHead++;
                    break;
                }
            }

            if (result.Properties["manager"][0].ToString() == @"CN=McKay\, David,OU=Developer,OU=RBC Bank,OU=Accounts,DC=maple,DC=fg,DC=rbc,DC=com" || headDistance > 12) // base case
            {
                chainOfCommandCSV = chainOfCommandCSV.Substring(0, chainOfCommandCSV.Length - 3);
                return;
            }
            myCounter++; // DELETE UNUSED VARIABLE
            readActiveDirectoryRecurByManagerName(mgrName);


        }

        private void tbnPrepareData_Click(object sender, EventArgs e)
        {
            updateCSVDataTable();
            updateCSVDataTableColumnMapping("fieldNameSource", false); // mapping columns
           
            //updateCSVDataTableColumnMapping("fieldNameDatabase", true); // reordering columns
            //testHierarchyList();
            //testdgv();
        }

        /* method to update data datatype. 
         * If completion Date is not entered in RBC Connect,
         * then the completion date field will contain "(--)" value, which will not be converted to date
         * For consistency, we would replace "(--)" with "1900/01/01"
         */
        private void updateCSVDataTableDataTypes(ref DataTable myDt, int j)
        {
            for(int i = 0; i< myDt.Rows.Count; i++)
            {
                if(myDt.Rows[i][j].ToString().Equals("(--)"))
                {
                     myDt.Rows[i][j] = "1900/01/01";                    
                }    

               
                
            }
        }
     
      // Test method. Delete later
        private void testHierarchyList()
        {
            int levelNum = 0;
            foreach (string element in myHierarchyListCSV)
            {
                // Console.WriteLine("level" + levelNum+ " " + element);
                levelNum++;
            }
        }

        private void updateCSVDataTableColumnMapping(string mappingField, bool sort)
        {
            bool found = true;
            DataTable dt = new DataTable();
            DataTable dt2 = new DataTable();
            dt = (DataTable)(dgvCSVUpload.DataSource);
            string columnName, newColumnName;
            string[] dateTimeField = {"completion_date"};
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                columnName = dt.Columns[i].ColumnName.ToString().Trim();
               
                for (int j = 0; j < dgvFieldMapping.Rows.Count - 1; j++)
                {

                    if (dgvFieldMapping.Rows[j].Cells[mappingField].Value.ToString().Trim().Equals(columnName))
                    {                      
                        if (!sort) // when remapping only
                        {
                            newColumnName = dgvFieldMapping.Rows[j].Cells["fieldNameDatabase"].Value.ToString();
                            dt.Columns[i].ColumnName = newColumnName;
                            if(Array.IndexOf(dateTimeField, newColumnName) >=0) // check if the field is a dateTimeField 
                            {
                               updateCSVDataTableDataTypes(ref dt, i); // update datatype for completion date and remove "(--)" values                                
                            }
                        }
                        else // when reordering columns
                        {
                            /* if (dt.Columns[i].ColumnName == "team")  // MessageBox.Show("AAA"); 
                             {
                                 dt.Columns[i].SetOrdinal(10);
                                // dt.Columns[10].SetOrdinal(0);
                                 //dt2.Columns.Add(dt.Columns[i]);
                             } */

                            //dgvCSVUpload.Columns[i].DisplayIndex = Convert.ToInt32(dgvFieldMapping.Rows[j].Cells["columnOrder"].Value.ToString());
                            // dt.Columns[i].SetOrdinal(Convert.ToInt16(dgvFieldMapping.Rows[j].Cells["columnOrder"].Value.ToString()));
                            //Console.WriteLine(columnName + " " + dgvFieldMapping.Rows[j].Cells["columnOrder"].Value.ToString());

                        }

                        // dt.Columns[i].SetOrdinal(Convert.ToInt16(dgvFieldMapping.Rows[j].Cells["columnOrder"].Value));
                        found = true;
                        //Console.WriteLine("database field name: " + dgvFieldMapping.Rows[j].Cells["fieldNameDatabase"].Value.ToString() + " source : " + columnName);
                        break;
                    }
                    else
                    {
                        found = false;
                    }
                }
                if (!found && !sort)
                {
                    //  Console.WriteLine("column name not found: " + columnName); // + " database field name: " + dgvFieldMapping.Rows[j].Cells["fieldNameDatabase"].Value.ToString());
                    dt.Columns.RemoveAt(i);
                    i--;
                }
            }
            if (!sort)
            {
                dgvCSVUpload.DataSource = dt;
            }
            else
            {
                dgvCSVUpload.DataSource = dt;

            }
            //dgvCSVUpload.Columns[0].DisplayIndex = 5;
         //   for (int i = 0; i < dt.Columns.Count; i++)
          //  {
                // Console.WriteLine("X: "+dt.Columns[i].ColumnName.ToString());
         //   }

            //Console.WriteLine("TEST: " + dt.Columns[10].ColumnName.ToString() + " " + dt.Columns[0].ColumnName.ToString());

        }

        private void updateCSVDataTable()
        {
            int levelNum;
            DataTable dt = new DataTable();
            dt = (DataTable)(dgvCSVUpload.DataSource as System.Data.DataTable).DefaultView.ToTable();
            dt.Columns.Add("userName", typeof(string));
            dt.Columns.Add("managerName", typeof(string));
            dt.Columns.Add("chainOfCommand", typeof(string));
            dt.Columns.Add("headDistance", typeof(string));
            dt.Columns.Add("userId", typeof(string));
            dt.Columns.Add("department", typeof(string));

            dt.Columns.Add("level0", typeof(string));
            dt.Columns.Add("level1", typeof(string));
            dt.Columns.Add("level2", typeof(string));
            dt.Columns.Add("level3", typeof(string));
            dt.Columns.Add("level4", typeof(string));
            dt.Columns.Add("level5", typeof(string));
            dt.Columns.Add("level6", typeof(string));
            dt.Columns.Add("level7", typeof(string));
            dt.Columns.Add("level8", typeof(string));
            dt.Columns.Add("level9", typeof(string));
            dt.Columns.Add("level10", typeof(string));
            //dt.Columns.Add("NewColumn", type(System.Int32));

            string emailAddr = "";

            /*  dgvCSVUpload.Columns.Add("userName", "userName");
             dgvCSVUpload.Columns.Add("managerName", "managerName");
             dgvCSVUpload.Columns.Add("chainOfCommand", "chainOfCommand");
             dgvCSVUpload.Columns.Add("headDistance", "headDistance");
             dgvCSVUpload.Columns.Add("userId", "userId");
             dgvCSVUpload.Columns.Add("department", "department"); */

            //DataGridView1.DataSource.EndEdit() does.
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                emailAddr = dgvCSVUpload.Rows[i].Cells["EMail"].Value.ToString();
                readActiveDirectoryByEmail(emailAddr);
                levelNum = 0;

                foreach (string element in myHierarchyListCSV) // populate level0-10 fields
                {
                    dt.Rows[i]["level" + levelNum] = element;
                    // Console.WriteLine("level" + levelNum + " " + dt.Rows[i]["level" + levelNum].ToString());
                    levelNum++;
                }

                /*  dgvCSVUpload.Rows[i].Cells["chainOfCommand"].Value = chainOfCommandCSV;
                  dgvCSVUpload.Rows[i].Cells["managerName"].Value = myManagerName;
                  dgvCSVUpload.Rows[i].Cells["userName"].Value = myFullName;
                  dgvCSVUpload.Rows[i].Cells["headDistance"].Value = myDistanceToHead;
                  dgvCSVUpload.Rows[i].Cells["userId"].Value = myUserId;
                  dgvCSVUpload.Rows[i].Cells["department"].Value = myDepartment; */

                dt.Rows[i]["chainOfCommand"] = chainOfCommandCSV;
                dt.Rows[i]["managerName"] = myManagerName;
                dt.Rows[i]["userName"] = myFullName;
                dt.Rows[i]["headDistance"] = myDistanceToHead;
                dt.Rows[i]["userId"] = myUserId;
                dt.Rows[i]["department"] = myDepartment;
            }

            dgvCSVUpload.DataSource = dt;
            // readActiveDirectoryByEmail(emailAddr);
        }



        private void displaySelectedFields()
        {

        }

        private void chkBoxFieldList_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 0; i < chkBoxFieldList.Items.Count; i++)
            {

                if (chkBoxFieldList.GetItemCheckState(i) != CheckState.Checked)
                {
                    gvImprovements.Columns[i].Visible = false;
                }
                else
                {
                    gvImprovements.Columns[i].Visible = true;
                }
            }
        }



        private void hideUnhideFieldFilter()
        {
            if (!fieldFilterApplied) // unhide the checklist
            {
                btnShowCheckBox.Text = "Hide field filter ↑";
                chkBoxFieldList.Visible = true;
                fieldFilterApplied = true;
            }

            else // hide the checklist
            {
                btnShowCheckBox.Text = "Show field filter ↓";
                chkBoxFieldList.Visible = false;
                fieldFilterApplied = false;
                displaySelectedFields();
            }
        }


        private void chkBoxFieldList_MouseLeave(object sender, EventArgs e)
        {
            hideUnhideFieldFilter();
        }

        private void btnShowCheckBox_MouseHover(object sender, EventArgs e)
        {
            hideUnhideFieldFilter();
        }

        private void btnFilterETLDates_Click(object sender, EventArgs e)
        {
            DateTime exportFrom = calExportFrom.Value;
            DateTime exportTo = calExportTo.Value;
            string exportDateFilter = string.Format("[Timestamp] >='{0}' AND [Timestamp] <='{1}' ", exportFrom, exportTo);

            (dgvCSVUpload.DataSource as System.Data.DataTable).DefaultView.RowFilter = exportDateFilter;
        }

        private void btnSaveFieldMapping_Click(object sender, EventArgs e)
        {
            deleteDatabaseTable("lssFieldMapping");
            InsertDataIntoSQLServerUsingSQLBulkCopy(ref dgvFieldMapping, "lssFieldMapping");
        }

        private void deleteDatabaseTable(string tableName)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("clearTable", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@tableName", tableName);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        private void callDomainList()
        {                 
        
            myDomailList = new LinkedList<string>(domains);
            myHierarchy = new string[11];


            string userId = "190475443"; // Keith
            // string userId = Environment.UserName.ToString();
            emplNum = Environment.UserName.ToString();
            //emplNum = "190475443";
            emplNum = "190475443";
            myDomailList = new LinkedList<string>(domains);


           
            string account = userId;//userId;
            //string mgrName = "";

            //DirectoryEntry entry = new DirectoryEntry();
            SearchResult result = null;
            myHierarchyList = new LinkedList<string>(); // initialize list to store hierarchies
            foreach (string element in myDomailList)
            {
                DirectoryEntry entry = new DirectoryEntry("LDAP://" + element);
                DirectorySearcher search = new DirectorySearcher(entry);

                // specify the search filter
                search.Filter = "(&(objectClass=user)(anr=" + account + "))";
                // specify which property values to return in the search               
               
                //search.PropertiesToLoad.Add("userprincipalname");
                search.PropertiesToLoad.Add("distinguishedname");
                // search.PropertiesToLoad.Add("samaccountname");
                // perform the search         
                result = search.FindOne();
                //MessageBox.Show(result.Properties["distinguishedname"][0].ToString());

                if (result == null) // == null)
                {
                    if (element == "gem") //exception when all domains are checked and noresult has been returned
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    myPrincipalName = result.Properties["distinguishedname"][0].ToString();
                    MessageBox.Show(myPrincipalName);
                    break;
                }
            }

            // hierarchy list has to be populated for all 11 poistions if there are less than 10 elements, then fill those elements with "null"
           
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            var currentForest = System.DirectoryServices.ActiveDirectory.Forest.GetCurrentForest();
            var gc = currentForest.FindGlobalCatalog();
            string emplNum = "19047";
            using (var userSearcher = gc.GetDirectorySearcher())
            {
                userSearcher.Filter = "(&(objectClass=user)(anr=" + emplNum + "))";
                SearchResult result = userSearcher.FindOne();
                userSearcher.PropertiesToLoad.Add("distinguishedname");

                if (result != null) // == null)
                {
                    Console.WriteLine(result.Properties["distinguishedname"][0].ToString());
                }
                else
                    Console.WriteLine("null");
            }


           // var domains = System.DirectoryServices.ActiveDirectory.Forest.GetCurrentForest().Domains.Cast<System.DirectoryServices.ActiveDirectory.Domain>();
           // foreach (var domain in domains)
          //  {
           //     Console.WriteLine(domain.Name);
          //  }
          //  callDomainList();
        }

        private void gvImprovements_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

