﻿namespace WindowsFormsApplication14
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.gvImprovements = new System.Windows.Forms.DataGridView();
            this.calFrom = new System.Windows.Forms.DateTimePicker();
            this.calTo = new System.Windows.Forms.DateTimePicker();
            this.txtSearchKeyword = new System.Windows.Forms.TextBox();
            this.cmbFieldFilter = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbAfter = new System.Windows.Forms.RadioButton();
            this.rbBefore = new System.Windows.Forms.RadioButton();
            this.rbBetween = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbpgMain = new System.Windows.Forms.TabControl();
            this.tbpgData = new System.Windows.Forms.TabPage();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lbDgvRecordCount = new System.Windows.Forms.ToolStripStatusLabel();
            this.btnShowCheckBox = new System.Windows.Forms.Button();
            this.chkBoxFieldList = new System.Windows.Forms.CheckedListBox();
            this.btnClearFilter = new System.Windows.Forms.Button();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.txtGivenName = new System.Windows.Forms.TextBox();
            this.txtUserDepartment = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtManagerName = new System.Windows.Forms.TextBox();
            this.tbpgMetrics = new System.Windows.Forms.TabPage();
            this.lstDrillDownOn = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnDrillup = new System.Windows.Forms.Button();
            this.btnDrilldown = new System.Windows.Forms.Button();
            this.lstTeam = new System.Windows.Forms.ListBox();
            this.lstImprovementType = new System.Windows.Forms.ListBox();
            this.chartSeries = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartContributor = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartTeams = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartImprovementType = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tbpgAdmin = new System.Windows.Forms.TabPage();
            this.btnSaveFieldMapping = new System.Windows.Forms.Button();
            this.btnFilterETLDates = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.calExportTo = new System.Windows.Forms.DateTimePicker();
            this.calExportFrom = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.dgvRefreshLog = new System.Windows.Forms.DataGridView();
            this.label11 = new System.Windows.Forms.Label();
            this.dgvFieldMapping = new System.Windows.Forms.DataGridView();
            this.tbnPrepareData = new System.Windows.Forms.Button();
            this.btnExportToSqlServer = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.dgvCSVUpload = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCSVFilePath = new System.Windows.Forms.TextBox();
            this.btnLoad = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvReferenceData = new System.Windows.Forms.DataGridView();
            this.dgvVersionControl = new System.Windows.Forms.DataGridView();
            this.dgvSuperuserList = new System.Windows.Forms.DataGridView();
            this.lsstrackerDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lSSTrackerDataSet = new WindowsFormsApplication14.LSSTrackerDataSet();
            this.lsstrackerDataTableAdapter = new WindowsFormsApplication14.LSSTrackerDataSetTableAdapters.lsstrackerDataTableAdapter();
            this.tableAdapterManager = new WindowsFormsApplication14.LSSTrackerDataSetTableAdapters.TableAdapterManager();
            this.lssTrackerDataSet1 = new WindowsFormsApplication14.LSSTrackerDataSet();
            this.lSSTrackerDataSet11 = new WindowsFormsApplication14.LSSTrackerDataSet1();
            this.lssReferenceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lssReferenceTableAdapter = new WindowsFormsApplication14.LSSTrackerDataSet1TableAdapters.lssReferenceTableAdapter();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactSupportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createCurrentMomthReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createReportForSelectedDatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.txtToolstringRefreshStatus = new System.Windows.Forms.ToolStripTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.gvImprovements)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tbpgMain.SuspendLayout();
            this.tbpgData.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tbpgMetrics.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartSeries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartContributor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTeams)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartImprovementType)).BeginInit();
            this.tbpgAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRefreshLog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFieldMapping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCSVUpload)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReferenceData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVersionControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuperuserList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsstrackerDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssTrackerDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssReferenceBindingSource)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gvImprovements
            // 
            this.gvImprovements.AllowUserToAddRows = false;
            this.gvImprovements.AllowUserToDeleteRows = false;
            this.gvImprovements.AllowUserToOrderColumns = true;
            this.gvImprovements.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gvImprovements.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gvImprovements.BackgroundColor = System.Drawing.Color.AntiqueWhite;
            this.gvImprovements.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.gvImprovements.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedHorizontal;
            this.gvImprovements.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvImprovements.GridColor = System.Drawing.Color.OrangeRed;
            this.gvImprovements.Location = new System.Drawing.Point(6, 136);
            this.gvImprovements.Name = "gvImprovements";
            this.gvImprovements.ReadOnly = true;
            this.gvImprovements.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.gvImprovements.RowHeadersWidth = 50;
            this.gvImprovements.RowTemplate.Height = 24;
            this.gvImprovements.Size = new System.Drawing.Size(1569, 633);
            this.gvImprovements.TabIndex = 0;
            this.gvImprovements.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvImprovements_CellClick);
            this.gvImprovements.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvImprovements_CellContentClick);
            // 
            // calFrom
            // 
            this.calFrom.Location = new System.Drawing.Point(66, 29);
            this.calFrom.Name = "calFrom";
            this.calFrom.Size = new System.Drawing.Size(200, 22);
            this.calFrom.TabIndex = 1;
            this.calFrom.ValueChanged += new System.EventHandler(this.calFrom_ValueChanged);
            // 
            // calTo
            // 
            this.calTo.Location = new System.Drawing.Point(66, 55);
            this.calTo.Name = "calTo";
            this.calTo.Size = new System.Drawing.Size(200, 22);
            this.calTo.TabIndex = 2;
            this.calTo.ValueChanged += new System.EventHandler(this.calTo_ValueChanged);
            // 
            // txtSearchKeyword
            // 
            this.txtSearchKeyword.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSearchKeyword.Location = new System.Drawing.Point(296, 73);
            this.txtSearchKeyword.Name = "txtSearchKeyword";
            this.txtSearchKeyword.Size = new System.Drawing.Size(1276, 22);
            this.txtSearchKeyword.TabIndex = 3;
            this.txtSearchKeyword.TextChanged += new System.EventHandler(this.txtSearchKeyword_TextChanged);
            // 
            // cmbFieldFilter
            // 
            this.cmbFieldFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFieldFilter.FormattingEnabled = true;
            this.cmbFieldFilter.Location = new System.Drawing.Point(296, 26);
            this.cmbFieldFilter.Name = "cmbFieldFilter";
            this.cmbFieldFilter.Size = new System.Drawing.Size(393, 24);
            this.cmbFieldFilter.TabIndex = 4;
            this.cmbFieldFilter.SelectionChangeCommitted += new System.EventHandler(this.cmbFieldFilter_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(296, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Field to search in";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(296, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Keywords to search";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbAfter);
            this.groupBox1.Controls.Add(this.rbBefore);
            this.groupBox1.Controls.Add(this.rbBetween);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.calFrom);
            this.groupBox1.Controls.Add(this.calTo);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(284, 124);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Date range filter";
            // 
            // rbAfter
            // 
            this.rbAfter.AutoSize = true;
            this.rbAfter.Location = new System.Drawing.Point(182, 83);
            this.rbAfter.Name = "rbAfter";
            this.rbAfter.Size = new System.Drawing.Size(59, 21);
            this.rbAfter.TabIndex = 7;
            this.rbAfter.Text = "After";
            this.rbAfter.UseVisualStyleBackColor = true;
            this.rbAfter.CheckedChanged += new System.EventHandler(this.rbAfter_CheckedChanged);
            // 
            // rbBefore
            // 
            this.rbBefore.AutoSize = true;
            this.rbBefore.Location = new System.Drawing.Point(93, 83);
            this.rbBefore.Name = "rbBefore";
            this.rbBefore.Size = new System.Drawing.Size(71, 21);
            this.rbBefore.TabIndex = 6;
            this.rbBefore.Text = "Before";
            this.rbBefore.UseVisualStyleBackColor = true;
            this.rbBefore.CheckedChanged += new System.EventHandler(this.rbBefore_CheckedChanged);
            // 
            // rbBetween
            // 
            this.rbBetween.AutoSize = true;
            this.rbBetween.Checked = true;
            this.rbBetween.Location = new System.Drawing.Point(4, 83);
            this.rbBetween.Name = "rbBetween";
            this.rbBetween.Size = new System.Drawing.Size(83, 21);
            this.rbBetween.TabIndex = 5;
            this.rbBetween.TabStop = true;
            this.rbBetween.Text = "Between";
            this.rbBetween.UseVisualStyleBackColor = true;
            this.rbBetween.CheckedChanged += new System.EventHandler(this.rbBetween_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "To:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "From:";
            // 
            // tbpgMain
            // 
            this.tbpgMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbpgMain.Controls.Add(this.tbpgData);
            this.tbpgMain.Controls.Add(this.tbpgMetrics);
            this.tbpgMain.Controls.Add(this.tbpgAdmin);
            this.tbpgMain.Location = new System.Drawing.Point(-1, 27);
            this.tbpgMain.Name = "tbpgMain";
            this.tbpgMain.SelectedIndex = 0;
            this.tbpgMain.Size = new System.Drawing.Size(1591, 835);
            this.tbpgMain.TabIndex = 8;
            // 
            // tbpgData
            // 
            this.tbpgData.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tbpgData.Controls.Add(this.statusStrip1);
            this.tbpgData.Controls.Add(this.btnShowCheckBox);
            this.tbpgData.Controls.Add(this.chkBoxFieldList);
            this.tbpgData.Controls.Add(this.btnClearFilter);
            this.tbpgData.Controls.Add(this.txtUserID);
            this.tbpgData.Controls.Add(this.txtGivenName);
            this.tbpgData.Controls.Add(this.txtUserDepartment);
            this.tbpgData.Controls.Add(this.txtEmail);
            this.tbpgData.Controls.Add(this.txtManagerName);
            this.tbpgData.Controls.Add(this.groupBox1);
            this.tbpgData.Controls.Add(this.label1);
            this.tbpgData.Controls.Add(this.label2);
            this.tbpgData.Controls.Add(this.gvImprovements);
            this.tbpgData.Controls.Add(this.cmbFieldFilter);
            this.tbpgData.Controls.Add(this.txtSearchKeyword);
            this.tbpgData.Location = new System.Drawing.Point(4, 25);
            this.tbpgData.Name = "tbpgData";
            this.tbpgData.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgData.Size = new System.Drawing.Size(1583, 806);
            this.tbpgData.TabIndex = 0;
            this.tbpgData.Text = "Data";
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lbDgvRecordCount});
            this.statusStrip1.Location = new System.Drawing.Point(3, 778);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1577, 25);
            this.statusStrip1.TabIndex = 16;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lbDgvRecordCount
            // 
            this.lbDgvRecordCount.BackColor = System.Drawing.Color.Transparent;
            this.lbDgvRecordCount.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDgvRecordCount.Name = "lbDgvRecordCount";
            this.lbDgvRecordCount.Size = new System.Drawing.Size(151, 20);
            this.lbDgvRecordCount.Text = "toolStripStatusLabel1";
            // 
            // btnShowCheckBox
            // 
            this.btnShowCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnShowCheckBox.Cursor = System.Windows.Forms.Cursors.PanSouth;
            this.btnShowCheckBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowCheckBox.ForeColor = System.Drawing.Color.Red;
            this.btnShowCheckBox.Location = new System.Drawing.Point(1261, 96);
            this.btnShowCheckBox.Name = "btnShowCheckBox";
            this.btnShowCheckBox.Size = new System.Drawing.Size(311, 34);
            this.btnShowCheckBox.TabIndex = 15;
            this.btnShowCheckBox.Text = "Show field filter ↓";
            this.btnShowCheckBox.UseVisualStyleBackColor = true;
            this.btnShowCheckBox.MouseHover += new System.EventHandler(this.btnShowCheckBox_MouseHover);
            // 
            // chkBoxFieldList
            // 
            this.chkBoxFieldList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chkBoxFieldList.BackColor = System.Drawing.Color.AntiqueWhite;
            this.chkBoxFieldList.CheckOnClick = true;
            this.chkBoxFieldList.FormattingEnabled = true;
            this.chkBoxFieldList.Location = new System.Drawing.Point(1261, 136);
            this.chkBoxFieldList.Name = "chkBoxFieldList";
            this.chkBoxFieldList.Size = new System.Drawing.Size(311, 633);
            this.chkBoxFieldList.TabIndex = 14;
            this.chkBoxFieldList.SelectedIndexChanged += new System.EventHandler(this.chkBoxFieldList_SelectedIndexChanged);
            this.chkBoxFieldList.MouseLeave += new System.EventHandler(this.chkBoxFieldList_MouseLeave);
            // 
            // btnClearFilter
            // 
            this.btnClearFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearFilter.ForeColor = System.Drawing.Color.Red;
            this.btnClearFilter.Location = new System.Drawing.Point(296, 101);
            this.btnClearFilter.Name = "btnClearFilter";
            this.btnClearFilter.Size = new System.Drawing.Size(102, 29);
            this.btnClearFilter.TabIndex = 13;
            this.btnClearFilter.Text = "Clear filter ☓";
            this.btnClearFilter.UseVisualStyleBackColor = true;
            this.btnClearFilter.Click += new System.EventHandler(this.btnClearFilter_Click);
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(1243, 7);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(100, 22);
            this.txtUserID.TabIndex = 12;
            this.txtUserID.Visible = false;
            // 
            // txtGivenName
            // 
            this.txtGivenName.Location = new System.Drawing.Point(1062, 39);
            this.txtGivenName.Name = "txtGivenName";
            this.txtGivenName.Size = new System.Drawing.Size(174, 22);
            this.txtGivenName.TabIndex = 11;
            this.txtGivenName.Visible = false;
            // 
            // txtUserDepartment
            // 
            this.txtUserDepartment.Location = new System.Drawing.Point(1062, 7);
            this.txtUserDepartment.Name = "txtUserDepartment";
            this.txtUserDepartment.Size = new System.Drawing.Size(174, 22);
            this.txtUserDepartment.TabIndex = 10;
            this.txtUserDepartment.Visible = false;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(897, 34);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(158, 22);
            this.txtEmail.TabIndex = 9;
            this.txtEmail.Visible = false;
            // 
            // txtManagerName
            // 
            this.txtManagerName.Location = new System.Drawing.Point(897, 6);
            this.txtManagerName.Name = "txtManagerName";
            this.txtManagerName.Size = new System.Drawing.Size(158, 22);
            this.txtManagerName.TabIndex = 8;
            this.txtManagerName.Visible = false;
            // 
            // tbpgMetrics
            // 
            this.tbpgMetrics.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tbpgMetrics.Controls.Add(this.lstDrillDownOn);
            this.tbpgMetrics.Controls.Add(this.button1);
            this.tbpgMetrics.Controls.Add(this.label6);
            this.tbpgMetrics.Controls.Add(this.label5);
            this.tbpgMetrics.Controls.Add(this.btnDrillup);
            this.tbpgMetrics.Controls.Add(this.btnDrilldown);
            this.tbpgMetrics.Controls.Add(this.lstTeam);
            this.tbpgMetrics.Controls.Add(this.lstImprovementType);
            this.tbpgMetrics.Controls.Add(this.chartSeries);
            this.tbpgMetrics.Controls.Add(this.chartContributor);
            this.tbpgMetrics.Controls.Add(this.chartTeams);
            this.tbpgMetrics.Controls.Add(this.chartImprovementType);
            this.tbpgMetrics.Location = new System.Drawing.Point(4, 25);
            this.tbpgMetrics.Name = "tbpgMetrics";
            this.tbpgMetrics.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgMetrics.Size = new System.Drawing.Size(1583, 806);
            this.tbpgMetrics.TabIndex = 1;
            this.tbpgMetrics.Text = "Metrics";
            // 
            // lstDrillDownOn
            // 
            this.lstDrillDownOn.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstDrillDownOn.FormattingEnabled = true;
            this.lstDrillDownOn.ItemHeight = 16;
            this.lstDrillDownOn.Location = new System.Drawing.Point(12, 568);
            this.lstDrillDownOn.Name = "lstDrillDownOn";
            this.lstDrillDownOn.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstDrillDownOn.Size = new System.Drawing.Size(258, 116);
            this.lstDrillDownOn.TabIndex = 13;
            this.lstDrillDownOn.Visible = false;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(12, 699);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(258, 36);
            this.button1.TabIndex = 12;
            this.button1.Text = " Refresh ↻";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "Select one or more team(s):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(261, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Select one or more improvement type(s)";
            // 
            // btnDrillup
            // 
            this.btnDrillup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDrillup.Cursor = System.Windows.Forms.Cursors.PanNorth;
            this.btnDrillup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDrillup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDrillup.ForeColor = System.Drawing.Color.Red;
            this.btnDrillup.Location = new System.Drawing.Point(137, 741);
            this.btnDrillup.Name = "btnDrillup";
            this.btnDrillup.Size = new System.Drawing.Size(133, 36);
            this.btnDrillup.TabIndex = 7;
            this.btnDrillup.Text = "Drill up ↑";
            this.btnDrillup.UseVisualStyleBackColor = true;
            this.btnDrillup.Click += new System.EventHandler(this.btnDrillup_Click);
            // 
            // btnDrilldown
            // 
            this.btnDrilldown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnDrilldown.Cursor = System.Windows.Forms.Cursors.PanSouth;
            this.btnDrilldown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDrilldown.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDrilldown.ForeColor = System.Drawing.Color.Red;
            this.btnDrilldown.Location = new System.Drawing.Point(9, 741);
            this.btnDrilldown.Name = "btnDrilldown";
            this.btnDrilldown.Size = new System.Drawing.Size(121, 36);
            this.btnDrilldown.TabIndex = 6;
            this.btnDrilldown.Text = "Drill down ↓";
            this.btnDrilldown.UseVisualStyleBackColor = true;
            this.btnDrilldown.Click += new System.EventHandler(this.btnDrilldown_Click);
            // 
            // lstTeam
            // 
            this.lstTeam.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstTeam.FormattingEnabled = true;
            this.lstTeam.ItemHeight = 16;
            this.lstTeam.Items.AddRange(new object[] {
            "HR & CWM",
            "Reporting & Production",
            "BI",
            "RPA/RDA",
            "RM"});
            this.lstTeam.Location = new System.Drawing.Point(10, 35);
            this.lstTeam.Name = "lstTeam";
            this.lstTeam.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstTeam.Size = new System.Drawing.Size(260, 228);
            this.lstTeam.TabIndex = 5;
            // 
            // lstImprovementType
            // 
            this.lstImprovementType.BackColor = System.Drawing.Color.NavajoWhite;
            this.lstImprovementType.FormattingEnabled = true;
            this.lstImprovementType.ItemHeight = 16;
            this.lstImprovementType.Items.AddRange(new object[] {
            "Automation",
            "Process Discontinuation",
            "Process documentation",
            "Documentation Improvement"});
            this.lstImprovementType.Location = new System.Drawing.Point(12, 286);
            this.lstImprovementType.Name = "lstImprovementType";
            this.lstImprovementType.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lstImprovementType.Size = new System.Drawing.Size(258, 276);
            this.lstImprovementType.TabIndex = 4;
            // 
            // chartSeries
            // 
            this.chartSeries.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartSeries.BackColor = System.Drawing.Color.Transparent;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.BackColor = System.Drawing.Color.Transparent;
            chartArea1.BorderColor = System.Drawing.Color.Transparent;
            chartArea1.Name = "ChartArea1";
            this.chartSeries.ChartAreas.Add(chartArea1);
            legend1.BackColor = System.Drawing.Color.Transparent;
            legend1.Name = "Legend1";
            this.chartSeries.Legends.Add(legend1);
            this.chartSeries.Location = new System.Drawing.Point(318, 411);
            this.chartSeries.Name = "chartSeries";
            this.chartSeries.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartSeries.Series.Add(series1);
            this.chartSeries.Size = new System.Drawing.Size(1280, 381);
            this.chartSeries.TabIndex = 3;
            this.chartSeries.Text = "chart4";
            title1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            title1.Name = "Title1";
            title1.Text = "Number of process improvement instances";
            this.chartSeries.Titles.Add(title1);
            // 
            // chartContributor
            // 
            this.chartContributor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chartContributor.BackColor = System.Drawing.Color.Transparent;
            chartArea2.BackColor = System.Drawing.Color.Transparent;
            chartArea2.BorderColor = System.Drawing.Color.Transparent;
            chartArea2.Name = "ChartArea1";
            this.chartContributor.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartContributor.Legends.Add(legend2);
            this.chartContributor.Location = new System.Drawing.Point(1182, 25);
            this.chartContributor.Name = "chartContributor";
            this.chartContributor.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series2.ChartArea = "ChartArea1";
            series2.IsVisibleInLegend = false;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chartContributor.Series.Add(series2);
            this.chartContributor.Size = new System.Drawing.Size(382, 335);
            this.chartContributor.TabIndex = 2;
            this.chartContributor.Text = "Team";
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title2.Name = "Team";
            title2.Text = "Team";
            this.chartContributor.Titles.Add(title2);
            // 
            // chartTeams
            // 
            this.chartTeams.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chartTeams.BackColor = System.Drawing.Color.Transparent;
            chartArea3.BackColor = System.Drawing.Color.Transparent;
            chartArea3.BorderColor = System.Drawing.Color.Transparent;
            chartArea3.Name = "ChartArea1";
            this.chartTeams.ChartAreas.Add(chartArea3);
            legend3.Alignment = System.Drawing.StringAlignment.Center;
            legend3.BackColor = System.Drawing.Color.Transparent;
            legend3.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Bottom;
            legend3.Name = "Legend1";
            this.chartTeams.Legends.Add(legend3);
            this.chartTeams.Location = new System.Drawing.Point(710, 25);
            this.chartTeams.Name = "chartTeams";
            this.chartTeams.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SemiTransparent;
            series3.ChartArea = "ChartArea1";
            series3.CustomProperties = "LabelStyle=Bottom";
            series3.IsValueShownAsLabel = true;
            series3.IsXValueIndexed = true;
            series3.Legend = "Legend1";
            series3.LegendText = "#VALX";
            series3.LegendToolTip = "#VALX";
            series3.Name = "Series1";
            series3.YAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Secondary;
            this.chartTeams.Series.Add(series3);
            this.chartTeams.Size = new System.Drawing.Size(456, 335);
            this.chartTeams.TabIndex = 1;
            this.chartTeams.Text = "chart2";
            title3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title3.Name = "Title1";
            title3.Text = "Type of saving";
            this.chartTeams.Titles.Add(title3);
            // 
            // chartImprovementType
            // 
            this.chartImprovementType.BackColor = System.Drawing.Color.Transparent;
            chartArea4.BackColor = System.Drawing.Color.Transparent;
            chartArea4.BorderColor = System.Drawing.Color.Transparent;
            chartArea4.Name = "ChartArea1";
            this.chartImprovementType.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.chartImprovementType.Legends.Add(legend4);
            this.chartImprovementType.Location = new System.Drawing.Point(318, 25);
            this.chartImprovementType.Name = "chartImprovementType";
            this.chartImprovementType.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.SeaGreen;
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.chartImprovementType.Series.Add(series4);
            this.chartImprovementType.Size = new System.Drawing.Size(362, 335);
            this.chartImprovementType.TabIndex = 0;
            this.chartImprovementType.Text = "Improvement Type";
            title4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title4.Name = "Type of benefit";
            title4.Text = "Type of benefit";
            this.chartImprovementType.Titles.Add(title4);
            // 
            // tbpgAdmin
            // 
            this.tbpgAdmin.Controls.Add(this.btnSaveFieldMapping);
            this.tbpgAdmin.Controls.Add(this.btnFilterETLDates);
            this.tbpgAdmin.Controls.Add(this.label15);
            this.tbpgAdmin.Controls.Add(this.label14);
            this.tbpgAdmin.Controls.Add(this.calExportTo);
            this.tbpgAdmin.Controls.Add(this.calExportFrom);
            this.tbpgAdmin.Controls.Add(this.label12);
            this.tbpgAdmin.Controls.Add(this.dgvRefreshLog);
            this.tbpgAdmin.Controls.Add(this.label11);
            this.tbpgAdmin.Controls.Add(this.dgvFieldMapping);
            this.tbpgAdmin.Controls.Add(this.tbnPrepareData);
            this.tbpgAdmin.Controls.Add(this.btnExportToSqlServer);
            this.tbpgAdmin.Controls.Add(this.btnBrowse);
            this.tbpgAdmin.Controls.Add(this.dgvCSVUpload);
            this.tbpgAdmin.Controls.Add(this.label10);
            this.tbpgAdmin.Controls.Add(this.txtCSVFilePath);
            this.tbpgAdmin.Controls.Add(this.btnLoad);
            this.tbpgAdmin.Controls.Add(this.label9);
            this.tbpgAdmin.Controls.Add(this.label8);
            this.tbpgAdmin.Controls.Add(this.label7);
            this.tbpgAdmin.Controls.Add(this.dgvReferenceData);
            this.tbpgAdmin.Controls.Add(this.dgvVersionControl);
            this.tbpgAdmin.Controls.Add(this.dgvSuperuserList);
            this.tbpgAdmin.Location = new System.Drawing.Point(4, 25);
            this.tbpgAdmin.Name = "tbpgAdmin";
            this.tbpgAdmin.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgAdmin.Size = new System.Drawing.Size(1583, 806);
            this.tbpgAdmin.TabIndex = 2;
            this.tbpgAdmin.Text = "Admin";
            this.tbpgAdmin.UseVisualStyleBackColor = true;
            this.tbpgAdmin.Enter += new System.EventHandler(this.tbpgAdmin_Enter);
            // 
            // btnSaveFieldMapping
            // 
            this.btnSaveFieldMapping.Location = new System.Drawing.Point(28, 761);
            this.btnSaveFieldMapping.Name = "btnSaveFieldMapping";
            this.btnSaveFieldMapping.Size = new System.Drawing.Size(123, 38);
            this.btnSaveFieldMapping.TabIndex = 22;
            this.btnSaveFieldMapping.Text = "Save Mapping";
            this.btnSaveFieldMapping.UseVisualStyleBackColor = true;
            this.btnSaveFieldMapping.Click += new System.EventHandler(this.btnSaveFieldMapping_Click);
            // 
            // btnFilterETLDates
            // 
            this.btnFilterETLDates.Location = new System.Drawing.Point(1171, 74);
            this.btnFilterETLDates.Name = "btnFilterETLDates";
            this.btnFilterETLDates.Size = new System.Drawing.Size(86, 27);
            this.btnFilterETLDates.TabIndex = 21;
            this.btnFilterETLDates.Text = "Filter";
            this.btnFilterETLDates.UseVisualStyleBackColor = true;
            this.btnFilterETLDates.Click += new System.EventHandler(this.btnFilterETLDates_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(856, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 17);
            this.label15.TabIndex = 20;
            this.label15.Text = "Entered to";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(505, 84);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(90, 17);
            this.label14.TabIndex = 19;
            this.label14.Text = "Entered from";
            // 
            // calExportTo
            // 
            this.calExportTo.Location = new System.Drawing.Point(936, 78);
            this.calExportTo.Name = "calExportTo";
            this.calExportTo.Size = new System.Drawing.Size(228, 22);
            this.calExportTo.TabIndex = 18;
            // 
            // calExportFrom
            // 
            this.calExportFrom.Location = new System.Drawing.Point(601, 79);
            this.calExportFrom.Name = "calExportFrom";
            this.calExportFrom.Size = new System.Drawing.Size(236, 22);
            this.calExportFrom.TabIndex = 17;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(929, 383);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 17);
            this.label12.TabIndex = 16;
            this.label12.Text = "Database refresh log";
            // 
            // dgvRefreshLog
            // 
            this.dgvRefreshLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRefreshLog.Location = new System.Drawing.Point(932, 403);
            this.dgvRefreshLog.Name = "dgvRefreshLog";
            this.dgvRefreshLog.RowTemplate.Height = 24;
            this.dgvRefreshLog.Size = new System.Drawing.Size(232, 171);
            this.dgvRefreshLog.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(25, 383);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(182, 17);
            this.label11.TabIndex = 14;
            this.label11.Text = "Field mapping for Database";
            // 
            // dgvFieldMapping
            // 
            this.dgvFieldMapping.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFieldMapping.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFieldMapping.Location = new System.Drawing.Point(28, 403);
            this.dgvFieldMapping.Name = "dgvFieldMapping";
            this.dgvFieldMapping.RowTemplate.Height = 24;
            this.dgvFieldMapping.Size = new System.Drawing.Size(667, 352);
            this.dgvFieldMapping.TabIndex = 13;
            // 
            // tbnPrepareData
            // 
            this.tbnPrepareData.Location = new System.Drawing.Point(165, 73);
            this.tbnPrepareData.Name = "tbnPrepareData";
            this.tbnPrepareData.Size = new System.Drawing.Size(149, 28);
            this.tbnPrepareData.TabIndex = 12;
            this.tbnPrepareData.Text = "2. Prepare data";
            this.tbnPrepareData.UseVisualStyleBackColor = true;
            this.tbnPrepareData.Click += new System.EventHandler(this.tbnPrepareData_Click);
            // 
            // btnExportToSqlServer
            // 
            this.btnExportToSqlServer.Location = new System.Drawing.Point(320, 71);
            this.btnExportToSqlServer.Name = "btnExportToSqlServer";
            this.btnExportToSqlServer.Size = new System.Drawing.Size(143, 29);
            this.btnExportToSqlServer.TabIndex = 11;
            this.btnExportToSqlServer.Text = "3. Export to DB";
            this.btnExportToSqlServer.UseVisualStyleBackColor = true;
            this.btnExportToSqlServer.Click += new System.EventHandler(this.btnExportToSqlServer_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(1436, 43);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 10;
            this.btnBrowse.Text = "Find";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // dgvCSVUpload
            // 
            this.dgvCSVUpload.AllowUserToAddRows = false;
            this.dgvCSVUpload.AllowUserToDeleteRows = false;
            this.dgvCSVUpload.AllowUserToOrderColumns = true;
            this.dgvCSVUpload.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvCSVUpload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCSVUpload.Location = new System.Drawing.Point(28, 106);
            this.dgvCSVUpload.Name = "dgvCSVUpload";
            this.dgvCSVUpload.RowTemplate.Height = 24;
            this.dgvCSVUpload.Size = new System.Drawing.Size(1621, 274);
            this.dgvCSVUpload.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "Upload File";
            // 
            // txtCSVFilePath
            // 
            this.txtCSVFilePath.Location = new System.Drawing.Point(28, 43);
            this.txtCSVFilePath.Name = "txtCSVFilePath";
            this.txtCSVFilePath.Size = new System.Drawing.Size(1402, 22);
            this.txtCSVFilePath.TabIndex = 7;
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(28, 71);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(131, 29);
            this.btnLoad.TabIndex = 6;
            this.btnLoad.Text = "1. Preview data";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.button2_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1168, 383);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "Reference data";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(698, 383);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 17);
            this.label8.TabIndex = 4;
            this.label8.Text = "Version control";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(701, 577);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "List of superusers";
            // 
            // dgvReferenceData
            // 
            this.dgvReferenceData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReferenceData.Location = new System.Drawing.Point(1171, 403);
            this.dgvReferenceData.Name = "dgvReferenceData";
            this.dgvReferenceData.RowTemplate.Height = 24;
            this.dgvReferenceData.Size = new System.Drawing.Size(478, 409);
            this.dgvReferenceData.TabIndex = 2;
            // 
            // dgvVersionControl
            // 
            this.dgvVersionControl.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVersionControl.Location = new System.Drawing.Point(701, 403);
            this.dgvVersionControl.Name = "dgvVersionControl";
            this.dgvVersionControl.RowTemplate.Height = 24;
            this.dgvVersionControl.Size = new System.Drawing.Size(225, 171);
            this.dgvVersionControl.TabIndex = 1;
            // 
            // dgvSuperuserList
            // 
            this.dgvSuperuserList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSuperuserList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSuperuserList.Location = new System.Drawing.Point(701, 597);
            this.dgvSuperuserList.Name = "dgvSuperuserList";
            this.dgvSuperuserList.RowTemplate.Height = 24;
            this.dgvSuperuserList.Size = new System.Drawing.Size(463, 216);
            this.dgvSuperuserList.TabIndex = 0;
            // 
            // lsstrackerDataBindingSource
            // 
            this.lsstrackerDataBindingSource.DataMember = "lsstrackerData";
            this.lsstrackerDataBindingSource.DataSource = this.lSSTrackerDataSet;
            // 
            // lSSTrackerDataSet
            // 
            this.lSSTrackerDataSet.DataSetName = "LSSTrackerDataSet";
            this.lSSTrackerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lsstrackerDataTableAdapter
            // 
            this.lsstrackerDataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.lsstrackerDataTableAdapter = this.lsstrackerDataTableAdapter;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApplication14.LSSTrackerDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // lssTrackerDataSet1
            // 
            this.lssTrackerDataSet1.DataSetName = "LSSTrackerDataSet";
            this.lssTrackerDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lSSTrackerDataSet11
            // 
            this.lSSTrackerDataSet11.DataSetName = "LSSTrackerDataSet1";
            this.lSSTrackerDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lssReferenceBindingSource
            // 
            this.lssReferenceBindingSource.DataMember = "lssReference";
            this.lssReferenceBindingSource.DataSource = this.lSSTrackerDataSet11;
            // 
            // lssReferenceTableAdapter
            // 
            this.lssReferenceTableAdapter.ClearBeforeFill = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 28);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1590, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.reportingToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1590, 28);
            this.menuStrip2.TabIndex = 10;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contactSupportToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // contactSupportToolStripMenuItem
            // 
            this.contactSupportToolStripMenuItem.Name = "contactSupportToolStripMenuItem";
            this.contactSupportToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.contactSupportToolStripMenuItem.Text = "Contact support";
            this.contactSupportToolStripMenuItem.Click += new System.EventHandler(this.contactSupportToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // reportingToolStripMenuItem
            // 
            this.reportingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createCurrentMomthReportToolStripMenuItem,
            this.createReportForSelectedDatesToolStripMenuItem});
            this.reportingToolStripMenuItem.Name = "reportingToolStripMenuItem";
            this.reportingToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
            this.reportingToolStripMenuItem.Text = "Reporting";
            // 
            // createCurrentMomthReportToolStripMenuItem
            // 
            this.createCurrentMomthReportToolStripMenuItem.Name = "createCurrentMomthReportToolStripMenuItem";
            this.createCurrentMomthReportToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.createCurrentMomthReportToolStripMenuItem.Text = "Create current month report";
            this.createCurrentMomthReportToolStripMenuItem.Click += new System.EventHandler(this.createCurrentMomthReportToolStripMenuItem_Click);
            // 
            // createReportForSelectedDatesToolStripMenuItem
            // 
            this.createReportForSelectedDatesToolStripMenuItem.Name = "createReportForSelectedDatesToolStripMenuItem";
            this.createReportForSelectedDatesToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.createReportForSelectedDatesToolStripMenuItem.Text = "Create report for selected dates";
            this.createReportForSelectedDatesToolStripMenuItem.Click += new System.EventHandler(this.createReportForSelectedDatesToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.txtToolstringRefreshStatus});
            this.toolStrip1.Location = new System.Drawing.Point(1249, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(302, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // txtToolstringRefreshStatus
            // 
            this.txtToolstringRefreshStatus.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.txtToolstringRefreshStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtToolstringRefreshStatus.Enabled = false;
            this.txtToolstringRefreshStatus.Name = "txtToolstringRefreshStatus";
            this.txtToolstringRefreshStatus.Size = new System.Drawing.Size(288, 25);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1590, 863);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tbpgMain);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "LSS Tracker";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvImprovements)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tbpgMain.ResumeLayout(false);
            this.tbpgData.ResumeLayout(false);
            this.tbpgData.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tbpgMetrics.ResumeLayout(false);
            this.tbpgMetrics.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartSeries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartContributor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartTeams)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartImprovementType)).EndInit();
            this.tbpgAdmin.ResumeLayout(false);
            this.tbpgAdmin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRefreshLog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFieldMapping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCSVUpload)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReferenceData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVersionControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSuperuserList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsstrackerDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssTrackerDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssReferenceBindingSource)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gvImprovements;
        private LSSTrackerDataSet lSSTrackerDataSet;
        private System.Windows.Forms.BindingSource lsstrackerDataBindingSource;
        private LSSTrackerDataSetTableAdapters.lsstrackerDataTableAdapter lsstrackerDataTableAdapter;
        private LSSTrackerDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DateTimePicker calFrom;
        private System.Windows.Forms.DateTimePicker calTo;
        private System.Windows.Forms.TextBox txtSearchKeyword;
        private System.Windows.Forms.ComboBox cmbFieldFilter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbAfter;
        private System.Windows.Forms.RadioButton rbBefore;
        private System.Windows.Forms.RadioButton rbBetween;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabControl tbpgMain;
        private System.Windows.Forms.TabPage tbpgData;
        private System.Windows.Forms.TabPage tbpgMetrics;
        private System.Windows.Forms.TabPage tbpgAdmin;
        private System.Windows.Forms.TextBox txtManagerName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtUserDepartment;
        private System.Windows.Forms.TextBox txtGivenName;
        private System.Windows.Forms.TextBox txtUserID;
        private LSSTrackerDataSet lssTrackerDataSet1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartSeries;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartContributor;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartTeams;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartImprovementType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnDrillup;
        private System.Windows.Forms.Button btnDrilldown;
        private System.Windows.Forms.ListBox lstTeam;
        private System.Windows.Forms.ListBox lstImprovementType;
        private LSSTrackerDataSet1 lSSTrackerDataSet11;
        private System.Windows.Forms.BindingSource lssReferenceBindingSource;
        private LSSTrackerDataSet1TableAdapters.lssReferenceTableAdapter lssReferenceTableAdapter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvReferenceData;
        private System.Windows.Forms.DataGridView dgvVersionControl;
        private System.Windows.Forms.DataGridView dgvSuperuserList;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contactSupportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createCurrentMomthReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createReportForSelectedDatesToolStripMenuItem;
        private System.Windows.Forms.Button btnClearFilter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCSVFilePath;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.DataGridView dgvCSVUpload;
        private System.Windows.Forms.Button btnExportToSqlServer;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button tbnPrepareData;
        private System.Windows.Forms.DataGridView dgvFieldMapping;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dgvRefreshLog;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripTextBox txtToolstringRefreshStatus;
        private System.Windows.Forms.CheckedListBox chkBoxFieldList;
        private System.Windows.Forms.Button btnShowCheckBox;
        private System.Windows.Forms.ListBox lstDrillDownOn;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lbDgvRecordCount;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker calExportTo;
        private System.Windows.Forms.DateTimePicker calExportFrom;
        private System.Windows.Forms.Button btnFilterETLDates;
        private System.Windows.Forms.Button btnSaveFieldMapping;
    }
}

