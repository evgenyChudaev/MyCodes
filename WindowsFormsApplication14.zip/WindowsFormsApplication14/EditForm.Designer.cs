﻿namespace WindowsFormsApplication14
{
    partial class frmEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.txtDetails = new System.Windows.Forms.TextBox();
            this.cmbTeam = new System.Windows.Forms.ComboBox();
            this.cmbImprovementType = new System.Windows.Forms.ComboBox();
            this.cmbBenefitType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbFreq = new System.Windows.Forms.ComboBox();
            this.cmbCertificationType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.calCompletionDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.txtCertificationDetails = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbEstimatedEffort = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmbFrequencyTime = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(469, 510);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(431, 50);
            this.btnClose.TabIndex = 0;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtDetails
            // 
            this.txtDetails.Location = new System.Drawing.Point(13, 114);
            this.txtDetails.Multiline = true;
            this.txtDetails.Name = "txtDetails";
            this.txtDetails.Size = new System.Drawing.Size(867, 97);
            this.txtDetails.TabIndex = 1;
            // 
            // cmbTeam
            // 
            this.cmbTeam.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTeam.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTeam.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTeam.FormattingEnabled = true;
            this.cmbTeam.Items.AddRange(new object[] {
            "HR & CWM",
            "Reporting & Production",
            "BI",
            "RPA/RDA",
            "RM"});
            this.cmbTeam.Location = new System.Drawing.Point(21, 39);
            this.cmbTeam.Name = "cmbTeam";
            this.cmbTeam.Size = new System.Drawing.Size(282, 24);
            this.cmbTeam.TabIndex = 2;
            // 
            // cmbImprovementType
            // 
            this.cmbImprovementType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbImprovementType.FormattingEnabled = true;
            this.cmbImprovementType.Items.AddRange(new object[] {
            "Automation",
            "Process Discontinuation",
            "Process Documentation",
            "Documentation Improvement"});
            this.cmbImprovementType.Location = new System.Drawing.Point(13, 54);
            this.cmbImprovementType.Name = "cmbImprovementType";
            this.cmbImprovementType.Size = new System.Drawing.Size(283, 24);
            this.cmbImprovementType.TabIndex = 3;
            // 
            // cmbBenefitType
            // 
            this.cmbBenefitType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBenefitType.FormattingEnabled = true;
            this.cmbBenefitType.Items.AddRange(new object[] {
            "Cost Avoidance",
            "Cost Reduction"});
            this.cmbBenefitType.Location = new System.Drawing.Point(14, 50);
            this.cmbBenefitType.Name = "cmbBenefitType";
            this.cmbBenefitType.Size = new System.Drawing.Size(283, 24);
            this.cmbBenefitType.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Team";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Type of savings ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Improvement Type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(301, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(272, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Savings per frequency in hours (estimate)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(588, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Activity frequency";
            // 
            // cmbFreq
            // 
            this.cmbFreq.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFreq.FormattingEnabled = true;
            this.cmbFreq.Items.AddRange(new object[] {
            "Daily",
            "Weekly",
            "Bi-weekly",
            "Monthly",
            "Quarterly",
            "Semi-annually",
            "Annually"});
            this.cmbFreq.Location = new System.Drawing.Point(589, 50);
            this.cmbFreq.Name = "cmbFreq";
            this.cmbFreq.Size = new System.Drawing.Size(282, 24);
            this.cmbFreq.TabIndex = 12;
            // 
            // cmbCertificationType
            // 
            this.cmbCertificationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCertificationType.FormattingEnabled = true;
            this.cmbCertificationType.Items.AddRange(new object[] {
            "LSS Certification",
            "Other"});
            this.cmbCertificationType.Location = new System.Drawing.Point(14, 48);
            this.cmbCertificationType.Name = "cmbCertificationType";
            this.cmbCertificationType.Size = new System.Drawing.Size(281, 24);
            this.cmbCertificationType.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Select purpose";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 94);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Comments";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(8, 508);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(418, 52);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Work Effort";
            // 
            // calCompletionDate
            // 
            this.calCompletionDate.Location = new System.Drawing.Point(16, 148);
            this.calCompletionDate.Name = "calCompletionDate";
            this.calCompletionDate.Size = new System.Drawing.Size(280, 22);
            this.calCompletionDate.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 128);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 17);
            this.label10.TabIndex = 21;
            this.label10.Text = "Completion Date:";
            // 
            // txtCertificationDetails
            // 
            this.txtCertificationDetails.Location = new System.Drawing.Point(13, 95);
            this.txtCertificationDetails.Multiline = true;
            this.txtCertificationDetails.Name = "txtCertificationDetails";
            this.txtCertificationDetails.Size = new System.Drawing.Size(542, 88);
            this.txtCertificationDetails.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 75);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(271, 17);
            this.label11.TabIndex = 23;
            this.label11.Text = "Brief Summary: old and improved process";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCertificationDetails);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.cmbCertificationType);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(8, 90);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(572, 189);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Purpose of improvement";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbEstimatedEffort);
            this.groupBox2.Controls.Add(this.cmbImprovementType);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.calCompletionDate);
            this.groupBox2.Location = new System.Drawing.Point(586, 90);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(314, 189);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "IMPROVEMENT DETAILS";
            // 
            // cmbEstimatedEffort
            // 
            this.cmbEstimatedEffort.Location = new System.Drawing.Point(13, 101);
            this.cmbEstimatedEffort.Name = "cmbEstimatedEffort";
            this.cmbEstimatedEffort.Size = new System.Drawing.Size(283, 22);
            this.cmbEstimatedEffort.TabIndex = 22;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmbFrequencyTime);
            this.groupBox3.Controls.Add(this.txtDetails);
            this.groupBox3.Controls.Add(this.cmbBenefitType);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.cmbFreq);
            this.groupBox3.Location = new System.Drawing.Point(8, 285);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(892, 217);
            this.groupBox3.TabIndex = 26;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " BENEFIT";
            // 
            // cmbFrequencyTime
            // 
            this.cmbFrequencyTime.Location = new System.Drawing.Point(303, 52);
            this.cmbFrequencyTime.Name = "cmbFrequencyTime";
            this.cmbFrequencyTime.Size = new System.Drawing.Size(279, 22);
            this.cmbFrequencyTime.TabIndex = 16;
            // 
            // frmEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 588);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cmbTeam);
            this.Controls.Add(this.btnClose);
            this.Name = "frmEdit";
            this.Text = "EDIT";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtDetails;
        private System.Windows.Forms.ComboBox cmbTeam;
        private System.Windows.Forms.ComboBox cmbImprovementType;
        private System.Windows.Forms.ComboBox cmbBenefitType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbFreq;
        private System.Windows.Forms.ComboBox cmbCertificationType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker calCompletionDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCertificationDetails;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox cmbEstimatedEffort;
        private System.Windows.Forms.TextBox cmbFrequencyTime;
    }
}