﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication14
{
    public partial class frmEdit : Form
    {
        SqlConnection conn = new SqlConnection(@"Data Source=SSRC\DEV2008,2301;Initial Catalog=LSSTracker;User ID=lssTrackerApp;Password=Qazwsx184!");
        string myRecordId;
        public frmEdit(string teamName, string benefitType, string improvementType, string frequencyTime, string frequency, string certificationType, string details, string recordId,  string estEffort, string completionDate, string certMemo)
        {
           InitializeComponent();
           cmbTeam.Text = teamName;
           cmbBenefitType.Text = benefitType;
           cmbImprovementType.SelectedItem = improvementType;
           cmbFrequencyTime.Text = frequencyTime;
           cmbCertificationType.Text = certificationType;
           cmbFreq.Text = frequency;          
           txtDetails.Text = details;
           myRecordId = recordId;         
           cmbEstimatedEffort.Text = estEffort;
           txtCertificationDetails.Text = certMemo;
           calCompletionDate.Value = Convert.ToDateTime(completionDate);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            updateLSSRecords();
            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {           
            this.Close();         
            
        }

        private bool checkDataEffortDataType(string myData)
        {
            double myDbl;
            int myInt;
            if (!Double.TryParse(myData, out myDbl) && !Int32.TryParse(myData, out myInt))
            {
                MessageBox.Show("The effort required & savings per frequency should be either a decimal or an integer number");
                return false;
            }
            else
            {
                return true;
            }
            
        }

        private void updateLSSRecords()
        {
            DialogResult deleteDialog = MessageBox.Show("Are you sure you want to update this record?", "Update record", MessageBoxButtons.YesNo);
            if (deleteDialog == DialogResult.Yes)
            {
                frmMain.updatedRecord = true;
                string myTeam = cmbTeam.Text;
                string myBenefitType = cmbBenefitType.Text;
                string myImprovementType = cmbImprovementType.Text;
                string myFrequencyTime = cmbFrequencyTime.Text;
                string myFrequency = cmbFreq.Text;
                string myCertificationType = cmbCertificationType.Text;
                string myDetails = txtDetails.Text == null ? "" : txtDetails.Text;               
                string myEstEffort = cmbEstimatedEffort.Text;
                
                // type checking - if user has updated effort required and it's not integer or double, then recor should not be saved.
                if (!checkDataEffortDataType(myEstEffort) || !checkDataEffortDataType(myFrequencyTime) )
                {
                    MessageBox.Show("Record was not saved");
                    return;
                }

                DateTime myCompletionDate = calCompletionDate.Value;
                string myCertDetails = txtCertificationDetails.Text;

                conn.Open();
                SqlCommand cmd = new SqlCommand("updateTrackerData", conn);
                cmd.Parameters.AddWithValue("@myTeam", myTeam);
                cmd.Parameters.AddWithValue("@myBenefitType", myBenefitType);
                cmd.Parameters.AddWithValue("@myImprovementType", myImprovementType);
                cmd.Parameters.AddWithValue("@myFrequencyTime", myFrequencyTime);
                cmd.Parameters.AddWithValue("@myFrequency", myFrequency);
                cmd.Parameters.AddWithValue("@myCertificationType", myCertificationType);
                cmd.Parameters.AddWithValue("@myRecordId", myRecordId);
                cmd.Parameters.AddWithValue("@detailsMemo", myDetails);                
                cmd.Parameters.AddWithValue("@estimated_effort", myEstEffort);
                cmd.Parameters.AddWithValue("@completion_date", myCompletionDate);
                cmd.Parameters.AddWithValue("@certification_memo", myCertDetails);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                conn.Close();
            }            
        }



      
    }
}
