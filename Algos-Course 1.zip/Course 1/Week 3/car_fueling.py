# python3
import sys


def compute_min_refills(distance, tank, stops):
    numRefills = 0
    tank_left = tank
    
    if tank >=distance: # no refill required
        return 0
    elif stops[0] > tank:
        return -1
    else:
        if len(stops) !=0: # need refill and have stops before the destination
            
            stops = [0]+stops
            stops.append(distance)

            for i in range(1, len(stops)-1):              
                dist_between = stops[i] - stops[i-1]
                dist_between_next = stops[i+1] - stops[i]
                tank_left = tank_left - dist_between

                if dist_between > tank or dist_between_next > tank: # can't reach target
                    return -1
                elif dist_between_next > tank_left: #dist_between > tank_left:
                       numRefills += 1
                       tank_left = tank
                else:
                        continue
            return numRefills

    return -1

if __name__ == '__main__':
    d, m, _, *stops = map(int, sys.stdin.read().split())
    print(compute_min_refills(d, m, stops))
