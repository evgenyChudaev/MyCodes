# Uses python3
import sys

def get_optimal_value(capacity, weights, values):
    value = 0.0000
    # write your code here
    weights_values = [i for i in zip(values, weights) if i[0] !=0 and i[1] != 0]
    ratios = sorted(weights_values, key = lambda x: x[1]/x[0])

    for i in ratios:
        if capacity == 0:
            return value
        else:
            a = min(capacity, i[1])
            value = value+a*(i[0]/i[1])
            capacity = capacity - a

    return  round(value, 4)


if __name__ == "__main__":
    data = list(map(int, sys.stdin.read().split()))
    n, capacity = data[0:2]
    values = data[2:(2 * n + 2):2]
    weights = data[3:(2 * n + 2):2]
    opt_value = get_optimal_value(capacity, weights, values)
    print("{:.10f}".format(opt_value))
