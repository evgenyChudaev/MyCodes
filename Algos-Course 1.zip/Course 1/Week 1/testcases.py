import sys
n = int (sys.argv[1] )
print(n)
print(' '.join([str(i*2 ) for i in range(n)]))