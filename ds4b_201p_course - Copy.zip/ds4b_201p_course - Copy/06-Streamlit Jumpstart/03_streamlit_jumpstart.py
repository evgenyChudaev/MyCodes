# BUSINESS SCIENCE UNIVERSITY
# COURSE: DS4B 201-P PYTHON MACHINE LEARNING
# MODULE 0: MACHINE LEARNING & API'S JUMPSTART 
# PART 3: STREAMLIT
# ----

# To run app (put this in Terminal):
#   streamlit run 00_streamlit_jumpstart/03_streamlit_jumpstart.py


# Import required libraries
import streamlit as st
import pandas as pd
import plotly.express as px

# 1.0 Title and Introduction
st.title('Business Dashboard!!!!!!!')
st.write('Test')
# 2.0 Data Input


# 3.0 App Body 
#  What Happens Once Data Is Loaded?

# * Sales insights


# * Customer Segmentation by Region


# * Product Analysis


# * Feedback Form


# 4.0 Footer



if __name__ == "__main__":
    pass