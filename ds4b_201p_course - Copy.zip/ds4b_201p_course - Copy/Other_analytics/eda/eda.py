import pandas as pd

url = r'C:\Users\natal\Downloads\example.txt'
#url = r'https://github.com/wesm/pydata-book/tree/3rd-edition/datasets/bitly_usagov/example.txt?raw=true'

df = pd.read_json(url)
with open(url) as f:
    print(f.readline())
#df = pd.read_csv(url, index_col=0)
#print(df.head(5))

import json
with open(url) as f:
    records = [json.loads(line) for line in f]


records[0]
time_zones = [rec['tz']  for rec in records if "tz" in rec ]


def get_counts(sequence):
    counts = {}
    for x in sequence:
        if x in counts:
            counts[x] +=1
        else:
            counts[x] = 1
    return counts

from collections import defaultdict

def get_counts2(sequence):
    counts = defaultdict(int)
    for x in sequence:
        counts[x]+=1
    return counts

counts = get_counts(time_zones)  


def top_counts(count_dict, n =10):
    value_key_pairs = [(count, tz) for tz, count in count_dict.items()]
    value_key_pairs.sort()
    return value_key_pairs[-n:]

top_counts(counts)

from collections import Counter
counts = Counter(time_zones)

frame = pd.DataFrame(records)

tz_counts = frame["tz"].value_counts().head(5)

clean_tz = frame['tz'].fillna("Missing")
clean_tz[clean_tz == ""] = "Unknown"
tz_counts = clean_tz.value_counts()


import seaborn as sns
subset = tz_counts.head()

sns.barplot(y=subset.index, x = subset.to_numpy())

frame["a"][1]

results = pd.Series([x.split()[0] for x in frame["a"].dropna()])

results.value_counts().head(8)

cframe = frame[frame["a"].notna()].copy()

import numpy as np

cframe["os"] = np.where(cframe["a"].str.contains("Windows"), "Windows", "Not Windows")

by_tz_os = cframe.groupby(["tz", "os"])

agg_counts = by_tz_os.size().unstack().fillna(0)

agg_counts.head()

indexer = agg_counts.sum("columns").argsort()

indexer.values[:10]

sum_series = agg_counts.sum("columns")

# DataFrame needs take method, which Return the elements in the given positional indices along an axis.
count_subset = agg_counts.take(indexer[-10:])
# Series can be sliced without take using argsort ndarray
count_subset_series = sum_series[indexer[-10:]]

agg_counts.sum(axis="columns").nlargest(10)

count_subset = count_subset.stack()

count_subset.name = "total"

count_subset = count_subset.reset_index()
count_subset.head(10)

sns.barplot(x="total", y = "tz", hue = "os", data = count_subset)

def norm_total(group):
    group["normed_total"] = group["total"]/group["total"].sum()   
    
    return group


results = count_subset.groupby("tz").apply(norm_total)

results["normed_total_grand"] = results["total"]/results["total"].sum()

sns.barplot(x="normed_total", y = "tz", hue = "os", data = results)

# More efficient way to calculate normalized sum using transform method

g = count_subset.groupby("tz")
results2 = count_subset["total"] / g["total"].transform("sum")


df = pd.DataFrame({

    "c": [1, 1, 1, 2, 2, 2, 2],

    "type": ["m", "n", "o", "m", "m", "n", "n"]

})

df
#Call func on self producing a DataFrame with the same axis shape as self.
df.groupby('c')['type'].transform(len)