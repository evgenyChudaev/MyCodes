

# page 2
import streamlit as st

if "data" in st.session_state:
    df = st.session_state["data"]

    st.write(df)
