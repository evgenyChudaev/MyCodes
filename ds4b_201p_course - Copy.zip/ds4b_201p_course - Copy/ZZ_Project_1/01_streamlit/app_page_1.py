# page 1
import pandas as pd
import streamlit as st

csv = st.file_uploader("Upload a file", type="csv")

if csv is not None:
    df = pd.read_csv(csv)
    st.session_state["data"] = df