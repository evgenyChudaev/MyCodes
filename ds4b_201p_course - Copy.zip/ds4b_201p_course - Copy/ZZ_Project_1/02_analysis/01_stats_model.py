import pandas as pd
from sklearn import linear_model as lm
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score
import statsmodels.api as sm
import statsmodels.formula.api as smf #import ols
from statsmodels.stats.outliers_influence import OLSInfluence
from dmba import AIC_score 

housing_df = pd.read_csv("./ZZ_Project_1/00_data/house_sales.csv", sep='\t')

housing_df.head()

housing_df.info()

subset = ['AdjSalePrice', 'SqFtTotLiving', 'SqFtLot', 'Bathrooms',
          'Bedrooms', 'BldgGrade']


outcome = subset.pop(0)
predictors = subset

housing_df[subset].head()

# Scikit Learn

house_lm = lm.LinearRegression()

house_lm.fit(housing_df[predictors], housing_df[outcome])


print(f'Intercept: {house_lm.intercept_:.3f}')
print('Coefficients:')
for name,coeff in zip(predictors, house_lm.coef_):
    print(f'{name}: {coeff}')

fitted = house_lm.predict(housing_df[predictors])
RMSE = np.sqrt(mean_squared_error(housing_df[outcome], fitted))
r2 = r2_score(housing_df[outcome], fitted)
print(f'RMSE: {RMSE:.0f}')
print(f'r2: {r2:.4f}')


# Statsmodels
model = sm.OLS(housing_df[outcome], 
               housing_df[predictors].assign(const=1))
results = model.fit()
results.summary()


# Stepwise regression: add all columns and see how it will work.
# DOesn't work because of ImportError: cannot import name 'TypedDict' from 'typing'
# TypedDict is implemented in Python 3.8 onwards only
housing_df.columns

predictors = [
    'SqFtTotLiving',
    'SqFtLot',
    'Bathrooms',
    'Bedrooms',
    'BldgGrade',
    'PropertyType',
    'NbrLivingUnits',
    'SqFtFinBasement',
    'YrBuilt',
    'YrRenovated',
    'NewConstruction'
]


X = pd.get_dummies(housing_df[predictors], drop_first=True)

X['NewConstruction'] = [1 if nc else 0 for nc in X['NewConstruction']]

house_full = sm.OLS(housing_df[outcome], X.assign(const=1))

results = house_full.fit()

results.summary()

y = housing_df[outcome]

def train_model(variables):
    if len(variables) == 0:
        return None
    model = lm.LinearRegression()
    model.fit(X[variables], y)
    return model

def score_model(model, variables):
    if len(variables == 0):
        return AIC_score(y, [y.mean()] * len(y), model, df=1)
    return AIC_score(y, model.predict(X[variables]), model)

best_model, best_variables = stepwise_selection(X.columns, 
                                                train_model, 
                                                score_model,
                                                verbose=True
                                                )

print(f'Intercept: {best_model.intercept_:.3f}')
print('Coefficients:')
for name, coef in zip(best_variables, best_model.coeff_):
    print(f'{name}: {coef}')
    
    
# Weighted regression
import datetime as dt
housing_df['Year'] = pd.to_datetime(housing_df.DocumentDate).dt.year
housing_df['Weight'] = housing_df.Year - 2005

housing_df.info()

predictors = ['SqFtTotLiving', 'SqFtLot', 'Bathrooms', 'Bedrooms', 'BldgGrade']

outcome = 'AdjSalePrice'

house_wt = lm.LinearRegression()
house_wt.fit(housing_df[predictors], 
             housing_df[outcome],
             sample_weight=housing_df.Weight
             )

house_lm.fit(housing_df[predictors], housing_df[outcome])


print(f'Intercept: {house_wt.intercept_:.3f}')
print('Coefficients:')
for name,coeff in zip(predictors, house_wt.coef_):
    print(f'{name}: {coeff}')

fitted = house_wt.predict(housing_df[predictors])
RMSE = np.sqrt(mean_squared_error(housing_df[outcome], fitted))
r2 = r2_score(housing_df[outcome], fitted)
print(f'RMSE: {RMSE:.0f}')
print(f'r2: {r2:.4f}')

housing_df.PropertyType.unique()

pd.get_dummies(housing_df['PropertyType']).head()
pd.get_dummies(housing_df['PropertyType'], drop_first=True).head()

predictors = ['SqFtTotLiving', 'SqFtLot', 'Bathrooms', 
              'Bedrooms', 'BldgGrade', 'PropertyType']
X = pd.get_dummies(housing_df[predictors], drop_first=True)

house_lm_factor = lm.LinearRegression()
house_lm_factor.fit(X, housing_df[outcome])

print(f'Intercept: {house_lm_factor.intercept_:.3f}')
print('Coefficients:')
for name,coeff in zip(X.columns, house_lm_factor.coef_):
    print(f'{name}: {coeff}')

# exploring factor variables
pd.DataFrame(housing_df['ZipCode'].value_counts()).transpose()

# example from textbook - too complicated, can be made much more simple
zip_groups = pd.DataFrame([
    *pd.DataFrame(
        {'ZipCode': housing_df['ZipCode'],
         'residual': housing_df[outcome] - house_lm_factor.predict(X),
        }) \
    .groupby(['ZipCode']) \
    .apply(lambda x: {'ZipCode': x.iloc[0,0], 
                      'count': len(x), 
                      'median_residual': x.residual.median()
    })
]).sort_values('median_residual')

zip_groups['cum_count'] = np.cumsum(zip_groups['count'])
zip_groups['ZipGroup'] = pd.qcut(zip_groups['cum_count'], 
                                 5, labels=False, retbins=False)

to_join = zip_groups[['ZipCode', 'ZipGroup']].set_index('ZipCode')
housing_df = housing_df.join(to_join, on='ZipCode')
housing_df['ZipGroup'] = housing_df['ZipGroup'].astype('category')

# my solution, more simple
housing_df_mod = housing_df
housing_df_mod['residual'] = housing_df_mod[outcome] - house_lm_factor.predict(X)
hdf = housing_df_mod.groupby(['ZipCode']).agg(
                                        {
                                          'ZipCode': 'size',
                                          'residual': np.median   
                                        }
                                    ) \
                                    .sort_values('residual')
hdf.columns = ['count', 'median_residual']

                                 
# housing_df[housing_df['ZipCode'] == 98057]
# zips = pd.DataFrame([{'A': 1, 'B':2}, {'A': 3, 'B':4}])


# remove correlated variables
predictors = ['Bedrooms', 'BldgGrade', 'PropertyType', 'YrBuilt']
outcome = 'AdjSalePrice'

X = pd.get_dummies(housing_df[predictors], drop_first=True)

reduced_lm = lm.LinearRegression()
reduced_lm.fit(X, housing_df[outcome])

predictors = [
    'SqFtTotLiving',
    'SqFtLot',
    'Bathrooms',
    'Bedrooms',
    'BldgGrade',
    'PropertyType',
    'ZipGroup'
]

outcome = 'AdjSalePrice'
housing_df.info()
X = pd.get_dummies(housing_df[predictors], drop_first=True)

confounding_lm = lm.LinearRegression()
confounding_lm.fit(X, housing_df[outcome])


print(f'Intercept: {confounding_lm.intercept_:.3f}')
print('Coefficients:')
for name,coeff in zip(X.columns, confounding_lm.coef_):
    print(f'{name}: {coeff}')
    

# Interactions and main effects - superimportant and increases model r-squared and other metrics significantly.
model = smf.ols(formula='AdjSalePrice ~ SqFtTotLiving*ZipGroup + SqFtLot + Bathrooms + Bedrooms+ BldgGrade + PropertyType', data=housing_df)

results = model.fit()
results.summary()

# outliers
house_98105 = housing_df[housing_df['ZipCode']== 98105]
predictors = ['SqFtTotLiving',
    'SqFtLot',
    'Bathrooms',
    'Bedrooms',
    'BldgGrade']
outcome = 'AdjSalePrice'

house_98105['AdjSalePrice'].mean()

house_outlier = sm.OLS(
    house_98105[outcome],
    house_98105[predictors].assign(const=1)
    )

result_98105 = house_outlier.fit()

influence = OLSInfluence(result_98105)
sresiduals = influence.resid_studentized_internal
sresiduals.idxmin(), sresiduals.min()

#influence plot
import matplotlib.pyplot as plt


influence = OLSInfluence(result_98105)
fig, ax = plt.subplots(figsize=(5,5))
ax.axhline(-2.5, linestyle='--', color='C1')
ax.axhline(2.5, linestyle='--', color = 'C1')
ax.scatter(influence.hat_matrix_diag, influence.resid_studentized_internal, s=1000 * np.sqrt(influence.cooks_distance[0]), alpha=0.5)

ax.set_xlabel('hat values')
ax.set_ylabel('studentized residuals')

#heteroskedasticity - variance of residuals tend to increase 
# for higher priced homes
import seaborn as sns
fig, ax = plt.subplots(figsize=(5,5))
sns.regplot(
    x = result_98105.fittedvalues, y =np.abs(result_98105.resid),
    scatter_kws={'alpha': 0.25}, line_kws={'color': 'C1'},
    lowess=True, ax=ax
)

ax.set_xlabel('predicted')
ax.set_ylabel('abs(residual)')

# partial residual plot
sm.graphics.plot_ccpr(result_98105, 'SqFtTotLiving')

# Generalized additive models
from pygam import *

predictors = ['SqFtTotLiving',
              'SqFtLot',
              'Bathrooms',
              'Bedrooms',
              'BldgGrade'
              ]
outcome = 'AdjSalePrice'
X = house_98105[predictors].values
y = house_98105[outcome]

gam = LinearGAM(s(0, n_splines=12)+ l(1) + l(2)+ l(3) + l(4))
gam.gridsearch(X,y)
