# BUSINESS SCIENCE UNIVERSITY
# HR CHURN PREDICTION RISK SCORING  
# PART 1: ANALYSIS
# ----

# GOAL: Predict Employee Churn (Attrition) 

# ABOUT THE DATA

# These data are from the Data Science For Business Part 2 Course (in R). Our outcome is to determine the probabiliy of an employee leaving the company based on various attributes related to their personal, professional, career, and work-life balance. 

# LIBRARIES

import pandas as pd
import pycaret.classification as clf
import plotly.express as px

from sklearn.pipeline import Pipeline

# DATA

hr_data_raw_df = pd.read_csv("BONUS_SHINY_APP_2/data/hr_data.csv")

hr_data_raw_df

hr_data_raw_df.columns

# 1.0 QUICK MACHINE LEARNING WITH PYCARET ----

# * Subset the data ----
df = hr_data_raw_df \
    .drop(["EmployeeNumber"], axis=1)

df.info()

# Numeric Columns
float_cols = df.select_dtypes(include="float64").columns.to_list()

int_cols = df.select_dtypes(include="int64").columns.to_list()

numeric_columns = [*float_cols, *int_cols]

# Categorical Columns
cat_columns = df \
    .drop("Attrition", axis=1) \
    .select_dtypes('object') \
    .columns \
    .to_list()

# * Setup the Classifier ----
clf_1 = clf.setup(
    data       = df, 
    target     = "Attrition",
    train_size = 0.8,
    session_id = 123,
    
    categorical_features=cat_columns,
    numeric_features=numeric_columns
    
)


# * Make A Machine Learning Model ----
xgb_model = clf.create_model(
    estimator = 'xgboost'
)



# CHECK MODEL ----

clf.plot_model(xgb_model, plot = "auc")

# FEATURE IMPORTANCE -----

# Basic Feature Importance
clf.plot_model(xgb_model, plot = 'feature')


# Shap Feature Importance
clf.interpret_model(xgb_model, plot='summary')

# FINALIZE MODEL ----
xgb_model_finalized = clf.finalize_model(xgb_model)

# MAKE PREDICTIONS & RANKING ATTRITION RISK ----

predictions_df = clf.predict_model(
    xgb_model_finalized, 
    data      = hr_data_raw_df,
    raw_score = True
)

predictions_df \
    .sort_values("Score_Yes", ascending=False)

# SAVE MODEL ----

clf.save_config("BONUS_SHINY_APP_2/config/clf_1")

clf.save_model(xgb_model_finalized, "BONUS_SHINY_APP_2/models/xgb_model_finalized")

# LOAD MODELS ----

xgb_model_finalized = clf.load_model("BONUS_SHINY_APP_2/models/xgb_model_finalized")

# VISUALS FOR APP ----


# High-Risk Employees ----

employees_scored = clf.predict_model(
    xgb_model_finalized,
    data=hr_data_raw_df,
    raw_score=True
) 

employees_scored['EmployeeNumber'] = hr_data_raw_df['EmployeeNumber']

employees_scored = employees_scored \
    .sort_values('Score_Yes', ascending=False)

# User Inputs:

df = employees_scored

employee_id = 1273

employee_df = df[df['EmployeeNumber'] == employee_id]

# Employee Insights ---- 

employee_df['Score_Yes']


# Trick: Need to pull XGB.Classifier from Sklearn Pipeline

model = xgb_model_finalized

if isinstance(model, Pipeline):
    model = model[len(model)-1]

shap_plot = clf.interpret_model(
    model,
    plot = "reason",
    X_new_sample=employee_df
)

shap_plot

shap_plot.matplotlib(
    figsize=(16, 2), 
    show=False,
    text_rotation = 90
)
