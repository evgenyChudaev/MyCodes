# BUSINESS SCIENCE UNIVERSITY
# HR CHURN PREDICTION RISK SCORING  
# PART 1: ANALYSIS
# ----

# GOAL: Predict Employee Churn (Attrition) 

# INSTRUCTIONS:
# shiny run --reload BONUS_SHINY_APP_2/02_shiny_app.py --port 8000
# Ctrl + C to shut down

# IMPORTS 
from shiny import (
    App, ui, reactive, Session, render
)
import shinyswatch

import pandas as pd
import pycaret.classification as clf

from pathlib import Path

import htmltools


# DIRECTORY PATHS ----

data_dir = Path(__file__).parent / "data"
config_dir = Path(__file__).parent / "config"
models_dir = Path(__file__).parent / "models"
www_dir = Path(__file__).parent / "www"

# DEFAULT APP INPUTS ----

TITLE = "Employee Attrition Risk Scoring App"

# DATA & MODEL PREP ----

hr_data_raw_df = pd.read_csv(data_dir / "hr_data.csv")

xgb_model_finalized = clf.load_model(models_dir / "xgb_model_finalized")

employees_scored = clf.predict_model(
    xgb_model_finalized,
    data=hr_data_raw_df,
    raw_score=True
) 

employees_scored['EmployeeNumber'] = hr_data_raw_df['EmployeeNumber']

employees_scored = employees_scored \
    .sort_values('Score_Yes', ascending=False)

# print(employees_scored)

df = employees_scored

employee_df = employees_scored.iloc[[0]]

attrition_risk_init = employee_df['Score_Yes']



# NEED TO LOAD EXPERIMENT TO GET SHAP TO WORK

clf_1 = clf.load_config(config_dir / "clf_1")


# LAYOUT ----
page_dependencies = ui.tags.head(
    ui.tags.link(
        rel="stylesheet", type="text/css", href="style.css"
    )
)

# Navbar Page ----
app_ui = ui.page_navbar(
    
    # Bootswatch Themes: https://bootswatch.com/
    shinyswatch.theme.lux(),
    
    ui.nav(
        "Employee Attrition Analysis",
        ui.layout_sidebar(
            sidebar=ui.panel_sidebar(
                
                ui.h2("Attrition Analysis"),
                
                ui.input_selectize(
                    "employee_selected", 
                    "Employee Selected:",
                    employees_scored['EmployeeNumber'].to_list(),
                    selected='XGBoost',
                    multiple=False
                ),
                
                ui.input_action_button(
                    "submit", "Submit", 
                    class_="btn-info"
                ),
                
                width=3,
                # class_ = "well-gray",
            ),
            main = ui.panel_main(
                
                ui.output_ui("ui_prediction_risk"),
                
                ui.column(
                    12,                    
                    ui.div(
                        ui.output_plot("ui_force_plot") ,
                        class_="card",
                        style="margin:10px;"
                    )
                                      
                ),
                
            )
        ),
        
        
    ),
    title=ui.tags.div(
        ui.img(src="business-science-logo.png", height="50px", style="margin:5px;"),
        ui.h4(" " + TITLE, style="color:white;margin-top:auto; margin-bottom:auto;"), 
        style="display:flex;-webkit-filter: drop-shadow(2px 2px 2px #222);"
    ),
    bg="#0062cc",
    inverse=True,
    header=page_dependencies
)

def server(input, output, session: Session):
    
    # MODEL 
    
    xgb_model = clf.create_model(
        estimator = 'xgboost'
    )
    
    shap_plot = clf.interpret_model(
        xgb_model,
        plot = "reason",
        X_new_sample=employee_df
    )
    
    # Reactivity
    attrition_risk = reactive.Value(employee_df['Score_Yes'].to_list())
    df_employee = reactive.Value(employee_df)
    plot_shap = reactive.Value(shap_plot)
    
    
    # SHAP 
    @reactive.Effect
    @reactive.event(input.submit)
    def _1():
        
        # Select New Employee
        # print(input.employee_selected())
        # print("---")
        
        # print(employees_scored['EmployeeNumber'].head())
        # print("---")
        
        df = employees_scored[employees_scored['EmployeeNumber'] == int(input.employee_selected())]
        
        df_employee.set(df)
        
        # print(df)
        # print("---")
        
        # Rerun Shap Plot
        shap_plot_new = clf.interpret_model(
            xgb_model,
            plot = "reason",
            X_new_sample=df_employee()
        )
        
        plot_shap.set(shap_plot_new)
        
        # Get attrition risk
        attrition_risk_new = df['Score_Yes'].to_list()
        
        # print(attrition_risk_new)
        # print("---")
        
        attrition_risk.set(attrition_risk_new)
        
    

    @output
    @render.plot
    def ui_force_plot():
        
        force_plot_mpl = plot_shap().matplotlib(
            figsize=(16, 2), 
            show=False,
            text_rotation = 45
        )
        
        return force_plot_mpl
    
    @output
    @render.ui
    def ui_prediction_risk():
        
        val_raw = attrition_risk()[0]
        
        print(val_raw)
        print("---")
        
        val_pct = '{:.1%}'.format(val_raw)
        
        print(val_pct)
        print("---")
        
        html_out = ui.HTML(f"<h1>Attrition Risk: {val_pct}</h1>")
        
        return html_out
    
    


app = App(
    app_ui, server, 
    static_assets=www_dir, 
    debug=False
)
