import pandas as pd
import calendar


in_Unit_directory_Flat_clean_address = "Unit_directory_Flat_clean_address_final_rakib2.csv" #Manually created
in_Unit_Property_Custom_Extract = "Unit_Property_Custom_Extract.csv" #by YSQL

out_Unit_directory_Flat_clean_address = 'Unit_directory_Flat_clean_address_final_rakib5.csv'

dic_Prop_Unit = {}


def parseDateStr(data_str):
    data_str = str(data_str).strip()
    try:
        date_ = pd.to_datetime(data_str)
       
        data_str = str(date_.day)+str(calendar.month_abbr[date_.month]).upper()
        print('parseDateStr', data_str, date_.year, date_.month, date_.day)
        
        return data_str
    except Exception as e:
        return data_str

def parseIntStr(data_str):
    data_str = str(data_str).strip()
    try:
        
        data_str = str(int(float(data_str))).strip()
        return data_str
    except Exception as e:
      
        return parseDateStr(data_str)

def populateDic(df):
    for i in df.index:
        Property = parseIntStr(str(df.at[i, 'Property']).strip())
        df.at[i, 'Property'] = Property
        Unit = parseIntStr(str(df.at[i, 'Unit']).strip().replace('________XXXXXXXXX', ''))
        df.at[i, 'Unit'] = Unit
      
        key = Property+'_'+Unit 
        
        
        
        
        dic_Prop_Unit.setdefault(key, []).append(df.iloc[i])
        
        
        
    

def ExtractCoord(row):
    Property = parseIntStr(str(row['Property']).strip())
    row['Property'] = Property
    Unit = parseIntStr(str(row['Unit']).strip().replace('________XXXXXXXXX', ''))
    row['Unit'] = Unit
   
    
    key = Property+'_'+Unit 
    
    zzLat_final=None
    zzLon_final=None


    if key in dic_Prop_Unit:
        zzLat_final = dic_Prop_Unit[key][0]['zzLat_final']
        zzLon_final = dic_Prop_Unit[key][0]['zzLon_final']
        
        
        if len(dic_Prop_Unit[key])>1:
            print(key, len(dic_Prop_Unit[key]))
            print(dic_Prop_Unit[key])
        
    else:
        
        pass
 

    return [zzLat_final, zzLon_final] 


if __name__ == "__main__":

    df_Unit_directory_Flat_clean_address = pd.read_csv(in_Unit_directory_Flat_clean_address)
    
    df_Unit_Property_Custom_Extract = pd.read_csv(in_Unit_Property_Custom_Extract)
    
    df_Unit_directory_Flat_clean_address['Property']=df_Unit_directory_Flat_clean_address['Property'].str.strip()
    df_Unit_directory_Flat_clean_address['Unit']=df_Unit_directory_Flat_clean_address['Unit'].str.strip() + "________XXXXXXXXX"
  
    print('before')
    print(len(df_Unit_directory_Flat_clean_address))
  
    df_Unit_directory_Flat_clean_address = df_Unit_directory_Flat_clean_address[['Property', 'Unit',  'zzLat_final',	'zzLon_final' ]]
    df_Unit_directory_Flat_clean_address.drop_duplicates(inplace=False)
    df_Unit_directory_Flat_clean_address.reset_index(drop=True, inplace=True)
    populateDic(df_Unit_directory_Flat_clean_address)
    
    print('after')
    print(len(df_Unit_directory_Flat_clean_address))
    
    
    
    df_Unit_Property_Custom_Extract['Property']=df_Unit_Property_Custom_Extract['Property'].str.strip()
    df_Unit_Property_Custom_Extract['Unit']=df_Unit_Property_Custom_Extract['Unit'].str.strip()+ "________XXXXXXXXX"
  
    
    

    
    print(df_Unit_Property_Custom_Extract)

    
    
    
    
    df_Unit_Property_Custom_Extract['zzLat_final'], df_Unit_Property_Custom_Extract['zzLon_final'] = zip(
        *df_Unit_Property_Custom_Extract.apply(lambda row: ExtractCoord(row), axis=1))
        
        
    df_Unit_Property_Custom_Extract['Unit'] = df_Unit_Property_Custom_Extract['Unit'].str.replace('________XXXXXXXXX', '')
    
    df_Unit_Property_Custom_Extract.dropna(subset = ['zzLat_final'], inplace=True)
    df_Unit_Property_Custom_Extract.dropna(subset = ['zzLon_final'], inplace=True)
    
    df_Unit_Property_Custom_Extract.to_csv(out_Unit_directory_Flat_clean_address, index=False) 

   