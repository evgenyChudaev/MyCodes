import shapefile
from shapely.geometry import Point  # Point class
from shapely.geometry import shape
import pandas as pd
import os
import sys
import cx_Oracle
import traceback

dic_point__geocode = {}
    
CONN_INFO = {
    'host':	'dbo08n.cio.gov.ns.ca',
    'port':	1521,
    'user':	'HOUSING_WORK',
    'psw':	'0Summer+=*',
    'service':	'DWH01_NPR'
}

CONN_STR = '{user}/{psw}@{host}:{port}/{service}'.format(**CONN_INFO)


class Oracle_DB:
    def __init__(self):
        self.conn = cx_Oracle.connect(CONN_STR)
        self.conn.autocommit = True  # autocommit attribute will ensure transactions are automatically committed . This reduces database load and eliminates the round-trip to the DB

    def query(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            result = cursor.execute(query, kwargs).fetchall()
            response = 'SUCCESS', result
        except:
            response = 'FAILED 	{}'.format(traceback.format_exc()), None
        finally:
            cursor.close()
        return response

    def insert(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.executemany(query, kwargs.get('values', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def update(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs.get('params', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def delete(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs)
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg



def getParentGeoCode(geoCode, dic_geo_hierarchy):
    geoCode = str(geoCode).strip()
    if geoCode.lower() == 'null' or geoCode.lower() == 'nan' or geoCode.lower() == 'none' or geoCode.lower() == '':
        return ''
    if geoCode in dic_geo_hierarchy:
        return dic_geo_hierarchy[geoCode]
    return ''


def dcodeGeoName(geoCode, dic_code_name):
    geoname = ''

    if geoCode in dic_code_name:
        geoname = dic_code_name[geoCode]

    return geoname


def getGeoCode(latitude, longitude, all_polygons, all_records, all_polygon_points, ignoreMissing=True):
    pt = Point(longitude, latitude)
    geoCode = ''
    missing = ''
    for i in range(len(all_polygons)):
        polygon = all_polygons[i]  # get a boundary polygon
        if pt.within(polygon):
            geoCode = all_records[i][2]
            break

    if geoCode == '':
        missing = 'MissingInMap'

    if geoCode == '' and ignoreMissing == False:
        min_dist = 100000000
        close_i = -1
        for i in range(len(all_polygon_points)):
            list_points = all_polygon_points[i]

            for tup_point in list_points:
                geo_point = Point(tup_point[0], tup_point[1])  # long, lat
                dist = pt.distance(geo_point)
                if min_dist > dist:
                    min_dist = dist
                    close_i = i

        if close_i != -1:
            geoCode = all_records[close_i][2]

    geoCode = geoCode.replace('\x00', '')

    point_key = str(latitude) + "_" + str(longitude)
    dic_point__geocode[point_key] = geoCode

    return [str(geoCode).strip(), missing]


def extract_rha_cd_csd(df_housing_coor, DivisionCol, SubDivisionCol, CDCol, CSDCol, latCol, longCol, saveRHA):
    
    df_housing_coor.reset_index(drop=True, inplace=True)
    
    print(df_housing_coor)
    
    print(DivisionCol, SubDivisionCol, CDCol, CSDCol, latCol, longCol, saveRHA)
    
    ####retreive cp_geo_master, and cp_geo_hierarchy

    myDb = Oracle_DB()
    select_result = myDb.query("select GEOCODE, GEONAME from CP_GEO_MASTER")
    list_table = select_result[1]
    df_code_name1 = pd.DataFrame(list_table, columns = ['GEOCODE','GEONAME'])
    
    select_result = myDb.query("select GEOCODE, PARENT_GEOCODE from CP_GEO_HIERARCHY")
    list_table = select_result[1]
    df_geo_hierarchy1 = pd.DataFrame(list_table, columns = ['GEOCODE','PARENT_GEOCODE'])
    
    ####end retreive  


    rootDir = '' 


    CSDCZ_shape_file = rootDir + 'CSDCZ-topo-format/CSDCZ.shp'
    shp_CSDCZ = shapefile.Reader(CSDCZ_shape_file)
    all_shapes = shp_CSDCZ.shapes()  # get all the polygons
    all_records = shp_CSDCZ.records()

    all_polygons = []
    all_polygon_points = []
    for shape_each in all_shapes:
        polygon = shape(shape_each)

        list_points = []
        if str(polygon.geom_type).lower() == 'multipolygon':
            polygons = list(polygon)
            for poly in polygons:  # same for multipolygon.geoms
                list_points.extend(list(zip(*poly.exterior.coords.xy)))
        elif str(polygon.geom_type).lower() == 'polygon':
            list_points.extend(list(zip(*polygon.exterior.coords.xy)))
        all_polygon_points.append(list_points)

        all_polygons.append(polygon)
    

    dic_code_name1 = dict(zip(df_code_name1['GEOCODE'], df_code_name1['GEONAME']))
    dic_geo_hierarchy1 = dict(zip(df_geo_hierarchy1['GEOCODE'], df_geo_hierarchy1['PARENT_GEOCODE']))

    list_SubDivision = []

    list_Division1 = [] #division name original
    list_CSD = []

    list_CD1 = [] #division code original
    list_missingInMap = []

    list_HA = []
    for i in df_housing_coor.index:
        lat = df_housing_coor.at[i, latCol]  #
        long = df_housing_coor.at[i, longCol]

        str_lat = str(lat).lower()
        str_long = str(long).lower()
        
        
        #print(i, lat, long)    

        if str_lat == 'none' or str_lat == 'nan' or str_lat == '' or str_lat == 'null' or str_long == 'none' or str_long == 'nan' or str_long == '' or str_long == 'null':
            list_SubDivision.append('')

            list_Division1.append('')
            list_CSD.append('')

            list_CD1.append('')
            list_HA.append('')
            list_missingInMap.append('')
            continue

        csd_geoCode = ''
        missing = ''

        point_key = str(lat) + "_" + str(long)

        
        
        if point_key in dic_point__geocode:
            csd_geoCode = dic_point__geocode[point_key]

        else:
            csd_geoCode, missing = getGeoCode(lat, long, all_polygons, all_records, all_polygon_points, False)


        cd_geoCode1 = getParentGeoCode(csd_geoCode, dic_geo_hierarchy1)
        ha_geoCode = getParentGeoCode(cd_geoCode1, dic_geo_hierarchy1)

        csd_geoname = dcodeGeoName(csd_geoCode, dic_code_name1)

        cd1_geoname = dcodeGeoName(cd_geoCode1, dic_code_name1)
        ha_geoname = dcodeGeoName(ha_geoCode, dic_code_name1)

        list_SubDivision.append(csd_geoname)

        list_Division1.append(cd1_geoname)

        list_CSD.append(csd_geoCode)

        list_CD1.append(cd_geoCode1)

        list_missingInMap.append(missing)

        if csd_geoCode == '1208001' or csd_geoCode == '1208002':
            ha_geoname = 'Western Regional'
        elif csd_geoCode == '1208008' or csd_geoCode == '1208014':
            ha_geoname = 'Cobequid'

        list_HA.append(ha_geoname)
        
        

    df_housing_coor[CSDCol] = list_CSD
    df_housing_coor[SubDivisionCol] = list_SubDivision


    df_housing_coor[CDCol] = list_CD1
    df_housing_coor[DivisionCol] = list_Division1

    if saveRHA=='yes':
        df_housing_coor['RHA'] = list_HA
    
    print(df_housing_coor)
    
    return df_housing_coor
    
    