import shapefile
from shapely.geometry import Point
from shapely.geometry import shape
import pandas as pd
import sys
#https://mapshaper.org/

def getGeoCodeByShape(latitude, longitude, all_shapes1, all_records1):
    pt = Point(longitude, latitude)
    geoCode = ''  # ED_Name
    objId = ''
    ED_No = ''
    for i in range(len(all_shapes1)):
        polygon = shape(all_shapes1[i])  # get a boundary polygon
        if polygon.contains(pt):
            objId = all_records1[i][0]
            ED_No = all_records1[i][1]
            name = all_records1[i][7]
            geoCode = name
            
            #print(all_records1[i])

            break

    geoCode = geoCode.replace('\x00', '')
    
    print(str(geoCode).strip(), str(objId).strip(), str(ED_No).strip())

    return [str(geoCode).strip(), str(objId).strip(), str(ED_No).strip()]


def getGeoCode(latitude, longitude, shp):
    # pt = shape(Point(longitude, latitude))
    pt = Point(longitude, latitude)
    all_shapes = shp.shapes()  # get all the polygons
    all_records = shp.records()
    geoCode = ''
    for i in range(len(all_shapes)):
        polygon = shape(all_shapes[i])  # get a boundary polygon
        if pt.within(polygon):
            name = all_records[i][2]
            print(all_records[i])
            geoCode = name
            break

    geoCode = geoCode.replace('\x00', '')

    return str(geoCode).strip()


def extract_municipality(df_housing_coor, MunIdCol, MunNameCol, latCol, longCol):
    rootDir = ''

    CSDCZ_shape_file = rootDir + 'Municipality/Municipality.shp'
    shp_CSDCZ = shapefile.Reader(CSDCZ_shape_file)
    all_shapes = shp_CSDCZ.shapes()  # get all the polygons
    all_records = shp_CSDCZ.records()
    
    print(all_shapes)
    print(all_records)

    df_housing_coor.reset_index(drop=True, inplace=True)
    
    print(df_housing_coor)

    list_ED = []
    list_EDNo = []

    dic_EDName__ObjID_EDNo = {}

    for i in df_housing_coor.index:
        lat = df_housing_coor.at[i, latCol]
        long = df_housing_coor.at[i, longCol]

        str_lat = str(lat).lower()
        str_long = str(long).lower()

        if str_lat == 'none' or str_lat == 'nan' or str_lat == '' or str_lat == 'null' or str_long == 'none' or str_long == 'nan' or str_long == '' or str_long == 'null':
            list_ED.append('')
            continue

        ed, objId, ED_No = getGeoCodeByShape(lat, long, all_shapes, all_records)
        if i%1000==0:
            print(i, lat, long, ed, len(ed))
        list_ED.append(ed)
        list_EDNo.append(ED_No)
        dic_EDName__ObjID_EDNo[ed] = [objId, ED_No]

    df_housing_coor[MunIdCol] = list_EDNo
    df_housing_coor[MunNameCol] = list_ED
    
    print(df_housing_coor)
    
    return df_housing_coor