from Util_HA_CD_CSD_by_coordinate_FAST import extract_rha_cd_csd
from Util_ED_by_coordinate_FAST import extract_ed
from Util_Municipality_by_coordinate_FAST import extract_municipality
import pandas as pd
import sys
from haversine import haversine, Unit
import cx_Oracle
import traceback
import datetime
from os import path
import os


DivisionCol = '' #Output
SubDivisionCol = '' #Output

CDCol = '' #Output
CSDCol = '' #Output

latCol =  '' #'zzLat_final'  # 'Latitude' #zzlat #INPUT
longCol = '' #'zzLon_final'  # 'Longitude' #zzlong #INPUT

saveRHA='no' #Output Flag
saveDatabase=''
saveFile=''

EDCol = ''
EDNo = ''

MunIdCol=''
MunNameCol= ''

if len(sys.argv) == 14:
    DivisionCol = sys.argv[1]
    SubDivisionCol = sys.argv[2]
    CDCol = sys.argv[3]
    CSDCol = sys.argv[4]
    latCol = sys.argv[5]
    longCol = sys.argv[6] 
    saveRHA = sys.argv[7]
    saveDatabase = sys.argv[8].split('=')[1]
    saveFile = sys.argv[9].split('=')[1]
    EDCol = sys.argv[10]
    EDNo = sys.argv[11]
    MunIdCol = sys.argv[12]
    MunNameCol = sys.argv[13]

outPutGeoTable = 'GeoTable.csv'

in_googlePlace=''
InputUnitDirectory_flat_coordinate=''

inputFilePath = "Main_FilePathInfo.csv"
df_path = pd.read_csv(inputFilePath)
for i in df_path.index:
    path_key = df_path.at[i,'Path_Key']
    if path_key=='Google_places_path':
        in_googlePlace = df_path.at[i,'Value']
    elif path_key=='Unit_Coordinate_Path':
        InputUnitDirectory_flat_coordinate = df_path.at[i,'Value']
 


########Data Manipulation in Oracle

CONN_INFO = {
    'host':	'dbo08n.cio.gov.ns.ca',
    'port':	1521,
    'user':	'HOUSING_WORK',
    'psw':	'0Summer+=*',
    'service':	'DWH01_NPR'
}

CONN_STR = '{user}/{psw}@{host}:{port}/{service}'.format(**CONN_INFO)

class Oracle_DB:
    def __init__(self):
        self.conn = cx_Oracle.connect(CONN_STR)
        self.conn.autocommit = True  # autocommit attribute will ensure transactions are automatically committed . This reduces database load and eliminates the round-trip to the DB

    def query(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            result = cursor.execute(query, kwargs).fetchall()
            response = 'SUCCESS', result
        except:
            response = 'FAILED 	{}'.format(traceback.format_exc()), None
        finally:
            cursor.close()
        return response

    def insert(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.executemany(query, kwargs.get('values', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def update(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs.get('params', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def delete(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs)
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

########End Data Manipulation in Oracle



#####Insert Unit Feature

def insertIntoTable_FeatureTable(df_ftrTable):

    myDb = Oracle_DB()
   
    
   
    list_records = df_ftrTable.to_records(index=False)
    list_records = list(list_records)

    rows = list_records

    INSERT_QRY_Answer = 'INSERT INTO DL_PHYSICAL_FEATURE (Regional_Housing, Municipality, Area, Bldg_Complex, Property, Unit#, FEATURE_NAME, FEATURE_VALUE, FEATURE_EFFECTIVE_DATE) VALUES(:Regional_Housing, :Municipality, :Area, :Bldg_Complex, :Property, :Unit#, :FEATURE_NAME, :FEATURE_VALUE, :FEATURE_EFFECTIVE_DATE)'
    
    
    print(rows[0:10])

    insert_result = myDb.insert(INSERT_QRY_Answer, values=rows)
    print(insert_result)


def insert_Unit_feature(df_ftrTable):
    df_ftrTable.fillna("", inplace=True)
    
    df_ftrTable['Municipality'] = df_ftrTable['Municipality'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_ftrTable['Area'] = df_ftrTable['Area'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_ftrTable['BldgComplex'] = df_ftrTable['BldgComplex'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_ftrTable['Property'] = df_ftrTable['Property'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_ftrTable['Unit'] = df_ftrTable['Unit'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    
    df_ftrTable['RegionalHousing']= df_ftrTable['RegionalHousing'].str.strip()
    df_ftrTable['Municipality']= df_ftrTable['Municipality'].str.strip()
    df_ftrTable['Area']= df_ftrTable['Area'].str.strip()
    df_ftrTable['BldgComplex']= df_ftrTable['BldgComplex'].str.strip()
    df_ftrTable['Property']= df_ftrTable['Property'].str.strip()
    df_ftrTable['Unit']= df_ftrTable['Unit'].str.strip()
    
    if saveDatabase=='yes':
        insertIntoTable_FeatureTable(df_ftrTable)
    

#####End Insert Unit Feature



#####Insert Geo Table #####
def insertIntoTable_GeoTable(df_geotable_sub):

    myDb = Oracle_DB()
   
    
   
    list_records = df_geotable_sub.to_records(index=False)
    rows = list(list_records)

    #'Regional Housing', 'Municipality', 'Area', 'Bldg Complex', 'Property', 'Unit#', 'zzLat_final', 'zzLon_final', 'CSD-Unit', 'SubDivision-Unit', 'CD-Unit' ,'Division-Unit', 'EDNo-Unit', 'EDName-Unit', 'Property_lat',	'Property_lon',  'CSD-Property',  'SubDivision-Property', 'CD-Property',	'Division-Property', 'EDNo-Property', 'EDName-Property',  'BldComplex_lat',	'BldComplex_lon',  'CSD-BldComplex',    'SubDivision-BldComplex', 'CD-BldComplex',	'Division-BldComplex',	'EDNo-BldComplex',	'EDName-BldComplex', 'Program Type', 'Postal Code', 'Address_1'

    INSERT_QRY_Answer = 'INSERT INTO DL_GEOTABLE (Regional_Housing, Municipality, Area, Bldg_Complex, Property, Unit#, UNIT_LAT, UNIT_LON, CSD_Unit, SubDivision_Unit, CD_Unit, Division_Unit, EDNo_Unit, EDName_Unit, Program_Type, Postal_Code, Address_1) VALUES(:Regional_Housing, :Municipality, :Area, :Bldg_Complex, :Property, :Unit#, :UNIT_LAT, :UNIT_LON, :CSD_Unit, :SubDivision_Unit, :CD_Unit, :Division_Unit, :EDNo_Unit, :EDName_Unit, :Program_Type, :Postal_Code, :Address_1)'
    
    
    #print(rows)

    insert_result = myDb.insert(INSERT_QRY_Answer, values=rows)
    print(insert_result)    

def insert_geo_table(df_geotable):
    df_geotable.fillna("", inplace=True)
    
    #Property  Regional Housing  Municipality	Area	Bldg Complex    Unit#   zzLat_final	zzLon_final  SubDivision-Unit	Division-Unit	ED-Unit
    #Property_lat	Property_lon    SubDivision-Property	Division-Property	ED-Property
    #BldComplex_lat	BldComplex_lon      SubDivision-BldComplex	Division-BldComplex	ED-BldComplex
    df_geotable_sub = df_geotable[['RegionalHousing', 'Municipality', 'Area', 'BldgComplex', 'Property', 'Unit', 'zzLat_final', 'zzLon_final', 'CSD-Unit', 'SubDivision-Unit', 'CD-Unit' ,'Division-Unit', 'EDNo-Unit', 'EDName-Unit', 'HousingProgram', 'PostalCode', 'Address']]
    
    print(df_geotable_sub)
    
    df_geotable_sub['CSD-Unit']=df_geotable_sub['CSD-Unit'].astype(str)
    df_geotable_sub['CD-Unit']=df_geotable_sub['CD-Unit'].astype(str)
    df_geotable_sub['EDNo-Unit']=df_geotable_sub['EDNo-Unit'].astype(str)
    
    
    
    df_geotable_sub['Municipality'] = df_geotable_sub['Municipality'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['Area'] = df_geotable_sub['Area'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['BldgComplex'] = df_geotable_sub['BldgComplex'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['Property'] = df_geotable_sub['Property'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['Unit'] = df_geotable_sub['Unit'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['SubDivision-Unit'] = df_geotable_sub['SubDivision-Unit'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['Division-Unit'] = df_geotable_sub['Division-Unit'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['EDName-Unit'] = df_geotable_sub['EDName-Unit'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    
    df_geotable_sub['HousingProgram'] = df_geotable_sub['HousingProgram'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['PostalCode'] = df_geotable_sub['PostalCode'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_geotable_sub['Address'] = df_geotable_sub['Address'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    
    #df_geotable_sub['zzLat_final'] = df_geotable_sub.apply(fillByZero, colName='zzLat_final', axis=1)
    #df_geotable_sub['zzLon_final'] = df_geotable_sub.apply(fillByZero, colName='zzLon_final', axis=1)
    #df_geotable_sub['Property_lat'] = df_geotable_sub.apply(fillByZero, colName='Property_lat', axis=1)
    #df_geotable_sub['Property_lon'] = df_geotable_sub.apply(fillByZero, colName='Property_lon', axis=1)
    #df_geotable_sub['BldComplex_lat'] = df_geotable_sub.apply(fillByZero, colName='BldComplex_lat', axis=1)
    #df_geotable_sub['BldComplex_lon'] = df_geotable_sub.apply(fillByZero, colName='BldComplex_lon', axis=1)
    
    print(df_geotable_sub)
    
    df_geotable.fillna("", inplace=True)
    
    #df_geotable_sub['Unit#'] = df_geotable_sub.apply(fillBlank,  FromCol='Property', ToCol='Unit#', axis=1)
    #df_geotable_sub['BldgComplex'] = df_geotable_sub.apply(fillBlank,  FromCol='Unit', ToCol='BldgComplex', axis=1)
    
    df_geotable_sub['RegionalHousing']= df_geotable_sub['RegionalHousing'].str.strip()
    df_geotable_sub['Municipality']= df_geotable_sub['Municipality'].str.strip()
    df_geotable_sub['Area']= df_geotable_sub['Area'].str.strip()
    df_geotable_sub['BldgComplex']= df_geotable_sub['BldgComplex'].str.strip()
    df_geotable_sub['Property']= df_geotable_sub['Property'].str.strip()
    df_geotable_sub['Unit']= df_geotable_sub['Unit'].str.strip()
    
    df_geotable_sub.drop_duplicates(subset=['RegionalHousing', 'Municipality', 'Area', 'BldgComplex', 'Property', 'Unit'], inplace=True)
    
    if saveDatabase=='yes':    
        insertIntoTable_GeoTable(df_geotable_sub)

#####End Insert Geo Table


##### Transform Unit Features
def transForm_Unit_feature(df_ftr_horizon):
    df_group = df_ftr_horizon.groupby(['RegionalHousing', 'Municipality', 'Area', 'BldgComplex', 'Property', 'Unit'])
    
    print(df_group)
    print(len(df_group))
    
    ftr_eff_date = datetime.datetime.now().strftime('%Y-%m-%d')
    
    list_records = []
    
    
    record_count = 0
    
    for name, group in df_group:
        group = group.reset_index(drop=True)
        
        if len(group)>1:
            print('\nGroup with more records\n')
            print(name)
            print(group)
        
        RegionalHousing = str(group.at[0, 'RegionalHousing']).strip()
        Municipality = str(group.at[0, 'Municipality']).strip()
        Area = str(group.at[0, 'Area']).strip()
        BldgComplex = str(group.at[0, 'BldgComplex']).strip()
        Property = str(group.at[0, 'Property']).strip()
        Unit = str(group.at[0, 'Unit']).strip()
        
        if Property=='3900301':
            print('Property', Property)

        ftr_total_units = 'Total #units'
        ftr_total_units_val = 1
        ftr_1_bedrom = '#Units-1bed'
        ftr_1_bedrom_val = 0
        ftr_2_bedrom = '#Units-2bed'
        ftr_2_bedrom_val = 0
        ftr_3_bedrom = '#Units-3bed'
        ftr_3_bedrom_val = 0
        ftr_4_bedrom = '#Units-4bed'
        ftr_4_bedrom_val = 0
        ftr_5_bedrom = '#Units-5bed'
        ftr_5_bedrom_val = 0
        ftr_6_bedrom = '#Units-6bed'
        ftr_6_bedrom_val = 0
        ftr_batchelor = '#Units-batchelor'
        ftr_batchelor_val = 0
        #ftr_excluded_units = '#Excluded units'
        #ftr_excluded_units_val = 0
        
        
        #bdroom = str(group.at[0,'Bedrooms']).lower() #list(group['Bedrooms'])[0]
        #unitTypeY = str(group.at[0,'Unit Type_y']).lower().replace('&', '')
        #unitTypeX = str(group.at[0,'Unit Type_x']).lower().replace('&', '')
        unitType = str(group.at[0,'UnitType']).lower().replace('&', '')
        '''if bdroom=='bach':
            ftr_batchelor_val+=1
        elif bdroom=='1bd':
            ftr_1_bedrom_val+=1
        elif bdroom=='2bd':
            ftr_2_bedrom_val+=1
        elif bdroom=='3bd':
            ftr_3_bedrom_val+=1
        elif bdroom=='4bd':
            ftr_4_bedrom_val+=1
        elif bdroom=='5bd':
            ftr_5_bedrom_val+=1
        elif bdroom=='6bd':
            ftr_6_bedrom_val+=1
        elif '1br' in unitTypeY or '1brd' in unitTypeY: #br brd bac
            ftr_1_bedrom_val+=1
        elif '2br' in unitTypeY or '2brd' in unitTypeY:
            ftr_2_bedrom_val+=1
        elif '3br' in unitTypeY or '3brd' in unitTypeY:
            ftr_3_bedrom_val+=1
        elif '4br' in unitTypeY or '4brd' in unitTypeY:
            ftr_4_bedrom_val+=1
        elif '5br' in unitTypeY or '5brd' in unitTypeY:
            ftr_5_bedrom_val+=1
        elif '6br' in unitTypeY or '6brd' in unitTypeY:
            ftr_6_bedrom_val+=1
        elif 'bac' in unitTypeY:
            ftr_batchelor_val+=1
        elif '1br' in unitTypeX or '1brd' in unitTypeX: #br brd bac
            ftr_1_bedrom_val+=1
        elif '2br' in unitTypeX or '2brd' in unitTypeX:
            ftr_2_bedrom_val+=1
        elif '3br' in unitTypeX or '3brd' in unitTypeX:
            ftr_3_bedrom_val+=1
        elif '4br' in unitTypeX or '4brd' in unitTypeX:
            ftr_4_bedrom_val+=1
        elif '5br' in unitTypeX or '5brd' in unitTypeX:
            ftr_5_bedrom_val+=1
        elif '6br' in unitTypeX or '6brd' in unitTypeX:
            ftr_6_bedrom_val+=1
        elif 'bac' in unitTypeX:
            ftr_batchelor_val+=1
        '''    
        if '1br' in unitType or '1brd' in unitType: #br brd bac
            ftr_1_bedrom_val+=1
        elif '2br' in unitType or '2brd' in unitType:
            ftr_2_bedrom_val+=1
        elif '3br' in unitType or '3brd' in unitType:
            ftr_3_bedrom_val+=1
        elif '4br' in unitType or '4brd' in unitType:
            ftr_4_bedrom_val+=1
        elif '5br' in unitType or '5brd' in unitType:
            ftr_5_bedrom_val+=1
        elif '6br' in unitType or '6brd' in unitType:
            ftr_6_bedrom_val+=1
        elif 'bac' in unitType:
            ftr_batchelor_val+=1
            
        
            

            
        
        
        #ready_y = str(group.at[0,'Ready']) #list(group['Ready_y'])[0]
        
        ##print(group['Ready_y'])
        #if ready_y=='Exclude':
        #    ftr_excluded_units_val+=1
            
        #print(name, ready_y, ftr_excluded_units_val, list(set(group['Ready'])), 'Exclude' in list(set(group['Ready'])))
        
        ##print()
        
        closePharmacyDist = str(group.at[0,'closePharmacyDist'])
        pharmacy3KmRadius = int(str(group.at[0,'#pharmacy3KmRadius']).strip())
        pharmacy5KmRadius = int(str(group.at[0,'#pharmacy5KmRadius']).strip())
        pharmacy10KmRadius = int(str(group.at[0,'#pharmacy10KmRadius']).strip())
        
        closeHospitalDist = str(group.at[0,'closeHospitalDist'])
        hospital3KmRadius = int(str(group.at[0,'#hospital3KmRadius']).strip())
        hospital5KmRadius = int(str(group.at[0,'#hospital5KmRadius']).strip())
        hospital10KmRadius = int(str(group.at[0,'#hospital10KmRadius']).strip())
        
        closeSchoolDist = str(group.at[0,'closeSchoolDist'])
        school3KmRadius = int(str(group.at[0,'#school3KmRadius']).strip())
        school5KmRadius = int(str(group.at[0,'#school5KmRadius']).strip())
        school10KmRadius = int(str(group.at[0,'#school10KmRadius']).strip())
        
        closeGroceryDist = str(group.at[0,'closeGroceryDist'])
        grocery3KmRadius = int(str(group.at[0,'#grocery3KmRadius']).strip())
        grocery5KmRadius = int(str(group.at[0,'#grocery5KmRadius']).strip())
        grocery10KmRadius = int(str(group.at[0,'#grocery10KmRadius']).strip())
        
        closeConvenienceDist = str(group.at[0,'closeConvenienceDist'])
        convenience3KmRadius = int(str(group.at[0,'#convenience3KmRadius']).strip())
        convenience5KmRadius = int(str(group.at[0,'#convenience5KmRadius']).strip())
        convenience10KmRadius = int(str(group.at[0,'#convenience10KmRadius']).strip())
        
        closeWalkInDist = str(group.at[0,'closeWalkInDist'])
        walkIn3KmRadius = int(str(group.at[0,'#walkIn3KmRadius']).strip())
        walkIn5KmRadius = int(str(group.at[0,'#walkIn5KmRadius']).strip())
        walkIn10KmRadius = int(str(group.at[0,'#walkIn10KmRadius']).strip())
        
        closeBusStopDist = str(group.at[0,'closeBusStopDist'])
        busStop3KmRadius = int(str(group.at[0,'#busStop3KmRadius']).strip())
        busStop5KmRadius = int(str(group.at[0,'#busStop5KmRadius']).strip())
        busStop10KmRadius = int(str(group.at[0,'#busStop10KmRadius']).strip())
        
        closeEmergencyDist = str(group.at[0,'closeEmergencyDist'])
        emergency3KmRadius = int(str(group.at[0,'#emergency3KmRadius']).strip())
        emergency5KmRadius = int(str(group.at[0,'#emergency5KmRadius']).strip())
        emergency10KmRadius = int(str(group.at[0,'#emergency10KmRadius']).strip())
        
        closeFoodbankDist = str(group.at[0,'closeFoodbankDist'])
        foodbank3KmRadius = int(str(group.at[0,'#foodbank3KmRadius']).strip())
        foodbank5KmRadius = int(str(group.at[0,'#foodbank5KmRadius']).strip())
        foodbank10KmRadius = int(str(group.at[0,'#foodbank10KmRadius']).strip())
        
        closeSalvationArmyDist = str(group.at[0,'closeSalvationArmyDist'])
        salvationArmy3KmRadius = int(str(group.at[0,'#salvationArmy3KmRadius']).strip())
        salvationArmy5KmRadius = int(str(group.at[0,'#salvationArmy5KmRadius']).strip())
        salvationArmy10KmRadius = int(str(group.at[0,'#salvationArmy10KmRadius']).strip())
        
        closeMosqueDist = str(group.at[0,'closeMosqueDist'])
        mosque3KmRadius = int(str(group.at[0,'#mosque3KmRadius']).strip())
        mosque5KmRadius = int(str(group.at[0,'#mosque5KmRadius']).strip())
        mosque10KmRadius = int(str(group.at[0,'#mosque10KmRadius']).strip())
        
        closeSynagogueDist = str(group.at[0,'closeSynagogueDist'])
        synagogue3KmRadius = int(str(group.at[0,'#synagogue3KmRadius']).strip())
        synagogue5KmRadius = int(str(group.at[0,'#synagogue5KmRadius']).strip())
        synagogue10KmRadius = int(str(group.at[0,'#synagogue10KmRadius']).strip())
        
        closeBuddhistTempleDist = str(group.at[0,'closeBuddhistTempleDist'])
        BuddhistTemple3KmRadius = int(str(group.at[0,'#BuddhistTemple3KmRadius']).strip())
        BuddhistTemple5KmRadius = int(str(group.at[0,'#BuddhistTemple5KmRadius']).strip())
        BuddhistTemple10KmRadius = int(str(group.at[0,'#BuddhistTemple10KmRadius']).strip())
        
        
        record_count+=1
        
        if record_count%1000==0:
            print(record_count, RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_total_units, ftr_total_units_val, ftr_eff_date)
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_total_units, ftr_total_units_val, ftr_eff_date])
        if ftr_1_bedrom_val>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_1_bedrom, ftr_1_bedrom_val, ftr_eff_date])
        if ftr_2_bedrom_val>0:    
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_2_bedrom, ftr_2_bedrom_val, ftr_eff_date])
        if ftr_3_bedrom_val>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_3_bedrom, ftr_3_bedrom_val, ftr_eff_date])
        if ftr_4_bedrom_val>0:    
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_4_bedrom, ftr_4_bedrom_val, ftr_eff_date])
        if ftr_5_bedrom_val>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_5_bedrom, ftr_5_bedrom_val, ftr_eff_date])
        if ftr_6_bedrom_val>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_6_bedrom, ftr_6_bedrom_val, ftr_eff_date])
        if ftr_batchelor_val>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_batchelor, ftr_batchelor_val, ftr_eff_date])
        
        #if ftr_excluded_units_val>0:
        #list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, ftr_excluded_units, ftr_excluded_units_val, ftr_eff_date])
        
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closePharmacyDist', closePharmacyDist, ftr_eff_date])
        if pharmacy3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#pharmacy3KmRadius', pharmacy3KmRadius, ftr_eff_date])
        if pharmacy5KmRadius>0:    
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#pharmacy5KmRadius', pharmacy5KmRadius, ftr_eff_date])
        if pharmacy10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#pharmacy10KmRadius', pharmacy10KmRadius, ftr_eff_date])
        
        
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeHospitalDist', closeHospitalDist, ftr_eff_date])
        if hospital3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#hospital3KmRadius', hospital3KmRadius, ftr_eff_date])
        if hospital5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#hospital5KmRadius', hospital5KmRadius, ftr_eff_date])
        if hospital10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#hospital10KmRadius', hospital10KmRadius, ftr_eff_date])
            
            
       
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeSchoolDist', closeSchoolDist, ftr_eff_date])
        if school3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#school3KmRadius', school3KmRadius, ftr_eff_date])
        if school5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#school5KmRadius', school5KmRadius, ftr_eff_date])
        if school10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#school10KmRadius', school10KmRadius, ftr_eff_date])
            
            
            
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeGroceryDist', closeGroceryDist, ftr_eff_date])
        if grocery3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#grocery3KmRadius', grocery3KmRadius, ftr_eff_date])
        if grocery5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#grocery5KmRadius', grocery5KmRadius, ftr_eff_date])
        if grocery10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#grocery10KmRadius', grocery10KmRadius, ftr_eff_date])
        
        
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeConvenienceDist', closeConvenienceDist, ftr_eff_date])
        if convenience3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#convenience3KmRadius', convenience3KmRadius, ftr_eff_date])
        if convenience5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#convenience5KmRadius', convenience5KmRadius, ftr_eff_date])
        if convenience10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#convenience10KmRadius', convenience10KmRadius, ftr_eff_date])
        
        
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeWalkInDist', closeWalkInDist, ftr_eff_date])
        if walkIn3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#walkIn3KmRadius', walkIn3KmRadius, ftr_eff_date])
        if walkIn5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#walkIn5KmRadius', walkIn5KmRadius, ftr_eff_date])
        if walkIn10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#walkIn10KmRadius', walkIn10KmRadius, ftr_eff_date])
            
            
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeBusStopDist', closeBusStopDist, ftr_eff_date])
        if busStop3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#busStop3KmRadius', busStop3KmRadius, ftr_eff_date])
        if busStop5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#busStop5KmRadius', busStop5KmRadius, ftr_eff_date])
        if busStop10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#busStop10KmRadius', busStop10KmRadius, ftr_eff_date])
            
            
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeEmergencyDist', closeEmergencyDist, ftr_eff_date])
        if emergency3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#emergency3KmRadius', emergency3KmRadius, ftr_eff_date])
        if emergency5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#emergency5KmRadius', emergency5KmRadius, ftr_eff_date])
        if emergency10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#emergency10KmRadius', emergency10KmRadius, ftr_eff_date])
            
            
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeFoodbankDist', closeFoodbankDist, ftr_eff_date])
        if foodbank3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#foodbank3KmRadius', foodbank3KmRadius, ftr_eff_date])
        if foodbank5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#foodbank5KmRadius', foodbank5KmRadius, ftr_eff_date])
        if foodbank10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#foodbank10KmRadius', foodbank10KmRadius, ftr_eff_date])
            
            
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeSalvationArmyDist', closeSalvationArmyDist, ftr_eff_date])
        if salvationArmy3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#salvationArmy3KmRadius', salvationArmy3KmRadius, ftr_eff_date])
        if salvationArmy5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#salvationArmy5KmRadius', salvationArmy5KmRadius, ftr_eff_date])
        if salvationArmy10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#salvationArmy10KmRadius', salvationArmy10KmRadius, ftr_eff_date])
        
        
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeMosqueDist', closeMosqueDist, ftr_eff_date])
        if mosque3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#mosque3KmRadius', mosque3KmRadius, ftr_eff_date])
        if mosque5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#mosque5KmRadius', mosque5KmRadius, ftr_eff_date])
        if mosque10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#mosque10KmRadius', mosque10KmRadius, ftr_eff_date])
        
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeSynagogueDist', closeSynagogueDist, ftr_eff_date])
        if synagogue3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#synagogue3KmRadius', synagogue3KmRadius, ftr_eff_date])
        if synagogue5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#synagogue5KmRadius', synagogue5KmRadius, ftr_eff_date])
        if synagogue10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#synagogue10KmRadius', synagogue10KmRadius, ftr_eff_date])
            
            
        
        list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, 'closeBuddhistTempleDist', closeBuddhistTempleDist, ftr_eff_date])
        if BuddhistTemple3KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#BuddhistTemple3KmRadius', BuddhistTemple3KmRadius, ftr_eff_date])
        if BuddhistTemple5KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#BuddhistTemple5KmRadius', BuddhistTemple5KmRadius, ftr_eff_date])
        if BuddhistTemple10KmRadius>0:
            list_records.append([RegionalHousing, Municipality, Area, BldgComplex, Property, Unit, '#BuddhistTemple10KmRadius', BuddhistTemple10KmRadius, ftr_eff_date])
        
        
    df_ftr_vertical = pd.DataFrame(list_records, columns = ['RegionalHousing', 'Municipality', 'Area', 'BldgComplex', 'Property', 'Unit', 'Feature name', 'Feature value', 'Feature effective date'])
    
    if saveFile=='yes':
        df_ftr_vertical.to_csv('PhysicalFeatureTable.csv', index=False)
    #df_ftr_vertical.to_csv(outPhysicalFeatureTable, index=False)
    #print('----PhysicalFeatureTable done----')
    
    return df_ftr_vertical
    

##### End Transform Unit Features



#####Find Google Place Distance    

def summerizeDistance(df_coor1, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius):

    #print("lat","\t", "long","\t", "lat_g","\t", "long_g","\t", "closeDist","\t", "postCode","\t", "address", "\t","businessname","\t", "dist","\t", "dist3Count","\t", "dist5Count","\t", "dist10Count")
    
    for i in df_coor1.index:
        lat = df_coor1.at[i, latCol]
        long = df_coor1.at[i, lonCol]
        
        closeDist = 10000000000
        dist3Count = 0
        dist5Count = 0
        dist10Count = 0
        
        for j in df_googlePlace.index:
            lat_g = df_googlePlace.at[j, "lat_coor"]
            long_g = df_googlePlace.at[j, "long_coor"]
            
            dist = haversine((lat, long), (lat_g, long_g)) #getPathLength(lat, long, lat_g, long_g)# distance(lat, long, lat_g, long_g)
            
            if dist!=0 and closeDist>dist:
                closeDist = dist
                
            if dist!=0 and dist<=3:
                dist3Count+=1
            
            if dist!=0 and dist<=5:
                dist5Count+=1
                
            if dist!=0 and dist<=10:
                dist10Count+=1
                
            #print(lat, "\t", long, "\t",lat_g, "\t",long_g, "\t",closeDist, "\t",df_googlePlace.at[j, "postCode"], "\t",df_googlePlace.at[j, "address"], "\t", df_googlePlace.at[j, "businessname"], "\t",dist, "\t",dist3Count, "\t",dist5Count,"\t", dist10Count)    
        if i%1000==0:        
            print(i, lat, long, closeDist, dist3Count, dist5Count, dist10Count)
        df_coor1.at[i, closePlaceColumn] = closeDist
        df_coor1.at[i, numberDist3Radius] = dist3Count
        df_coor1.at[i, numberDist5Radius] = dist5Count
        df_coor1.at[i, numberDist10Radius] = dist10Count
        
        
        
    #print(df_coor1)
    
    return df_coor1   
  


def find_google_place_distance(df_coor):
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='pharmacy_DONE')
    closePlaceColumn= "closePharmacyDist"
    numberDist3Radius = "#pharmacy3KmRadius"
    numberDist5Radius = "#pharmacy5KmRadius"
    numberDist10Radius = "#pharmacy10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    #find close hospital from unit
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='hospital_done')
    closePlaceColumn= "closeHospitalDist"
    numberDist3Radius = "#hospital3KmRadius"
    numberDist5Radius = "#hospital5KmRadius"
    numberDist10Radius = "#hospital10KmRadius"
    latCol = "zzLat_final" 
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='school_done')
    closePlaceColumn= "closeSchoolDist"
    numberDist3Radius = "#school3KmRadius"
    numberDist5Radius = "#school5KmRadius"
    numberDist10Radius = "#school10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='grocery store_done')
    closePlaceColumn= "closeGroceryDist"
    numberDist3Radius = "#grocery3KmRadius"
    numberDist5Radius = "#grocery5KmRadius"
    numberDist10Radius = "#grocery10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='convenience store_done')
    closePlaceColumn= "closeConvenienceDist"
    numberDist3Radius = "#convenience3KmRadius"
    numberDist5Radius = "#convenience5KmRadius"
    numberDist10Radius = "#convenience10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='walk in clinic_done')
    closePlaceColumn= "closeWalkInDist"
    numberDist3Radius = "#walkIn3KmRadius"
    numberDist5Radius = "#walkIn5KmRadius"
    numberDist10Radius = "#walkIn10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='childcare_done')
    closePlaceColumn= "closeChildcareDist"
    numberDist3Radius = "#childcare3KmRadius"
    numberDist5Radius = "#childcare5KmRadius"
    numberDist10Radius = "#childcare10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
   
   
   
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='bus stop_done')
    closePlaceColumn= "closeBusStopDist"
    numberDist3Radius = "#busStop3KmRadius"
    numberDist5Radius = "#busStop5KmRadius"
    numberDist10Radius = "#busStop10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='emergency room_DONE')
    closePlaceColumn= "closeEmergencyDist"
    numberDist3Radius = "#emergency3KmRadius"
    numberDist5Radius = "#emergency5KmRadius"
    numberDist10Radius = "#emergency10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='food bank_DONE')
    closePlaceColumn= "closeFoodbankDist"
    numberDist3Radius = "#foodbank3KmRadius"
    numberDist5Radius = "#foodbank5KmRadius"
    numberDist10Radius = "#foodbank10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='salvation army_DONE')
    closePlaceColumn= "closeSalvationArmyDist"
    numberDist3Radius = "#salvationArmy3KmRadius"
    numberDist5Radius = "#salvationArmy5KmRadius"
    numberDist10Radius = "#salvationArmy10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='mosque_DONE')
    closePlaceColumn= "closeMosqueDist"
    numberDist3Radius = "#mosque3KmRadius"
    numberDist5Radius = "#mosque5KmRadius"
    numberDist10Radius = "#mosque10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='synagogue_DONE')
    closePlaceColumn= "closeSynagogueDist"
    numberDist3Radius = "#synagogue3KmRadius"
    numberDist5Radius = "#synagogue5KmRadius"
    numberDist10Radius = "#synagogue10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    
    
    
    df_googlePlace = pd.read_excel(in_googlePlace, sheet_name='buddhist temple_DONE')
    closePlaceColumn= "closeBuddhistTempleDist"
    numberDist3Radius = "#BuddhistTemple3KmRadius"
    numberDist5Radius = "#BuddhistTemple5KmRadius"
    numberDist10Radius = "#BuddhistTemple10KmRadius"
    latCol = "zzLat_final" #find close hospital from unit
    lonCol = "zzLon_final"
    df_coor[closePlaceColumn]=''
    df_coor[numberDist3Radius]=''
    df_coor[numberDist5Radius]=''
    df_coor[numberDist10Radius]=''
    df_coor = summerizeDistance(df_coor, df_googlePlace, latCol, lonCol, closePlaceColumn, numberDist3Radius, numberDist5Radius, numberDist10Radius)
    
    if saveFile=='yes':
        df_coor.to_csv(outPutGeoTable, index=False)
    
    return df_coor

#####End Find Google Place Distance    
    

#### Fill missing cols
    
def fillSingleCol(df, fromCol, toCol):
    df = df.reset_index(drop=True)
    
    for i in df.index:
    
        if str(df.at[i, toCol]).strip()!='nan' and str(df.at[i, toCol]).strip()!='':
            continue
    
        if str(df.at[i, fromCol]).strip()!='nan' and str(df.at[i, fromCol]).strip()!='':
            print('fillSingleCol', fromCol, toCol)
            df.at[i, toCol] = df.at[i, fromCol]
       
    return df
    
    
def fill_missing_cols(df):
    
    df.drop('RegionalHousing', axis=1, inplace=True)
    df.rename(columns={'RHA': 'RegionalHousing'}, inplace=True)
    
    print(df)
    
    
    df = fillSingleCol(df, 'Division-Unit', 'Municipality')
    df = fillSingleCol(df, 'SubDivision-Unit', 'Area')  
    df = fillSingleCol(df, 'Unit', 'BldgComplex')  
     
    return df
    
#### End Fill missing cols   



######Preprocess UnitCoorFile###
def preprocessUnitCoorFile():
    if path.exists(outPutGeoTable):
        os.remove(outPutGeoTable)
    

    df = pd.read_csv(InputUnitDirectory_flat_coordinate)

    df['Property']=df['Property'].str.strip()
    df['Unit']=df['Unit'].str.strip()
    df['Address']=df['Address'].str.strip()
    df['City']=df['City'].str.strip()
    df['PostalCode']=df['PostalCode'].str.strip()
    df['ResidentialType']=df['ResidentialType'].str.strip()
    df['HousingProgram']=df['HousingProgram'].str.strip()
    df['RegionalHousing']=df['RegionalHousing'].str.strip()
    df['Municipality']=df['Municipality'].str.strip()
    df['Area']=df['Area'].str.strip()
    df['BldgComplex']=df['BldgComplex'].str.strip()
    df['BuildingType']=df['BuildingType'].str.strip()
    df['PropertyType']=df['PropertyType'].str.strip()
    df['UnitType']=df['UnitType'].str.strip()
    
    return df


######End Preprocess UnitCoorFile###
    
if __name__ == '__main__':

    df_geo_table = preprocessUnitCoorFile()
    
    #df_geo_table = extract_rha_cd_csd(df_geo_table, DivisionCol, SubDivisionCol, CDCol, CSDCol, latCol, longCol, saveRHA)
    
    #df_geo_table = extract_ed(df_geo_table, EDCol, EDNo, latCol, longCol)
    
    df_geo_table = extract_municipality(df_geo_table, MunIdCol, MunNameCol, latCol, longCol)

    #df_geo_table = fill_missing_cols(df_geo_table)

    #df_geo_table = find_google_place_distance(df_geo_table)
    
    #df_ftr_vertical = transForm_Unit_feature(df_geo_table)
    
    #insert_geo_table(df_geo_table)
    
    #insert_Unit_feature(df_ftr_vertical)
    
    