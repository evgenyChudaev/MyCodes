import pandas as pd
import glob
import re
from csv import reader
import numpy as np
from os import path
import os
import cx_Oracle
import traceback
import sys

saveDatabase = sys.argv[1].split('=')[1]
saveFile = sys.argv[2].split('=')[1] 

waitlist_files = 'Path_waitlist.csv'

dic_rhabld__cd_csd_ed={}

########Data Manipulation in Oracle

CONN_INFO = {
    'host':	'dbo08n.cio.gov.ns.ca',
    'port':	1521,
    'user':	'HOUSING_WORK',
    'psw':	'0Summer+=*',
    'service':	'DWH01_NPR'
}

CONN_STR = '{user}/{psw}@{host}:{port}/{service}'.format(**CONN_INFO)

class Oracle_DB:
    def __init__(self):
        self.conn = cx_Oracle.connect(CONN_STR)
        self.conn.autocommit = True  # autocommit attribute will ensure transactions are automatically committed . This reduces database load and eliminates the round-trip to the DB

    def query(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            result = cursor.execute(query, kwargs).fetchall()
            response = 'SUCCESS', result
        except:
            response = 'FAILED 	{}'.format(traceback.format_exc()), None
        finally:
            cursor.close()
        return response

    def insert(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.executemany(query, kwargs.get('values', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def update(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs.get('params', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def delete(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs)
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

########End Data Manipulation in Oracle


########Helper functions

def trim_all_columns(df):
    trim_strings = lambda x: x.strip() if isinstance(x, str) else x
    return df.applymap(trim_strings)

def convertNumber(s):
    s = str(s).strip()
    try:
        return int(float(s))
    except Exception as e:
        print('parse error: s', s)
        return None

########End Helper functions


########### Calculate Demands
    
    
def UpdateApplicantType(df):
    #print("df['Household Size']",df['Household Size'])
    
    Household_Size = convertNumber(df['Household Size'])
    Age = convertNumber(df['Age'])
    
    if Household_Size > 2:
        applicantType = 'Family'
    elif Household_Size == 2 and df['Marital Status'] not in ('Married', 'Common Law'):
        applicantType = 'Family'
    elif Age < 58 and Household_Size <= 2:
        applicantType = 'Non-Elderly'
    elif Age >= 58 and Household_Size <= 2:
        applicantType = 'Senior'
    else:
        applicantType = 'na'

    return applicantType

def summarizeDemandBuilding(df_geo_table_gr, demandCols, DemandTotal, DemandWheelchair, DemandParaplegic, DemandGroundFloor, DemandSupports, DemandHearingImpaired, DemandVisuallyImpaired):
    
    
    list_rows = []
    for rha_y_m, group in df_geo_table_gr:
        rha = rha_y_m[0]
        mn = rha_y_m[1]
        ar = rha_y_m[2]
        bld = rha_y_m[3]
        y = rha_y_m[4]
        m = rha_y_m[5]
        
        geo_key = rha+"_"+mn+"_"+ar+"_"+bld
        
        #group by HNS_Client_Type and Applicant ID
        group_Client_Type = group.groupby(['HNS_Client_Type'])
        for Client_Type, gr_ct in group_Client_Type:
            
            demandTotal = len(set(list(gr_ct['Applicant ID'])))
            demandWheelchair=0
            demandParaplegic=0
            demandGroundFloor=0
            demandSupports=0
            demandHearingImpaired=0
            demandVisuallyImpaired=0
            
            group_app = gr_ct.groupby(['Applicant ID'])
            
            for appId, gr_app in group_app:
                Wheelchair = list(set(gr_app['Wheelchair']))
                Paraplegic = list(set(gr_app['Paraplegic']))
                GroundFloor = list(set(gr_app['Ground Floor']))                    
                Supports = list(set(gr_app['Supports']))        
                HearingImpaired = list(set(gr_app['Hearing Impaired']))        
                VisuallyImpaired = list(set(gr_app['Visually Impaired']))

                if 'yes' in Wheelchair:
                    demandWheelchair+=1 
                if 'yes' in Paraplegic:
                    demandParaplegic+=1
                if 'yes' in GroundFloor:
                    demandGroundFloor+=1 
                if 'yes' in Supports:
                    demandSupports+=1 
                if 'yes' in HearingImpaired:
                    demandHearingImpaired+=1 
                if 'yes' in VisuallyImpaired:
                    demandVisuallyImpaired+=1 
                        
            
            
            list_rows.append([geo_key, y, m, Client_Type, DemandTotal,  demandTotal])
            list_rows.append([geo_key, y, m, Client_Type, DemandWheelchair,  demandWheelchair])
            list_rows.append([geo_key, y, m, Client_Type, DemandParaplegic,  demandParaplegic])
            list_rows.append([geo_key, y, m, Client_Type, DemandGroundFloor,  demandGroundFloor])
            list_rows.append([geo_key, y, m, Client_Type, DemandSupports,  demandSupports])
            list_rows.append([geo_key, y, m, Client_Type, DemandHearingImpaired,  demandHearingImpaired])
            list_rows.append([geo_key, y, m, Client_Type, DemandVisuallyImpaired,  demandVisuallyImpaired])
    
    
    df = pd.DataFrame(list_rows, columns=demandCols)
    
    
    return df

    
def summarizeDemand(df_geo_table_gr, demandCols, DemandTotal, DemandWheelchair, DemandParaplegic, DemandGroundFloor, DemandSupports, DemandHearingImpaired, DemandVisuallyImpaired):
    
    
    list_rows = []
    for geocode_y_m, group in df_geo_table_gr:
        geocode = geocode_y_m[0]
        y = geocode_y_m[1]
        m = geocode_y_m[2]
        
        
        
        #group by HNS_Client_Type and Applicant ID
        group_Client_Type = group.groupby(['HNS_Client_Type'])
        for Client_Type, gr_ct in group_Client_Type:
            
            demandTotal = len(set(list(gr_ct['Applicant ID'])))
            demandWheelchair=0
            demandParaplegic=0
            demandGroundFloor=0
            demandSupports=0
            demandHearingImpaired=0
            demandVisuallyImpaired=0
            
            group_app = gr_ct.groupby(['Applicant ID'])
            
            for appId, gr_app in group_app:
                Wheelchair = list(set(gr_app['Wheelchair']))
                Paraplegic = list(set(gr_app['Paraplegic']))
                GroundFloor = list(set(gr_app['Ground Floor']))                    
                Supports = list(set(gr_app['Supports']))        
                HearingImpaired = list(set(gr_app['Hearing Impaired']))        
                VisuallyImpaired = list(set(gr_app['Visually Impaired']))

                if 'yes' in Wheelchair:
                    demandWheelchair+=1 
                if 'yes' in Paraplegic:
                    demandParaplegic+=1
                if 'yes' in GroundFloor:
                    demandGroundFloor+=1 
                if 'yes' in Supports:
                    demandSupports+=1 
                if 'yes' in HearingImpaired:
                    demandHearingImpaired+=1 
                if 'yes' in VisuallyImpaired:
                    demandVisuallyImpaired+=1 
                        
            
            list_rows.append([geocode, y, m, Client_Type, DemandTotal,  demandTotal])
            list_rows.append([geocode, y, m, Client_Type, DemandWheelchair,  demandWheelchair])
            list_rows.append([geocode, y, m, Client_Type, DemandParaplegic,  demandParaplegic])
            list_rows.append([geocode, y, m, Client_Type, DemandGroundFloor,  demandGroundFloor])
            list_rows.append([geocode, y, m, Client_Type, DemandSupports,  demandSupports])
            list_rows.append([geocode, y, m, Client_Type, DemandHearingImpaired,  demandHearingImpaired])
            list_rows.append([geocode, y, m, Client_Type, DemandVisuallyImpaired,  demandVisuallyImpaired])
    
    df = pd.DataFrame(list_rows, columns=demandCols)
    
    
    return df
    
def isEmptyColumn(col):
    if col.isnull().all():
        return True
        
    vals = list(set(list(col)))
    print('len(vals)', len(vals), 'len(vals[0])', len(vals[0]))
    
    if len(vals)==1 and len(vals[0])==0:    
        return True
        
    return False
        
    
def SummarizeYrMn(df_all_waitlist, df_geo_table):
    df_all_waitlist['HNS_Client_Type'] = df_all_waitlist.apply(UpdateApplicantType, axis=1)
    
    dic_rhabld__cd_csd_ed.clear()
    
    #df_all_waitlist = df_all_waitlist.reset_index(drop=True)
    
    
    dm_rha=None
    dm_cd=None 
    dm_csd=None
    dm_ed=None
    dm_bldx = None
    
    
    

    print(df_all_waitlist)
    wailist_cols = df_all_waitlist.columns.tolist()
 
    print("df_all_waitlist['Municipality'].isnull().all()", df_all_waitlist['Municipality'].isnull().all())
    print("df_all_waitlist['Area'].isnull().all()", df_all_waitlist['Area'].isnull().all())
    
    print(set(list(df_all_waitlist['Municipality'])))
    print(set(list(df_all_waitlist['Area'])))
    
    if isEmptyColumn(df_all_waitlist['Municipality']) and isEmptyColumn(df_all_waitlist['Area']):
        df_all_waitlist = pd.merge(df_all_waitlist, df_geo_table, left_on=['RHA', 'Building Complex'], right_on=['Regional_Housing', 'Bldg_Complex'], how='left')
        
        print('after merge cols', df_all_waitlist.columns.tolist())
        
        print(df_all_waitlist['Municipality_x'])
        print(df_all_waitlist['Municipality_y'])
        
        df_all_waitlist.drop('Municipality_x', axis=1, inplace=True)
        df_all_waitlist.drop('Area_x', axis=1, inplace=True)
        
        df_all_waitlist = df_all_waitlist.rename({'Municipality_y': 'Municipality', 'Area_y': 'Area'}, axis=1)
        
        
        
    else:
        df_all_waitlist = pd.merge(df_all_waitlist, df_geo_table, left_on=['RHA', 'Municipality', 'Area', 'Building Complex'], right_on=['Regional_Housing', 'Municipality', 'Area', 'Bldg_Complex'], how='left')
    
    
    df_all_waitlist= df_all_waitlist[wailist_cols+['CD_Unit', 'CSD_Unit', 'EDNo_Unit']]
    df_all_waitlist = df_all_waitlist.rename({'CD_Unit': 'CD_UNIT', 'CSD_Unit': 'CSD_UNIT', 'EDNo_Unit':'EDNO_UNIT'}, axis=1)
    
    print(df_all_waitlist)
    
    
    
    
    
    
    #df_all_waitlist.to_csv('AllWaitListGEO_CD_CSD_EDNo.csv', index=False)
    df_base1 = df_all_waitlist.copy()
    df_base2 = df_all_waitlist.copy()
    df_base3 = df_all_waitlist.copy()
    
    
    
    
    ####RHA####
    df_AllWaitListGEO_CD_CSD_EDNo = df_base1

    
    #df_AllWaitListGEO_CD_CSD_EDNo.drop_duplicates(['Applicant ID', 'RHA'], keep='first', inplace = True)
    df_AllWaitListGEO_CD_CSD_EDNo.drop_duplicates(['Applicant ID'], keep='first', inplace = True)
    
    
    
    
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['RHA', 'year', 'month'])
    dm_rha = summarizeDemand(df_geo_table_gr, ["RHA", "Year", "Month", "Client_Type",  "DemandType", "DemandValue"], 'DemandTotal', 'DemandWheelchair', 'DemandParaplegic', 'DemandGroundFloor', 'DemandSupports', 'DemandHearingImpaired', 'DemandVisuallyImpaired')
        
    ####End RHA####
    
    
    ##Approve
    ####CD_UNIT####
    
    df_AllWaitListGEO_CD_CSD_EDNo = df_base2
    
    df_AllWaitListGEO_CD_CSD_EDNo = df_AllWaitListGEO_CD_CSD_EDNo[df_AllWaitListGEO_CD_CSD_EDNo['Approved']=='Yes']
    
    
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['CD_UNIT', 'year', 'month'])    
    dm_cd_app = summarizeDemand(df_geo_table_gr, ["CD", "Year", "Month", "Client_Type",  "DemandType", "DemandValue"], 'DemandTotal_Approve', 'DemandWheelchair_Approve', 'DemandParaplegic_Approve', 'DemandGroundFloor_Approve', 'DemandSupports_Approve', 'DemandHearingImpaired_Approve', 'DemandVisuallyImpaired_Approve')
    ####End CD_UNIT####
    
    
    ####CSD_UNIT####
    
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['CSD_UNIT', 'year', 'month'])
    dm_csd_app = summarizeDemand(df_geo_table_gr, ["CSD", "Year", "Month", "Client_Type",  "DemandType", "DemandValue"], 'DemandTotal_Approve', 'DemandWheelchair_Approve', 'DemandParaplegic_Approve', 'DemandGroundFloor_Approve', 'DemandSupports_Approve', 'DemandHearingImpaired_Approve', 'DemandVisuallyImpaired_Approve')
    ####End CSD_UNIT####
    
    
    ####EDNO_UNIT####
   
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['EDNO_UNIT', 'year', 'month'])  
    dm_ed_app = summarizeDemand(df_geo_table_gr, ["EDNO", "Year", "Month", "Client_Type", "DemandType", "DemandValue"], 'DemandTotal_Approve', 'DemandWheelchair_Approve', 'DemandParaplegic_Approve', 'DemandGroundFloor_Approve', 'DemandSupports_Approve', 'DemandHearingImpaired_Approve', 'DemandVisuallyImpaired_Approve')
    
        
    ####End EDNO_UNIT####
    
    
    ####bld complex
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['RHA', 'Municipality', 'Area', 'Building Complex', 'year', 'month'])
    dm_bldx_app = summarizeDemandBuilding(df_geo_table_gr, ["Rha|Mun|Are|Bld", "Year", "Month", "Client_Type", "DemandType", "DemandValue"], 'DemandTotal_Approve', 'DemandWheelchair_Approve', 'DemandParaplegic_Approve', 'DemandGroundFloor_Approve', 'DemandSupports_Approve', 'DemandHearingImpaired_Approve', 'DemandVisuallyImpaired_Approve')
    
    ####End bld complex 
    ###End Approve
    
    
    
    
    
    
    
    ####(approved | not approved)#####
    
    
    
    df_AllWaitListGEO_CD_CSD_EDNo = df_base3
    
    ##CD
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['CD_UNIT', 'year', 'month'])    
    dm_cd = summarizeDemand(df_geo_table_gr, ["CD", "Year", "Month", "Client_Type",  "DemandType", "DemandValue"], 'DemandTotal', 'DemandWheelchair', 'DemandParaplegic', 'DemandGroundFloor', 'DemandSupports', 'DemandHearingImpaired', 'DemandVisuallyImpaired')
    ##End CD
    
    ##CSD
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['CSD_UNIT', 'year', 'month'])    
    dm_csd = summarizeDemand(df_geo_table_gr, ["CSD", "Year", "Month", "Client_Type",  "DemandType", "DemandValue"], 'DemandTotal', 'DemandWheelchair', 'DemandParaplegic', 'DemandGroundFloor', 'DemandSupports', 'DemandHearingImpaired', 'DemandVisuallyImpaired')
    ##End CSD
    
    ##ED
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['EDNO_UNIT', 'year', 'month'])
    dm_ed = summarizeDemand(df_geo_table_gr, ["EDNO", "Year", "Month", "Client_Type",  "DemandType", "DemandValue"], 'DemandTotal', 'DemandWheelchair', 'DemandParaplegic', 'DemandGroundFloor', 'DemandSupports', 'DemandHearingImpaired', 'DemandVisuallyImpaired')
    ##End ED
    
    ##bld complex 
    df_geo_table_gr = df_AllWaitListGEO_CD_CSD_EDNo.groupby(['RHA', 'Municipality', 'Area', 'Building Complex', 'year', 'month'])
    dm_bldx = summarizeDemandBuilding(df_geo_table_gr, ["Rha|Mun|Are|Bld", "Year", "Month", "Client_Type", "DemandType", "DemandValue"], 'DemandTotal', 'DemandWheelchair', 'DemandParaplegic', 'DemandGroundFloor', 'DemandSupports', 'DemandHearingImpaired', 'DemandVisuallyImpaired')
    ##end bld complex 
    
    ##end (approved | not approved)
    
    dm_cd = pd.concat([dm_cd_app, dm_cd])
    dm_csd = pd.concat([dm_csd_app, dm_csd])
    dm_ed = pd.concat([dm_ed_app, dm_ed])
    dm_bldx = pd.concat([dm_bldx_app, dm_bldx])
    
    return [dm_rha, dm_cd, dm_csd, dm_ed, dm_bldx]

def addNames(df, code, df_code_Name, name_code, name_name):
    print('addNames')
    print(df[code])
    print(df_code_Name[name_code])
    #df_code_Name[name_code] = pd.to_numeric(df_code_Name[name_code], downcast="float")
    #print(df_code_Name[name_code])
    
    df = pd.merge(df, df_code_Name, left_on=[code], right_on=[name_code], how='left')
    df.drop(name_code, axis=1, inplace=True)
    
    print(df)

    return df    
   
def calculate_demand(df_all_waitlist):
    
    myDb = Oracle_DB()
    select_result = myDb.query("select Regional_Housing, Municipality, Area, Bldg_Complex, Property, Unit#, UNIT_LAT, UNIT_LON, CSD_Unit, SubDivision_Unit, CD_Unit, Division_Unit, EDNo_Unit, EDName_Unit, Property_lat,	Property_lon, CSD_Property,  SubDivision_Property, CD_Property, 	Division_Property, EDNo_Property,	EDName_Property,  BldComplex_lat,	BldComplex_lon, CSD_BldComplex, SubDivision_BldComplex, CD_BldComplex,	Division_BldComplex, EDNo_BldComplex,	EDName_BldComplex, Program_Type, Postal_Code, Address_1 from dl_geotable")
    list_geo_table = select_result[1]
    df_geo_table = pd.DataFrame(list_geo_table, columns = ['Regional_Housing','Municipality','Area','Bldg_Complex','Property','Unit#','UNIT_LAT','UNIT_LON','CSD_Unit','SubDivision_Unit','CD_Unit','Division_Unit','EDNo_Unit','EDName_Unit','Property_lat',	'Property_lon','CSD_Property',' SubDivision_Property','CD_Property','Division_Property','EDNo_Property',	'EDName_Property',' BldComplex_lat',	'BldComplex_lon','CSD_BldComplex','SubDivision_BldComplex','CD_BldComplex',	'Division_BldComplex','EDNo_BldComplex',	'EDName_BldComplex','Program_Type','Postal_Code','Address_1'])

    
    #df_geo_table.to_csv('temp_df_geo_table.csv', index=False)
    
    df_CD_CDName = df_geo_table[['CD_Unit', 'Division_Unit' ]]
    df_CSD_CSDName = df_geo_table[['CSD_Unit', 'SubDivision_Unit' ]]
    df_ED_EDName = df_geo_table[['EDNo_Unit', 'EDName_Unit' ]]
    
    df_CD_CDName = df_CD_CDName.rename({'CD_Unit': 'CD_UNIT'}, axis=1)
    df_CSD_CSDName = df_CSD_CSDName.rename({'CSD_Unit': 'CSD_UNIT'}, axis=1)
    df_ED_EDName = df_ED_EDName.rename({'EDNo_Unit':'EDNO_UNIT'}, axis=1)
    
    df_CD_CDName.drop_duplicates(['CD_UNIT'], keep='first', inplace = True)
    df_CSD_CSDName.drop_duplicates(['CSD_UNIT'], keep='first', inplace = True)
    df_ED_EDName.drop_duplicates(['EDNO_UNIT'], keep='first', inplace = True)
    
    print('df_all_waitlist')
    print(df_all_waitlist)
    
    df_yr_mn = df_all_waitlist.groupby(['year', 'month'])
    
    list_dm_rha=[]
    list_dm_cd=[] 
    list_dm_csd=[]
    list_dm_ed = []
    list_dm_bldx = []
    for name, group in df_yr_mn:
        dm_rha, dm_cd, dm_csd, dm_ed, dm_bldx = SummarizeYrMn(group, df_geo_table)
        list_dm_rha.append(dm_rha)
        list_dm_cd.append(dm_cd)
        list_dm_csd.append(dm_csd)
        list_dm_ed.append(dm_ed)
        list_dm_bldx.append(dm_bldx)
        
    
    df_dm_rha = pd.concat(list_dm_rha)
    if saveFile=='yes':
        df_dm_rha.to_csv('Demands_RHA.csv', index=False)
    
    
    
    df_dm_cd = pd.concat(list_dm_cd) 
    df_dm_cd = addNames(df_dm_cd, 'CD', df_CD_CDName, 'CD_UNIT', 'Division_Unit')
    if saveFile=='yes':
        df_dm_cd.to_csv('Demands_CD.csv', index=False)    
    
    
    
    
    
    df_dm_csd = pd.concat(list_dm_csd)    
    df_dm_csd = pd.merge(df_dm_csd, df_CSD_CSDName, left_on=['CSD'], right_on=['CSD_UNIT'], how='left')
    df_dm_csd.drop('CSD_UNIT', axis=1, inplace=True)
    if saveFile=='yes':
        df_dm_csd.to_csv('Demands_CSD.csv', index=False)
    
    
    df_dm_ed = pd.concat(list_dm_ed)
    #df_dm_ed = pd.merge(df_dm_ed, df_ED_EDName, left_on=['EDNO'], right_on=['EDNO_UNIT'], how='left')
    if saveFile=='yes':
        df_dm_ed.to_csv('Demands_ED.csv', index=False)
    
    df_dm_bld = pd.concat(list_dm_bldx)
    if saveFile=='yes':
        df_dm_bld.to_csv('Demands_BldComplx.csv', index=False)
    
    return [df_dm_rha, df_dm_cd, df_dm_csd, df_dm_ed, df_dm_bld]
    
   
  


########### End Calculate Demands


########### Combine waitlists

def FilterCommonEligibleApplicants(df):
    #df = df.query('HILS != "Yes" & (Application Status == "Eligible")& Transfer != "Yes"')
    #df = df.query('HILS != "Yes" & (Application_Status == "Eligible")& Transfer != "Yes"')
    df = df[(df["Over HILS"] != "Yes") & (df["Applicant Status"] == "Eligible") & (df["Transfer"] != "Yes")]
    
    return df
    
###
#[3:38 p.m.] Chudaev, Evgeny
#So, you need to change the function in a way that keeps only properties that are in one of the PH program list

#[3:38 p.m.] Chudaev, Evgeny
#and eliminates all other rows not pertinent to this.

#[3:39 p.m.] Chudaev, Evgeny
#They way I did before was for a different purpose and it worked, but not for the county/csd

#[3:40 p.m.] Chudaev, Evgeny
#So, you can change whatever you need in the function or any other code to produce the desired result. The desired result is demand for Public Housing buildings (list of programs you have mentioned) at CD/CSD level.
###


def filter_rent_supp_only(df):
    
    df['PH_Counter'] = np.where(
        df['Program'].isin(['RNH', 'Public Housing', 'AHP - Affordable Housing Progr', 'Other', 'LP - Lease Purchase', 'Demo']),
        1, 0)
    df_group_by_counter = df.groupby(['Applicant ID', 'RHA']).agg({'PH_Counter': 'sum'}).reset_index()
    df_group_by_counter = df_group_by_counter.loc[df_group_by_counter['PH_Counter'] > 0]
    # df_group_by_counter.to_csv(OUTPUT_PATH + 'RS_Only3.csv')
    df_no_rent_supps_only = pd.merge(df, df_group_by_counter, on=['Applicant ID', 'RHA'], how='inner')
    
    df_no_rent_supps_only.to_csv('waitlist_final1.csv', index=False)
    
    #df_no_rent_supps_only = df
    df_no_rent_supps_only = df_no_rent_supps_only[df_no_rent_supps_only.Program.isin([ 'Public Housing', 'RNH', 'AHP - Affordable Housing Progr', 'Other', 'LP - Lease Purchase', 'Demo'])]
    
    df_no_rent_supps_only.to_csv('waitlist_final2.csv', index=False)
    
    return df_no_rent_supps_only

def SplitUnitType(row):
    
    Wheelchair = 'No'
    Paraplegic = 'No'
    GroundFloor = 'No'
    Supports = 'No'
    HearingImpaired = 'No'
    VisuallyImpaired = 'No'

    unitType_str = str(row['Unit Type']).strip().lower()

    if 'wheelchair' in unitType_str:
        Wheelchair = 'yes'
    if 'paraplegic' in unitType_str:
        Paraplegic = 'yes'
    if 'ground floor' in unitType_str:
        GroundFloor = 'yes'
    if 'supports' in unitType_str:
        Supports = 'yes'
    if 'hearing impaired' in unitType_str:
        HearingImpaired = 'yes'
    if 'visually impaired' in unitType_str:
        VisuallyImpaired = 'yes'
        
    

    return [Wheelchair, Paraplegic, GroundFloor, Supports, HearingImpaired, VisuallyImpaired]


def adjust_columns(df_wList, source_col_names_toCheck, target_col_names):
    print('len(list(df_wList.columns)), len(list(source_col_names_toCheck)), len(list(target_col_names))', len(list(df_wList.columns)), len(list(source_col_names_toCheck)), len(list(target_col_names)))
    
    print(list(df_wList.columns))
    
    if len(list(df_wList.columns))>len(list(source_col_names_toCheck)):
        extra_cols = len(list(df_wList.columns)) - len(list(source_col_names_toCheck))
        df_wList = df_wList.iloc[: , :-extra_cols]
    elif len(list(df_wList.columns))<len(list(source_col_names_toCheck)):
        #'Status.3', 'Met', 'Selected', 'Approved', 'Deny', 'Denied', 'Priority', 'Area', 'Municipality'
        if 'Status.3' not in list(df_wList.columns):
            df_wList['Status.3'] = ''
        if 'Met' not in list(df_wList.columns):
            df_wList['Met'] = ''
        if 'Selected' not in list(df_wList.columns):
            df_wList['Selected'] = ''
        if 'Approved' not in list(df_wList.columns):
            df_wList['Approved'] = ''
        if 'Deny' not in list(df_wList.columns):
            df_wList['Deny'] = ''
        if 'Denied' not in list(df_wList.columns):
            df_wList['Denied'] = ''
        if 'Priority' not in list(df_wList.columns):
            df_wList['Priority'] = ''        
        if 'Area' not in list(df_wList.columns):
            df_wList['Area'] = ''
        if 'Municipality' not in list(df_wList.columns):
            df_wList['Municipality'] = ''
    
    df_wList.columns = target_col_names  
    
    return df_wList

def read_csv_dynamic(filePath):

    with open(filePath, 'r') as read_obj:
        # pass the file object to reader() to get the reader object
        csv_reader = reader(read_obj)
        # Iterate over each row in the csv using reader object
        i=-1
        for row in csv_reader:
            # row variable is a list that represents a row in csv
            print(row)
            i+=1
            
            x = re.search("^a\d{7,7}$", row[0])
            if x:
                print('AppID found Front', i)
                skiprows = list(range(0, i-1))
                df = pd.read_csv(filePath,  skiprows=skiprows, engine='python')
                #print(df)
                for j in range(1,10):
                    print(j, str(df.iat[-j,0]))
                    y = re.search("^a\d{7,7}$", str(df.iat[-j,0]))
                    if y:
                        print('AppID found Tail')
                        df.drop(df.tail(j-1).index,inplace=True)
                        
                        return df
                        #break
                break

    
    return None
    
def read_files_dynamic(fileList):
    
    source_col_names_toCheck = ['ID', 'Program', 'RHA', 'Complex', 'For Complex', 'Type', 'HILS', 'Gross Income', 'Gross Income.1', 'Receives IA', 'Size', 'Status', 'Age', 'Gender', 'Status.1', 'Status.2', 'Status is Other', 'Owner', 'Student', 'City', 'Code', 'Applied', 'Size Min - Max', 'Type.1', 'Transfer', 'Access', 'of Refusals', 'For Refusals', 'Status.3', 'Met', 'Selected', 'Approved', 'Deny', 'Denied', 'Priority', 'Area', 'Municipality']
    
    target_col_names = ["Applicant ID", "Program", "RHA", "Building Complex", "Approved", "Applicant Type",
                                  "Over HILS", "App Monthly Gross Income", "RGI Monthly Gross Income",
                                  "Primary Receives IA",
                                  "Household Size", "Applicant Status", "Age", "Gender", "Marital Status",
                                  "Resident Status", "If Resident Status is Other", "Home Owner", "Student",
                                  "Current City",
                                  "Postal Code", "Date Applied", "Unit Qualified Size Min - Max", "Unit Type",
                                  "Transfer",
                                  "Priority Access", "Number of Refusals", "Reasons For Refusals", "Date Status", "Residency Met", "Date Selected", "Date Approved", "Deny", "Date Denied", "Date Priority", "Area",
                                  "Municipality"
                                  ]
    
    
    
    list_Df_demands_totals = []

    for filePath_tup in fileList:
        
        filePath = filePath_tup[0]
        year = str(filePath_tup[1])
        month = str(filePath_tup[2])
        
        ###this code is used for the .xlsx files which are save as .csv
        try:
            df_temp = pd.read_csv(filePath, engine='python', encoding='utf-8')
            print(df_temp)
            df_temp = trim_all_columns(df_temp)
            if len(df_temp.columns)>=20:
                df_temp.to_csv(filePath, index=False)
        except Exception as e:
            print('csv reading error=', e, filePath)
        ###end this code is used for the .xlsx files which are save as .csv
        
        
        
        
        df_wList = read_csv_dynamic(filePath)
        print(df_wList)
        
        
        df_wList = adjust_columns(df_wList, source_col_names_toCheck, target_col_names)
                             
        df_wList = trim_all_columns(df_wList)
        
        df_wList = FilterCommonEligibleApplicants(df_wList)
        
        year_int = int(year)
        mon_int = int(month)
        
        if year_int>=2021 and mon_int>=10:
            #Filter applicants from October-2021
            df_wList= filter_rent_supp_only(df_wList)
        print("filter_rent_supp_only")
        print(df_wList)
        
        df_wList = df_wList.reset_index(drop=True)
        
        
        df_wList['Wheelchair'], df_wList['Paraplegic'], df_wList['Ground Floor'], df_wList['Supports'], df_wList['Hearing Impaired'], df_wList['Visually Impaired'] = zip(*df_wList.apply(lambda row: SplitUnitType(row), axis=1))
        
        df_wList['year'] = year
        df_wList['month'] = month

        
        print(df_wList)
        
        list_Df_demands_totals.append(df_wList)
        
        
        
        
    return list_Df_demands_totals

def combine_waitlists_dynamic():
    list_combine_Df_demands_totals = []

    
    Path_waitlist = pd.read_csv(waitlist_files)
    
    fileList = Path_waitlist.values.tolist()
    
    print(fileList)
    
    
    
    list_Df_demands_totals = read_files_dynamic(fileList)
    list_combine_Df_demands_totals.extend(list_Df_demands_totals)
    
    df_combined = pd.concat(list_combine_Df_demands_totals)
    if saveFile=='yes':
        df_combined.to_csv('AllWaitList-dynamic.csv', index=False)
    return df_combined
    
########### End Combine waitlists


###########Insert Demands####

def insertIntoTable(df_Demands_all):

    myDb = Oracle_DB()
   
    list_records = df_Demands_all.to_records(index=False)
    rows = list(list_records)
        
    INSERT_QRY_Answer = 'INSERT INTO DL_DEMANDS (GEOCODE,	DEMAND_YEAR, DEMAND_MONTH,	CLIENT_TYPE, DEMAND_TYPE, DEMAND_VALUE, GEOTYPE) VALUES(:GEOCODE, :DEMAND_YEAR, :DEMAND_MONTH,	:CLIENT_TYPE, :DEMAND_TYPE, :DEMAND_VALUE, :GEOTYPE)'

    insert_result = myDb.insert(INSERT_QRY_Answer, values=rows)
    print(insert_result)  

def insert_demands(df_DemandsRha, df_DemandsCd, df_DemandsCsd, df_DemandsEd, df_DemandsBld):
    df_DemandsRha = trim_all_columns(df_DemandsRha)
    df_DemandsCd = trim_all_columns(df_DemandsCd)
    df_DemandsCsd = trim_all_columns(df_DemandsCsd)
    df_DemandsEd = trim_all_columns(df_DemandsEd)
    df_DemandsBld = trim_all_columns(df_DemandsBld)
    
    df_DemandsBld['Rha|Mun|Are|Bld'] = df_DemandsBld['Rha|Mun|Are|Bld'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    
    df_DemandsRha = df_DemandsRha.rename(columns={'RHA': 'GEOCODE'})
    df_DemandsCd = df_DemandsCd.rename(columns={'CD': 'GEOCODE'})
    df_DemandsCsd = df_DemandsCsd.rename(columns={'CSD': 'GEOCODE'})
    df_DemandsEd = df_DemandsEd.rename(columns={'EDNO': 'GEOCODE'})
    df_DemandsBld = df_DemandsBld.rename(columns={'Rha|Mun|Are|Bld': 'GEOCODE'})
    
    df_DemandsRha['GEO_TYPE'] = 'RHA'
    df_DemandsCd['GEO_TYPE'] = 'CD'
    df_DemandsCsd['GEO_TYPE'] = 'CSD'
    df_DemandsEd['GEO_TYPE'] = 'ED'
    df_DemandsBld['GEO_TYPE'] = 'BLD'
    
    
    
    df_Demands_all = pd.concat([df_DemandsRha, df_DemandsCd, df_DemandsCsd, df_DemandsEd, df_DemandsBld])
    #df_Demands_all = pd.concat([df_DemandsRha, df_DemandsCd, df_DemandsCsd, df_DemandsEd])
    #df_Demands_all = pd.concat([ df_DemandsBld])
    
    df_Demands_all['DemandValue']=df_Demands_all['DemandValue'].astype(str)
    df_Demands_all['Year']=df_Demands_all['Year'].astype(str)
    df_Demands_all['Month']=df_Demands_all['Month'].astype(str)
    df_Demands_all['GEOCODE']=df_Demands_all['GEOCODE'].astype(str)
    
    df_Demands_all.drop_duplicates(inplace=True)
    print(df_Demands_all)
    
    if saveFile=='yes':
        df_Demands_all.to_csv('Demands_all.csv', index=False)
    
    if saveDatabase=='yes':
        insertIntoTable(df_Demands_all)  


  

###########End Insert Demands####
    

if __name__ == "__main__":
    df_waitlist_combined = combine_waitlists_dynamic()
    
    df_dm_rha, df_dm_cd, df_dm_csd, df_dm_ed, df_dm_bld = calculate_demand(df_waitlist_combined)
    
    insert_demands(df_dm_rha, df_dm_cd, df_dm_csd, df_dm_ed, df_dm_bld)
    
    
    
    
    
    
    
    