from Util_HA_CD_CSD_by_coordinate_FAST import extract_rha_cd_csd
from Util_ED_by_coordinate_FAST import extract_ed
import sys
import pandas as pd
import cx_Oracle
import traceback

DivisionCol = '' #Output
SubDivisionCol = '' #Output

CDCol = '' #Output
CSDCol = '' #Output

latCol =  '' #'zzLat_final'  # 'Latitude' #zzlat #INPUT
longCol = '' #'zzLon_final'  # 'Longitude' #zzlong #INPUT

saveRHA='no' #Output Flag
saveDatabase=''
saveFile=''

EDCol = ''
EDNo = ''

if len(sys.argv) == 12:
    DivisionCol = sys.argv[1]
    SubDivisionCol = sys.argv[2]
    CDCol = sys.argv[3]
    CSDCol = sys.argv[4]
    latCol = sys.argv[5]
    longCol = sys.argv[6] 
    saveRHA = sys.argv[7]
    saveDatabase = sys.argv[8].split('=')[1]
    saveFile = sys.argv[9].split('=')[1]
    EDCol = sys.argv[10]
    EDNo = sys.argv[11]

outputFile = 'CombineGooglePlace.csv' 
in_googlePlace=''

inputFilePath = "Main_FilePathInfo.csv"
df_path = pd.read_csv(inputFilePath)
for i in df_path.index:
    path_key = df_path.at[i,'Path_Key']
    if path_key=='Google_places_path':
        in_googlePlace = df_path.at[i,'Value']

########Data Manipulation in Oracle

CONN_INFO = {
    'host':	'dbo08n.cio.gov.ns.ca',
    'port':	1521,
    'user':	'HOUSING_WORK',
    'psw':	'0Summer+=*',
    'service':	'DWH01_NPR'
}

CONN_STR = '{user}/{psw}@{host}:{port}/{service}'.format(**CONN_INFO)

class Oracle_DB:
    def __init__(self):
        self.conn = cx_Oracle.connect(CONN_STR)
        self.conn.autocommit = True  # autocommit attribute will ensure transactions are automatically committed . This reduces database load and eliminates the round-trip to the DB

    def query(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            result = cursor.execute(query, kwargs).fetchall()
            response = 'SUCCESS', result
        except:
            response = 'FAILED 	{}'.format(traceback.format_exc()), None
        finally:
            cursor.close()
        return response

    def insert(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.executemany(query, kwargs.get('values', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def update(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs.get('params', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def delete(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs)
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED 	{}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

########End Data Manipulation in Oracle

        

#### Combine Google places ###
def combineGooglePlaces():
    list_df = []    

    list_df.append(pd.read_excel(in_googlePlace, sheet_name='hospital_done'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='school_done'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='grocery store_done'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='convenience store_done'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='walk in clinic_done'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='childcare_done'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='bus stop_done'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='emergency room_DONE'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='food bank_DONE'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='salvation army_DONE'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='pharmacy_DONE'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='mosque_DONE'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='synagogue_DONE'))
    list_df.append(pd.read_excel(in_googlePlace, sheet_name='buddhist temple_DONE'))
    
    df_all_place = pd.concat(list_df)
    df_all_place = df_all_place[['lat_coor',	'long_coor',	'postCode', 'address', 'businessname',  'businesstype',  'keyword']]
    
    df_all_place['postCode']=df_all_place['postCode'].str.strip()
    df_all_place['address']=df_all_place['address'].str.strip()
    df_all_place['businessname']=df_all_place['businessname'].str.strip()
    df_all_place['businesstype']=df_all_place['businesstype'].str.strip()
    df_all_place['keyword']=df_all_place['keyword'].str.strip()
    
    if saveFile=='yes':
        df_all_place.to_csv(outputFile, index=False)
        
    return df_all_place    

####End Combine Google places ###



####Insert Google Places to Oracle #####
def insertIntoTable(df_combGoogPlace):

    myDb = Oracle_DB()
   
    
   
    list_records = df_combGoogPlace.to_records(index=False)
    rows = list(list_records)

    INSERT_QRY_Answer = 'INSERT INTO DL_Google_Place (lat_coor,	long_coor,	postCode,	address,	businessname,	businesstype,	keyword, CSD_Google, SubDivision_Google, CD_Google ,	Division_Google, RHA_Google,  EDNo_Google,	EDName_Google ) VALUES(:lat_coor,	:long_coor,	:postCode,	:address,	:businessname,	:businesstype,	:keyword, :CSD_Google, :SubDivision_Google, :CD_Google , :Division_Google, :RHA_Google,  :EDNo_Google,	:EDName_Google)'
   

    insert_result = myDb.insert(INSERT_QRY_Answer, values=rows)
    print(insert_result)


def Insert_googlePlaces(df_combGoogPlace):  
  
    df_combGoogPlace.fillna("", inplace=True)
    
    df_combGoogPlace['postCode'] = df_combGoogPlace['postCode'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_combGoogPlace['address'] = df_combGoogPlace['address'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_combGoogPlace['businessname'] = df_combGoogPlace['businessname'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    df_combGoogPlace['businesstype'] = df_combGoogPlace['businesstype'].apply(lambda x:	''.join([" " if ord(i) < 32 or ord(i) > 126 else i for i in x]))
    
    df_combGoogPlace['CD-Google']=df_combGoogPlace['CD-Google'].astype(str)
    df_combGoogPlace['CSD-Google']=df_combGoogPlace['CSD-Google'].astype(str)
    df_combGoogPlace['EDNo-Google']=df_combGoogPlace['EDNo-Google'].astype(str)
    
    print(df_combGoogPlace)
    
    if saveDatabase=='yes':
        insertIntoTable(df_combGoogPlace)
        
    if saveFile=='yes':
        df_combGoogPlace.to_csv(outputFile, index=False)
    
    
####End Insert Google Places to Oracle #####
            

if __name__ == "__main__":
    df_all_place = combineGooglePlaces()
    
    df_all_place = extract_rha_cd_csd(df_all_place, DivisionCol, SubDivisionCol, CDCol, CSDCol, latCol, longCol, saveRHA)
    
    df_all_place = extract_ed(df_all_place, EDCol, EDNo, latCol, longCol)
    
    Insert_googlePlaces(df_all_place)
    


    