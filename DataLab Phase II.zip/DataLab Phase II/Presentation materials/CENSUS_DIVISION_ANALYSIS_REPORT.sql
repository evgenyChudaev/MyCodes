/**
    Census division profiles showing rhe following domensions:
    1. Classification of demand by applicant type in a given census division (based on proportion of  a particular applicant type (Family, NES, Senior) to the overall number of applications) 
    2. Ranking of each census division by total # of approved applications
    3. Social amenities such as # of hospitals, grocery stores, child cares etc. as well as Median Age, composition of family in each Censsu Division 
*/

WITH CD_PROFILES AS
(
SELECT * FROM
(
SELECT GEOCODE, QUESTIONDESCRIPTION, ANSWER, GEONAME 
FROM VIEW_CD_PROFILE
WHERE QUESTIONDESCRIPTION IN ('Population, 2016 (1)', 'Average size of census families', 'Median age of the population (6)', 
                             'Total lone-parent families by sex of parent',  'Total - Couple census families in private households - 100% data', 'One-person households', 
                             'Number of convenience store', 'Number of grocery store', 'Number of childcare',   
                             'Number of school', 'Number of hospital')  
) 
PIVOT
(
    SUM(ANSWER)
    FOR QUESTIONDESCRIPTION  IN ('Population, 2016 (1)' AS "POPULATION_2016", 'Average size of census families' AS "2016_AVG_FAMILY_SIZE", 'Median age of the population (6)' AS "2016_MEDIAN_AGE",
                             'Total lone-parent families by sex of parent' AS "2016_LONE_PARENT_FAMILIES",  'Total - Couple census families in private households - 100% data' AS "2016_COUPLE_FAMILIED",
                             'One-person households' AS "2016_ONE_PERSON_HOUSEHOLD", 'Number of convenience store' AS "COUNT_CONVENIENCE_STORES", 
                             'Number of grocery store' AS "COUNT_GROCERY_STORES", 'Number of childcare' AS "COUNT_CHILDCARES",   
                             'Number of school' AS "COUNT_SCHOOLS", 'Number of hospital' AS "COUNT_HOSPITALS")   
)
ORDER BY GEONAME
)
,
PROFILE_DEMAND_MERGE AS
(
SELECT D.GEOTYPE, D.DEMAND_TYPE, D.DEMAND_YEAR, D.DEMAND_MONTH,
NVL(D.FAMILY, 0) AS FAMILY, NVL(D.NES, 0) AS NES, NVL(D.SENIOR, 0) AS SENIOR, NVL(D.FAMILY,0)+NVL(D.NES, 0) +NVL(D.SENIOR, 0) AS TOTAL_APPLICATIONS, V.*
FROM
(
SELECT GEOTYPE, SUBSTR(GEOCODE,1,4) AS GEOCODE, DEMAND_TYPE, DEMAND_YEAR, DEMAND_MONTH, FAMILY, NES, SENIOR 
FROM DL_DEMANDS 
PIVOT(
    SUM(DEMAND_VALUE)
    FOR CLIENT_TYPE  IN ('Family' AS "FAMILY", 'Non-Elderly' AS "NES", 'Senior' AS "SENIOR") 
)
WHERE GEOTYPE = 'CD' AND DEMAND_TYPE = 'DemandTotal_Approve' AND DEMAND_YEAR = '2021' and DEMAND_MONTH = '12'
ORDER BY GEOCODE
) D
INNER JOIN CD_PROFILES V ON D.GEOCODE = V.GEOCODE
)

SELECT ROUND(POPULATION_2016/TOTAL_APPLICATIONS) AS POPULATION_APPPLICATION_RATIO ,
RANK() OVER(ORDER BY ROUND(POPULATION_2016/TOTAL_APPLICATIONS)) AS "APPLICATION_LOAD_RANK",
CASE 
    WHEN FAMILY > NES AND FAMILY > SENIOR THEN 'FAMILY'
    WHEN NES > FAMILY AND NES > SENIOR THEN 'NES'
    ELSE 'SENIOR'
END AS SOURCE_OF_HIGHEST_NUMBER_OF_APPLICATIONS,
PD.*   
FROM PROFILE_DEMAND_MERGE PD







