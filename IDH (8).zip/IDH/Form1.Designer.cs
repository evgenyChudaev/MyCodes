﻿namespace WindowsFormsApplication14
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tbpgMain = new System.Windows.Forms.TabControl();
            this.tbpgAdmin = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.label8 = new System.Windows.Forms.Label();
            this.btnExportAutomate = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbDestinationTable = new System.Windows.Forms.ComboBox();
            this.dgvCSVUpload = new System.Windows.Forms.DataGridView();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.txtCSVFilePath = new System.Windows.Forms.TextBox();
            this.btnExportToSqlServer = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnUpdateCategory = new System.Windows.Forms.Button();
            this.btnPeriMapping = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnUpdateAlise = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbMappingChoice = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvFieldMapping = new System.Windows.Forms.DataGridView();
            this.dgvDataSourceDefs = new System.Windows.Forms.DataGridView();
            this.btnSaveFieldMapping = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbUser = new System.Windows.Forms.TabPage();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.txtExportReport = new System.Windows.Forms.Button();
            this.dgvUserViews = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRunUserReport = new System.Windows.Forms.Button();
            this.cmbUserReports = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtCurrentReportStatus = new System.Windows.Forms.TextBox();
            this.dgvReportStatusDetails = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.sourceExtractMappingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lSSTrackerDataSet2 = new WindowsFormsApplication14.LSSTrackerDataSet2();
            this.lsstrackerDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lSSTrackerDataSet = new WindowsFormsApplication14.LSSTrackerDataSet();
            this.lsstrackerDataTableAdapter = new WindowsFormsApplication14.LSSTrackerDataSetTableAdapters.lsstrackerDataTableAdapter();
            this.tableAdapterManager = new WindowsFormsApplication14.LSSTrackerDataSetTableAdapters.TableAdapterManager();
            this.lssTrackerDataSet1 = new WindowsFormsApplication14.LSSTrackerDataSet();
            this.lSSTrackerDataSet11 = new WindowsFormsApplication14.LSSTrackerDataSet1();
            this.lssReferenceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lssReferenceTableAdapter = new WindowsFormsApplication14.LSSTrackerDataSet1TableAdapters.lssReferenceTableAdapter();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactSupportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createCurrentMomthReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createReportForSelectedDatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.txtToolstringRefreshStatus = new System.Windows.Forms.ToolStripTextBox();
            this.sourceExtractMappingTableAdapter = new WindowsFormsApplication14.LSSTrackerDataSet2TableAdapters.SourceExtractMappingTableAdapter();
            this.tbpgMain.SuspendLayout();
            this.tbpgAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCSVUpload)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFieldMapping)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataSourceDefs)).BeginInit();
            this.tbUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserViews)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReportStatusDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sourceExtractMappingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsstrackerDataBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssTrackerDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssReferenceBindingSource)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbpgMain
            // 
            this.tbpgMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbpgMain.Controls.Add(this.tbpgAdmin);
            this.tbpgMain.Controls.Add(this.tbUser);
            this.tbpgMain.Location = new System.Drawing.Point(-1, 27);
            this.tbpgMain.Name = "tbpgMain";
            this.tbpgMain.SelectedIndex = 0;
            this.tbpgMain.Size = new System.Drawing.Size(1591, 835);
            this.tbpgMain.TabIndex = 8;
            // 
            // tbpgAdmin
            // 
            this.tbpgAdmin.Controls.Add(this.splitContainer1);
            this.tbpgAdmin.Controls.Add(this.label11);
            this.tbpgAdmin.Controls.Add(this.label9);
            this.tbpgAdmin.Controls.Add(this.label7);
            this.tbpgAdmin.Location = new System.Drawing.Point(4, 25);
            this.tbpgAdmin.Name = "tbpgAdmin";
            this.tbpgAdmin.Padding = new System.Windows.Forms.Padding(3);
            this.tbpgAdmin.Size = new System.Drawing.Size(1583, 806);
            this.tbpgAdmin.TabIndex = 2;
            this.tbpgAdmin.Text = "Admin";
            this.tbpgAdmin.UseVisualStyleBackColor = true;
            this.tbpgAdmin.Enter += new System.EventHandler(this.tbpgAdmin_Enter);
            // 
            // splitContainer1
            // 
            this.splitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer1.Location = new System.Drawing.Point(9, 17);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.label8);
            this.splitContainer1.Panel1.Controls.Add(this.btnExportAutomate);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            this.splitContainer1.Panel1.Controls.Add(this.btnUpdateCategory);
            this.splitContainer1.Panel1.Controls.Add(this.btnPeriMapping);
            this.splitContainer1.Panel1.Controls.Add(this.button2);
            this.splitContainer1.Panel1.Controls.Add(this.btnUpdateAlise);
            this.splitContainer1.Panel1.ForeColor = System.Drawing.Color.DarkRed;
            this.splitContainer1.Panel1.Margin = new System.Windows.Forms.Padding(1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.button3);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.cmbMappingChoice);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.dgvFieldMapping);
            this.splitContainer1.Panel2.Controls.Add(this.dgvDataSourceDefs);
            this.splitContainer1.Panel2.Controls.Add(this.btnSaveFieldMapping);
            this.splitContainer1.Size = new System.Drawing.Size(1520, 693);
            this.splitContainer1.SplitterDistance = 1133;
            this.splitContainer1.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(225, 462);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(369, 17);
            this.label8.TabIndex = 31;
            this.label8.Text = "<- Import all GL source and mapping files at once if ready";
            // 
            // btnExportAutomate
            // 
            this.btnExportAutomate.Location = new System.Drawing.Point(34, 456);
            this.btnExportAutomate.Name = "btnExportAutomate";
            this.btnExportAutomate.Size = new System.Drawing.Size(172, 29);
            this.btnExportAutomate.TabIndex = 30;
            this.btnExportAutomate.Text = "1. Import All Data";
            this.btnExportAutomate.UseVisualStyleBackColor = true;
            this.btnExportAutomate.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.cmbDestinationTable);
            this.groupBox1.Controls.Add(this.dgvCSVUpload);
            this.groupBox1.Controls.Add(this.btnBrowse);
            this.groupBox1.Controls.Add(this.btnLoad);
            this.groupBox1.Controls.Add(this.txtCSVFilePath);
            this.groupBox1.Controls.Add(this.btnExportToSqlServer);
            this.groupBox1.Location = new System.Drawing.Point(18, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1480, 441);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Upload Files";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(351, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(335, 17);
            this.label10.TabIndex = 30;
            this.label10.Text = "<- Import GL source and mapping files one at a time";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 17);
            this.label1.TabIndex = 29;
            this.label1.Text = "Chose what to import";
            // 
            // cmbDestinationTable
            // 
            this.cmbDestinationTable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDestinationTable.FormattingEnabled = true;
            this.cmbDestinationTable.Items.AddRange(new object[] {
            "Source Data",
            "Master Mapping",
            "Upline Mapping",
            "Category Mapping",
            "Peri Mapping"});
            this.cmbDestinationTable.Location = new System.Drawing.Point(16, 51);
            this.cmbDestinationTable.Name = "cmbDestinationTable";
            this.cmbDestinationTable.Size = new System.Drawing.Size(253, 24);
            this.cmbDestinationTable.TabIndex = 28;
            // 
            // dgvCSVUpload
            // 
            this.dgvCSVUpload.AllowUserToAddRows = false;
            this.dgvCSVUpload.AllowUserToDeleteRows = false;
            this.dgvCSVUpload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCSVUpload.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvCSVUpload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCSVUpload.Location = new System.Drawing.Point(16, 179);
            this.dgvCSVUpload.Name = "dgvCSVUpload";
            this.dgvCSVUpload.RowTemplate.Height = 24;
            this.dgvCSVUpload.Size = new System.Drawing.Size(1173, 238);
            this.dgvCSVUpload.TabIndex = 9;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(1114, 92);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 10;
            this.btnBrowse.Text = "Find";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(16, 144);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(156, 29);
            this.btnLoad.TabIndex = 6;
            this.btnLoad.Text = "1. Preview data";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtCSVFilePath
            // 
            this.txtCSVFilePath.Location = new System.Drawing.Point(16, 93);
            this.txtCSVFilePath.Name = "txtCSVFilePath";
            this.txtCSVFilePath.Size = new System.Drawing.Size(1078, 22);
            this.txtCSVFilePath.TabIndex = 7;
            // 
            // btnExportToSqlServer
            // 
            this.btnExportToSqlServer.Location = new System.Drawing.Point(178, 144);
            this.btnExportToSqlServer.Name = "btnExportToSqlServer";
            this.btnExportToSqlServer.Size = new System.Drawing.Size(156, 29);
            this.btnExportToSqlServer.TabIndex = 11;
            this.btnExportToSqlServer.Text = "2. Export to DB";
            this.btnExportToSqlServer.UseVisualStyleBackColor = true;
            this.btnExportToSqlServer.Click += new System.EventHandler(this.btnExportToSqlServer_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(34, 635);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 44);
            this.button1.TabIndex = 23;
            this.button1.Text = "Preview Results";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnUpdateCategory
            // 
            this.btnUpdateCategory.Location = new System.Drawing.Point(34, 601);
            this.btnUpdateCategory.Name = "btnUpdateCategory";
            this.btnUpdateCategory.Size = new System.Drawing.Size(172, 28);
            this.btnUpdateCategory.TabIndex = 27;
            this.btnUpdateCategory.Text = "5. Update Categories";
            this.btnUpdateCategory.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnUpdateCategory.UseVisualStyleBackColor = true;
            this.btnUpdateCategory.Click += new System.EventHandler(this.btnUpdateCategory_Click);
            // 
            // btnPeriMapping
            // 
            this.btnPeriMapping.Location = new System.Drawing.Point(34, 566);
            this.btnPeriMapping.Name = "btnPeriMapping";
            this.btnPeriMapping.Size = new System.Drawing.Size(172, 29);
            this.btnPeriMapping.TabIndex = 26;
            this.btnPeriMapping.Text = "4. Update PERI Map";
            this.btnPeriMapping.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnPeriMapping.UseVisualStyleBackColor = true;
            this.btnPeriMapping.Click += new System.EventHandler(this.btnPeriMapping_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(34, 496);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(172, 29);
            this.button2.TabIndex = 24;
            this.button2.Text = "2. Update Master Map";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btnUpdateAlise
            // 
            this.btnUpdateAlise.Location = new System.Drawing.Point(34, 531);
            this.btnUpdateAlise.Name = "btnUpdateAlise";
            this.btnUpdateAlise.Size = new System.Drawing.Size(172, 29);
            this.btnUpdateAlise.TabIndex = 25;
            this.btnUpdateAlise.Text = "3. Update Upline Map";
            this.btnUpdateAlise.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnUpdateAlise.UseVisualStyleBackColor = true;
            this.btnUpdateAlise.Click += new System.EventHandler(this.btnUpdateAlise_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(764, 41);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(90, 23);
            this.button3.TabIndex = 32;
            this.button3.Text = "GO";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(522, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 17);
            this.label4.TabIndex = 31;
            this.label4.Text = "Select Mapping to Update";
            // 
            // cmbMappingChoice
            // 
            this.cmbMappingChoice.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMappingChoice.FormattingEnabled = true;
            this.cmbMappingChoice.Items.AddRange(new object[] {
            "Categories Map",
            "Source Extract Map",
            "Peri Map",
            "Master Map"});
            this.cmbMappingChoice.Location = new System.Drawing.Point(522, 40);
            this.cmbMappingChoice.Name = "cmbMappingChoice";
            this.cmbMappingChoice.Size = new System.Drawing.Size(236, 24);
            this.cmbMappingChoice.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 17);
            this.label3.TabIndex = 23;
            this.label3.Text = "Mapping sequence";
            // 
            // dgvFieldMapping
            // 
            this.dgvFieldMapping.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFieldMapping.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvFieldMapping.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFieldMapping.Location = new System.Drawing.Point(17, 32);
            this.dgvFieldMapping.Name = "dgvFieldMapping";
            this.dgvFieldMapping.RowTemplate.Height = 24;
            this.dgvFieldMapping.Size = new System.Drawing.Size(499, 647);
            this.dgvFieldMapping.TabIndex = 13;
            // 
            // dgvDataSourceDefs
            // 
            this.dgvDataSourceDefs.AllowUserToAddRows = false;
            this.dgvDataSourceDefs.AllowUserToDeleteRows = false;
            this.dgvDataSourceDefs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDataSourceDefs.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            this.dgvDataSourceDefs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataSourceDefs.Location = new System.Drawing.Point(525, 66);
            this.dgvDataSourceDefs.Name = "dgvDataSourceDefs";
            this.dgvDataSourceDefs.ReadOnly = true;
            this.dgvDataSourceDefs.RowTemplate.Height = 24;
            this.dgvDataSourceDefs.Size = new System.Drawing.Size(804, 613);
            this.dgvDataSourceDefs.TabIndex = 0;
            // 
            // btnSaveFieldMapping
            // 
            this.btnSaveFieldMapping.Location = new System.Drawing.Point(860, 38);
            this.btnSaveFieldMapping.Name = "btnSaveFieldMapping";
            this.btnSaveFieldMapping.Size = new System.Drawing.Size(123, 26);
            this.btnSaveFieldMapping.TabIndex = 22;
            this.btnSaveFieldMapping.Text = "Save Mapping";
            this.btnSaveFieldMapping.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(25, 383);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(125, 17);
            this.label11.TabIndex = 14;
            this.label11.Text = "Mapping Summary";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1168, 383);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 17);
            this.label9.TabIndex = 5;
            this.label9.Text = "Reference data";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(701, 383);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(157, 17);
            this.label7.TabIndex = 3;
            this.label7.Text = "Data Source Definitions";
            // 
            // tbUser
            // 
            this.tbUser.Controls.Add(this.splitContainer2);
            this.tbUser.Location = new System.Drawing.Point(4, 25);
            this.tbUser.Name = "tbUser";
            this.tbUser.Padding = new System.Windows.Forms.Padding(3);
            this.tbUser.Size = new System.Drawing.Size(1583, 806);
            this.tbUser.TabIndex = 3;
            this.tbUser.Text = "User";
            this.tbUser.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainer2.Location = new System.Drawing.Point(23, 32);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label5);
            this.splitContainer2.Panel1.Controls.Add(this.txtExportReport);
            this.splitContainer2.Panel1.Controls.Add(this.dgvUserViews);
            this.splitContainer2.Panel1.Controls.Add(this.label2);
            this.splitContainer2.Panel1.Controls.Add(this.txtRunUserReport);
            this.splitContainer2.Panel1.Controls.Add(this.cmbUserReports);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.textBox2);
            this.splitContainer2.Panel2.Controls.Add(this.txtCurrentReportStatus);
            this.splitContainer2.Panel2.Controls.Add(this.dgvReportStatusDetails);
            this.splitContainer2.Panel2.Controls.Add(this.label6);
            this.splitContainer2.Size = new System.Drawing.Size(1552, 749);
            this.splitContainer2.SplitterDistance = 716;
            this.splitContainer2.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(305, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(419, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Please reivew report before exporting to CSV or export right away";
            // 
            // txtExportReport
            // 
            this.txtExportReport.Location = new System.Drawing.Point(431, 45);
            this.txtExportReport.Name = "txtExportReport";
            this.txtExportReport.Size = new System.Drawing.Size(100, 30);
            this.txtExportReport.TabIndex = 4;
            this.txtExportReport.Text = "Export ";
            this.txtExportReport.UseVisualStyleBackColor = true;
            this.txtExportReport.Click += new System.EventHandler(this.txtExportReport_Click);
            // 
            // dgvUserViews
            // 
            this.dgvUserViews.AllowUserToAddRows = false;
            this.dgvUserViews.AllowUserToDeleteRows = false;
            this.dgvUserViews.AllowUserToOrderColumns = true;
            this.dgvUserViews.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvUserViews.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUserViews.Location = new System.Drawing.Point(16, 81);
            this.dgvUserViews.Name = "dgvUserViews";
            this.dgvUserViews.RowTemplate.Height = 24;
            this.dgvUserViews.Size = new System.Drawing.Size(1277, 651);
            this.dgvUserViews.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Select report";
            // 
            // txtRunUserReport
            // 
            this.txtRunUserReport.Location = new System.Drawing.Point(308, 44);
            this.txtRunUserReport.Name = "txtRunUserReport";
            this.txtRunUserReport.Size = new System.Drawing.Size(93, 31);
            this.txtRunUserReport.TabIndex = 1;
            this.txtRunUserReport.Text = "Review";
            this.txtRunUserReport.UseVisualStyleBackColor = true;
            this.txtRunUserReport.Click += new System.EventHandler(this.txtRunUserReport_Click);
            // 
            // cmbUserReports
            // 
            this.cmbUserReports.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserReports.FormattingEnabled = true;
            this.cmbUserReports.Items.AddRange(new object[] {
            "Reconciliation",
            "IDH CSV File",
            "IDH EPM Rec",
            "Unmapped",
            "CL Categories",
            "Master Map Summary",
            "Zero Balances"});
            this.cmbUserReports.Location = new System.Drawing.Point(16, 44);
            this.cmbUserReports.Name = "cmbUserReports";
            this.cmbUserReports.Size = new System.Drawing.Size(266, 24);
            this.cmbUserReports.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(38, 52);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(222, 23);
            this.textBox2.TabIndex = 6;
            this.textBox2.Text = "Current report status: ";
            // 
            // txtCurrentReportStatus
            // 
            this.txtCurrentReportStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCurrentReportStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentReportStatus.Location = new System.Drawing.Point(292, 54);
            this.txtCurrentReportStatus.Multiline = true;
            this.txtCurrentReportStatus.Name = "txtCurrentReportStatus";
            this.txtCurrentReportStatus.Size = new System.Drawing.Size(534, 39);
            this.txtCurrentReportStatus.TabIndex = 5;
            // 
            // dgvReportStatusDetails
            // 
            this.dgvReportStatusDetails.AllowUserToAddRows = false;
            this.dgvReportStatusDetails.AllowUserToDeleteRows = false;
            this.dgvReportStatusDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvReportStatusDetails.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvReportStatusDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReportStatusDetails.Location = new System.Drawing.Point(38, 132);
            this.dgvReportStatusDetails.Name = "dgvReportStatusDetails";
            this.dgvReportStatusDetails.RowTemplate.Height = 24;
            this.dgvReportStatusDetails.Size = new System.Drawing.Size(788, 346);
            this.dgvReportStatusDetails.TabIndex = 4;
            this.dgvReportStatusDetails.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReportStatusDetails_CellContentClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 112);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 17);
            this.label6.TabIndex = 3;
            this.label6.Text = "Status Details";
            // 
            // sourceExtractMappingBindingSource
            // 
            this.sourceExtractMappingBindingSource.DataMember = "SourceExtractMapping";
            this.sourceExtractMappingBindingSource.DataSource = this.lSSTrackerDataSet2;
            // 
            // lSSTrackerDataSet2
            // 
            this.lSSTrackerDataSet2.DataSetName = "LSSTrackerDataSet2";
            this.lSSTrackerDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lsstrackerDataBindingSource
            // 
            this.lsstrackerDataBindingSource.DataMember = "lsstrackerData";
            this.lsstrackerDataBindingSource.DataSource = this.lSSTrackerDataSet;
            // 
            // lSSTrackerDataSet
            // 
            this.lSSTrackerDataSet.DataSetName = "LSSTrackerDataSet";
            this.lSSTrackerDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lsstrackerDataTableAdapter
            // 
            this.lsstrackerDataTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.lsstrackerDataTableAdapter = this.lsstrackerDataTableAdapter;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApplication14.LSSTrackerDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // lssTrackerDataSet1
            // 
            this.lssTrackerDataSet1.DataSetName = "LSSTrackerDataSet";
            this.lssTrackerDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lSSTrackerDataSet11
            // 
            this.lSSTrackerDataSet11.DataSetName = "LSSTrackerDataSet1";
            this.lSSTrackerDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lssReferenceBindingSource
            // 
            this.lssReferenceBindingSource.DataMember = "lssReference";
            this.lssReferenceBindingSource.DataSource = this.lSSTrackerDataSet11;
            // 
            // lssReferenceTableAdapter
            // 
            this.lssReferenceTableAdapter.ClearBeforeFill = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Location = new System.Drawing.Point(0, 28);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1590, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuStrip2
            // 
            this.menuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.reportingToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(1590, 28);
            this.menuStrip2.TabIndex = 10;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contactSupportToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // contactSupportToolStripMenuItem
            // 
            this.contactSupportToolStripMenuItem.Name = "contactSupportToolStripMenuItem";
            this.contactSupportToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.contactSupportToolStripMenuItem.Text = "Contact support";
            this.contactSupportToolStripMenuItem.Click += new System.EventHandler(this.contactSupportToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // reportingToolStripMenuItem
            // 
            this.reportingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createCurrentMomthReportToolStripMenuItem,
            this.createReportForSelectedDatesToolStripMenuItem});
            this.reportingToolStripMenuItem.Name = "reportingToolStripMenuItem";
            this.reportingToolStripMenuItem.Size = new System.Drawing.Size(87, 24);
            this.reportingToolStripMenuItem.Text = "Reporting";
            // 
            // createCurrentMomthReportToolStripMenuItem
            // 
            this.createCurrentMomthReportToolStripMenuItem.Name = "createCurrentMomthReportToolStripMenuItem";
            this.createCurrentMomthReportToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.createCurrentMomthReportToolStripMenuItem.Text = "Create current month report";
            // 
            // createReportForSelectedDatesToolStripMenuItem
            // 
            this.createReportForSelectedDatesToolStripMenuItem.Name = "createReportForSelectedDatesToolStripMenuItem";
            this.createReportForSelectedDatesToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.createReportForSelectedDatesToolStripMenuItem.Text = "Create report for selected dates";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.txtToolstringRefreshStatus});
            this.toolStrip1.Location = new System.Drawing.Point(1249, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(302, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // txtToolstringRefreshStatus
            // 
            this.txtToolstringRefreshStatus.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.txtToolstringRefreshStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtToolstringRefreshStatus.Enabled = false;
            this.txtToolstringRefreshStatus.Name = "txtToolstringRefreshStatus";
            this.txtToolstringRefreshStatus.Size = new System.Drawing.Size(288, 25);
            // 
            // sourceExtractMappingTableAdapter
            // 
            this.sourceExtractMappingTableAdapter.ClearBeforeFill = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1590, 863);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tbpgMain);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.menuStrip2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.Text = "IDH Runner";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tbpgMain.ResumeLayout(false);
            this.tbpgAdmin.ResumeLayout(false);
            this.tbpgAdmin.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCSVUpload)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFieldMapping)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataSourceDefs)).EndInit();
            this.tbUser.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel1.PerformLayout();
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserViews)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReportStatusDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sourceExtractMappingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lsstrackerDataBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssTrackerDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lSSTrackerDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lssReferenceBindingSource)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private LSSTrackerDataSet lSSTrackerDataSet;
        private System.Windows.Forms.BindingSource lsstrackerDataBindingSource;
        private LSSTrackerDataSetTableAdapters.lsstrackerDataTableAdapter lsstrackerDataTableAdapter;
        private LSSTrackerDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TabControl tbpgMain;
        private System.Windows.Forms.TabPage tbpgAdmin;
        private LSSTrackerDataSet lssTrackerDataSet1;
        private LSSTrackerDataSet1 lSSTrackerDataSet11;
        private System.Windows.Forms.BindingSource lssReferenceBindingSource;
        private LSSTrackerDataSet1TableAdapters.lssReferenceTableAdapter lssReferenceTableAdapter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvDataSourceDefs;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contactSupportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createCurrentMomthReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createReportForSelectedDatesToolStripMenuItem;
        private System.Windows.Forms.TextBox txtCSVFilePath;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.DataGridView dgvCSVUpload;
        private System.Windows.Forms.Button btnExportToSqlServer;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.DataGridView dgvFieldMapping;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripTextBox txtToolstringRefreshStatus;
        private System.Windows.Forms.Button btnSaveFieldMapping;
        private System.Windows.Forms.TabPage tbUser;
        private System.Windows.Forms.Button button1;
        private LSSTrackerDataSet2 lSSTrackerDataSet2;
        private System.Windows.Forms.BindingSource sourceExtractMappingBindingSource;
        private LSSTrackerDataSet2TableAdapters.SourceExtractMappingTableAdapter sourceExtractMappingTableAdapter;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnUpdateAlise;
        private System.Windows.Forms.Button btnPeriMapping;
        private System.Windows.Forms.Button btnUpdateCategory;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ComboBox cmbDestinationTable;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbMappingChoice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbUserReports;
        private System.Windows.Forms.Button txtRunUserReport;
        private System.Windows.Forms.DataGridView dgvUserViews;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txtCurrentReportStatus;
        private System.Windows.Forms.DataGridView dgvReportStatusDetails;
        private System.Windows.Forms.Button txtExportReport;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnExportAutomate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
    }
}

