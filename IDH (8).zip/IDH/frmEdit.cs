﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication14
{
    public partial class frmEdit : Form
    {
        string statusName;
        SqlConnection conn = new SqlConnection(@"Data Source=SSRC\DEV2008,2301;Initial Catalog=LSSTracker;User ID=lssTrackerApp;Password=Qazwsx184!");
        
        public frmEdit(string myRecord, string statusComments)
        {
            InitializeComponent();
            statusName = myRecord;            
            txtStatusComment.Text = statusComments;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            DialogResult updateDialog = MessageBox.Show("Are you sure you want to save your comments", "Update comments", 
                                        MessageBoxButtons.YesNo);
            if (updateDialog == DialogResult.Yes)
            {
                string newComments = txtStatusComment.Text;
                conn.Open();
                SqlCommand cmd = new SqlCommand("IDH_updateComments", conn);
                cmd.Parameters.AddWithValue("@myComment", newComments);
                cmd.Parameters.AddWithValue("@myStatus", statusName);               
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            frmMain.updatedRecord = true;
            this.Close();
        }
    }
}
