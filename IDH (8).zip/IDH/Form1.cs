﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;
//using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Windows.Forms.DataVisualization.Charting;
//using Microsoft.Office.Interop.Outlook;
using Outlook = Microsoft.Office.Interop.Outlook;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using Microsoft.VisualBasic.FileIO;
using System.IO;




namespace WindowsFormsApplication14
{

    public partial class frmMain : Form
    {
        public static string myUserId;
        public static bool updatedRecord = false;
        public static bool loadAdminData = false;
        private bool isDataLoaded = false;
        string versionNumber = "1.1";  // update version number every time new application version is released.
        SqlConnection conn = new SqlConnection(@"Data Source=SSRC\DEV2008,2301;Initial Catalog=LSSTracker;User ID=lssTrackerApp;Password=Qazwsx184!");
        bool fieldFilterApplied;
        string selectedIndividuals = "";
       
        
        public frmMain()
        {

            InitializeComponent();
           
        }

      

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lSSTrackerDataSet2.SourceExtractMapping' table. You can move, or remove it, as needed.
            this.sourceExtractMappingTableAdapter.Fill(this.lSSTrackerDataSet2.SourceExtractMapping);

            loadMapSummary("IDH_SourceExtractDefsMapped");
            loadSourceExtractDefs("IDH_SourceExtractDefs");
            cmbDestinationTable.SelectedIndex = 0;
            cmbUserReports.SelectedIndex = 0;
            startForm();
            // Add 2 new button columns

         
        }

        

        private void getLastRefreshTime()
        {
            string lastDate;
            //fieldNameDatabase
            conn.Open();
            SqlCommand cmd = new SqlCommand("getLastUpdatedDate", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@myVersion", version);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            lastDate = ds.Tables[0].Rows[0][0].ToString();
            txtToolstringRefreshStatus.Text = "Last upload: " + lastDate;
            //getLastUpdatedDate
        }      

       

        private void tbpgAdmin_Enter(object sender, EventArgs e)
        {
           // loginPage loginForm = new loginPage();
          //  loginForm.ShowDialog();

            loadAdminData = true;
            if (loadAdminData)
            {
                //load data into tables on the admin tab
                //loadAdminDataTables("extractAdminData", ref dgvDataSourceDefs);
                //loadAdminDataTables("extractVersionNumber", ref dgvVersionControl);
                //loadAdminDataTables("extractReference", ref dgvReferenceData);
                //loadAdminDataTables("extractDatabaseUpdateHistory", ref dgvRefreshLog);
            }
            else
            {
                tbpgMain.SelectedIndex = 0; // if user navagates away from the admin tab, programs takes user to the first tab
            }
        }
        // extract data for tables on admin tab
        private void loadAdminDataTables(string sp_name, ref DataGridView myDataGrid)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            myDataGrid.DataSource = ds.Tables[0];
        }

        private void contactSupportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /* OutlookApp outlookApp = new OutlookApp();
             MailItem mailItem = outlookApp.CreateItem(OlItemType.olMailItem);
             mailItem.Subject = "This is the subject";
             mailItem.HTMLBody = "<html><body>This is the <strong>funky</strong> message body</body></html>";

             //Set a high priority to the message
             mailItem.Importance = OlImportance.olImportanceHigh; */

            sendEMailThroughOUTLOOK();
        }

        //method to send email to outlook
        public void sendEMailThroughOUTLOOK()
        {
            try
            {
                Outlook.Application olApp = new Outlook.Application();
                Outlook.MailItem olMailItem = olMailItem = (Outlook.MailItem)olApp.CreateItem(Outlook.OlItemType.olMailItem);

                // recepient of the email, cc & subject
                // olMailItem.To = drvSource[oEmailChoice.To].ToString(); 
                olMailItem.To = "evgeny.chudaev@rbc.com;tse.robin@rbc.com;joshua.h.zhang@rbc.com";

                /// if (oEmailChoice.CC != "")
                // olMailItem.CC = drvSource[oEmailChoice.CC].ToString();
                olMailItem.Subject = "LSS Tracker tool support";
                olMailItem.Display();
                olMailItem.HTMLBody = "Something" + olMailItem.HTMLBody;
                olMailItem.Display(true);
            }//end of try block
            catch (Exception ex)
            {
            }//end of catch
        }//end of Email Method


       

       

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       

       

        private string folderDialogWindow()
        {
            string folderName = "";
            using (var folderDialog = new FolderBrowserDialog())
            {
                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    folderName = folderDialog.SelectedPath;
                }
            }
            return folderName;
        }


        public static void ExportToExcel(ref System.Data.DataTable DataTable, string ExcelFilePath, string periodName)
        {
            try
            {
                int ColumnsCount;

                if (DataTable == null || (ColumnsCount = DataTable.Columns.Count) == 0)
                    throw new Exception("ExportToExcel: Null or empty input table!\n");

                // load excel, and create a new workbook
                Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();
                Excel.Workbooks.Add();

                // single worksheet
                Microsoft.Office.Interop.Excel._Worksheet Worksheet = Excel.ActiveSheet;

                object[] Header = new object[ColumnsCount];

                // column headings               
                for (int i = 0; i < ColumnsCount; i++)
                {
                    Header[i] = DataTable.Columns[i].ColumnName;
                }

                Microsoft.Office.Interop.Excel.Range HeaderRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, ColumnsCount]));
                HeaderRange.Value = Header;
                HeaderRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                HeaderRange.Font.Bold = true;


                // DataCells
                int RowsCount = DataTable.Rows.Count;

                object[,] Cells = new object[RowsCount, ColumnsCount];

                for (int i = 0; i < ColumnsCount; i++)
                {

                    for (int j = 0; j < RowsCount; j++)
                    {
                        Cells[j, i] = DataTable.Rows[j][i];
                    }
                }




                Worksheet.Cells[1, 1].Value = "Report generated " + periodName;
                Worksheet.Cells[1, 1].Font.Italic = true;

                if (RowsCount == 0)
                {
                    Worksheet.Cells[3, 1].Value = "No results";
                }
                else
                {
                    Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[RowsCount + 2, ColumnsCount])).Value = Cells;
                }


                Worksheet.Columns.AutoFit();

                // check fielpath
                if (ExcelFilePath != null && ExcelFilePath != "")
                {
                    try
                    {
                        Worksheet.SaveAs(ExcelFilePath);
                        Excel.Quit();
                        MessageBox.Show("Report saved!");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                            + ex.Message);
                    }
                }
                else    // no filepath is given
                {
                    Excel.Visible = true;
                }

                Marshal.FinalReleaseComObject(Worksheet);
                Marshal.FinalReleaseComObject(HeaderRange);
                Marshal.FinalReleaseComObject(Excel);
            }
            catch (Exception ex)
            {
                throw new Exception("ExportToExcel: \n" + ex.Message);
            }

        }      

        private void button2_Click(object sender, EventArgs e)
        {
            string filePath = txtCSVFilePath.Text;
            GetDataTabletFromCSVFile(filePath);
        }

        private void getDataMapping(string mySPName)
        {
            //fieldNameDatabase
            conn.Open();
            SqlCommand cmd = new SqlCommand(mySPName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@myVersion", version);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            dgvFieldMapping.DataSource = ds.Tables[0];
        }

        // read csv file in datatable, merge with the below method and make one generic method later 
        DataTable importTbl;
        private void GetDataTableFromCSVFile(string csv_file_path)
        {
            importTbl = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "\t" });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {

                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        importTbl.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        importTbl.Rows.Add(fieldData);
                    }
                }
              
            }           
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }            
        }



        //read csv and display content on the datagrid, merge with above method and make one generic method later
        private void GetDataTabletFromCSVFile(string csv_file_path)
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "\t" });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {               

                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
                dgvCSVUpload.DataSource = csvData;                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }


        // oveloaded method for bulk import from datatable
        private void InsertDataIntoSQLServerUsingSQLBulkCopy(ref DataTable myDataTable, string destinationTableName)
        {    

            conn.Open();
            using (SqlBulkCopy s = new SqlBulkCopy(conn))
            {
                s.BulkCopyTimeout = 180;
                s.DestinationTableName = destinationTableName;
                s.WriteToServer(myDataTable);
            }
            conn.Close();
        }

        // oveloaded method for bulk import from datagrid view
        private void InsertDataIntoSQLServerUsingSQLBulkCopy(ref DataGridView myDataGrid, string destinationTableName)
        {

            DataTable exportTable = new DataTable();
            exportTable = (myDataGrid.DataSource as System.Data.DataTable).DefaultView.ToTable(); // export default view (filtered view) of datagridView  // (DataTable)dgvCSVUpload.DataSource;
          
            conn.Open();
           
            using (SqlBulkCopy s = new SqlBulkCopy(conn))
            {
                s.BulkCopyTimeout = 180;
                s.DestinationTableName = destinationTableName;
                s.WriteToServer(exportTable);
            }
            conn.Close();
        }

        private string browseFile()
        {
            Stream myStream = null;
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            string fPath = "";

            openFileDialog1.Filter = "CSV (*.csv. *.txt)|*.csv;*.txt";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((myStream = openFileDialog1.OpenFile()) != null)
                    {
                        using (myStream)
                        {
                            fPath = openFileDialog1.FileName.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }

            }
            return fPath;
        }

        private void btnExportToSqlServer_Click(object sender, EventArgs e)
        {
            string destinationTbl = cmbDestinationTable.Text.ToString();
            string finalDestination = "";
            switch (destinationTbl)
            {
                case "Source Data":
                    finalDestination = "importIDH";
                    updateTimeStamp("Source Data Import");
                    break;
                case "Master Mapping":
                    finalDestination = "IDHMAP";
                    deleteDatabaseTable("IDHMAP");
                    updateTimeStamp("Source Data Import");
                    break;
                case "Upline Mapping":
                    finalDestination = "IDH_UplineRLNAliasMapping";
                    deleteDatabaseTable("IDH_UplineRLNAliasMapping");
                    updateTimeStamp("Source Data Import");
                    break;
                case "Category Mapping":
                    finalDestination = "IDHMAP_CATEGORIES";
                    deleteDatabaseTable("IDHMAP_CATEGORIES");
                    updateTimeStamp("Source Data Import");
                    break;
                case "Peri Mapping":
                    finalDestination = "IDHMAP_PERI";
                    deleteDatabaseTable("IDHMAP_PERI");
                    updateTimeStamp("Source Data Import");
                    break;
                default:
                    MessageBox.Show("UNKNOWN INPUT");                   
                    break;
            }

            InsertDataIntoSQLServerUsingSQLBulkCopy(ref dgvCSVUpload, finalDestination);
            startForm();
            MessageBox.Show("Database updated!");           
        }

        private void updateTimeStamp(string myStep)
        {
            DateTime currentTime = DateTime.Now;
            conn.Open();

            //MessageBox.Show(currentTime.ToString());
            SqlCommand cmd = new SqlCommand("IDH_UpdateReportStatus", conn);
            cmd.Parameters.AddWithValue("@myStep", myStep);            
            cmd.Parameters.AddWithValue("@myTime", currentTime);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            txtCSVFilePath.Text = browseFile();
        }


         

        private void deleteDatabaseTable(string tableName)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("clearTable", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@tableName", tableName);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

       

        private void loadMapSummary(string mySPName)
        {
            //fieldNameDatabase
            conn.Open();
            SqlCommand cmd = new SqlCommand(mySPName , conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@myVersion", version);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            dgvFieldMapping.DataSource = ds.Tables[0];
        }


       

        private void loadSourceExtractDefs(string sp_name)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@myVersion", version);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            dgvDataSourceDefs.DataSource = ds.Tables[0];
        }

        // similar to loadFromAnyTable, except loads data from any stored procedure
        private void loadFromAnyStoredProcedure(string sp_name, ref DataGridView myDataGrid)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand(sp_name, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 80; 
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            int rowCount = ds.Tables[0].Rows.Count;
            
            if (rowCount == 0)
            {
                DataRow newRow = ds.Tables[0].NewRow();
                newRow[0] = " *** No records *** ";
                ds.Tables[0].Rows.Add(newRow);
            }
                

               // MessageBox.Show("No records");

            myDataGrid.DataSource = ds.Tables[0];
        }


        private void loadFromAnyTable(string tableName, ref DataGridView myDataGrid)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("IDH_SELECTALLFROMANYTABLE", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@myTable", tableName);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            //dgvDataSourceDefs.DataSource = ds.Tables[0];
            myDataGrid.DataSource = ds.Tables[0];
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            runMapping(true);
            updateTimeStamp("Process mapping");
            startForm();
        }

        private void runMapping(bool clearIDH)
        {
            string[,] sourceDef = new string[dgvDataSourceDefs.Rows.Count - 1, 2];
            string myClass, myBatch, mySourceDef;

            string myPeri, myPeriDesc;
          
           // do clean up - delete records from mappedIDH, reimport clean data from importIDHand create adjustmenets
            if (clearIDH)  
            {
                callNonParameterizedProcedure("IDH_InsertImportDataIntoMapped");
                callNonParameterizedProcedure("IDH_removeGLAliases");
                
                // create peri and reverse sign lines in the mapped table from AssetsAdj and LiabilityAdj              
                callNonParameterizedProcedure("IDH_CreateAdjustments");
            }
           

            for (int i = 0; i < dgvFieldMapping.Rows.Count - 1; i++)
            {
                if (dgvFieldMapping.Rows[i].Cells[3].Value.ToString() != "")
                {
                    myClass = dgvFieldMapping.Rows[i].Cells[1].Value.ToString();
                    myBatch = dgvFieldMapping.Rows[i].Cells[0].Value.ToString();
                   
                    mySourceDef = addSingleQuotes(dgvFieldMapping.Rows[i].Cells[3].Value.ToString());
                   
                    switch (myClass)
                    {
                        case "class 1": mapSourceData(myBatch, myClass, mySourceDef, "updateIDHByGl"); break;
                        case "class 7": mapSourceData(myBatch, myClass, mySourceDef, "updateIDHByGl"); break;
                        case "class 8": mapSourceData(myBatch, myClass, mySourceDef, "updateIDHByGl_AND_Transit"); break;
                        case "class 2": mapSourceData(myBatch, myClass, mySourceDef, "updateIDHByGl_AND_Transit"); break;
                        case "class 3": mapSourceData(myBatch, myClass, mySourceDef, "updateIDHByGl_AND_Transit"); break;
                        case "reversal": mapSourceData(myBatch, myClass, mySourceDef, "updateIDHByGl_Sign_Reversal"); break;
                        case "LBE": // in case of LBE, first create LBE lines from RLN dy duplication, then do the mapping
                            duplicateLines(myBatch, "LBE", "IDH_CreateLBE"); //create LBE Lines
                            mapSourceData(myBatch, myClass, mySourceDef, "updateIDHByGl"); // map LBE as any other category per the mapping
                            break;
                        case "Peri Class 1": 
                            mapSourceData(myBatch, myClass, mySourceDef, "IDH_updatePERIByTransit"); 
                            break;
                        case "Peri Class 2": 
                            myPeri =  addSingleQuotes(dgvFieldMapping.Rows[i].Cells[4].Value.ToString());
                            myPeriDesc = addSingleQuotes(dgvFieldMapping.Rows[i].Cells[5].Value.ToString());
                            mapSourceDataPeri(myPeri, myPeriDesc, mySourceDef, "IDH_updatePERIClass2"); 
                            break;
                        case "Peri Class 3": 
                            myPeri =  addSingleQuotes(dgvFieldMapping.Rows[i].Cells[4].Value.ToString());
                            myPeriDesc = addSingleQuotes(dgvFieldMapping.Rows[i].Cells[5].Value.ToString());
                            //mapSourceDataPeri(myPeri, myPeriDesc, mySourceDef, "IDH_updatePERIClass3");
                            mapSourceDataPeri(myPeri, myPeriDesc, mySourceDef, "IDH_updatePERIClass3"); 
                            break;    
                        default: MessageBox.Show("Unknown case type encountered. Please update code and mappings"); break;
                    }

                }

            }

           

            MessageBox.Show("Done");
        }

        // Add single quites around all names so a range of values can be parsed by SQL Server for tne IN() Clause
        private string addSingleQuotes(string name)
        {
            string[] newNameArr = name.Split(',');
            string newNameInSingleQuites = "";
            if (name.Length == 1)
            {
                newNameInSingleQuites = "'" + newNameArr[0].Trim() + "'";
            }
            else
            {
                for (int i = 0; i < newNameArr.Length; i++)
                {
                    newNameInSingleQuites += "'" + newNameArr[i].Trim() +"',";
                }
                newNameInSingleQuites = newNameInSingleQuites.Substring(0, newNameInSingleQuites.Length - 1);
            }
            return newNameInSingleQuites;
        }

        private void callNonParameterizedProcedure(string procName)
        {
            // Console.WriteLine(myBatch + " | " + myClass + " | " + mySourceDef);
            conn.Open();
            SqlCommand cmd = new SqlCommand(procName, conn);            
            cmd.CommandType = CommandType.StoredProcedure;
            // increased timeout for command to 80 seconds in case server is overloaded which has happened
            cmd.CommandTimeout = 180; 
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        private void mapSourceData(string myBatch, string myClass, string mySourceDef, string procName)
        {
           // Console.WriteLine(myBatch + " | " + myClass + " | " + mySourceDef);
            conn.Open();
            SqlCommand cmd = new SqlCommand(procName , conn);
            cmd.CommandTimeout = 80; 
            cmd.Parameters.AddWithValue("@fieldName", "Batch");
            cmd.Parameters.AddWithValue("@filterParam", myBatch);
            cmd.Parameters.AddWithValue("@categories", mySourceDef);            
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        // merge with above method later
        private void mapSourceDataPeri(string myBatch, string myClass, string mySourceDef, string procName)
        {
            // Console.WriteLine(myBatch + " | " + myClass + " | " + mySourceDef);
            conn.Open();
            SqlCommand cmd = new SqlCommand(procName, conn);
            cmd.Parameters.AddWithValue("@fieldName", myBatch);
            cmd.Parameters.AddWithValue("@filterParam", myClass);
            cmd.Parameters.AddWithValue("@categories", mySourceDef);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        // Creates LBE lines
        private void duplicateLines(string myBatch, string categoryName, string procName)
        {
           // Console.WriteLine(myBatch + " | " + myClass + " | " + mySourceDef);
            conn.Open();
            SqlCommand cmd = new SqlCommand(procName, conn);          
            cmd.Parameters.AddWithValue("@filterParam", myBatch);
            cmd.Parameters.AddWithValue("@category", categoryName); 
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            conn.Close();
        }




        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("IDH_DisplaySourceData", conn);
            cmd.CommandType = CommandType.StoredProcedure;           
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            dgvCSVUpload.DataSource = ds.Tables[0];                      
        }

        private void btnUpdateAlise_Click(object sender, EventArgs e)
        {
           // callNonParameterizedProcedure("IDH_updateRLNGLAliase");
            callNonParameterizedProcedure("IDH_updateUplineAliases");
            updateTimeStamp("Process mapping");
            startForm();
            MessageBox.Show("Done!");
        }

        private void btnPeriMapping_Click(object sender, EventArgs e)
        {
            callNonParameterizedProcedure("removeTransitAliases");
            callNonParameterizedProcedure("removeCurrencyAliases");
            loadMapSummary("IDH_PeriSourceExtractDefsMapped");
            this.Refresh();
            runMapping(false);
            
            updateTimeStamp("Process mapping");
            startForm();
            //updateTimeStamp("Source Data Import");
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            callNonParameterizedProcedure("IDH_updateCategory");
            updateTimeStamp("Process mapping");
            startForm();
            MessageBox.Show("Done!");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            extractMappingForReview();            
        }

        private void extractMappingForReview()
        {
            string mappingTbl = cmbMappingChoice.Text.ToString();

            switch (mappingTbl)
            {
                case "Categories Map":
                    loadFromAnyTable("IDHMAP_CATEGORIES", ref dgvDataSourceDefs);
                    break;
                case "Source Extract Map":
                    loadSourceExtractDefs("IDH_SourceExtractDefs");
                    break;
                case "Peri Map":
                    loadFromAnyTable("IDHMAP_PERI", ref dgvDataSourceDefs);
                    break;
                case "Master Map":
                    loadFromAnyTable("IDHMAP", ref dgvDataSourceDefs);
                    break;
                case "Upline Map":
                    loadFromAnyTable("IDH_UplineRLNAliasMapping", ref dgvDataSourceDefs);
                    break;
                default:
                    MessageBox.Show("UNKNOWN INPUT");
                    break;
            }
        }

        // get SUMS and other matadata for the CSV file (has to be put in the first row)
        private string getCSVFileMetadata(string sp_name)
        {
            SqlDataReader reader;
            StringBuilder sb = null;
            string strDelimiter = ",";
            string qualifier = "\"";
            conn.Open();

            using (reader = new SqlCommand(sp_name, conn).ExecuteReader())
            {
                if (reader.HasRows)
                {
                    sb = new StringBuilder();
                    Object[] items = new Object[reader.FieldCount];
                    while (reader.Read())
                    {
                        reader.GetValues(items);
                        foreach (var item in items)
                        {
                            sb.Append(qualifier + item.ToString() + qualifier);
                            sb.Append(strDelimiter);
                        }
                        sb.Length--;
                        sb.Append("\n");
                    }

                }
            }
            conn.Close();

            return sb.ToString();
        }

        private void exportCSVFIle(string sp_name, string outputFileName, string reportDate, bool epmrec)
        {
            string CSVMetadata = getCSVFileMetadata("IDH_DisplayCSVMetaData"); // get the first row containing # of rows and SUMs for the CSV file
            string folderPath = folderDialogWindow();
            int eof = 3;  // total number of lines in the CSV (has to be added at the bottom) + 3 lines

            callNonParameterizedProcedure("IDH_UpdateReportingDate");

            SqlDataReader reader;
            string strDelimiter = ",";
            string qualifier = "\"";
            StringBuilder sb = null;
            string strFilePath = folderPath + "\\" + outputFileName;
            conn.Open();
            SqlCommand command = new SqlCommand(sp_name, conn);
            command.CommandTimeout = 360;

            using (reader = command.ExecuteReader())
            {
                if (reader.HasRows)
                {
                    sb = new StringBuilder();
                    Object[] items = new Object[reader.FieldCount];
                    sb.Append(CSVMetadata);
                    if(!epmrec)
                        sb.Append("REPORTING_DATE,ORIG_CCY,AMT_ORIG_CCY,AMT_CAD,AMT_USD,UNIT_NO,RLN,RLN_NAME,GL_ACCT_NO,GL_ACCT_NAME,CL_HUB_BS_CATEGORY,CL_HUB_BS_CATEGORY_DESC,CL_HUB_CONS_PERI,CL_HUB_CONS_PERI_DESC,CL_OD_TYPE,CL_OD_TYPE_DESC,ACL Code,ACL Name");  // headers
                    else
                        sb.Append("REPORTING_DATE,ORIG_CCY,AMT_ORIG_CCY,AMT_CAD,AMT_USD,UNIT_NO,RLN,RLN_NAME,GL_ACCT_NO,GL_ACCT_NAME,CL_HUB_BS_CATEGORY,CL_HUB_BS_CATEGORY_DESC,CL_HUB_CONS_PERI,CL_HUB_CONS_PERI_DESC,CL_OD_TYPE,CL_OD_TYPE_DESC,ACL Code,ACL Name,Sorting order");  // headers
                    sb.Append("\n");
                    while (reader.Read())
                    {
                        reader.GetValues(items);
                        foreach (var item in items)
                        {
                            // Using two sb.Append is better because if you 
                            // concat the two strings it will first build a new string
                            // and then discard it after its use.                               
                            sb.Append(qualifier + item.ToString() + qualifier);
                           // sb.Append(item.ToString());
                            sb.Append(strDelimiter);
                           
                        }
                        sb.Length--;
                        sb.Append("\n");
                        eof++;                       
                    }
                    sb.Append("T,"+eof);
                    sb.Append("\n");
                }
            }
            conn.Close();
            File.WriteAllText(strFilePath, sb.ToString());
            MessageBox.Show("Done");
        }


        private void txtRunUserReport_Click(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            runUserReports();
            Cursor = Cursors.Default;
        }     
   
        private void runUserReports()
        {
           
            string userReportName = cmbUserReports.Text.ToString();

            switch (userReportName)
            {
                case "Reconciliation":
                    loadFromAnyStoredProcedure("IDH_GLRLNReconciliation", ref dgvUserViews);
                    break;
                case "IDH CSV File":
                    loadFromAnyStoredProcedure("IDH_DisplaySourceData", ref dgvUserViews);
                    break;
                case "Unmapped":
                    loadFromAnyStoredProcedure("IDH_DisplayUnmapped", ref dgvUserViews);
                    break;
                case "CL Categories":
                    loadFromAnyTable("IDHMAP_CATEGORIES", ref dgvUserViews);
                    break;
                case "Master Map Summary":
                    loadFromAnyStoredProcedure("IDH_CL_HUB_SUMMARY", ref dgvUserViews);
                    break;
                case "Zero Balances":
                    loadFromAnyStoredProcedure("IDH_checkZeroBalances", ref dgvUserViews);
                    break; 
                default:
                    MessageBox.Show("UNKNOWN INPUT");
                    break;
            }          

        }
        bool commentUpdateColCreated = false;
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            startForm();
        }

        // add additional fields/controls to the gridview
        private void addGridViewFields(string btnName, string headerText, string buttonText)
        {
            var dgvButton = new DataGridViewButtonColumn();
            dgvButton.Name = btnName;
            dgvButton.HeaderText = headerText;
            dgvButton.Text = buttonText;
            dgvButton.UseColumnTextForButtonValue = true;
            this.dgvReportStatusDetails.Columns.Add(dgvButton);
        }

        private void refreshStatusReport()
        {
            loadFromAnyTable("IDH_StatusReport", ref dgvReportStatusDetails);
            // update latest report status
            string previous = "", next = "", previousStatus = "", nextStatus = "";
            int rowCount = dgvReportStatusDetails.Rows.Count;
            int i = 0;
            foreach (DataGridViewRow row in dgvReportStatusDetails.Rows)
            {
               // if(row.Cells["Completed"].Value.ToString()
                i++;
                next = row.Cells["Completed"].Value.ToString();
                nextStatus = row.Cells["Step"].Value.ToString();
                if (next == "" || String.IsNullOrEmpty(next))
                {
                    if(i > 1)
                        txtCurrentReportStatus.Text = previousStatus + " as of " + previous;
                    else
                        txtCurrentReportStatus.Text = nextStatus + " as of " + next; 
                    break;
                }
                else if(i >= rowCount)
                {
                    txtCurrentReportStatus.Text = nextStatus + " as of " + next;
                    break;
                }                
                else
                {
                    previousStatus = nextStatus;
                    previous = next;
                }           
                
                //More code here
            }
        }

        private void txtExportReport_Click(object sender, EventArgs e)
        {
            exportReport();
        }

        private void exportReport()
        {
            Cursor = Cursors.WaitCursor;

            string userReportName = cmbUserReports.Text.ToString();

            switch (userReportName)
            {
                case "Reconciliation":
                    loadFromAnyStoredProcedure("IDH_GLRLNReconciliation", ref dgvUserViews);
                    break;
                case "IDH CSV File":
                  // callNonParameterizedProcedure("IDH_UpdateReportingDate");
                   exportCSVFIle("IDH_DisplaySourceData", "IDH_EPM_Data_" + getPriorMonthEndDate() + ".csv", getPriorMonthEndDate(), false);
                   break;
                case "IDH EPM Rec":
                  // callNonParameterizedProcedure("IDH_UpdateReportingDate");
                   exportCSVFIle("IDH_DisplaySourceDataEPMRec", "IDH_EPM_Data_" + getPriorMonthEndDate() + ".csv", getPriorMonthEndDate(), true);
                   break;
                case "Unmapped":
                    loadFromAnyStoredProcedure("IDH_DisplayUnmapped", ref dgvUserViews);
                    break;
                case "CL Categories":
                    loadFromAnyTable("IDHMAP_CATEGORIES", ref dgvUserViews);
                    break;
                case "Master Map Summary":
                    loadFromAnyStoredProcedure("IDH_CL_HUB_SUMMARY", ref dgvUserViews);
                    break; 
                default:
                    MessageBox.Show("UNKNOWN INPUT");
                    break;
            }

            Cursor = Cursors.Default;
        }
       
        private string getPriorMonthEndDate()
        {        
            DateTime today = DateTime.Today;
            DateTime first = new DateTime(today.Year, today.Month, 1);
            DateTime lastMonthEnd = first.AddDays(-1);
            return lastMonthEnd.ToString("yyyyMMdd");           
        }

       

        private void dgvReportStatusDetails_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {           
            //if click is on new row or header row
            if (e.RowIndex == dgvReportStatusDetails.NewRowIndex || e.RowIndex < 0)
                return;
            //Check if click is on comment column 
            if (e.ColumnIndex == dgvReportStatusDetails.Columns["btnCommentEditButton"].Index)
            {            
                string clickedStatus = dgvReportStatusDetails.CurrentCell.OwningRow.Cells["Step"].Value.ToString();
                string statusComments = dgvReportStatusDetails.CurrentCell.OwningRow.Cells["Comments"].Value.ToString();
                frmEdit editForm = new frmEdit(clickedStatus, statusComments);
                editForm.ShowDialog();

                if (updatedRecord)
                {
                    startForm();                    
                }
                updatedRecord = false;

            }

        }


        private void startForm()
        {
            Cursor = Cursors.WaitCursor;
            refreshStatusReport();
            if (!commentUpdateColCreated)
                addGridViewFields("btnCommentEditButton", "Update Comments", "Update");
            Cursor = Cursors.Default;
            commentUpdateColCreated = true;
        }

        //private void AppendEPMDataFiles(ref List<String> sourceDataFilesAppend)
         private string AppendEPMDataFiles(string sourceDataFilesAppend, string folderPath)        
        {
           // foreach(string elem in sourceDataFilesAppend){
             //   Console.WriteLine("source file" + elem);
            //}

            Console.WriteLine("source file" + sourceDataFilesAppend);

            
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
           // string destFile = @" C:\Users\285431649\Documents\backup\EPM_GL_DATA.txt";
            startInfo.Arguments = @"/C copy " + sourceDataFilesAppend + " " + folderPath + "\\zz_EPM_GL_DATA.txt";
            process.StartInfo = startInfo;
            process.Start();

            return folderPath + "\\zz_EPM_GL_DATA.txt";

                   
        }

         private void PrepareGLData(string folderPath)
         {

             string EPMDataFiles = "";
             string newFile = "";
             int fileNameIndex, fileExtensionIndex, fileUnderscoreIndex, extractCounter;
             String fileName;
            // String folderPath = folderDialogWindow(); //@"C:\Users\285431649\Documents\backup";
             extractCounter = 0;
             int rowIndex;

             foreach (string file in Directory.EnumerateFiles(folderPath))
             {
                 fileNameIndex = file.LastIndexOf("\\") + 1;
                 fileExtensionIndex = file.LastIndexOf(".");
                 fileName = file.Substring(fileNameIndex, fileExtensionIndex - fileNameIndex);
                 fileUnderscoreIndex = fileName.LastIndexOf("_") + 1;  

                 if (file.ToUpper().IndexOf("IDH_EXTRACT") > 0 && file.IndexOf("~$") < 0) // Transform Excel files
                 {                
                     extractCounter++;
                     updateIDHSourceExtracts(file, fileName.Substring(fileUnderscoreIndex, fileName.Length - fileUnderscoreIndex), extractCounter, folderPath);                 
                     EPMDataFiles += folderPath + "\\" + fileName.Substring(fileUnderscoreIndex, fileName.Length - fileUnderscoreIndex) + ".txt + ";

                   
                     
                     string searchValue = fileName.Substring(fileUnderscoreIndex, fileName.Length - fileUnderscoreIndex).ToUpper();
                    
                      DataGridViewRow row = dgvCSVUpload.Rows
                      .Cast<DataGridViewRow>()
                      .Where(r => r.Cells["Required File"].Value.ToString().ToUpper().Split(' ')[0].Equals(searchValue))
                      .First();

                     rowIndex = row.Index;
                     dgvCSVUpload.Rows[rowIndex].Cells["File in Directory"].Value = file;

                     dgvCSVUpload.Rows[rowIndex].Cells["Status"].Value = ((char)0x221A).ToString() + " done";
                     dgvCSVUpload.Rows[rowIndex].Cells["Status"].Style.ForeColor = Color.Green;

                     newFile = folderPath + "\\" + fileName.Substring(fileUnderscoreIndex, fileName.Length - fileUnderscoreIndex) + ".txt"; // make reusable in EPMDataFiles string later
                     long lineCount = File.ReadLines(newFile).Count();
                     dgvCSVUpload.Rows[rowIndex].Cells["Rows"].Value = lineCount;
                    
                 }               

             }

             EPMDataFiles = EPMDataFiles.Substring(0, EPMDataFiles.Length - 2);            
             string gl_file = AppendEPMDataFiles(EPMDataFiles, folderPath);
             MessageBox.Show("A consolidated GL file " + gl_file + " was created and will be imported");
         }
     
        private void button4_Click(object sender, EventArgs e)
        {
            List<String> sourceDataFilesAppend = new List<String>();
            Dictionary<string, string> fileMap = new Dictionary<string, string>();
          
            String folderPath = folderDialogWindow(); 
            String[]  requiredFiles = { "Assets - EPM Extract", "Liabilities - EPM Extract", "AUMAUC - EPM Extract",
                                         "OffBal - EPM Extract", "AssetAdj - EPM Extract", "LiabAdj - EPM Extract", 
                                         "Manual GL Adjustments - From Template", "Master Mapping", "PERI Mapping", "RLN Alias Mapping" };


            DataTable requiredFileTable = new DataTable();
            requiredFileTable.Columns.Add("Required File", typeof(String));            
            requiredFileTable.Columns.Add("File in Directory", typeof(String));
            requiredFileTable.Columns.Add("Status", typeof(String));
            requiredFileTable.Columns.Add("Rows", typeof(int));
         
            for (int i = 0; i < requiredFiles.Length; i++)
            {
                DataRow row = requiredFileTable.NewRow();
                row["Required File"] = requiredFiles[i];
                requiredFileTable.Rows.Add(row);
            }

          
            dgvCSVUpload.DataSource = requiredFileTable;
            this.Refresh();
            dgvCSVUpload.Refresh();

            PrepareGLData(folderPath); // create a consolidated GL file out of multiple files

            deleteDatabaseTable("importIDH"); // clear import IDH table
                foreach (string file in Directory.EnumerateFiles(folderPath))
                {
                    long lineCount = File.ReadLines(file).Count();
                    
                    if (file.ToUpper().IndexOf("XX_MANUALADJSOURCE") > 0)
                    {
                        GetDataTableFromCSVFile(file);
                        InsertDataIntoSQLServerUsingSQLBulkCopy(ref importTbl, "importIDH");
                        dgvCSVUpload.Rows[6].Cells["File in Directory"].Value = file;
                        dgvCSVUpload.Rows[6].Cells["Status"].Value = ((char)0x221A).ToString() + " done";
                        dgvCSVUpload.Rows[6].Cells["Status"].Style.ForeColor = Color.Green;
                        dgvCSVUpload.Rows[6].Cells["Rows"].Value = lineCount;
                       
                    }
                    else if (file.ToUpper().IndexOf("ZZ_EPM_GL_DATA") > 0)
                    {
                        GetDataTableFromCSVFile(file);
                        InsertDataIntoSQLServerUsingSQLBulkCopy(ref importTbl, "importIDH");
                      
                    }

                    else if (file.ToUpper().IndexOf("IDH_MAP_MASTERMAPPING") > 0)
                    {
                        deleteDatabaseTable("IDHMAP");
                        GetDataTableFromCSVFile(file);                        
                        InsertDataIntoSQLServerUsingSQLBulkCopy(ref importTbl, "IDHMAP");
                        dgvCSVUpload.Rows[7].Cells["File in Directory"].Value = file;
                        dgvCSVUpload.Rows[7].Cells["Status"].Value = ((char)0x221A).ToString() + " done";
                        dgvCSVUpload.Rows[7].Cells["Status"].Style.ForeColor = Color.Green;
                        dgvCSVUpload.Rows[7].Cells["Rows"].Value = lineCount;
                       
                    }
                    else if (file.ToUpper().IndexOf("IDH_MAP_UPLINEMAPPING") > 0)
                    {
                        deleteDatabaseTable("IDH_UplineRLNAliasMapping");
                        GetDataTableFromCSVFile(file);
                        InsertDataIntoSQLServerUsingSQLBulkCopy(ref importTbl, "IDH_UPLINERLNALIASMAPPING");
                        dgvCSVUpload.Rows[9].Cells["File in Directory"].Value = file;
                        dgvCSVUpload.Rows[9].Cells["Status"].Value = ((char)0x221A).ToString() + " done";
                        dgvCSVUpload.Rows[9].Cells["Status"].Style.ForeColor = Color.Green;
                        dgvCSVUpload.Rows[9].Cells["Rows"].Value = lineCount;
 
                    }
                    else if (file.ToUpper().IndexOf("IDH_MAP_PERI") > 0)
                    {
                        deleteDatabaseTable("IDHMAP_PERI");
                        GetDataTableFromCSVFile(file);
                        InsertDataIntoSQLServerUsingSQLBulkCopy(ref importTbl, "IDHMAP_PERI");
                        dgvCSVUpload.Rows[8].Cells["File in Directory"].Value = file;
                        dgvCSVUpload.Rows[8].Cells["Status"].Value = ((char)0x221A).ToString() + " done";
                        dgvCSVUpload.Rows[8].Cells["Status"].Style.ForeColor = Color.Green;
                        dgvCSVUpload.Rows[8].Cells["Rows"].Value = lineCount;
                    }


                }

            // mark missing documents
                for (int i = 0; i < dgvCSVUpload.Rows.Count; i++ )
                {
                    if (dgvCSVUpload.Rows[i].Cells["Status"].Value.ToString().Equals("") || dgvCSVUpload.Rows[i].Cells["Status"].Value == null)
                    {
                        dgvCSVUpload.Rows[i].Cells["Status"].Value = "X MISSING";
                        dgvCSVUpload.Rows[i].Cells["Status"].Style.ForeColor = Color.Red;  
                    }
                       

                }


                    // EPMDataFiles = EPMDataFiles.Substring(0, EPMDataFiles.Length - 2);
                    //AppendEPMDataFiles(ref sourceDataFilesAppend);
                    // string gl_file = AppendEPMDataFiles(EPMDataFiles, folderPath);
                    // MessageBox.Show(gl_file + " was created and will be imported");
                    // GetDataTableFromCSVFile(gl_file);
                    // InsertDataIntoSQLServerUsingSQLBulkCopy(ref importTbl, "importIDH");
                    /* Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
                     String xlFilePath = @"C:\Users\285431649\Documents\backup\IDH_EXTRACT_LIABILITIES.xlsx";

                     Excel.Workbook workbook = app.Workbooks.Open(xlFilePath);
                     app.DisplayAlerts = false;
                     Excel.Worksheet worksheet = workbook.Worksheets["Sheet1"];

                     long fullRow = worksheet.Rows.Count;
                     long fullCol = worksheet.Columns.Count;
                     int lastRow = worksheet.Cells[fullRow, 1].End(Excel.XlDirection.xlUp).Row;
                     int lastCol = worksheet.Cells[1, fullCol].End(Excel.XlDirection.xlToLeft).Column;
                     string lastCell = "C" + lastCol;

                     Excel.Range xlRng = worksheet.Range["A1"];
                     xlRng.EntireColumn.Insert(Excel.XlInsertShiftDirection.xlShiftToRight, Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);

                     Excel.Range destRng = worksheet.Range["A1:A"+lastRow];
                    // worksheet.Cells[1, 1] = "test macroXXXX";
                     destRng.Value = "Assets";


                    // workbook.SaveAs("C:\good.csv", Excel.XlFileFormat.xlCSV);   
                    // workbook.Close(SaveChanges:=False);


                     workbook.SaveAs(@"C:\Users\285431649\Documents\backup\testCSV.txt", Excel.XlFileFormat.xlTextWindows);

                     workbook.Close(true, Type.Missing, Type.Missing);

                     app.Quit();
                     Marshal.ReleaseComObject(app);
                     GC.Collect();
                     GC.WaitForPendingFinalizers();

                    // string strCmdText;
                    // strCmdText = @"copy copy C:\Users\285431649\Documents\backup\assets.txt + C:\Users\285431649\Documents\backup\liabilities.txt C:\Users\285431649\Documents\backup\cobs.txt";
                     //System.Diagnostics.Process.Start("CMD.exe", strCmdText);

                     System.Diagnostics.Process process = new System.Diagnostics.Process();
                     System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                     startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                     startInfo.FileName = "cmd.exe";
                     startInfo.Arguments = @"/C copy C:\Users\285431649\Documents\backup\assets.txt + C:\Users\285431649\Documents\backup\liabilities.txt C:\Users\285431649\Documents\backup\cobs.txt";
                     process.StartInfo = startInfo;
                     process.Start(); */


                    MessageBox.Show("Done");
        }

       
        private void updateIDHSourceExtracts(string filePath, string category, int extractNumber, string fileDestPath)
        {

           // Console.WriteLine("fle path: " + filePath + " category " + category);
            Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            String xlFilePath = filePath;
            //string fileDestPath = @"C:\Users\285431649\Documents\backup";
            Excel.Workbook workbook = app.Workbooks.Open(xlFilePath);
            app.DisplayAlerts = false;
            Excel.Worksheet worksheet = workbook.Worksheets["Sheet1"];

            long fullRow = worksheet.Rows.Count;
           // long fullCol = worksheet.Columns.Count;
          
            //int lastCol = worksheet.Cells[1, fullCol].End(Excel.XlDirection.xlToLeft).Column;
            //string lastCell = "C" + lastCol;

            

            Excel.Range xlRng = worksheet.Range["A1"];
            xlRng.EntireColumn.Insert(Excel.XlInsertShiftDirection.xlShiftToRight, Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);

            int lastRow;
            Excel.Range destRng;
            if (extractNumber == 1) // need to add header only in the first file
            {
                Excel.Range xlDeleteRng = worksheet.Range["A1:A14"].EntireRow;
                xlDeleteRng.Delete();

                worksheet.Range["A1"].Value = "Category";
                worksheet.Range["B1"].Value = "CURRENCY";
                worksheet.Range["C1"].Value = "Transit";
                worksheet.Range["D1"].Value = "GL";
                worksheet.Range["E1"].Value = "Amt_BOOKED";
                worksheet.Range["F1"].Value = "AMT_DISPLAY_CAD";
                worksheet.Range["G1"].Value = "AMT_DISPLAY_USD";

                lastRow = worksheet.Cells[fullRow, 2].End(Excel.XlDirection.xlUp).Row;
                destRng = worksheet.Range["A2:A" + lastRow];
               
            }
            else
            {
                Excel.Range xlDeleteRng = worksheet.Range["A1:A15"].EntireRow;
                xlDeleteRng.Delete();

                lastRow = worksheet.Cells[fullRow, 2].End(Excel.XlDirection.xlUp).Row;
                destRng = worksheet.Range["A1:A" + lastRow];
                
            }

            destRng.Value = category;
           

            workbook.SaveAs(fileDestPath+"\\"+category+".txt", Excel.XlFileFormat.xlTextWindows);
            workbook.Close(true, Type.Missing, Type.Missing);


         //   workbook.SaveAs(@"C:\Users\285431649\Documents\backup\testCSV.txt", Excel.XlFileFormat.xlTextWindows);

           

            app.Quit();
            Marshal.ReleaseComObject(app);
            GC.Collect();
            GC.WaitForPendingFinalizers();

           // string strCmdText;
           // strCmdText = @"copy copy C:\Users\285431649\Documents\backup\assets.txt + C:\Users\285431649\Documents\backup\liabilities.txt C:\Users\285431649\Documents\backup\cobs.txt";
            //System.Diagnostics.Process.Start("CMD.exe", strCmdText);

          /*  System.Diagnostics.Process process = new System.Diagnostics.Process();
            System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = @"/C copy C:\Users\285431649\Documents\backup\assets.txt + C:\Users\285431649\Documents\backup\liabilities.txt C:\Users\285431649\Documents\backup\cobs.txt";
            process.StartInfo = startInfo;
            process.Start(); */
        }

        private void button5_Click(object sender, EventArgs e)
        {
            GetDataTableFromCSVFile(@"C:\Users\285431649\Documents\backup\zz_EPM_GL_DATA.txt");
            InsertDataIntoSQLServerUsingSQLBulkCopy(ref importTbl, "importIDH");
        }
    }
}

