from collections import defaultdict
import plotly.figure_factory as ff
import pandas as pd
import numpy as np
import calendar
import tabula
import requests

# some suspect counties, maybe some months had a foot of rain..
issue_counties = [] #'Eaton', 'Otsego', 'Wayne']

# stations that look to have bad data. (hundreds of miles of rain per month)
# tweaking the value of 48000005.16 to 4.80 and similar in a few other months.
issue_stations = ['rgay']

last_years_data_saved = {
'Alcona': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Allegan': [5.46, 4.12, 2.02, 2.03, 8.73, 6.31, 1.95, 2.09, 2.7, 0.56, 3.02, 3.28],
'Alpena': [5.04, 3.23, 1.68, 1.55, 3.39, 5.2, 2.66, 3.13, 1.79, 1.17, 2.66, 3.36],
'Antrim': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Arenac': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Barry': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Bay': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Benzie': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Berrien': [6.22, 4.24, 2.94, 3.29, 6.81, 5.1, 1.43, 2.22, 3.46, 0.77, 3.1, 3.37],
'Branch': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Calhoun': [4.59, 5.81, 2.06, 3.09, 4.31, 5.97, 1.19, 2.61, 3.01, 0.47, 2.68, 1.7],
'Cass': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Charlevoix': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Cheboygan': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Clare': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Clinton': [2.57, 6.32, 2.64, 1.44, 3.42, 6.98, 1.74, 3.79, 3.93, 1.14, 2.84, 2.52],
'Crawford': [2.51, 2.87, 1.77, 0.55, 1.54, 2.26, 1.56, 2.22, 1.07, 0.38, 1.86, 2.62],
'Eaton': [32.22, 2.28, 0.46, 0.87, 2.12, 2.22, 0.07, 1.93, 2.46, 0.29, 2.22, 2.26],
'Emmet': [4.15, 3.3, 2.49, 0.74, 5.03, 5.14, 2.39, 2.7, 0.94, 0.8, 2.69, 4.72],
'Genesee': [2.78, 5.34, 1.81, 3.11, 2.86, 6.11, 1.99, 2.11, 3.19, 0.81, 2.35, 1.7],
'Gladwin': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Grand Traverse': [4.02, 3.83, 2.94, 1.16, 5.88, 3.79, 2.03, 3.2, 1.17, 0.4, 2.06, 3.32],
'Gratiot': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Hillsdale': [6.88, 6.9, 3.39, 4.67, 9.39, 8.59, 2.1, 4.71, 4.14, 0.4, 3.57, 4.76],
'Huron': [3.37, 2.65, 2.78, 1.45, 3.34, 4.18, 2.65, 2.01, 2.45, 1.04, 2.25, 1.48],
'Ingham': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Ionia': [0.49, 1.26, 0.01, 0.22, 0.39, 0.52, 0.06, 0.54, 1.49, 0.0, 0.77, 23.18],
'Iosco': [5.69, 3.4, 5.92, 3.25, 7.07, 7.69, 5.13, 4.07, 1.29, 0.44, 2.08, 4.74],
'Isabella': [6.46, 6.63, 1.58, 3.15, 9.22, 12.32, 2.71, 3.5, 1.46, 0.19, 3.13, 3.58],
'Jackson': [3.65, 4.59, 3.09, 1.73, 5.08, 4.91, 1.49, 3.0, 3.12, 0.73, 3.76, 2.52],
'Kalamazoo': [5.42, 5.79, 2.65, 1.73, 4.11, 4.56, 1.24, 2.69, 3.39, 0.47, 2.78, 2.79],
'Kalkaska': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Kent': [5.96, 4.01, 3.63, 3.19, 7.12, 6.44, 2.55, 3.61, 3.17, 1.0, 3.13, 3.63],
'Lake': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Lapeer': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Leelanau': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Lenawee': [5.09, 3.77, 2.64, 4.72, 4.58, 4.3, 1.08, 2.15, 3.56, 0.73, 2.78, 2.4],
'Livingston': [5.71, 7.25, 11.21, 2.12, 5.23, 6.7, 2.1, 2.68, 4.32, 0.13, 3.62, 1.47],
'Macomb': [0.01, 0.0, 0.0, 0.19, 0.0, 0.05, 0.0, 0.09, 0.59, 0.01, 0.26, 0.0],
'Manistee': [3.17, 4.89, 0.93, 0.0, 0.0, 5.01, 3.5, 2.26, 1.43, 0.39, 3.76, 2.5],
'Mason': [5.69, 7.91, 4.38, 5.06, 8.63, 10.03, 2.95, 3.9, 1.84, 0.68, 5.6, 4.16],
'Mecosta': [7.56, 6.49, 3.53, 2.37, 7.54, 8.49, 2.39, 2.9, 0.92, 0.1, 3.87, 2.25],
'Midland': [4.37, 5.68, 2.17, 2.74, 8.14, 9.83, 1.78, 2.8, 1.62, 0.05, 2.67, 2.98],
'Missaukee': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Monroe': [4.78, 3.12, 2.7, 1.19, 3.04, 3.34, 0.35, 1.61, 2.29, 0.25, 1.81, 1.94],
'Montcalm': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Montmorency': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Muskegon': [6.12, 3.04, 2.99, 2.04, 5.5, 7.6, 3.07, 3.73, 2.51, 1.01, 3.73, 5.4],
'Newaygo': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Oakland': [4.05, 4.18, 3.01, 2.47, 4.65, 4.47, 1.54, 1.85, 3.14, 0.34, 2.77, 1.84],
'Oceana': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Ogemaw': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Osceola': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Oscoda': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Otsego': [9.77, 4.8, 3.6, 3.08, 11.31, 9.13, 6.62, 8.1, 4.05, 3.14, 5.89, 7.96],
'Ottawa': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Presque Isle': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Roscommon': [4.54, 3.88, 2.92, 2.03, 4.63, 3.83, 2.04, 3.19, 1.49, 0.75, 2.31, 3.32],
'Saginaw': [3.23, 4.49, 1.61, 1.6, 4.45, 7.19, 1.98, 2.7, 2.4, 0.37, 2.25, 2.16],
'Sanilac': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Shiawassee': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'St Clair': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'St Joseph': [6.49, 7.77, 9.07, 6.06, 8.31, 7.07, 0.96, 3.69, 4.16, 0.55, 2.91, 4.12],
'Tuscola': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Van Buren': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
'Washtenaw': [2.63, 4.75, 1.78, 0.94, 1.08, 3.53, 1.0, 2.2, 3.36, 0.44, 3.73, 1.76],
'Wayne': [17.17, 7.91, 11.33, 12.48, 16.540000000000003, 18.42, 5.54, 8.56, 13.030000000000001, 2.13, 15.07, 7.81],
'Wexford': [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
}


read_internal = True
# data about the state
state = "Michigan"
state_fips = 26

# counties to ignore as we only want the mitton
upper_counties = ['Baraga', 'Ontonagon', 'Marquette', 'Iron', 'Gogebic', 'Houghton', 'Dickinson',
                  'Keweenaw', 'Luce', 'Menominee', 'Alger', 'Chippewa', 'Delta', 'Schoolcraft', 'Mackinac']

# month names in short and long form
long_months = list(map(lambda x: calendar.month_name[x], range(1, 13)))
months = list(map(lambda x: calendar.month_abbr[x], range(1, 13)))

# columns in dataframe
columns = ['County'] + months

# URLs for average monthly rainfall by county for the years 1971-2000
rain_fall_url = "https://www.nrcs.usda.gov/Internet/FSE_DOCUMENTS/nrcs141p2_024319.pdf"
county_fips_url = "https://raw.githubusercontent.com/plotly/datasets/master/laucnty16.csv"

# Cli-DAP: Climate Data Access Portal Web Services for Retrieving Climate Data
# for info see: https://mrcc.illinois.edu/data_serv/docs/Cli-DAPRetrievalHandout.pdf
# and https://cli-dap.mrcc.illinois.edu/#!/station/station_read
station_info_url = "https://cli-dap.mrcc.illinois.edu/county/FIPS/"
# Cli-DAP: Url to get monthly rain amounts for 2019-05-01 through 2020-05-01
station_data_url = "https://cli-dap.mrcc.illinois.edu/station/CALLSIGN/data?start=20190501&end=20200501&elem=PRE&interval=mly&reduction=sum"

df_geo = pd.read_csv(county_fips_url)

# read in the historic data in in PDF form
url_input = tabula.read_pdf(rain_fall_url, pages='all') #, output_format='dataframe')
# plt.style.use('seaborn-pastel')

# sadly trying to read the pdf isnt as nice as possible as they spanned a table across multiple pages.
start = False
page = False
mid = False
late = False
count = 0
offset = 0
county=m1=m2=m3=m4=m5=m6=m7=m8=m9=m10=m11=m12 = "()"
c_list = list()
tmp_dict = defaultdict(list)

df_input = pd.DataFrame(columns=columns)

for line in str(url_input).split('\n'):

    county = ""

    if len(line) == 0:
        page = True
        start = False
        mid = False
        late = False
        if count == 0:
            count = offset
        offset = 0

    if mid:
        county, m4, m5, m6, m7, m8, m9 = line.split()
        tmp_dict[c_list[int(county)-1]].extend((m4,m5,m6,m7,m8,m9))

    if late:
        county, m10, m11, m12 = line.split()[:4]
        tmp_dict[c_list[int(county)-1]].extend((m10,m11,m12))
        offset += 1

    if page:
        if 'Apr' in line:
            mid = True
            page = False

        if 'Oct.' in line:
            late = True
            page = False
            mid = False

    if start:
        if len(line.split()) > 5:
            ca, cb, m1, m2, m3 = line.split()[1:6]
            county = "{} {}".format(ca, cb)
        else:
            county, m1 , m2 , m3 = line.split()[1:5]
            county = county.replace('\\r', ' ')
        c_list.append(county)
        if offset == 0:
            tmp_dict[county] = list()
        tmp_dict[county].extend((m1,m2,m3))
        offset += 1

    if 'Jan.' in line:
        start = True
        offset = 0
        c_list.clear()

    if len(county) > 0:
        if late:
            tmp = dict(zip(columns, [c_list[int(county)-1]] + tmp_dict[c_list[int(county)-1]]))
            df_input = df_input.append(tmp, ignore_index=True)

    if late and 'County Monthly Precipitation' in line:
        page = True
        start = False
        mid = False
        late = False
        count = offset

# remove the non-mitton counties
df_input = df_input[~(df_input['County'].isin(upper_counties))]

fips = list()
headers = {'Accept': 'text/html'}
tmp_station = dict()

# determine the FIPS state/county value for the county in question
for county in df_input['County']:
    county_fips = df_geo[(df_geo['State FIPS Code'] == state_fips) &
                 (df_geo['County Name/State Abbreviation'].str.contains(county))]['County FIPS Code'].values
    if len(county_fips) == 0:
        county_fips = df_geo[(df_geo['State FIPS Code'] == state_fips) &
             (df_geo['County Name/State Abbreviation'].str.contains(county.split()[1]))]['County FIPS Code'].values
    fips.append("{:02d}{:03d}".format(state_fips, county_fips[0]))
    station = "{:02d}{:03d}".format(state_fips, county_fips[0])

    # overall note: the web scrapping takes a long time so we have a saved table to pull from instead.
    # but flip the value for the read_internal variable to have to actually read the data.
    # always download data from counties that have issues.

    if read_internal and county not in issue_counties:
        county_stations = last_years_data_saved[county]
    else:
        # To get the "latest" rainfall data we must queriey the cli-dap online database.
        # For each county found out which weather stations exists in the county and database
        resp = requests.get(station_info_url.replace('FIPS', station), headers=headers)

        # start with zero rainfall and sum on top of it.
        county_stations = [ 0.0 ] * 12

        for entry in resp.json():
            # get the name of each station in this county
            station_id = entry['weabaseid'].lower()

            # sometimes downloaded data is really bad, in which case read the saved and cleaned values
            if station_id in issue_stations:
                county_stations = last_years_data_saved[county]
                continue

            # for this station grab the data. The URL has a year range/data type/monthly sum already baked in
            data_resp = requests.get(station_data_url.replace('CALLSIGN', station_id)).json()
            index = 0

            # for each month in the data given back add it into the monthly sum array for this county
            for item in data_resp:
                if index < 12:
                    if not str(data_resp[item]['PRE']).isalpha():
                        county_stations[index] += data_resp[item]['PRE']

                index += 1

    # make a column to slap into the main dataframe
    tmp_station[county] = county_stations

df_input['Latest Rainfall'] = tmp_station.values()

# some initial values for a color range. In the end its not used.
colorscale = ["#8dd3c7", "#ffffb3", "#bebada", "#fb8072",
              "#80b1d3", "#fdb462", "#b3de69", "#fccde5",
              "#d9d9d9", "#bc80bd", "#ccebc5", "#ffed6f",
              "#8dd3c7", "#ffffb3", "#bebada", "#fb8072",
              "#80b1d3", "#fdb462", "#b3de69", "#fccde5",
              "#d9d9d9", "#bc80bd", "#ccebc5", "#ffed6f",
              "#8dd3c7", "#ffffb3", "#bebada", "#fb8072",
              "#80b1d3", "#fdb462", "#b3de69", "#fccde5",
              "#d9d9d9", "#bc80bd", "#ccebc5", "#ffed6f"]

# use only non-negative values.
# when plotting the difference between historic and last year's data we only
# care about that which is greater then average (ie positive)
endpts = list(np.linspace(0.01, 5.0, len(colorscale) - 1))

# try to make an animated image.
# each step is a month
def animate_plot(step):
    # step = 1

    legend_txt = "Inches Above Historic Average (in)"
    values = list()
    max_country = 0
    max_val = -10.0

    # go through each county in this month and find the one with the most rainfall
    for county in df_input.index:
        tmp_val = float(df_input['Latest Rainfall'].loc[county][step]) - float(df_input.loc[county][months[step]])
        values.append(tmp_val)
        if tmp_val > max_val:
            max_country = county
            max_val = tmp_val

    # if last year's data isnt larger then historic plot the historic data.
    if max_val < 0:
        values = df_input[months[step]].astype('float').to_list()
        legend_txt = "Inches of Average Monthly Rainfall (in)"

    # create a plot of the mitten part of Michigan with county markers.
    # color is the amount last year's monthly average is above average for that county
    fig = ff.create_choropleth(
        fips=fips,
        values=values,
        scope=[state],
        show_state_data=False,
        # colorscale=colorscale,
        binning_endpoints=endpts,
        round_legend_values=False,
        # legend_title=legend_txt,
        plot_bgcolor='rgb(229,229,229)',
        paper_bgcolor='rgb(229,229,229)',
        # title="Monthly Rainfall for the Month of {}: Max Country This Month: {}".format(long_months[step], df_input.loc[max_country][0]),
        county_outline={'color': 'rgb(255,255,255)', 'width': 0.5},
        show_hover=True, #hoverlabel=df_input['County'],
        exponent_format=False
    )

    fig.layout.template = None
    fig.update_layout(legend_title_text=legend_txt, legend_orientation="v", # legend=dict(x=0, y=0),
                      title="Monthly Rainfall for the Month of {}: Max Country This Month: {}".format(long_months[step], df_input.loc[max_country][0]),
                      autosize=True, width=700, height=800)

    fig.show()

# anim = FuncAnimation(ff, animate_plot, init_func=init_plot, frames=2, interval=20, blit=True)
for mon in range(12):
    animate_plot(mon)
