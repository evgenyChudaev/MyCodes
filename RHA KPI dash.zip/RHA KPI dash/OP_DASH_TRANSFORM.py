import pandas as pd
import numpy as np
from pandas.tseries.offsets import MonthEnd
import sys
import cx_Oracle
import traceback
import datetime

CONN_INFO = {
    'host': 'dbo08n.cio.gov.ns.ca',
    'port': 1521,
    'user': 'HOUSING_WORK',
    'psw': '0Summer+=*',
    'service': 'DWH01_NPR'
}

CONN_STR = '{user}/{psw}@{host}:{port}/{service}'.format(**CONN_INFO)


class Oracle_DB:
    def __init__(self):
        self.conn = cx_Oracle.connect(CONN_STR)
        self.conn.autocommit = True  # autocommit attribute will ensure transactions are automatically committed . This reduces database load and eliminates the round-trip to the DB

    def query(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            result = cursor.execute(query, kwargs).fetchall()
            response = 'SUCCESS', result
        except:
            response = 'FAILED : {}'.format(traceback.format_exc()), None
        finally:
            cursor.close()
        return response

    def insert(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.executemany(query, kwargs.get('values', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED : {}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def update(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs.get('params', None))
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED : {}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg

    def delete(self, query, **kwargs):
        try:
            cursor = self.conn.cursor()
            cursor.execute(query, kwargs)
            ora_msg = 'SUCCESS'
        except:
            ora_msg = 'FAILED : {}'.format(traceback.format_exc())
        finally:
            cursor.close()
        return ora_msg


def trim_all_columns(df):
    trim_strings = lambda x: x.strip() if isinstance(x, str) else x
    return df.applymap(trim_strings)


def FilterEligibleApplicants(df):
    df = df.query('STATUS == "Eligible" | STATUS == "To Board"')
    #df = df.query('HILS != "Yes" & (Application_Status == "Eligible" | Application_Status == "Applied" | Application_Status == "Pending")& Transfer != "Yes"')
    #df = df.query('HILS != "Yes" & (Application_Status == "Eligible")& Transfer != "Yes"')
    #df = df[df["HILS"] != "Yes" & (df["Application_Status"] == "Eligible" | df["Application_Status"] == "Applied" | df["Application_Status"] == "Pending") & Transfer != "Yes"]
    return df

def RemoveTransfers(df):    
    df = df.query('TRANSFER != "Yes"')    
    return df

def filter_rent_supp_only(df):
    df['PH_Counter'] = np.where(
        df['PROGRAM'].isin(['RNH', 'Public Housing', 'AHP - Affordable Housing Progr', 'Other', 'LP - Lease Purchase', 'Demo']),
        1, 0)
    df_group_by_counter = df.groupby(['ID', 'RHA']).agg({'PH_Counter': 'sum'}).reset_index()
    df_group_by_counter = df_group_by_counter.loc[df_group_by_counter['PH_Counter'] > 0]
    # df_group_by_counter.to_csv(OUTPUT_PATH + 'RS_Only3.csv')
    df_no_rent_supps_only = pd.merge(df, df_group_by_counter, on=['ID', 'RHA'], how='inner')
    # df_no_rent_supps_only.to_csv(OUTPUT_PATH + 'waitlist_final.csv')
    return df_no_rent_supps_only


def ImportCSV(v_path, v_colNumsRequired, v_colNames, v_dtypes, v_skipRows, v_skipFooter, v_orderList):
    df = pd.read_csv(v_path, skiprows=v_skipRows, usecols=v_colNumsRequired, dtype=v_dtypes, skipfooter=v_skipFooter,
                     engine='python')
    df = df[v_orderList]
    df.columns = v_colNames
    return df


def UpdateApplicantType(df):
    if df['Household_Size'] > 2:
        applicantType = 'Family'
    elif df['Household_Size'] == 2 and df['Marital_Status'] not in ('Married', 'Common Law'):
        applicantType = 'Family'
    elif df['Applicant_Age'] < 58 and df['Household_Size'] <= 2:
        applicantType = 'Non-Elderly'
    elif df['Applicant_Age'] >= 58 and df['Household_Size'] <= 2:
        applicantType = 'Senior'
    else:
        applicantType = 'na'

    return applicantType


def MapDataFrame(df, cal_yr, month, day):       
    df['APPLIED_DATE'] = pd.to_datetime(df['APPLIED_DATE']) 
    df['STATUS_DATE'] = pd.to_datetime(df['STATUS_DATE']) 
    df['REPORTING_PERIOD'] = pd.to_datetime(str(cal_yr) + '-' + month + '-' + day)   
    return df


def group_and_clean(df):
    #df = df[df["Application_Status"] == status]
    #df['Income_Bucket'] = df.apply(Bucket_Incomes, axis=1)
    #df['Family_Size_SUM'] = df['Household_Size'].astype(int)
    df = df.drop_duplicates(['APPLICANT_ID', 'RHA'], keep='last')
    
    # group by and append 3 dataframes - for Eligible, Applied and Pending. Some apps may be Eligible in 1 RHA and Applied/Pending in Another
    
    #df_dedup = df.drop_duplicates(['ID'], keep='first')
    #df_dedup = df_dedup.fillna(
    '''    value={'RHA': '0', 'Yardi_Res_Type': 'n/a', 'HILS': 'n/a', 'Transfer': 'n/a', 'Receives_IA': 'n/a',
               'Household_Size': 'n/a', 'Gender': 'n/a',
               'Marital_Status': 'n/a', 'Homeowner': 'n/a', 'Priority_Access': 'n/a', 'HNS_Client_Type': 'n/a',
               'Year_Applied': 'n/a', 'Month_Applied': 'n/a',
               'Period': 'n/a', 'Income_Bucket': 'n/a', 'Applicant_Age': 0, 'Income': 0, 'Applied_Today_DateDelta': 0,
               'Family_Size_SUM': 0, 'Application_Status': 'n/a'})

                df_grouped = df_dedup.groupby(['RHA', 'Yardi_Res_Type', 'HILS', 'Transfer', 'Receives_IA', 'Household_Size',
                                   'Gender', 'Marital_Status', 'Homeowner', 'Priority_Access', 'HNS_Client_Type',
                                   'Year_Applied', 'Month_Applied', 'Period', 'Income_Bucket', 'Application_Status']).agg({'Count': 'sum',
                                                                                                     'Applicant_Age': 'sum',
                                                                                                     'Income': 'sum',
                                                                                                     'Applied_Today_DateDelta': 'sum',
                                                                                                     'Family_Size_SUM': 'sum'
                                                                                                     }).reset_index() '''
    return df

def upload_targets(TARGET_REPORT_PATH):
    required_col_list = ['Target Name', 'RHA', 'Target 1', 'Target 2', 'Target 3', 'Target Start Date', 'Target End Date']
    required_dtypes = {'Target Name': str, 'RHA': str, 'Target 1': str, 'Target 2': str, 'Target 3': str, 'Target Start Date': str, 'Target End Date': str}                           
    new_col_name_list = ['TARGET_NAME', 'TARGET_RHA', 'TARGET_VALUE_1', 'TARGET_VALUE_2', 'TARGET_VALUE_3', 'TARGET_START_DATE', 'TARGET_END_DATE']
    skip_header_rows = 0
    skip_footer_rows = 0
    
    df_targets = ImportCSV(TARGET_REPORT_PATH, required_col_list, new_col_name_list, required_dtypes, skip_header_rows, skip_footer_rows, required_col_list)        
    df_targets = trim_all_columns(df_targets)
    df_targets = df_targets.fillna(
        value={'TARGET_NAME': 'n/a', 'TARGET_RHA': 'n/a', 'TARGET_VALUE_1': 0, 'TARGET_VALUE_2': 0, 'TARGET_VALUE_3': 0,
        'TARGET_START_DATE': '1900-Jan-01', 'TARGET_END_DATE': '1900-Jan-01'})            
    
    df_targets['TARGET_START_DATE'] = pd.to_datetime(df_targets['TARGET_START_DATE'])
    df_targets['TARGET_END_DATE'] = pd.to_datetime(df_targets['TARGET_END_DATE'])         
    
    # upload Targets to Oracle if output flag = 'y' in parameters file           
    myDb = Oracle_DB()  # instantiate Oracle DB instance
    # convert dataframe serioes to lists to be uploaded to Oracle            
    TARGET_NAME = df_targets['TARGET_NAME'].tolist()
    TARGET_RHA = df_targets['TARGET_RHA'].tolist()
    TARGET_VALUE_1 = df_targets['TARGET_VALUE_1'].tolist()
    TARGET_VALUE_2 = df_targets['TARGET_VALUE_2'].tolist()
    TARGET_VALUE_3 = df_targets['TARGET_VALUE_3'].tolist()
    TARGET_START_DATE = df_targets['TARGET_START_DATE'].tolist()
    TARGET_END_DATE = df_targets['TARGET_END_DATE'].tolist()
    
    # perform target start/end date validation to make sure user can not append targets with the same or overalapping start/end dates  that already exist in the DB.
    # create a set of unique target dates
    set_target_start_date = set(TARGET_START_DATE)
    set_target_end_date = set(TARGET_END_DATE)
    
    SELECT_QRY_START_END_DATES = '''
        SELECT TARGET_START_DATE, TARGET_END_DATE 
        FROM OP_DASH_TARGETS
        GROUP BY TARGET_START_DATE,TARGET_END_DATE
    '''
    select_result = myDb.query(SELECT_QRY_START_END_DATES)
    if select_result[0] == 'SUCCESS':
        DATE_OVERLAP_EXCEPTION_MSG = 'One of the target dates you are trying to upload overlaps with the start/end dates in the database. Please review targets file before uploading.'
        #stop_flag = False
        date_set = select_result[1]
        for tuple in date_set:
            ora_start_date = tuple[0]
            ora_end_date = tuple[1]
            for start_date in set_target_start_date:  # check if start date is within the period that already exists in DB and avoid period overlap                      
                #print("new start date: {} start: {} , end: {}, compared: {}".format(start_date, tuple[0], tuple[1], start_date >= tuple[0] and start_date <= tuple[1]))
                if start_date >= ora_start_date and start_date <= ora_end_date:
                    #stop_flag = True 
                    raise Exception(DATE_OVERLAP_EXCEPTION_MSG)
            for end_date in set_target_end_date:      # check if end date is within the period that already exists in DB and avoid period overlap                            
                #print("new end date: {} start: {} , end: {}, compared: {}".format(end_date, tuple[0], tuple[1], end_date >= tuple[0] and end_date <= tuple[1]))
                if end_date >= ora_start_date and end_date <= tuple[1]:
                    #stop_flag = True
                    raise Exception(DATE_OVERLAP_EXCEPTION_MSG)
        
        
        #print("One of the rarget dates you are trying to upload overlaps with the start/end dates in the database. Please review targets file before uploading.")
                
                
    else:
        print('UNABLE TO RUN SELECT STATEMENT ON TARGET START/END DATES')
    
    #for i in set_target_start_date
    #    print(i)
    
    upload_rows = list(
        zip(TARGET_NAME, TARGET_RHA, TARGET_VALUE_1,TARGET_VALUE_2, TARGET_VALUE_3, TARGET_START_DATE, TARGET_END_DATE ))

    INSERT_QRY = '''
                   INSERT INTO OP_DASH_TARGETS   (TARGET_NAME,
                                                        TARGET_RHA,
                                                        TARGET_VALUE_1,
                                                        TARGET_VALUE_2,
                                                        TARGET_VALUE_3,
                                                        TARGET_START_DATE,
                                                        TARGET_END_DATE)                                                             
                                                VALUES (:TARGET_NAME,
                                                        :TARGET_RHA,
                                                        :TARGET_VALUE_1,
                                                        :TARGET_VALUE_2,
                                                        :TARGET_VALUE_3,
                                                        :TARGET_START_DATE,
                                                        :TARGET_END_DATE)
                                                                       '''

    insert_result = myDb.insert(INSERT_QRY, values=upload_rows)
    return insert_result

def upload_actuals(df_waitlist_dedup):
    myDb = Oracle_DB()  # instantiate Oracle DB instance
    # convert dataframe serioes to lists to be uploaded to Oracle            
    APPLICANT_ID = df_waitlist_dedup['APPLICANT_ID'].tolist()
    RHA = df_waitlist_dedup['RHA'].tolist()
    STATUS = df_waitlist_dedup['STATUS'].tolist()
    PRIORITY_ACCESS = df_waitlist_dedup['PRIORITY_ACCESS'].tolist()
    APPLIED_DATE = df_waitlist_dedup['APPLIED_DATE'].tolist()
    STATUS_DATE = df_waitlist_dedup['STATUS_DATE'].tolist()
    AREA = df_waitlist_dedup['AREA'].tolist()
    MUNICIPALITY = df_waitlist_dedup['MUNICIPALITY'].tolist()
    REPORTING_PERIOD = df_waitlist_dedup['REPORTING_PERIOD'].tolist()
    COMPLETENESS = df_waitlist_dedup['COMPLETENESS'].tolist()
    upload_rows = list(zip(APPLICANT_ID, RHA, STATUS,  AREA, MUNICIPALITY, APPLIED_DATE, STATUS_DATE,REPORTING_PERIOD, COMPLETENESS))

    INSERT_QRY = '''
                   INSERT INTO OP_DASH_ACTUALS         (APPLICANT_ID,
                                                        RHA,
                                                        STATUS,                                                                                                            
                                                        AREA,
                                                        MUNICIPALITY,
                                                        APPLIED_DATE,
                                                        STATUS_DATE,
                                                        REPORTING_PERIOD,
                                                        COMPLETENESS
                                                        )                                                             
                                                VALUES (:APPLICANT_ID,
                                                        :RHA,
                                                        :STATUS,                                                                                                               
                                                        :AREA,
                                                        :MUNICIPALITY,
                                                        :APPLIED_DATE,
                                                        :STATUS_DATE,
                                                        :REPORTING_PERIOD,
                                                        :COMPLETENESS
                                                       )
                                                                       '''

    insert_result = myDb.insert(INSERT_QRY, values=upload_rows)
    return insert_result

def import_actuals(ACTUALS_REPORT_PATH, skip_header_rows,skip_footer_rows, required_col_list, required_dtypes, new_col_name_list):
   
    df_waitlist = ImportCSV(ACTUALS_REPORT_PATH, required_col_list, new_col_name_list, required_dtypes,
                            skip_header_rows, skip_footer_rows, required_col_list)    
    return df_waitlist

def check_completeness(df, cols_to_check):
    for col in cols_to_check:        
        if col == 'SIN PROVIDED':
            #df.loc[(df[col].isnull()) | df[col].isnull()), col] = 0
            #df.loc[df[col].isnull(), col] = 0
            df[col] = df[col].apply(lambda x: 0 if (x.upper() == 'BLANK' or x.upper() == 'NO') else 1)
        else:
            df[col] = df[col].apply(lambda x: 0 if x.upper() == 'BLANK' else 1)           
    
    return df   
    
    
def concat_columns(df, cols_to_concat, new_col_name, column_sep=";", value_sep=':'):
    df[new_col_name] = cols_to_concat[0] + value_sep + df[cols_to_concat[0]].astype(str)
    for col in cols_to_concat[1:]:        
        df[new_col_name] =  df[new_col_name] + column_sep + col + value_sep + df[col].astype(str)
    
    return df

def transform_actuals(df_waitlist, cal_yr, month, day, OUTPUT_PATH, filter_eligible, excl_rs, save_details, save_summary, source_name):           
    
    df_waitlist = trim_all_columns(df_waitlist)
   
    # temporary solution to fill n/a for LONG waitlist report in a different way than for eligible/to board/canceled while 
    # LONG report is in development and for now needs to be merged with normal waitlist report. 
    if source_name != 'WAITLIST_LONG':
        df_waitlist = MapDataFrame(df_waitlist, cal_yr, month, day)
        df_waitlist = RemoveTransfers(df_waitlist)
    
    if filter_eligible:
        df_waitlist = FilterEligibleApplicants(df_waitlist)  #XXXX!!! eligible applicants only
    
    
    if excl_rs  == 'y':  #XXXX!!!  exclude rent supp only applications
        df_waitlist = filter_rent_supp_only(df_waitlist)
    # group by and append 3 dataframes - for Eligible, Applied and Pending. Some apps may be Eligible in 1 RHA and Applied/Pending in Another
   
          
     
    if save_details  == 'y':  #XXXX!!!  save details to csv
        df_waitlist.to_csv('{}{}{}'.format(OUTPUT_PATH, source_name ,'_details.csv'))
    
     
    
    # temporary solution to fill n/a for LONG waitlist report in a different way than for eligible/to board/canceled while 
    # LONG report is in development and for now needs to be merged with normal waitlist report. 
    if source_name == 'WAITLIST_LONG':
        df_waitlist_dedup = df_waitlist.drop_duplicates('APPLICANT_ID', keep='last') # LONG waitlist does not have RHA, can only dedup on App ID
        df_waitlist_dedup = df_waitlist_dedup.fillna(value={'APPLICANT_ID': 'n/a', 'RHA': 'n/a', 'OVER HILS':'blank', 'RESIDENCY MET':'blank', 'HOME PHONE':'blank', 'CELL PHONE':'blank',
                                                            'EMAIL':'blank', 'SIN PROVIDED':'blank', 'SAFE TO CONTACT':'blank', 'CURRENT ADDRESS':'blank', 'CURRENT POSTAL CODE':'blank', 
                                                            'CURRENT CITY':'blank', 'CURRENT PROVINCE':'blank', 'CURRENT COUNTRY':'blank'}) 
        #concatenate all columns where completeness is checked in 1 column so it can be saved in the Database                                                                    
        cols_to_concatenate = ['OVER HILS', 'RESIDENCY MET', 'HOME PHONE', 'CELL PHONE', 'EMAIL', 'SIN PROVIDED', 'SAFE TO CONTACT', 
                               'CURRENT ADDRESS', 'CURRENT POSTAL CODE', 'CURRENT CITY', 'CURRENT PROVINCE', 'CURRENT COUNTRY']
        df_waitlist_dedup =   check_completeness(df_waitlist_dedup, cols_to_concatenate )                        
        df_waitlist_dedup =   concat_columns(df_waitlist_dedup, cols_to_concatenate, 'COMPLETENESS', ' | ', ':')                                             
    else:
        df_waitlist_dedup = group_and_clean(df_waitlist)  # remove duplicates based on Application ID and RHA   
        df_waitlist_dedup = df_waitlist_dedup.fillna(value={'APPLICANT_ID': 'n/a', 'RHA': 'n/a', 'STATUS': 'n/a', 'PRIORITY_ACCESS': 'n/a', 'AREA': 'n/a', 'MUNICIPALITY': 'n/a', 
                                                    'APPLIED_DATE': pd.Timestamp('19000101'), 'STATUS_DATE': pd.Timestamp('19000101'), 'REPORTING_PERIOD': pd.Timestamp('19000101')})  
    
    if save_summary  == 'y':  #XXXX!!!  save details to csv
        df_waitlist_dedup.to_csv('{}{}{}'.format(OUTPUT_PATH, source_name ,'_summary.csv'))
    
    
    #print(df_waitlist_dedup.dtypes)
    # fix below as fillna doesn't always work
    #df_waitlist_dedup = df_waitlist_dedup.fillna(value={'APPLICANT_ID': 'n/a', 'RHA': 'n/a', 'STATUS': 'n/a', 'PRIORITY_ACCESS': 'n/a', 'AREA': 'n/a', 'MUNICIPALITY': 'n/a', 
    #                                             'APPLIED_DATE': '1900-01-01', 'STATUS_DATE': '1900-01-01', 'REPORTING_PERIOD': '1900-01-01'})         
       
    return df_waitlist_dedup

def GetDataFromOra(select_qry_str):
    myDb = Oracle_DB()  # instantiate Oracle DB instance    
    #SELECT_QRY_STATUS_REC_COUNT = "SELECT STATUS, COUNT(*) FROM OP_DASH_ACTUALS WHERE REPORTING_PERIOD = TO_DATE('"+ report_date+ "', 'yyyy-MONTH-dd') GROUP BY STATUS"
    select_result = myDb.query(select_qry_str)
    return (select_result)
    

        
if __name__ == '__main__':
   
    df_params = pd.read_csv(sys.argv[1])
    print("\n PARAMETERS FOR REPORT GENERATOR: \n ")
    print(df_params)
    print("\n PLEASE REVIEW THE ABOVE PARAMETERS AND ENTER 'yes' and PRESS ENTER TO CONTINUE: ")

    if str.upper(str.strip(str(input()))) == 'YES':  # if user selected yes, continue running the report
        print("Running report... \n")
        
        targets_ora_upload = df_params.iloc[9]['Value']
        actuals_waitlist_ora_upload = df_params.iloc[6]['Value']
        actuals_cancelled_ora_upload = df_params.iloc[13]['Value']
        actuals_housed_ora_upload = df_params.iloc[20]['Value']
        OUTPUT_PATH = df_params.iloc[5]['Value'] + '\\'
        WAITLIST_REPORT_PATH = df_params.iloc[0]['Value']     
        CANCELLED_REPORT_PATH = df_params.iloc[10]['Value']
        HOUSED_REPORT_PATH = df_params.iloc[17]['Value']
        WAITLIST_LONG_REPORT_PATH = df_params.iloc[15]['Value']
        TARGET_REPORT_PATH = df_params.iloc[8]['Value']
        cal_yr = int(df_params.iloc[1]['Value'])
        month = df_params.iloc[2]['Value']
        day = df_params.iloc[16]['Value']
            
        if targets_ora_upload == 'y':  # upload targets                      
            upload_result = upload_targets(TARGET_REPORT_PATH)
            print("Oracle import status for TARGETS: " + upload_result)  # If all is fine, Oracle will return "Success" message.
            
        if actuals_waitlist_ora_upload == 'y':  # upload actuals & actuals for completeness           
            include_eligible_only = False  # include Eligible and To Board only
            excl_rs = df_params.iloc[7]['Value']
            save_details = df_params.iloc[3]['Value']
            save_summary = df_params.iloc[4]['Value']
            source_name = 'waitlist'
            required_col_list = ['ID', 'RHA', 'Program', 'Status', 'Access', 'Applied', 'Status.3', 'Area', 'Municipality', 'Transfer']
            required_dtypes = {'ID': str, 'RHA': str, 'Program': str, 'Status': str, 'Access': str, 'Applied': str, 'Status.3': str, 'Area': str, 'Municipality': str, 'Transfer': str}
            new_col_name_list = ['APPLICANT_ID', 'RHA', 'PROGRAM', 'STATUS', 'PRIORITY_ACCESS', 'APPLIED_DATE', 'STATUS_DATE', 'AREA', 'MUNICIPALITY', 'TRANSFER']
            df_waitlist_short = import_actuals(WAITLIST_REPORT_PATH, 2,1, required_col_list, required_dtypes, new_col_name_list)
            df_waitlist_short_transformed = transform_actuals(df_waitlist_short, cal_yr, month, day, OUTPUT_PATH, include_eligible_only, excl_rs, save_details, save_summary, source_name)
            #ora_upload_status = upload_actuals(df_waitlist_short_transformed)
            
            #add logic to merge in Applicant management extract long version for completeness
            source_name = 'WAITLIST_LONG'
            required_col_list = ['ID', 'RHA', 'HILS', 'ResidencyMet', 'HomePhone', 'CellPhone', 'email', 'SIN', 'Safecontact', 'CSTREET', 'CPOSTALCODE', 'ccity', 'CPROVINCE', 'ccountry']
            required_dtypes = {'ID':str, 'RHA':str, 'HILS':str, 'ResidencyMet':str, 'HomePhone':str, 'CellPhone':str, 'email':str, 'SIN':str, 'Safecontact':str, 'CSTREET':str, 'CPOSTALCODE':str, 'ccity':str, 'CPROVINCE':str, 'ccountry':str}
            new_col_name_list = ['APPLICANT_ID', 'RHA', 'OVER HILS', 'RESIDENCY MET', 'HOME PHONE', 'CELL PHONE', 'EMAIL', 'SIN PROVIDED', 'SAFE TO CONTACT', 'CURRENT ADDRESS', 'CURRENT POSTAL CODE', 
                                'CURRENT CITY', 'CURRENT PROVINCE', 'CURRENT COUNTRY']
            df_waitlist_long = import_actuals(WAITLIST_LONG_REPORT_PATH, 2,1, required_col_list, required_dtypes, new_col_name_list)
            df_waitlist_long_transformed = transform_actuals(df_waitlist_long, cal_yr, month, day, OUTPUT_PATH, False, False, 'y', 'y', source_name)
            df_waitlist_long_transformed = df_waitlist_long_transformed[['APPLICANT_ID', 'COMPLETENESS']]
            df_waitlist_short_long_merge = pd.merge(df_waitlist_short_transformed, df_waitlist_long_transformed, on=['APPLICANT_ID'], how='left').fillna('n/a') # merge waitlist and waitlist long
            df_waitlist_short_long_merge.to_csv(('{}{}'.format(OUTPUT_PATH, 'completeness_summary.csv')))              
            ora_upload_status = upload_actuals(df_waitlist_short_long_merge)
            print("Oracle import status for ACTUALS - ELIGIBLE: " + ora_upload_status)  # If all is fine, Oracle will return "Success" message.
            
        if actuals_cancelled_ora_upload == 'y':  # upload cancellations          
            include_eligible_only = False
            excl_rs = df_params.iloc[14]['Value']
            save_details = df_params.iloc[11]['Value']
            save_summary = df_params.iloc[12]['Value']
            source_name = 'cancellations'        
            
            
            required_col_list = ['ID', 'RHA', 'Program', 'Status', 'Access', 'Applied', 'Status.3', 'Area', 'Municipality', 'Transfer']
            required_dtypes = {'ID': str, 'RHA': str, 'Program': str, 'Status': str, 'Access': str, 'Applied': str, 'Status.3': str, 'Area': str, 'Municipality': str, 'Transfer': str}
            new_col_name_list = ['APPLICANT_ID', 'RHA', 'PROGRAM', 'STATUS', 'PRIORITY_ACCESS', 'APPLIED_DATE', 'STATUS_DATE', 'AREA', 'MUNICIPALITY', 'TRANSFER']
            
            df_waitlist_canceled = import_actuals(CANCELLED_REPORT_PATH, 2,1, required_col_list, required_dtypes, new_col_name_list)
            df_waitlist_canceled_dedup = transform_actuals(df_waitlist_canceled, cal_yr, month, day, OUTPUT_PATH, include_eligible_only, excl_rs, save_details, save_summary, source_name)
            df_waitlist_canceled_dedup['COMPLETENESS'] = 'n/a'  #add completeness column for cancellations with constant value as completeness check is not done for cancellations
            ora_upload_status = upload_actuals(df_waitlist_canceled_dedup)
            
            
            #upload_result = upload_actuals(CANCELLED_REPORT_PATH, cal_yr, month, OUTPUT_PATH, include_eligible_only, excl_rs, save_details, save_summary, source_name)
            print("Oracle import status for ACTUALS - CANCELED: " + ora_upload_status)  # If all is fine, Oracle will return "Success" message.
            
        if actuals_housed_ora_upload == 'y':  # upload housed     
            include_eligible_only = False
            excl_rs = df_params.iloc[21]['Value']
            save_details = df_params.iloc[18]['Value']
            save_summary = df_params.iloc[19]['Value']
            source_name = 'housed'         
                      
            
            required_col_list = ['ID', 'RHA', 'Program', 'Status', 'Access', 'Applied', 'Status.3', 'Area', 'Municipality', 'Transfer']
            required_dtypes = {'ID': str, 'RHA': str, 'Program': str, 'Status': str, 'Access': str, 'Applied': str, 'Status.3': str, 'Area': str, 'Municipality': str, 'Transfer': str}
            new_col_name_list = ['APPLICANT_ID', 'RHA', 'PROGRAM', 'STATUS', 'PRIORITY_ACCESS', 'APPLIED_DATE', 'STATUS_DATE', 'AREA', 'MUNICIPALITY', 'TRANSFER']
            
            df_waitlist_housed = import_actuals(HOUSED_REPORT_PATH, 2,1, required_col_list, required_dtypes, new_col_name_list)
            df_waitlist_housed_dedup = transform_actuals(df_waitlist_housed, cal_yr, month, day, OUTPUT_PATH, include_eligible_only, excl_rs, save_details, save_summary, source_name)
            df_waitlist_housed_dedup['COMPLETENESS'] = 'n/a'  #add completeness column for cancellations with constant value as completeness check is not done for cancellations
            ora_upload_status = upload_actuals(df_waitlist_housed_dedup)
            
            
            #upload_result = upload_actuals(CANCELLED_REPORT_PATH, cal_yr, month, OUTPUT_PATH, include_eligible_only, excl_rs, save_details, save_summary, source_name)
            print("Oracle import status for ACTUALS - HOUSED: " + ora_upload_status)  # If all is fine, Oracle will return "Success" message.
            
        
        date_current = str(cal_yr) + '-' + month + '-' + day
        # show stats by status (# of applications for current reporting period)        
        SELECT_QRY_STATUS_REC_COUNT = "SELECT STATUS, COUNT(*) FROM OP_DASH_ACTUALS WHERE REPORTING_PERIOD = TO_DATE('"+ date_current+ "', 'yyyy-MONTH-dd') GROUP BY STATUS"        
        status_stats_list = GetDataFromOra(SELECT_QRY_STATUS_REC_COUNT)
        if status_stats_list[0] == 'SUCCESS':
            print("\n-------------------------------")
            print("RECORDS IMPORTED BY STATUS: ")
            print("-------------------------------")
            status_stats_dict = dict(status_stats_list[1])
            complete_status_list = ['Prospect', 'Appeal', 'Canceled', 'Applied', 'Housed', 'Eligible', 'Pending', 'To Board', 'Ineligible', 'On Offer']
            for status in complete_status_list:
                status_stat_val = status_stats_dict.get(status, 'none')
                if status_stat_val != 'none':
                    print('{}: {}'.format(status, status_stat_val))
                else:
                    print('{}: {}'.format(status, 'NO RECORDS'))
        else:
            print('SOMETHING WENT WRONG')
                
                    
        # show duplicate stats        
        SELECT_QRY_DUPLICATE_REC_COUNT = "SELECT COUNT(*) FROM (SELECT applicant_id, RHA, COUNT(*) AS COUNT FROM OP_DASH_ACTUALS WHERE REPORTING_PERIOD = TO_DATE('"+ date_current+ "', 'yyyy-MONTH-dd') GROUP BY applicant_id, RHA HAVING COUNT(*) > 1)"        
        duplicate_stats = GetDataFromOra(SELECT_QRY_DUPLICATE_REC_COUNT)
        if duplicate_stats[0] == 'SUCCESS':
            print("\n--------------------------------------------")
            print("DUPLICATE RECORDS ON APPLICANT ID & RHA KEY:  ")
            print("----------------------------------------------")            
        
            print(duplicate_stats[1][0][0])
        
        else:
            print('SOMETHING WENT WRONG')
            
        #else:
        #    print('No records available')
        
    else:
        print('You have selected not to run the report. Good bye')
    
    
    
