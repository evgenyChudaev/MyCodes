﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using Oracle.ManagedDataAccess;
using System.Data.SQLite;
using Oracle.ManagedDataAccess.Client;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
using excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApp1
{

    public partial class Form1 : Form
    {
        // SqlConnection conn = new SqlConnection(@"Data Source=L-5CG8477VP6\SQLEXPRESS;Initial Catalog=testDb;Integrated Security=True");
        OracleConnection con = new OracleConnection();

        OracleConnectionStringBuilder ocsb = new OracleConnectionStringBuilder();

        public Form1()
        {
            InitializeComponent();
            populateSearchTableColumns();
        }

        private void textBox1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;
            textBox1.BackColor = Color.MistyRose;
        }

        private void textBox1_DragDrop(object sender, DragEventArgs e)
        {
            textBox1.Clear();
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string file in files)
            {
                textBox1.Text += "\r\n" + file;
                Console.WriteLine(file);
            }

        }


        private void button2_Click(object sender, EventArgs e)
        {
            int lines = textBox1.Lines.Length;
            if (lines > 0)
            {
                for (int i = 1; i < lines; i++)
                {
                    //MessageBox.Show(textBox1.Lines[i]);
                }

               // if(textBox1.Lines[1])
                uploadExcelToDatabase(textBox1.Lines[1]);
            }


            textBox1.Text = "Drag and Drop Spreadsheet here";
            textBox1.BackColor = Color.Linen;
        }



        private void uploadExcelToDatabase(string csv_file_path)
        {
            string ext = Path.GetExtension(csv_file_path);

            if (ext == ".txt" || ext == ".csv")
            {
                uploadTextFile(csv_file_path);
            }
            else if(ext == ".xlsx")
            {
                uploadXlsx(csv_file_path);
            }
            else if (ext == ".xls")
            {
                uploadXlsx(csv_file_path);
            }
        }

        private void uploadXlsx(string xlsx_file_path)
        {
            //Create COM Objects. Create a COM object for everything that is referenced
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(xlsx_file_path);
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Excel.Range xlRange = xlWorksheet.UsedRange;

            DataTable dt = new DataTable();

            int rowCount = xlRange.Rows.Count;
            int colCount = xlRange.Columns.Count;
            string[] values; //= new string[colCount];

            // take column names from excel, it appears the file excel is not zero based!!
            for (int i = 1; i <= colCount; i++)
            {
                string headerName = xlRange.Cells[1, i].Value2;
                dt.Columns.Add(xlRange.Cells[1, i].Value2);               
            }

            //read excel data from row 2
            for (int i = 2; i <= rowCount; i++)
            {
                values = new string[colCount];
                for (int j = 1; j <= colCount; j++)
                {              
                    //write the value to the console
                    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                    {
                        if(j == 18 || j== 19)
                        {
                            //MessageBox.Show("i: " + i  + "j: " + j + " " +xlRange.Cells[i, j].Value.ToString());
                            values[j - 1] = Convert.ToDateTime(xlRange.Cells[i, j].Value).ToString("yyyy-MM-dd");
                        }
                        else
                        {
                            values[j - 1] = xlRange.Cells[i, j].Value2.ToString();
                        }
                                            
                    }
                   // Console.WriteLine("j: " + j);
                }
               
                dt.Rows.Add(values);
            }

            //cleanup
            GC.Collect();
            GC.WaitForPendingFinalizers();

            //rule of thumb for releasing com objects:
            //  never use two dots, all COM objects must be referenced and released individually
            //  ex: [somthing].[something].[something] is bad

            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);

            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);

            dgvShowData.DataSource = dt;

            txtRowsSourceFile.Text = checkDataTableRowCount(ref dt).ToString();
            txtRowsUpload.Text = "N/A";
        }
             


        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = "Drag and Drop Spreadsheet here";
        }

        // list box for drag and drop instead of textbox)
        private void listBox1_DragEnter(object sender, DragEventArgs e)
        {
            listBox1.BackColor = Color.Aqua;
        }

        private void lstFileUploader_DragLeave(object sender, EventArgs e)
        {
            listBox1.BackColor = Color.Beige;
        }

     

        private void uploadTextFile(string csv_file_path)
        {
            DataTable csvData = new DataTable();
            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { "\t" });
                    //csvReader.SetDelimiters(new string[] { "|" });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {

                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }
                dgvShowData.DataSource = csvData;
                txtRowsSourceFile.Text = checkDataTableRowCount(ref csvData).ToString();
                txtRowsUpload.Text = "N/A";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void listBox1_DragDrop(object sender, DragEventArgs e)
        {
            textBox1.Clear();
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string file in files)
            {
                listBox1.Items.Add(file);
                // Console.WriteLine(file);
            }
        }



        private void textBox1_DragLeave(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.Linen;
        }


        private void load_CumulativeData()
        {

        }

        // Load Raw Data from the CLAIMS_DATA table
        private DataTable load_ORA_Data(string procName, string currQuarter, string currFY)
        {
            connectOracle();
            con.Open();

            DataTable myTbl = null;
            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = procName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_fy", OracleDbType.Varchar2).Value = currFY;
            cmd.Parameters.Add("p_fq", OracleDbType.Varchar2).Value = currQuarter;
            cmd.Parameters.Add("p_ref", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda = new OracleDataAdapter(cmd);
            oda.Fill(ds);

            if (ds.Tables.Count > 0)
            {
                myTbl = ds.Tables[0];
            }
            con.Close();
            return myTbl;

        }






        private void connectOracle()
        {
            ocsb.Password = "XXXX";
            ocsb.UserID = "XXXX";
            ocsb.DataSource = "XXXX";
            con.ConnectionString = ocsb.ConnectionString;

        }


        private void button8_Click(object sender, EventArgs e)
        {
            if (cmbFY_Upload.Text == "--SELECT FY--" || cmbFQ_Upload.Text == "--SELECT FQ--" || txtTransactionDescription.Text == "")
            {
                MessageBox.Show("Select a valid fiscal year and a quarter and input short description and try again.");
            }
            else
            {
                if (dgvShowData.Rows.Count == 0)
                {
                    MessageBox.Show("There are no records to upload to the database. Please select the file and review its content below before uploading.");
                }
                else
                {
                    uploadData();
                }
            }
        }


        private void uploadData()
        {
            try
            {
                DataTable dt = new DataTable();
                foreach (DataGridViewColumn col in dgvShowData.Columns)
                {
                    dt.Columns.Add(col.Name);
                }

                foreach (DataGridViewRow row in dgvShowData.Rows)
                {
                    DataRow dRow = dt.NewRow();
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        dRow[cell.ColumnIndex] = cell.Value;
                    }
                    dt.Rows.Add(dRow);
                }

                string currQuarter = cmbFQ_Upload.Text;
                string currFY = cmbFY_Upload.Text;
                txtRowsUpload.Text = UploadRawDataToOracle(dt, currQuarter, currFY).ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public int UploadRawDataToOracle(DataTable dt, string currQuarter, string currFY)
        {
            int rowsAffected = 0;
            try
            {
                connectOracle();
                con.Open();

                int arraySize = dt.Rows.Count;
                string[] FQ = new string[arraySize];
                string[] FY = new string[arraySize];
                string[] TYPE = new string[arraySize];
                string[] REFERENCE_NUM = new string[arraySize];
                string[] PROJECT_NAME = new string[arraySize];
                string[] ADDRESS_STREET_NUM = new string[arraySize];
                string[] ADDRESS_STREET_NAME = new string[arraySize];
                string[] ADDRESS_STREET_TYPE = new string[arraySize];
                string[] ADDRESS_STREET_DIRECTION = new string[arraySize];
                string[] ADDRESS_UNIT_NUM = new string[arraySize];
                string[] ADDRESS_CITY = new string[arraySize];
                string[] ADDRESS_POSTAL_CODE = new string[arraySize];
                string[] ADDRESS_PROVINCE_TERRITORY = new string[arraySize];
                string[] SPONSOR = new string[arraySize];
                string[] INITIATIVES = new string[arraySize];
                string[] HOUSING_INTERVENTION = new string[arraySize];
                string[] HOUSING_TYPE = new string[arraySize];
                string[] SOCIAL_HOUSING_TYPE = new string[arraySize];
                string[] TARGET_GROUPS = new string[arraySize];
                string[] START_DATE = new string[arraySize];
                string[] COMPLETED_DATE = new string[arraySize];
                decimal[] UNITS_TOTAL = new decimal[arraySize];
                decimal[] UNITS_BELOW_MARKET = new decimal[arraySize];
                decimal[] UNITS_LOW_INCOME = new decimal[arraySize];
                decimal[] UNITS_TARGET_GROUPS = new decimal[arraySize];
                decimal[] UNITS_ACCESSIBLE = new decimal[arraySize];
                decimal[] TOTAL_DOLLARS_COMMITTED = new decimal[arraySize];
                decimal[] FUNDING_AMT_OF_CLAIM = new decimal[arraySize];
                decimal[] CM_COMMITTED_PT_FUNDING = new decimal[arraySize];
                decimal[] CM_COMMITTED_MUNICIPAL_FUNDING = new decimal[arraySize];
                decimal[] CM_COMMITTED_OTHERS = new decimal[arraySize];
                decimal[] CM_COMMITTED_TOTAL = new decimal[arraySize];
                decimal[] CMHC_ONGOING_CONTRIB_YEAR_NUM = new decimal[arraySize];
                decimal[] CMHC_ONGOING_CONTRIB_LIFETIME = new decimal[arraySize];
                decimal[] CM_ONGOING_PT_YEAR_NUM = new decimal[arraySize];
                decimal[] CM_ONGOING_PT_LIFETIME = new decimal[arraySize];
                decimal[] CM_ONGOING_MUNICIPAL_YEAR_NUM = new decimal[arraySize];
                decimal[] CM_ONGOING_MUNICIPAL_LIFETIME = new decimal[arraySize];
                decimal[] CM_ONGOING_OTHERS_YEAR_NUM = new decimal[arraySize];
                decimal[] CM_ONGOING_OTHERS_LIFETIME = new decimal[arraySize];
                decimal[] TOTAL_DOLLARS_DISBURSED = new decimal[arraySize];
                decimal[] CM_DISBURSED_PT_FUNDING = new decimal[arraySize];
                decimal[] CM_DISBURED_MUNICIPAL_FUNDING = new decimal[arraySize];
                decimal[] CM_DISBURSED_OTHERS = new decimal[arraySize];
                decimal[] CM_DISBURSED_TOTAL = new decimal[arraySize];
                string[] ENVIRONMENTAL_COMPLIANCE = new string[arraySize];
                decimal[] EFFICIENCY_REDUCTION_ACHIEVED = new decimal[arraySize];
                decimal[] EFFICIENCY_TARGET = new decimal[arraySize];
                string[] TRANSACTION_DESCRIPTION = new string[arraySize];
                string[] PRODUCTS = new string[arraySize];



                for (int j = 0; j < dt.Rows.Count; j++)
                {
                    FQ[j] = currQuarter;
                    FY[j] = currFY;
                    TYPE[j] = Convert.ToString(dt.Rows[j]["TYPE"]);
                    REFERENCE_NUM[j] = Convert.ToString(dt.Rows[j]["REFERENCE_NUM"]);
                    PROJECT_NAME[j] = Convert.ToString(dt.Rows[j]["PROJECT_NAME"]);
                    ADDRESS_STREET_NUM[j] = Convert.ToString(dt.Rows[j]["ADDRESS_STREET_NUM"]);
                    ADDRESS_STREET_NAME[j] = Convert.ToString(dt.Rows[j]["ADDRESS_STREET_NAME"]);
                    ADDRESS_STREET_TYPE[j] = Convert.ToString(dt.Rows[j]["ADDRESS_STREET_TYPE"]);
                    ADDRESS_STREET_DIRECTION[j] = Convert.ToString(dt.Rows[j]["ADDRESS_STREET_DIRECTION"]);
                    ADDRESS_UNIT_NUM[j] = Convert.ToString(dt.Rows[j]["ADDRESS_UNIT_NUM"]);
                    ADDRESS_CITY[j] = Convert.ToString(dt.Rows[j]["ADDRESS_CITY"]);
                    ADDRESS_POSTAL_CODE[j] = Convert.ToString(dt.Rows[j]["ADDRESS_POSTAL_CODE"]);
                    ADDRESS_PROVINCE_TERRITORY[j] = Convert.ToString(dt.Rows[j]["ADDRESS_PROVINCE_TERRITORY"]);
                    SPONSOR[j] = Convert.ToString(dt.Rows[j]["SPONSOR"]);
                    INITIATIVES[j] = Convert.ToString(dt.Rows[j]["INITIATIVES"]);
                    HOUSING_INTERVENTION[j] = Convert.ToString(dt.Rows[j]["HOUSING_INTERVENTION"]);
                    HOUSING_TYPE[j] = Convert.ToString(dt.Rows[j]["HOUSING_TYPE"]);
                    SOCIAL_HOUSING_TYPE[j] = Convert.ToString(dt.Rows[j]["SOCIAL_HOUSING_TYPE"]);
                    TARGET_GROUPS[j] = Convert.ToString(dt.Rows[j]["TARGET_GROUPS"]);
                    START_DATE[j] = Convert.ToString(dt.Rows[j]["START_DATE"]);
                    COMPLETED_DATE[j] = Convert.ToString(dt.Rows[j]["COMPLETED_DATE"]);

                    UNITS_TOTAL[j] = convertToDecimal(dt.Rows[j]["UNITS_TOTAL"].ToString());
                    UNITS_BELOW_MARKET[j] = convertToDecimal(dt.Rows[j]["UNITS_BELOW_MARKET"].ToString());
                    UNITS_LOW_INCOME[j] = convertToDecimal(dt.Rows[j]["UNITS_LOW_INCOME"].ToString());
                    UNITS_TARGET_GROUPS[j] = convertToDecimal(dt.Rows[j]["UNITS_TARGET_GROUPS"].ToString());
                    UNITS_ACCESSIBLE[j] = convertToDecimal(dt.Rows[j]["UNITS_ACCESSIBLE"].ToString());
                    TOTAL_DOLLARS_COMMITTED[j] = convertToDecimal(dt.Rows[j]["TOTAL_DOLLARS_COMMITTED"].ToString());
                    FUNDING_AMT_OF_CLAIM[j] = convertToDecimal(dt.Rows[j]["FUNDING_AMT_OF_CLAIM"].ToString());
                    CM_COMMITTED_PT_FUNDING[j] = convertToDecimal(dt.Rows[j]["CM_COMMITTED_PT_FUNDING"].ToString());
                    CM_COMMITTED_MUNICIPAL_FUNDING[j] = convertToDecimal(dt.Rows[j]["CM_COMMITTED_MUNICIPAL_FUNDING"].ToString());
                    CM_COMMITTED_OTHERS[j] = convertToDecimal(dt.Rows[j]["CM_COMMITTED_OTHERS"].ToString());
                    CM_COMMITTED_TOTAL[j] = convertToDecimal(dt.Rows[j]["CM_COMMITTED_TOTAL"].ToString());
                    CMHC_ONGOING_CONTRIB_YEAR_NUM[j] = convertToDecimal(dt.Rows[j]["CMHC_ONGOING_CONTRIB_YEAR_NUM"].ToString());
                    CMHC_ONGOING_CONTRIB_LIFETIME[j] = convertToDecimal(dt.Rows[j]["CMHC_ONGOING_CONTRIB_LIFETIME"].ToString());
                    CM_ONGOING_PT_YEAR_NUM[j] = convertToDecimal(dt.Rows[j]["CM_ONGOING_PT_YEAR_NUM"].ToString());
                    CM_ONGOING_PT_LIFETIME[j] = convertToDecimal(dt.Rows[j]["CM_ONGOING_PT_LIFETIME"].ToString());
                    CM_ONGOING_MUNICIPAL_YEAR_NUM[j] = convertToDecimal(dt.Rows[j]["CM_ONGOING_MUNICIPAL_YEAR_NUM"].ToString());
                    CM_ONGOING_MUNICIPAL_LIFETIME[j] = convertToDecimal(dt.Rows[j]["CM_ONGOING_MUNICIPAL_LIFETIME"].ToString());
                    CM_ONGOING_OTHERS_YEAR_NUM[j] = convertToDecimal(dt.Rows[j]["CM_ONGOING_OTHERS_YEAR_NUM"].ToString());
                    CM_ONGOING_OTHERS_LIFETIME[j] = convertToDecimal(dt.Rows[j]["CM_ONGOING_OTHERS_LIFETIME"].ToString());
                    TOTAL_DOLLARS_DISBURSED[j] = convertToDecimal(dt.Rows[j]["TOTAL_DOLLARS_DISBURSED"].ToString());
                    CM_DISBURSED_PT_FUNDING[j] = convertToDecimal(dt.Rows[j]["CM_DISBURSED_PT_FUNDING"].ToString());
                    CM_DISBURED_MUNICIPAL_FUNDING[j] = convertToDecimal(dt.Rows[j]["CM_DISBURED_MUNICIPAL_FUNDING"].ToString());
                    CM_DISBURSED_OTHERS[j] = convertToDecimal(dt.Rows[j]["CM_DISBURSED_OTHERS"].ToString());
                    CM_DISBURSED_TOTAL[j] = convertToDecimal(dt.Rows[j]["CM_DISBURSED_TOTAL"].ToString());

                    ENVIRONMENTAL_COMPLIANCE[j] = Convert.ToString(dt.Rows[j]["ENVIRONMENTAL_COMPLIANCE"]);
                    EFFICIENCY_REDUCTION_ACHIEVED[j] = convertToDecimal(dt.Rows[j]["EFFICIENCY_REDUCTION_ACHIEVED"].ToString());
                    EFFICIENCY_TARGET[j] = convertToDecimal(dt.Rows[j]["EFFICIENCY_TARGET"].ToString());
                    PRODUCTS[j] = Convert.ToString(dt.Rows[j]["PRODUCTS"]);

                    TRANSACTION_DESCRIPTION[j] = Convert.ToString(txtTransactionDescription.Text);

                }

                OracleParameter param_FQ = new OracleParameter(); param_FQ.OracleDbType = OracleDbType.Varchar2; param_FQ.Value = FQ;
                OracleParameter param_FY = new OracleParameter(); param_FY.OracleDbType = OracleDbType.Varchar2; param_FY.Value = FY;
                OracleParameter param_TYPE = new OracleParameter(); param_TYPE.OracleDbType = OracleDbType.Varchar2; param_TYPE.Value = TYPE;
                OracleParameter param_REFERENCE_NUM = new OracleParameter(); param_REFERENCE_NUM.OracleDbType = OracleDbType.Varchar2; param_REFERENCE_NUM.Value = REFERENCE_NUM;
                OracleParameter param_PROJECT_NAME = new OracleParameter(); param_PROJECT_NAME.OracleDbType = OracleDbType.Varchar2; param_PROJECT_NAME.Value = PROJECT_NAME;
                OracleParameter param_ADDRESS_STREET_NUM = new OracleParameter(); param_ADDRESS_STREET_NUM.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_STREET_NUM.Value = ADDRESS_STREET_NUM;
                OracleParameter param_ADDRESS_STREET_NAME = new OracleParameter(); param_ADDRESS_STREET_NAME.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_STREET_NAME.Value = ADDRESS_STREET_NAME;
                OracleParameter param_ADDRESS_STREET_TYPE = new OracleParameter(); param_ADDRESS_STREET_TYPE.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_STREET_TYPE.Value = ADDRESS_STREET_TYPE;
                OracleParameter param_ADDRESS_STREET_DIRECTION = new OracleParameter(); param_ADDRESS_STREET_DIRECTION.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_STREET_DIRECTION.Value = ADDRESS_STREET_DIRECTION;
                OracleParameter param_ADDRESS_UNIT_NUM = new OracleParameter(); param_ADDRESS_UNIT_NUM.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_UNIT_NUM.Value = ADDRESS_UNIT_NUM;
                OracleParameter param_ADDRESS_CITY = new OracleParameter(); param_ADDRESS_CITY.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_CITY.Value = ADDRESS_CITY;
                OracleParameter param_ADDRESS_POSTAL_CODE = new OracleParameter(); param_ADDRESS_POSTAL_CODE.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_POSTAL_CODE.Value = ADDRESS_POSTAL_CODE;
                OracleParameter param_ADDRESS_PROVINCE_TERRITORY = new OracleParameter(); param_ADDRESS_PROVINCE_TERRITORY.OracleDbType = OracleDbType.Varchar2; param_ADDRESS_PROVINCE_TERRITORY.Value = ADDRESS_PROVINCE_TERRITORY;
                OracleParameter param_SPONSOR = new OracleParameter(); param_SPONSOR.OracleDbType = OracleDbType.Varchar2; param_SPONSOR.Value = SPONSOR;
                OracleParameter param_INITIATIVES = new OracleParameter(); param_INITIATIVES.OracleDbType = OracleDbType.Varchar2; param_INITIATIVES.Value = INITIATIVES;
                OracleParameter param_HOUSING_INTERVENTION = new OracleParameter(); param_HOUSING_INTERVENTION.OracleDbType = OracleDbType.Varchar2; param_HOUSING_INTERVENTION.Value = HOUSING_INTERVENTION;
                OracleParameter param_HOUSING_TYPE = new OracleParameter(); param_HOUSING_TYPE.OracleDbType = OracleDbType.Varchar2; param_HOUSING_TYPE.Value = HOUSING_TYPE;
                OracleParameter param_SOCIAL_HOUSING_TYPE = new OracleParameter(); param_SOCIAL_HOUSING_TYPE.OracleDbType = OracleDbType.Varchar2; param_SOCIAL_HOUSING_TYPE.Value = SOCIAL_HOUSING_TYPE;
                OracleParameter param_TARGET_GROUPS = new OracleParameter(); param_TARGET_GROUPS.OracleDbType = OracleDbType.Varchar2; param_TARGET_GROUPS.Value = TARGET_GROUPS;
                OracleParameter param_START_DATE = new OracleParameter(); param_START_DATE.OracleDbType = OracleDbType.Varchar2; param_START_DATE.Value = START_DATE;
                OracleParameter param_COMPLETED_DATE = new OracleParameter(); param_COMPLETED_DATE.OracleDbType = OracleDbType.Varchar2; param_COMPLETED_DATE.Value = COMPLETED_DATE;


                OracleParameter param_UNITS_TOTAL = new OracleParameter(); param_UNITS_TOTAL.OracleDbType = OracleDbType.Decimal; param_UNITS_TOTAL.Value = UNITS_TOTAL;
                OracleParameter param_UNITS_BELOW_MARKET = new OracleParameter(); param_UNITS_BELOW_MARKET.OracleDbType = OracleDbType.Decimal; param_UNITS_BELOW_MARKET.Value = UNITS_BELOW_MARKET;
                OracleParameter param_UNITS_LOW_INCOME = new OracleParameter(); param_UNITS_LOW_INCOME.OracleDbType = OracleDbType.Decimal; param_UNITS_LOW_INCOME.Value = UNITS_LOW_INCOME;
                OracleParameter param_UNITS_TARGET_GROUPS = new OracleParameter(); param_UNITS_TARGET_GROUPS.OracleDbType = OracleDbType.Decimal; param_UNITS_TARGET_GROUPS.Value = UNITS_TARGET_GROUPS;
                OracleParameter param_UNITS_ACCESSIBLE = new OracleParameter(); param_UNITS_ACCESSIBLE.OracleDbType = OracleDbType.Decimal; param_UNITS_ACCESSIBLE.Value = UNITS_ACCESSIBLE;
                OracleParameter param_TOTAL_DOLLARS_COMMITTED = new OracleParameter(); param_TOTAL_DOLLARS_COMMITTED.OracleDbType = OracleDbType.Decimal; param_TOTAL_DOLLARS_COMMITTED.Value = TOTAL_DOLLARS_COMMITTED;
                OracleParameter param_FUNDING_AMT_OF_CLAIM = new OracleParameter(); param_FUNDING_AMT_OF_CLAIM.OracleDbType = OracleDbType.Decimal; param_FUNDING_AMT_OF_CLAIM.Value = FUNDING_AMT_OF_CLAIM;
                OracleParameter param_CM_COMMITTED_PT_FUNDING = new OracleParameter(); param_CM_COMMITTED_PT_FUNDING.OracleDbType = OracleDbType.Decimal; param_CM_COMMITTED_PT_FUNDING.Value = CM_COMMITTED_PT_FUNDING;
                OracleParameter param_CM_COMMITTED_MUNICIPAL_FUNDING = new OracleParameter(); param_CM_COMMITTED_MUNICIPAL_FUNDING.OracleDbType = OracleDbType.Decimal; param_CM_COMMITTED_MUNICIPAL_FUNDING.Value = CM_COMMITTED_MUNICIPAL_FUNDING;
                OracleParameter param_CM_COMMITTED_OTHERS = new OracleParameter(); param_CM_COMMITTED_OTHERS.OracleDbType = OracleDbType.Decimal; param_CM_COMMITTED_OTHERS.Value = CM_COMMITTED_OTHERS;
                OracleParameter param_CM_COMMITTED_TOTAL = new OracleParameter(); param_CM_COMMITTED_TOTAL.OracleDbType = OracleDbType.Decimal; param_CM_COMMITTED_TOTAL.Value = CM_COMMITTED_TOTAL;
                OracleParameter param_CMHC_ONGOING_CONTRIB_YEAR_NUM = new OracleParameter(); param_CMHC_ONGOING_CONTRIB_YEAR_NUM.OracleDbType = OracleDbType.Decimal; param_CMHC_ONGOING_CONTRIB_YEAR_NUM.Value = CMHC_ONGOING_CONTRIB_YEAR_NUM;
                OracleParameter param_CMHC_ONGOING_CONTRIB_LIFETIME = new OracleParameter(); param_CMHC_ONGOING_CONTRIB_LIFETIME.OracleDbType = OracleDbType.Decimal; param_CMHC_ONGOING_CONTRIB_LIFETIME.Value = CMHC_ONGOING_CONTRIB_LIFETIME;
                OracleParameter param_CM_ONGOING_PT_YEAR_NUM = new OracleParameter(); param_CM_ONGOING_PT_YEAR_NUM.OracleDbType = OracleDbType.Decimal; param_CM_ONGOING_PT_YEAR_NUM.Value = CM_ONGOING_PT_YEAR_NUM;
                OracleParameter param_CM_ONGOING_PT_LIFETIME = new OracleParameter(); param_CM_ONGOING_PT_LIFETIME.OracleDbType = OracleDbType.Decimal; param_CM_ONGOING_PT_LIFETIME.Value = CM_ONGOING_PT_LIFETIME;
                OracleParameter param_CM_ONGOING_MUNICIPAL_YEAR_NUM = new OracleParameter(); param_CM_ONGOING_MUNICIPAL_YEAR_NUM.OracleDbType = OracleDbType.Decimal; param_CM_ONGOING_MUNICIPAL_YEAR_NUM.Value = CM_ONGOING_MUNICIPAL_YEAR_NUM;
                OracleParameter param_CM_ONGOING_MUNICIPAL_LIFETIME = new OracleParameter(); param_CM_ONGOING_MUNICIPAL_LIFETIME.OracleDbType = OracleDbType.Decimal; param_CM_ONGOING_MUNICIPAL_LIFETIME.Value = CM_ONGOING_MUNICIPAL_LIFETIME;
                OracleParameter param_CM_ONGOING_OTHERS_YEAR_NUM = new OracleParameter(); param_CM_ONGOING_OTHERS_YEAR_NUM.OracleDbType = OracleDbType.Decimal; param_CM_ONGOING_OTHERS_YEAR_NUM.Value = CM_ONGOING_OTHERS_YEAR_NUM;
                OracleParameter param_CM_ONGOING_OTHERS_LIFETIME = new OracleParameter(); param_CM_ONGOING_OTHERS_LIFETIME.OracleDbType = OracleDbType.Decimal; param_CM_ONGOING_OTHERS_LIFETIME.Value = CM_ONGOING_OTHERS_LIFETIME;
                OracleParameter param_TOTAL_DOLLARS_DISBURSED = new OracleParameter(); param_TOTAL_DOLLARS_DISBURSED.OracleDbType = OracleDbType.Decimal; param_TOTAL_DOLLARS_DISBURSED.Value = TOTAL_DOLLARS_DISBURSED;
                OracleParameter param_CM_DISBURSED_PT_FUNDING = new OracleParameter(); param_CM_DISBURSED_PT_FUNDING.OracleDbType = OracleDbType.Decimal; param_CM_DISBURSED_PT_FUNDING.Value = CM_DISBURSED_PT_FUNDING;
                OracleParameter param_CM_DISBURED_MUNICIPAL_FUNDING = new OracleParameter(); param_CM_DISBURED_MUNICIPAL_FUNDING.OracleDbType = OracleDbType.Decimal; param_CM_DISBURED_MUNICIPAL_FUNDING.Value = CM_DISBURED_MUNICIPAL_FUNDING;
                OracleParameter param_CM_DISBURSED_OTHERS = new OracleParameter(); param_CM_DISBURSED_OTHERS.OracleDbType = OracleDbType.Decimal; param_CM_DISBURSED_OTHERS.Value = CM_DISBURSED_OTHERS;
                OracleParameter param_CM_DISBURSED_TOTAL = new OracleParameter(); param_CM_DISBURSED_TOTAL.OracleDbType = OracleDbType.Decimal; param_CM_DISBURSED_TOTAL.Value = CM_DISBURSED_TOTAL;

                OracleParameter param_ENVIRONMENTAL_COMPLIANCE = new OracleParameter(); param_ENVIRONMENTAL_COMPLIANCE.OracleDbType = OracleDbType.Varchar2; param_ENVIRONMENTAL_COMPLIANCE.Value = ENVIRONMENTAL_COMPLIANCE;
                OracleParameter param_EFFICIENCY_REDUCTION_ACHIEVED = new OracleParameter(); param_EFFICIENCY_REDUCTION_ACHIEVED.OracleDbType = OracleDbType.Decimal; param_EFFICIENCY_REDUCTION_ACHIEVED.Value = EFFICIENCY_REDUCTION_ACHIEVED;
                OracleParameter param_EFFICIENCY_TARGET = new OracleParameter(); param_EFFICIENCY_TARGET.OracleDbType = OracleDbType.Decimal; param_EFFICIENCY_TARGET.Value = EFFICIENCY_TARGET;
                OracleParameter param_PRODUCTS = new OracleParameter(); param_PRODUCTS.OracleDbType = OracleDbType.Varchar2; param_PRODUCTS.Value = PRODUCTS;
                OracleParameter param_TRANSACTION_DESCRIPTION = new OracleParameter(); param_TRANSACTION_DESCRIPTION.OracleDbType = OracleDbType.Varchar2; param_TRANSACTION_DESCRIPTION.Value = TRANSACTION_DESCRIPTION;

                OracleCommand cmd = con.CreateCommand();
                cmd.CommandText = "INSERT INTO CLAIMS_DATA (FQ, FY, TYPE, REFERENCE_NUM, PROJECT_NAME, ADDRESS_STREET_NUM, ADDRESS_STREET_NAME, " +
                    "ADDRESS_STREET_TYPE, ADDRESS_STREET_DIRECTION, ADDRESS_UNIT_NUM, ADDRESS_CITY, ADDRESS_POSTAL_CODE, ADDRESS_PROVINCE_TERRITORY, " +
                    "SPONSOR, INITIATIVES, HOUSING_INTERVENTION, HOUSING_TYPE, SOCIAL_HOUSING_TYPE, TARGET_GROUPS, START_DATE, COMPLETED_DATE," +
                    " UNITS_TOTAL, UNITS_BELOW_MARKET, UNITS_LOW_INCOME, UNITS_TARGET_GROUPS, UNITS_ACCESSIBLE, TOTAL_DOLLARS_COMMITTED, " +
                    "FUNDING_AMT_OF_CLAIM, CM_COMMITTED_PT_FUNDING, CM_COMMITTED_MUNICIPAL_FUNDING, CM_COMMITTED_OTHERS, CM_COMMITTED_TOTAL, " +
                    "CMHC_ONGOING_CONTRIB_YEAR_NUM, CMHC_ONGOING_CONTRIB_LIFETIME, CM_ONGOING_PT_YEAR_NUM, CM_ONGOING_PT_LIFETIME, " +
                    "CM_ONGOING_MUNICIPAL_YEAR_NUM, CM_ONGOING_MUNICIPAL_LIFETIME, CM_ONGOING_OTHERS_YEAR_NUM, CM_ONGOING_OTHERS_LIFETIME, " +
                    "TOTAL_DOLLARS_DISBURSED, CM_DISBURSED_PT_FUNDING, CM_DISBURED_MUNICIPAL_FUNDING, CM_DISBURSED_OTHERS, CM_DISBURSED_TOTAL," +
                    " ENVIRONMENTAL_COMPLIANCE, EFFICIENCY_REDUCTION_ACHIEVED, EFFICIENCY_TARGET, TRANSACTION_DESCRIPTION, PRODUCTS) " +
                    "VALUES (:1, :2, :3, :4, :5, :6, :7, :8, :9, :10, :11, :12, :13, :14, :15, :16, :17, :18, :19, :20, :21, :22, :23, " +
                    ":24, :25, :26, :27, :28, :29, :30, :31, :32, :33, :34, :35, :36, :37, :38, :39, :40, :41, :42, :43, :44, :45, :46, :47, :48, :49, :50)";

                cmd.ArrayBindCount = arraySize;

                cmd.Parameters.Add(param_FQ);
                cmd.Parameters.Add(param_FY);
                cmd.Parameters.Add(param_TYPE);
                cmd.Parameters.Add(param_REFERENCE_NUM);
                cmd.Parameters.Add(param_PROJECT_NAME);
                cmd.Parameters.Add(param_ADDRESS_STREET_NUM);
                cmd.Parameters.Add(param_ADDRESS_STREET_NAME);
                cmd.Parameters.Add(param_ADDRESS_STREET_TYPE);
                cmd.Parameters.Add(param_ADDRESS_STREET_DIRECTION);
                cmd.Parameters.Add(param_ADDRESS_UNIT_NUM);
                cmd.Parameters.Add(param_ADDRESS_CITY);
                cmd.Parameters.Add(param_ADDRESS_POSTAL_CODE);
                cmd.Parameters.Add(param_ADDRESS_PROVINCE_TERRITORY);
                cmd.Parameters.Add(param_SPONSOR);
                cmd.Parameters.Add(param_INITIATIVES);
                cmd.Parameters.Add(param_HOUSING_INTERVENTION);
                cmd.Parameters.Add(param_HOUSING_TYPE);
                cmd.Parameters.Add(param_SOCIAL_HOUSING_TYPE);
                cmd.Parameters.Add(param_TARGET_GROUPS);
                cmd.Parameters.Add(param_START_DATE);
                cmd.Parameters.Add(param_COMPLETED_DATE);

                cmd.Parameters.Add(param_UNITS_TOTAL);
                cmd.Parameters.Add(param_UNITS_BELOW_MARKET);
                cmd.Parameters.Add(param_UNITS_LOW_INCOME);
                cmd.Parameters.Add(param_UNITS_TARGET_GROUPS);
                cmd.Parameters.Add(param_UNITS_ACCESSIBLE);
                cmd.Parameters.Add(param_TOTAL_DOLLARS_COMMITTED);
                cmd.Parameters.Add(param_FUNDING_AMT_OF_CLAIM);
                cmd.Parameters.Add(param_CM_COMMITTED_PT_FUNDING);
                cmd.Parameters.Add(param_CM_COMMITTED_MUNICIPAL_FUNDING);
                cmd.Parameters.Add(param_CM_COMMITTED_OTHERS);
                cmd.Parameters.Add(param_CM_COMMITTED_TOTAL);
                cmd.Parameters.Add(param_CMHC_ONGOING_CONTRIB_YEAR_NUM);
                cmd.Parameters.Add(param_CMHC_ONGOING_CONTRIB_LIFETIME);
                cmd.Parameters.Add(param_CM_ONGOING_PT_YEAR_NUM);
                cmd.Parameters.Add(param_CM_ONGOING_PT_LIFETIME);
                cmd.Parameters.Add(param_CM_ONGOING_MUNICIPAL_YEAR_NUM);
                cmd.Parameters.Add(param_CM_ONGOING_MUNICIPAL_LIFETIME);
                cmd.Parameters.Add(param_CM_ONGOING_OTHERS_YEAR_NUM);
                cmd.Parameters.Add(param_CM_ONGOING_OTHERS_LIFETIME);
                cmd.Parameters.Add(param_TOTAL_DOLLARS_DISBURSED);
                cmd.Parameters.Add(param_CM_DISBURSED_PT_FUNDING);
                cmd.Parameters.Add(param_CM_DISBURED_MUNICIPAL_FUNDING);
                cmd.Parameters.Add(param_CM_DISBURSED_OTHERS);
                cmd.Parameters.Add(param_CM_DISBURSED_TOTAL);

                cmd.Parameters.Add(param_ENVIRONMENTAL_COMPLIANCE);
                cmd.Parameters.Add(param_EFFICIENCY_REDUCTION_ACHIEVED);
                cmd.Parameters.Add(param_EFFICIENCY_TARGET);
                cmd.Parameters.Add(param_TRANSACTION_DESCRIPTION);
                cmd.Parameters.Add(param_PRODUCTS);

                rowsAffected = cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            con.Close();

            MessageBox.Show("Uploaded to Oracle!!!");
            return rowsAffected;
        }


        public decimal convertToDecimal(string cellValue)
        {
            decimal cellValueDecimal = 0.00m;
            if (cellValue.Length != 0)
            {
                cellValueDecimal = Convert.ToDecimal(cellValue);
            }
            return cellValueDecimal;
        }




        private string folderDialogWindow()
        {
            string folderName = "";
            using (var folderDialog = new FolderBrowserDialog())
            {
                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    folderName = folderDialog.SelectedPath;
                }
            }
            return folderName;
        }

        public static void ExportToExcel(ref System.Data.DataTable DataTable, string ExcelFilePath, string periodName)
        {
            try
            {
                int ColumnsCount;

                if (DataTable == null || (ColumnsCount = DataTable.Columns.Count) == 0)
                {
                    //throw new Exception("ExportToExcel: Null or empty input table!\n");
                    MessageBox.Show("There are no records to export.");
                    return;
                }


                // load excel, and create a new workbook
                Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();
                Excel.Workbooks.Add();

                // single worksheet
                Microsoft.Office.Interop.Excel._Worksheet Worksheet = Excel.ActiveSheet;

                object[] Header = new object[ColumnsCount];

                // column headings               
                for (int i = 0; i < ColumnsCount; i++)
                {
                    Header[i] = DataTable.Columns[i].ColumnName;
                }

                Microsoft.Office.Interop.Excel.Range HeaderRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, ColumnsCount]));
                HeaderRange.Value = Header;
                HeaderRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                HeaderRange.Font.Bold = true;


                // DataCells
                int RowsCount = DataTable.Rows.Count;

                object[,] Cells = new object[RowsCount, ColumnsCount];

                for (int i = 0; i < ColumnsCount; i++)
                {

                    for (int j = 0; j < RowsCount; j++)
                    {
                        Cells[j, i] = DataTable.Rows[j][i];
                    }
                }

                Worksheet.Cells[1, 1].Value = "Report generated " + periodName;
                Worksheet.Cells[1, 1].Font.Italic = true;

                if (RowsCount == 0)
                {
                    Worksheet.Cells[3, 1].Value = "No results";
                }
                else
                {
                    Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[RowsCount + 2, ColumnsCount])).Value = Cells;
                }


                Worksheet.Columns.AutoFit();

                // check fielpath
                if (ExcelFilePath != null && ExcelFilePath != "")
                {
                    try
                    {
                        Worksheet.SaveAs(ExcelFilePath);
                        Excel.Quit();
                        MessageBox.Show("Report saved!");
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                            + ex.Message);
                    }
                }
                else    // no filepath is given
                {
                    Excel.Visible = true;
                }

                Marshal.FinalReleaseComObject(Worksheet);
                Marshal.FinalReleaseComObject(HeaderRange);
                Marshal.FinalReleaseComObject(Excel);
            }
            catch (Exception ex)
            {
                throw new Exception("ExportToExcel: \n" + ex.Message);
            }

        }



        private void deleteData(string procName, string currFY, string currQuarter)
        {
            connectOracle();
            con.Open();

            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = procName; //"GetClaimsPckg2.GetRawData";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_fy", OracleDbType.Varchar2).Value = currFY;
            cmd.Parameters.Add("p_fq", OracleDbType.Varchar2).Value = currQuarter;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void flagClaimData(string procName, string currFY, string currQuarter)
        {
            connectOracle();
            con.Open();

            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = procName; //"GetClaimsPckg2.GetRawData";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_fy", OracleDbType.Varchar2).Value = currFY;
            cmd.Parameters.Add("p_fq", OracleDbType.Varchar2).Value = currQuarter;
            cmd.ExecuteNonQuery();
            con.Close();
        }


        private void getCumulativeWithHierarchy(string cumulativeProc, string RawDataUptoProc, Dictionary<string, string> procParamsDictionary)
        {
            DataSet dsDataset = new DataSet();

            connectOracle();
            con.Open();

            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = cumulativeProc;
            cmd.CommandType = CommandType.StoredProcedure;


            //cmd.Parameters.Add("p_fy", OracleDbType.Varchar2).Value = currFY;
            //cmd.Parameters.Add("p_fq", OracleDbType.Varchar2).Value = currQuarter;
            foreach (KeyValuePair<string, string> entry in procParamsDictionary)
            {
                cmd.Parameters.Add(entry.Key, OracleDbType.Varchar2).Value = entry.Value;
            }
            cmd.Parameters.Add("p_ref", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda = new OracleDataAdapter(cmd);
            oda.Fill(ds);

            DataTable myPrimaryTbl = null;
            if (ds.Tables.Count > 0)
            {
                ds.Tables[0].TableName = "A";
                myPrimaryTbl = ds.Tables[0];               
                dsDataset.Tables.Add(ds.Tables[0].Copy());
                txtRecordsReport.Text = checkDataTableRowCount(ref myPrimaryTbl).ToString();
            }

            DataSet ds2 = new DataSet();
            OracleCommand cmd2 = con.CreateCommand();
            cmd2.CommandText = RawDataUptoProc;
            cmd2.CommandType = CommandType.StoredProcedure;
            //cmd2.Parameters.Add("p_fy", OracleDbType.Varchar2).Value = currFY;
            //cmd2.Parameters.Add("p_fq", OracleDbType.Varchar2).Value = currQuarter;
            foreach (KeyValuePair<string, string> entry in procParamsDictionary)
            {
                cmd2.Parameters.Add(entry.Key, OracleDbType.Varchar2).Value = entry.Value;
            }
            cmd2.Parameters.Add("p_ref", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda2 = new OracleDataAdapter(cmd2);
            oda2.Fill(ds2);

            if (ds2.Tables.Count > 0)
            {
                ds2.Tables[0].TableName = "B";
                dsDataset.Tables.Add(ds2.Tables[0].Copy());
            }

            // relate 2 tables on reference number 
            DataRelation Datatablerelation = new DataRelation("Project Details", dsDataset.Tables[0].Columns[1], dsDataset.Tables[1].Columns[3], false);
            dsDataset.Relations.Add(Datatablerelation);
            dgResultView.DataSource = dsDataset.Tables[0];

            con.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (cmbFQ_Expand.Text == "" && cmbFY_Expand.Text == "")
            {
                MessageBox.Show("You haven't selected a period in scope. Please select  FY and/or FQ.");
            }
            else // extract based on FY & FQ
            {
               string claim_flag_1;
               string claim_flag_2;

                if (chClaimExclude.Checked)
                {
                    //MessageBox.Show("CLAIMED INCLUDED");
                    claim_flag_1 = "0";
                    claim_flag_2 = "0";
                }                    
                else
                {
                   // MessageBox.Show("CLAIMED EXCLUDED");
                    claim_flag_1 = "0";
                    claim_flag_2 = "1";
                }

                string cumulativeProcedureName, rawDataProcedureName = "";
                string currQuarter = cmbFQ_Expand.Text;
                string currFY = cmbFY_Expand.Text;

                Dictionary<string, string> parametersForProcedure = new Dictionary<string, string>();

                if (cmbFY_Expand.Text == "ALL")
                {
                    // parametersForProcedure.Add("p_fy", currFY);                   
                    cumulativeProcedureName = "GetClaimsPckg2.GetCumulativeDataAllYears";
                    rawDataProcedureName = "GetClaimsPckg2.GetRawDataUpToAll";
                }
                else if (cmbFY_Expand.Text != "ALL" && cmbFY_Expand.Text != "" && cmbFQ_Expand.Text != "")
                {
                    parametersForProcedure.Add("p_fy", currFY);
                    parametersForProcedure.Add("p_fq", currQuarter);
                    parametersForProcedure.Add("p_claimed_1", claim_flag_1);
                    parametersForProcedure.Add("p_claimed_2", claim_flag_2);
                    cumulativeProcedureName = "GetClaimsPckg2.GetCumulativeData";
                    rawDataProcedureName = "GetClaimsPckg2.GetRawDataUpTo";
                }
                else
                {
                    MessageBox.Show("You haven't selected an FQ in scope.");
                    return;
                }

                getCumulativeWithHierarchy(cumulativeProcedureName, rawDataProcedureName, parametersForProcedure);
            }
        }

        // Load Raw Data from the CLAIMS_DATA table
        private DataTable get_RawOrCumulativeDataTable(string procName, string currQuarter, string currFY)
        {
            connectOracle();
            con.Open();


            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            DataTable myTable = new DataTable();
            cmd.CommandText = procName; //"GetClaimsPckg2.GetRawData";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_fy", OracleDbType.Varchar2).Value = currFY;
            cmd.Parameters.Add("p_fq", OracleDbType.Varchar2).Value = currQuarter;
            cmd.Parameters.Add("p_ref", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda = new OracleDataAdapter(cmd);
            oda.Fill(ds);

            if (ds.Tables.Count > 0)
            {

                myTable = ds.Tables[0];
            }


            con.Close();
            return myTable;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            ExportViewToExcelExpand();
        }


        private void ExportViewToExcelExpand()
        {
            string folderPath = folderDialogWindow();
            string asOfDate = DateTime.Today.ToString("d-M-yyyy");
            string periodCovered = cmbFY_Expand.Text + "-" + cmbFQ_Expand.Text;
            DataTable myTable = (DataTable)dgResultView.DataSource;

            string outputText = " for the period of " + periodCovered + " as at " + asOfDate;
            ExportToExcel(ref myTable, folderPath + @"\CMHC_Claims_Report" + outputText + ".xlsx", outputText);
        }

        private void btnDeleteFromDb_Click(object sender, EventArgs e)
        {

            if (cmbFY_Expand.Text == "ALL")
            {
                MessageBox.Show("You can only delete one quarter at a time for safety reasons. ");

            }
            else if (cmbFY_Expand.Text == "" || cmbFQ_Expand.Text == "")
            {
                MessageBox.Show("Please select a valid FY & FQ to delete. ");
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete records from the database?", "DELETE RECORD", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    deleteData("GetClaimsPckg2.DeleteClaimsData", cmbFY_Expand.Text, cmbFQ_Expand.Text);
                    MessageBox.Show("Records deleted");
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do nothing
                }
            }

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (cmbReportSelector.Text == "" || cmbFY_Analytics.Text == "" || cmbFQ_Analytics.Text == "")
            {
                MessageBox.Show("Either report name, FY or FQ hasn't been selected. Please try again.");
            }
            else
            {
                extractAnalyticsReports();
            }

        }

        private void extractAnalyticsReports()
        {
            string currQuarter = cmbFQ_Analytics.Text;
            string currFY = cmbFY_Analytics.Text;
            string selectedReport = cmbReportSelector.Text;
            DataTable myDtTbl = null;

            switch (selectedReport)
            {
                case "Same Building Analysis":
                    myDtTbl = load_ORA_Data("ANALYZECLAIMSPCKG.SameBldgReport", currQuarter, currFY);
                    break;
                case "Spend-to-date vs Committed":
                    myDtTbl = load_ORA_Data("ANALYZECLAIMSPCKG.SpendVsCommittedReport", currQuarter, currFY);
                    break;
                case "CMHC Claims (cumulative)":
                    myDtTbl = load_ORA_Data("GetClaimsPckg2.GetCumulativeData", currQuarter, currFY);
                    break;
                case "CMHC Claims (raw data)":
                    myDtTbl = load_ORA_Data("GetClaimsPckg2.GetRawData", currQuarter, currFY);
                    break;
                default:
                    MessageBox.Show("Invalid Report selected. Please try again");
                    break;
            }

            dgvAnalyticsReport.DataSource = myDtTbl.DefaultView;
            txtRecordsAnalysis.Text = checkDataTableRowCount(ref myDtTbl).ToString();

            populateDimensionMeasureDropDown();
            pnlVizContainer.BringToFront();
        }

        private void populateDimensionMeasureDropDown()
        {
            //DataTable dt = new DataTable();
            // dt = (DataTable)dgvAnalyticsReport.DataSource;
            string columnDataType;

            cmbGraphDimension.Items.Clear();
            cmbGraphMeasure.Items.Clear();
            foreach (DataGridViewColumn col in dgvAnalyticsReport.Columns)
            {
                columnDataType = col.ValueType.ToString();
                // Console.WriteLine(col.ValueType.ToString());
                switch (columnDataType)
                {
                    case "System.String":
                        cmbGraphDimension.Items.Add(col.Name);
                        cmbUserSearchField.Items.Add(col.Name);
                        break;
                    case "System.Decimal":
                        cmbGraphMeasure.Items.Add(col.Name);
                        break;
                    default:
                        break;
                }
            }
        }

        private int checkDataTableRowCount(ref DataTable dt)
        {
            int rowCount = 0;
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    rowCount = dt.Rows.Count;
                }
            }

            return rowCount;
        }


        private void btnRenderGraph_Click(object sender, EventArgs e)
        {
            if (dgvAnalyticsReport.RowCount <= 0)
            {
                MessageBox.Show("The data table is empty. Nothing to vizualize.");
            }
            else
            {
                if (cmbGraphDimension.Text == "" || cmbGraphMeasure.Text == "" || cmbChartType.Text == "")
                {
                    MessageBox.Show("You have to selected a dimension, measure and a chart type to visualize the data.");
                }
                else
                {
                    renderAnalyticsCharts();
                }
            }
        }


        private void renderAnalyticsCharts()
        {
            int rowCount = dgvAnalyticsReport.RowCount;
            int i = 0;
            List<dgvRecord> recordList = new List<dgvRecord>();
            string dimensionCol = "", measureCol = "", chartType = "";
            dimensionCol = cmbGraphDimension.Text;
            measureCol = cmbGraphMeasure.Text;
            chartType = cmbChartType.Text;

            while (i < rowCount)
            {
                recordList.Add(new dgvRecord(i, dgvAnalyticsReport.Rows[i].Cells[dimensionCol].Value.ToString(),
                    Convert.ToDecimal(dgvAnalyticsReport.Rows[i].Cells[measureCol].Value.ToString())));

                i++;
            }


            /*foreach(dgvRecord item in recordList)
            {
                Console.WriteLine(item.ToString());
            } */

            var qrySummary = from p in recordList
                             group p by new { p.dimension } into grp
                             select new
                             {
                                 category = grp.Key.dimension,
                                 totalMeasure = Math.Round(grp.Sum(p => Convert.ToDouble(p.measure)), 2)
                             };

            var analyticsDataArray = qrySummary.ToArray(); // putting category LINQ to array list so we can put it in a graph 

            // Console.WriteLine(analyticsDataArray[0].ToString());

            while (vizAnalytics1.Series.Count > 0) // delete all series
            {
                vizAnalytics1.Series.RemoveAt(0);
            }

            while (vizAnalytics1.Titles.Count > 0) // delete all titles
            {
                vizAnalytics1.Titles.RemoveAt(0);
            }

            String seriesName = dimensionCol;
            vizAnalytics1.Series.Add(seriesName);
            // vizAnalytics1.Series[seriesName].IsVisibleInLegend = false;
            vizAnalytics1.ChartAreas[0].AxisX.MajorGrid.LineWidth = 0;
            vizAnalytics1.ChartAreas[0].AxisY.MajorGrid.LineWidth = 0;

            for (int n = 0; n < analyticsDataArray.Length; n++)
            {
                vizAnalytics1.Series[seriesName].Points.AddXY(analyticsDataArray[n].category, analyticsDataArray[n].totalMeasure);


                if (chartType == "Column")
                {
                    vizAnalytics1.ChartAreas[0].Area3DStyle.Enable3D = false;
                    vizAnalytics1.ChartAreas[0].Area3DStyle.Inclination = 0; // By setting the inclination to 0, the chart essentially goes back to being a 2D chart
                    vizAnalytics1.Series[seriesName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                    vizAnalytics1.Legends[0].Enabled = false;
                }
                else
                {
                    vizAnalytics1.Legends[0].Enabled = true;
                    vizAnalytics1.Series[seriesName].Label = "#VALX";
                    vizAnalytics1.Series[seriesName].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
                    vizAnalytics1.Series[seriesName].LegendText = "#VALX" + " : " + "#VALY";
                    vizAnalytics1.Series[seriesName]["PieLabelStyle"] = "Outside";
                    vizAnalytics1.Series[seriesName].BorderDashStyle = ChartDashStyle.Solid;
                    vizAnalytics1.Series[seriesName].BorderColor = System.Drawing.Color.FromArgb(200, 26, 59, 105);
                    vizAnalytics1.ChartAreas[0].Area3DStyle.Enable3D = true; // Set Pie chart to 3D to tackle label collisions when it's too tight
                    vizAnalytics1.ChartAreas[0].Area3DStyle.Inclination = 0; // By setting the inclination to 0, the chart essentially goes back to being a 2D chart
                }

            }

            Title dimensionTitle = new Title();
            dimensionTitle.Text = dimensionCol + " over " + measureCol;
            dimensionTitle.Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold);
            vizAnalytics1.Titles.Add(dimensionTitle);

            // rescale chart after selections have been made
            vizAnalytics1.ChartAreas[0].RecalculateAxesScale();
        }

        bool pnlVizContainerExpanded = false;
        private void btnExpandVizPanel_Click(object sender, EventArgs e)
        {
            if (pnlVizContainerExpanded)
            {
                btnExpandVizPanel.Text = "<<<";
                pnlVizContainer.Location = new Point(1212, 24);
                pnlVizContainer.Size = new Size(57, 572);
                pnlVizContainerExpanded = false;
            }
            else
            {
                btnExpandVizPanel.Text = ">>>";
                pnlVizContainer.Location = new Point(336, 24);
                pnlVizContainer.Size = new Size(918, 572);
                pnlVizContainer.BringToFront();
                pnlVizContainerExpanded = true;
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (cmbFY_Expand.Text == null)
            {
                Console.WriteLine("null");
            }
            else if (cmbFY_Expand.Text == "")
            {
                Console.WriteLine("empty");
            }
            else
            {
                Console.WriteLine(cmbFY_Expand.Text);
            }

        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            string folderPath = folderDialogWindow();
            string asOfDate = DateTime.Today.ToString("d-M-yyyy");
            string periodCovered = cmbFY_Analytics.Text + "-" + cmbFQ_Analytics.Text;
            string reportName = cmbReportSelector.Text;
            //DataTable myTable = (DataTable)dgvAnalyticsReport.DataSource;
            DataTable myTable = ((DataView)dgvAnalyticsReport.DataSource).Table;
            string outputText = " for the period of " + periodCovered + " as at " + asOfDate;
            ExportToExcel(ref myTable, folderPath + "\\" + reportName + " " + outputText + ".xlsx", outputText);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string myOperator = @" " +  cmbMatchOperator.Text + @" ";
            string myOperator = cmbMatchOperator.Text;
            //string searchTerm = @"'%" + txtSearchCriteria.Text +@"%'";
            string searchTerm = txtSearchCriteria.Text;
            //string searchColumn = @" " + cmbUserSearchField.Text + @" ";
            string searchColumn = cmbUserSearchField.Text;

            DataTable myDtTbl = null;
            //myDtTbl = load_ORA_DataDynamic("Pr_get_result", "CLAIMS_DATA", "UNITS_TOTAL", "0");
            // myDtTbl = load_ORA_DataDynamic2("Produce_Custom_DataExtract", "CLAIMS_DATA", "REFERENCE_NUM", "=", "'%357%'");
            myDtTbl = load_ORA_DataDynamic2("Produce_Custom_DataExtract", "CLAIMS_DATA", searchColumn, myOperator, searchTerm);
            dgvAnalyticsReport.DataSource = myDtTbl.DefaultView;
            txtRecordsAnalysis.Text = checkDataTableRowCount(ref myDtTbl).ToString();

            populateDimensionMeasureDropDown();
        }

        // Load Raw Data from the CLAIMS_DATA table
        private DataTable load_ORA_DataDynamic2(string procName, string table_name, string field_name, string myOperator, string condition)
        {
            connectOracle();
            con.Open();

            DataTable myTbl = null;
            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = procName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_table_name", OracleDbType.Varchar2).Value = table_name;
            cmd.Parameters.Add("p_col_names", OracleDbType.Varchar2).Value = field_name;
            cmd.Parameters.Add("p_operator", OracleDbType.Varchar2).Value = myOperator;
            cmd.Parameters.Add("p_condition", OracleDbType.Varchar2).Value = condition;
            cmd.Parameters.Add("p_output", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda = new OracleDataAdapter(cmd);
            oda.Fill(ds);

            if (ds.Tables.Count > 0)
            {
                myTbl = ds.Tables[0];
            }
            con.Close();
            return myTbl;

        }


        // Load Raw Data from the CLAIMS_DATA table
        private DataTable load_ORA_DataDynamic(string procName, string table_name, string field_name, string condition)
        {
            connectOracle();
            con.Open();

            DataTable myTbl = null;
            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = procName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_table_name", OracleDbType.Varchar2).Value = table_name;
            cmd.Parameters.Add("p_col_names", OracleDbType.Varchar2).Value = field_name;
            //cmd.Parameters.Add("p_condition", OracleDbType.Varchar2).Value = condition;
            cmd.Parameters.Add("p_condition", OracleDbType.Varchar2).Value = condition;
            cmd.Parameters.Add("p_output", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda = new OracleDataAdapter(cmd);
            oda.Fill(ds);

            if (ds.Tables.Count > 0)
            {
                myTbl = ds.Tables[0];
            }
            con.Close();
            return myTbl;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            populateSearchTableColumns();
        }

        private void populateSearchTableColumns()
        {
            DataTable myDtTbl = null;
            string myTableName = "CLAIMS_DATA";         
            // string myTableName = cmbSourceTableName.Text;
            myDtTbl = getTableColumnNames("GetColumnNames", myTableName);
            //dgvAnalyticsReport.DataSource = myDtTbl.DefaultView;
            populateSearchFieldNames(ref myDtTbl);
        }

        private void populateSearchFieldNames(ref DataTable myDtTbl)
        {
            foreach(DataRow row in myDtTbl.Rows)
            {
                if (row["data_type"].Equals("VARCHAR2")){
                    cmbUserSearchField.Items.Add(row["column_name"].ToString());
                }
                
            }
        }

        private DataTable getTableColumnNames(string procName, string tableName)
        {
            connectOracle();
            con.Open();

            DataTable myTbl = null;
            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = procName;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_table_name", OracleDbType.Varchar2).Value = tableName;        
            cmd.Parameters.Add("p_output", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda = new OracleDataAdapter(cmd);
            oda.Fill(ds);

            if (ds.Tables.Count > 0)
            {
                myTbl = ds.Tables[0];
            }
            con.Close();
            return myTbl;
        }

        private void updateClaimFlag()
        {
            if (cmbFY_Expand.Text == "ALL")
            {
                MessageBox.Show("Please select an FY to set claims flag. ");

            }
            else if (cmbFY_Expand.Text == "" || cmbFQ_Expand.Text == "")
            {
                MessageBox.Show("Please select a valid FY & FQ to update claims flag. ");
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to flag records as claimed in the database?", "FLAG CLAIMED", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    flagClaimData("GetClaimsPckg2.MarkClaimsEntered", cmbFY_Expand.Text, cmbFQ_Expand.Text);
                    MessageBox.Show("Records for selected quarter have been flagged as claimed in the database.");
                }
                else if (dialogResult == DialogResult.No)
                {
                    //do nothing
                }
            }
        }

        private void btnExtractProgressRpt_Click(object sender, EventArgs e)
        {
            string currFY = "2020";
            string cat1 = "New Construction";
            string cat2 = "Repaired/Renewed";
            string cat3 = "Affordabiliy Assistance - Project Based Subsidy";
            string cat4 = "Affordability Assistance - assistance to household";

            string procName = "PROC_C3A";
                        
            Dictionary<string, string> procParamsDictionary = new Dictionary<string, string>();
            procParamsDictionary.Add("p_fy", currFY);
            procParamsDictionary.Add("p_Cat1", cat1);
            procParamsDictionary.Add("p_Cat2", cat2);
            procParamsDictionary.Add("p_Cat3", cat3);
            procParamsDictionary.Add("p_Cat4", cat4);

            dgvProgressRpt.DataSource = getDataFromOracleStoredProc(procName, procParamsDictionary);
        }

       

        private DataTable getDataFromOracleStoredProc(string procName, Dictionary<string, string> procParamsDictionary)
        {          

            connectOracle();
            con.Open();

            DataSet ds = new DataSet();
            OracleCommand cmd = con.CreateCommand();
            cmd.CommandText = procName;
            cmd.CommandType = CommandType.StoredProcedure;

            foreach (KeyValuePair<string, string> entry in procParamsDictionary)
            {
                cmd.Parameters.Add(entry.Key, OracleDbType.Varchar2).Value = entry.Value;
            }
            cmd.Parameters.Add("p_ref", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
            OracleDataAdapter oda = new OracleDataAdapter(cmd);
            oda.Fill(ds);
            //dgvProgressRpt.DataSource = ds.Tables[0];
            con.Close();
            return ds.Tables[0];
        }

        

        private void btnExtractDistinctColVals_Click(object sender, EventArgs e)
        {

            string tbl_name = "CLAIMS_DATA";
            string col_name = "HOUSING_TYPE";
            string col_order_by = "HOUSING_TYPE";
            string procName = "GetColumnDATA";

            Dictionary<string, string> procParamsDictionary = new Dictionary<string, string>();
            procParamsDictionary.Add("p_table_name", tbl_name);
            procParamsDictionary.Add("p_column_name", col_name);
            procParamsDictionary.Add("p_order_by", col_order_by);
          
            DataTable colTbl = getDataFromOracleStoredProc(procName, procParamsDictionary);

            foreach (DataRow row in colTbl.Rows)
            {
                if (String.IsNullOrEmpty(row[0].ToString()))
                {
                    Console.WriteLine("null");
                }
                else
                {
                    Console.WriteLine(row[0].ToString());
                }
                
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ExportViewToExcelExpand();
        }

        private void btnFlagClaimed_Click(object sender, EventArgs e)
        {
            updateClaimFlag();
        }
    }

        
    


}




   



