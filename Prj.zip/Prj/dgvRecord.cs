﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class dgvRecord
    {
        public int id { get; set; }
        public string dimension { get; set; }
        public decimal measure { get; set; }

        public dgvRecord(int id, string dimension, decimal measure)
        {
            this.id = id;
            this.dimension = dimension;
            this.measure = measure;
        }

        override
        public string ToString()
        {
            return id + " " + dimension + " " + measure;
        }

    }
}
