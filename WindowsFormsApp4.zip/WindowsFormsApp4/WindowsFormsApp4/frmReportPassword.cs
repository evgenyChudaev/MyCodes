﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class frmReportPassword : Form
    {
        public frmReportPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // string reportPassword = txtReportPassword.Text;
            Form1.reportPasswordStr = txtReportPassword.Text;
            this.Close();
        }
    }
}
