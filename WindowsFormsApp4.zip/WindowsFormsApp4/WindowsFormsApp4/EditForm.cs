﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class frmEdit : Form
    {
        int record_id;
        public static string webUrl;
        public static string userName;
        public static System.Security.SecureString password;
        string tactic;
        List<string[]> tactic_list;
        List<string> submitted_quarters;
        public frmEdit(string priority, string subgrouping, string tactic,  string status, string details, string outcomes, int rec_id, List<string[]> tactic_list, string start_dt, string exp_completion_dt, string actual_completion_dt)
        {
            InitializeComponent();        
            this.tactic = tactic;
            this.tactic_list = tactic_list;
            cmbTacticStatus.Text = status;

            dtStartDate.Value = DateTime.Parse(start_dt);
            dtExpectedCompletionDate.Value = DateTime.Parse(exp_completion_dt);
            dtActualCompletion.Value = DateTime.Parse(actual_completion_dt);

            /*  if (String.IsNullOrEmpty(actual_completion_dt))
              {                
                  dtActualCompletion.CustomFormat = " ";
                  dtActualCompletion.Format = DateTimePickerFormat.Custom;   

              }
              else
              {
                  dtActualCompletion.Value = DateTime.Parse(actual_completion_dt);
              }    */

            submitted_quarters = new List<string>();
            updateSubmittedQuarters();       

           
            record_id = rec_id;
        }


        private void updateSubmittedQuarters()
        {
         
            submitted_quarters.Clear();

            foreach (var item in tactic_list)
            {              
                submitted_quarters.Add(item[2]);
            }
        }
      
       

        private void btnSave_Click(object sender, EventArgs e)
        {
         
            Form1.updated = true;
            Form1.record_id = this.record_id;

            DialogResult updateDialog = MessageBox.Show("Are you sure you want to update this record?", "Update record", MessageBoxButtons.YesNo);          
            if (updateDialog == DialogResult.Yes)
            {
               
                update_master_item(dtStartDate.Value, dtExpectedCompletionDate.Value, dtActualCompletion.Value, cmbTacticStatus.Text ,this.record_id);
                Form1.data_update = true;
                MessageBox.Show("Record has been updated");
                this.Close();
            }
            else
            {
                MessageBox.Show("Record has NOT been updated");
                Form1.data_update = false;
            }                

          
        }


        private void btnSaveNewQuarterly_Click(object sender, EventArgs e)
        {

            DialogResult updateDialog = MessageBox.Show("Are you sure you want to update this record?", "Update record", MessageBoxButtons.YesNo);

            if (updateDialog == DialogResult.Yes)
            {             

                updateSubmittedQuarters();
                MessageBox.Show("Report has been submitted");
               
            }
            else
            {
                MessageBox.Show("Report has NOT been submitted");
                // Form1.data_update = false;
            }


            

        }

        private void create_item(string period, string memo)
        {
            using (var context = new Microsoft.SharePoint.Client.ClientContext(webUrl))
            {
                context.Credentials = new Microsoft.SharePoint.Client.SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Add new item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Details");
                Microsoft.SharePoint.Client.ListItemCreationInformation itemCreateInfo = new Microsoft.SharePoint.Client.ListItemCreationInformation();
                Microsoft.SharePoint.Client.ListItem oListItem = oList.AddItem(itemCreateInfo);
                oListItem["Title"] = tactic;
                oListItem["Period"] = period;
                oListItem["Memo"] = memo; 
                oListItem.Update();
                context.ExecuteQuery();
                context.Load(oListItem);              
                tactic_list.Add(new string[] { tactic, memo, period, oListItem.Id.ToString() });
            }
        }


        // Update master list details - start & end dates
        private void update_master_item(DateTime start_date, DateTime expected_completion_date, DateTime actual_completion_date, string status, int id)
        {           
            using (var context = new Microsoft.SharePoint.Client.ClientContext(webUrl))
            {
                context.Credentials = new Microsoft.SharePoint.Client.SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Add new item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Master");
                Microsoft.SharePoint.Client.ListItemCreationInformation itemCreateInfo = new Microsoft.SharePoint.Client.ListItemCreationInformation();
                Microsoft.SharePoint.Client.ListItem oListItem = oList.GetItemById(record_id);
                if (start_date.Year.ToString() != "1900")
                {
                    oListItem["StartDate"] = start_date;
                }
                if (actual_completion_date.Year.ToString() != "1900") // make sure actual completion date is saved only when real date is entered
                {
                    oListItem["ActualCompletion"] = actual_completion_date;
                }

                oListItem["ExpectedCompletion"] = expected_completion_date;
                oListItem["Tactic_x0020_Status"] = status;

                oListItem.Update();
                context.ExecuteQuery();
            }
        }


        private void update_item(string memo, int id)
        {
            using (var context = new Microsoft.SharePoint.Client.ClientContext(webUrl))
            {
                context.Credentials = new Microsoft.SharePoint.Client.SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Add new item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Details");
                Microsoft.SharePoint.Client.ListItemCreationInformation itemCreateInfo = new Microsoft.SharePoint.Client.ListItemCreationInformation();
                Microsoft.SharePoint.Client.ListItem oListItem = oList.GetItemById(id);
                oListItem["Memo"] = memo;
                oListItem.Update();
                context.ExecuteQuery();             
            }
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }       
       

        private void btnUpdateQuarterlyRpt_Click(object sender, EventArgs e)
        {
       
            DialogResult updateDialog = MessageBox.Show("Are you sure you want to update this record?", "Update record", MessageBoxButtons.YesNo);

            if (updateDialog == DialogResult.Yes)
            {           
           
                updateSubmittedQuarters();
                MessageBox.Show("Record has been updated");
            }
            else
            {
                MessageBox.Show("Record has NOT been updated");
              
            }

        }

        private void delete_item(int id)
        {
            using (var context = new Microsoft.SharePoint.Client.ClientContext(webUrl))
            {
                context.Credentials = new Microsoft.SharePoint.Client.SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Add new item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Details");
                Microsoft.SharePoint.Client.ListItemCreationInformation itemCreateInfo = new Microsoft.SharePoint.Client.ListItemCreationInformation();
                Microsoft.SharePoint.Client.ListItem oListItem = oList.GetItemById(id);  
                               
                oListItem.DeleteObject();
                context.ExecuteQuery();

            }
        }

        private void btnDeleteExistingPeriod_Click(object sender, EventArgs e)
        {
            DialogResult updateDialog = MessageBox.Show("Are you sure you want to DELETE this record?", "Delete record", MessageBoxButtons.YesNo);

            if (updateDialog == DialogResult.Yes)
            {          

                updateSubmittedQuarters();
                MessageBox.Show("Record has been deleted");
            }
            else
            {
                MessageBox.Show("Record has NOT been deleted");              
            }
        }

       

        private void dtActualCompletion_ValueChanged(object sender, EventArgs e)
        {           
           
            dtActualCompletion.CustomFormat = "MMMM dd, yyyy";
            
        }       

       
    }
}
