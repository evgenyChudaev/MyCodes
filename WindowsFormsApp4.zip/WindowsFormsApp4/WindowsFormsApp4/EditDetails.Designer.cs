﻿namespace WindowsFormsApp4
{
    partial class EditDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMemo = new System.Windows.Forms.TextBox();
            this.btnSaveDetails = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProjectRiskMemo = new System.Windows.Forms.TextBox();
            this.txtProjectMitigationMemo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCloseDeitDetails = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMemo
            // 
            this.txtMemo.Location = new System.Drawing.Point(7, 57);
            this.txtMemo.Multiline = true;
            this.txtMemo.Name = "txtMemo";
            this.txtMemo.Size = new System.Drawing.Size(377, 438);
            this.txtMemo.TabIndex = 0;
            // 
            // btnSaveDetails
            // 
            this.btnSaveDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnSaveDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveDetails.Location = new System.Drawing.Point(7, 501);
            this.btnSaveDetails.Name = "btnSaveDetails";
            this.btnSaveDetails.Size = new System.Drawing.Size(377, 59);
            this.btnSaveDetails.TabIndex = 3;
            this.btnSaveDetails.Text = "SAVE";
            this.btnSaveDetails.UseVisualStyleBackColor = false;
            this.btnSaveDetails.Click += new System.EventHandler(this.btnSaveDetails_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(4, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(310, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Please enter your comments in below text boxes";
            // 
            // txtProjectRiskMemo
            // 
            this.txtProjectRiskMemo.Location = new System.Drawing.Point(390, 57);
            this.txtProjectRiskMemo.Multiline = true;
            this.txtProjectRiskMemo.Name = "txtProjectRiskMemo";
            this.txtProjectRiskMemo.Size = new System.Drawing.Size(361, 438);
            this.txtProjectRiskMemo.TabIndex = 1;
            // 
            // txtProjectMitigationMemo
            // 
            this.txtProjectMitigationMemo.Location = new System.Drawing.Point(757, 57);
            this.txtProjectMitigationMemo.Multiline = true;
            this.txtProjectMitigationMemo.Name = "txtProjectMitigationMemo";
            this.txtProjectMitigationMemo.Size = new System.Drawing.Size(393, 438);
            this.txtProjectMitigationMemo.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(7, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Project Status ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(387, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Project Risk";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(770, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "Project Mitigation";
            // 
            // btnCloseDeitDetails
            // 
            this.btnCloseDeitDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnCloseDeitDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseDeitDetails.Location = new System.Drawing.Point(757, 501);
            this.btnCloseDeitDetails.Name = "btnCloseDeitDetails";
            this.btnCloseDeitDetails.Size = new System.Drawing.Size(393, 59);
            this.btnCloseDeitDetails.TabIndex = 4;
            this.btnCloseDeitDetails.Text = "CANCEL";
            this.btnCloseDeitDetails.UseVisualStyleBackColor = false;
            this.btnCloseDeitDetails.Click += new System.EventHandler(this.btnCloseDeitDetails_Click);
            // 
            // EditDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1158, 572);
            this.Controls.Add(this.btnCloseDeitDetails);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtProjectMitigationMemo);
            this.Controls.Add(this.txtProjectRiskMemo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSaveDetails);
            this.Controls.Add(this.txtMemo);
            this.Name = "EditDetails";
            this.Text = "Your comment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMemo;
        private System.Windows.Forms.Button btnSaveDetails;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtProjectRiskMemo;
        private System.Windows.Forms.TextBox txtProjectMitigationMemo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCloseDeitDetails;
    }
}