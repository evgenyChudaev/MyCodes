﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    class ReportGenerator
    {

        public static void WriteToExcelFile(DataTable dataTablePrimary, DataTable dataTableSecondary, string ExcelFilePath, string reportPeriodFrom, string reportPeriodTo)
        {

            var resultsTemp = from table1 in dataTablePrimary.AsEnumerable()
                              join table2 in dataTableSecondary.AsEnumerable()
                              on (string)table1["Tactic"] equals (string)table2["Tactic"]
                              select new
                              {
                                  Priority = (string)table1["Priority Area"],
                                  Subgroup = (string)table1["Subgrouping"],
                                  Tactic = (string)table1["Tactic"],
                                  Outcomes = (string)table1["Outcomes"],
                                  Assignee = (string)table1["Assignee"],
                                  tacticStatus = (string)table1["Tactic Status"],
                                  StartDate = table1["Start Date"],
                                  ExpectedCompletion = table1["Expected Completion"],
                                  ActualCompletion = table1["Actual Completion"],
                                  ReportPeriod = (string)table2["Period"],
                                  StatusComment = (string)table2["Memo"],
                                  ProjectRisk = (string)table2["Project Risk"],
                                  RiskMitigation = (string)table2["Risk Mitigation"],
                                  recordId = (string)table2["Record id"]
                              };

            var results = resultsTemp.Where(x => x.ReportPeriod.CompareTo(reportPeriodFrom) >= 0 && x.ReportPeriod.CompareTo(reportPeriodTo) <= 0); // limit output to results for selected periods
            // sort results by Option, then subgroup then tactic in ascending order

            // load excel, and create a new workbook
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();
            Excel.Workbooks.Add();

            // single worksheet
            Microsoft.Office.Interop.Excel._Worksheet Worksheet = Excel.ActiveSheet;

            string[] actualHeader = new string[] { "", "", "", "Assignee", "Tactic Status", "Start Date", "Expected Completion", "Actual Completion",
                                             "Reduce PH Waitlist", "Safe, Connected Communities",
                                            "Ensure Long-Term Sustainability", "Serve Most Vulnerable", "Increase Affordable Supply", "Leverage Federal Funding",
                                            "Effective/Efficient Ops" }; // this is actual header for the report (does not include report specifric fields)

            string[] outcomes = {"Reduce PH Waitlist", "Safe, Connected Communities", "Ensure Long-Term Sustainability",
                                          "Serve Most Vulnerable", "Increase Affordable Supply", "Leverage Federal Funding", "Effective/Efficient Ops" };

            int colCount = actualHeader.Length;
            int rowCount = results.Count();

            Microsoft.Office.Interop.Excel.Range HeaderRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, colCount]));
            HeaderRange.Value = actualHeader;
            HeaderRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
            HeaderRange.Font.Bold = true;

            Microsoft.Office.Interop.Excel.Range subheaderRange = null;
            Microsoft.Office.Interop.Excel.Range tacticRange = null;
            Microsoft.Office.Interop.Excel.Range tacticStatusRange = null;

            object[,] Cells = new object[rowCount, colCount + 4]; // inflate array size just in case since we skip a lot of lines for different headers. Thus, array size = record count may be too small 

            int i = 0;

            string tactic_current = null, tactic_previous = null, tactic_status = null;
            string subgroup_current = null, subgroup_previous = null;
            string priority_current = null, priority_previous = null;

            Microsoft.Office.Interop.Excel.Range priorityRange = null;
            Microsoft.Office.Interop.Excel.Range subgroupRange = null;


            foreach (var item in results)
            {
                subgroup_current = item.Subgroup;
                tactic_current = item.Tactic;
                priority_current = item.Priority;

               // Console.WriteLine("ARRAY SIZE: " + Cells.GetLength(0));
                if (i >= Cells.GetLength(0) - 10) // resize array of cells as needed. Array of cells can be smaller than number of actual cells populated as we create subheaders that take additional rows
                {
                   // MessageBox.Show("EXCEEDED");
                    HelperClass.ResizeArray(ref Cells, Cells.GetLength(0)+200, Cells.GetLength(1));
                } 

                if (priority_current != priority_previous)
                {   
                  
                      

                    i++;
                    Cells[i, 0] = item.Priority;
                    priorityRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 4, 15]));
                    priorityRange.Font.Size = 20;
                    priorityRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                    priorityRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DarkBlue);
                    i++;
                }

                if (subgroup_current != subgroup_previous)
                {
                    i++;
                    Cells[i, 0] = item.Subgroup;
                    subgroupRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 4, 15]));
                    subgroupRange.Font.Size = 14;
                    subgroupRange.Font.Bold = true;
                    subgroupRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Beige);
                    i++;

                }

                if (tactic_current != tactic_previous)
                {
                    i += 2; // skip a line before new tactic row                     
                    Cells[i, 0] = tactic_current;
                    Cells[i, 3] = item.Assignee;
                    // special symbols for tactic
                    
                    Cells[i, 5] = item.StartDate;
                    Cells[i, 6] = item.ExpectedCompletion;
                    Cells[i, 7] = item.ActualCompletion;
                    tacticRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 4, 15]));
                    // tacticRange.Font.Italic = true;
                    tacticRange.Font.Bold = true;
                    tacticRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);

                    string tacticStatus = item.tacticStatus;
                    tacticStatusRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 3, 5]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 3, 5]));
                    switch (tacticStatus)
                    {
                        case "Completed":
                            tacticStatus += "  ☑";
                            tacticStatusRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                            break;
                        case "On track":
                            tacticStatus += "  ☆";
                            tacticStatusRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                            break;
                        case "Delayed":
                            tacticStatus += "  ⚠";
                            tacticStatusRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                            break;
                        default:
                            tacticStatus += " \uFFFD";
                            tacticStatusRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black);
                            break;
                    }

                    Cells[i, 4] = tacticStatus;                           
                    tacticStatusRange.Font.Bold = true;
                    tacticStatusRange.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                    tacticStatusRange.Font.Name = "Arial"; 
                    //tacticRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                    //Cells[i, 4] = tacticStatus;

                    // special formatting and color coding for tactic
                    string[] outcomes_details = item.Outcomes.ToString().Split(';');  // split out the Outcomes Column 
                    int j = 1;
                    foreach (string outcome in outcomes)
                    {

                        if (Array.IndexOf(outcomes_details, outcome) >= 0)
                        {
                            Cells[i, 7 + j] = "\u2714";
                        }
                        j++;
                    }

                    i += 2; // skip to the next line after new tactic starts

                    Cells[i, 0] = "Period";
                    Cells[i, 1] = "Comment";
                    Cells[i, 2] = "Project Risks";
                    Cells[i, 3] = "Risk Mitigation";
                    // Cells[i, 4] = "Status";
                    subheaderRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[i + 3, 4]));
                    subheaderRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
                    subheaderRange.Font.Italic = true;
                    subheaderRange.Font.Bold = true;
                    i++;

                    Cells[i, 0] = item.ReportPeriod;
                    Cells[i, 1] = item.StatusComment;
                    Cells[i, 2] = item.ProjectRisk;
                    Cells[i, 3] = item.RiskMitigation;

                    // Disable report status indicator as per request from Karen for now. 
                    // May be required in the future
                    /*  switch (item.recordId)
                    {
                        case "-1":
                            tactic_status = "Due Later"; // report due after this fq                            
                            break;
                        case "-2":
                            tactic_status = "Due This Month"; // report due in this fq                       
                            break;
                        case "-3":
                            tactic_status = "Overdue"; // report overdue                           
                            break;
                        default:
                            tactic_status = "Submitted"; // report overdue                           
                            break;

                    }
                    Cells[i, 4] = tactic_status; */
                    i++;

                }
                else
                {

                    Cells[i, 0] = item.ReportPeriod;
                    Cells[i, 1] = item.StatusComment;
                    Cells[i, 2] = item.ProjectRisk;
                    Cells[i, 3] = item.RiskMitigation;

                    // Disable report status indicator as per request from Karen for now. 
                    // May be required in the future
                    /*
                    switch (item.recordId)
                    {
                        case "-1":
                            tactic_status = "Due Later"; // report due after this fq                            
                            break;
                        case "-2":
                            tactic_status = "Due This Month"; // report due in this fq                       
                            break;
                        case "-3":
                            tactic_status = "Overdue"; // report overdue                           
                            break;
                        default:
                            tactic_status = "Submitted"; // report overdue                           
                            break;
                    }
                    Cells[i, 4] = tactic_status; */
                    i++;
                }

                tactic_previous = tactic_current;
                subgroup_previous = subgroup_current;
                priority_previous = priority_current;
            }

            Worksheet.Cells[1, 1].Value = "Report generated " + DateTime.Today.ToString("yyyy-MM-dd"); ;
            Worksheet.Cells[1, 1].Font.Italic = true;

            if (rowCount == 0)
            {
                Worksheet.Cells[3, 1].Value = "No results";
            }
            else
            {
                Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[Cells.GetLength(0)+200, colCount])).Value = Cells;
            }

            for (int m = 1; m <= 15; m++) // set width of columns 
            {
                if (m == 1)
                {
                    Worksheet.Columns[m].ColumnWidth = 16;
                }
                else if (m > 1 && m <= 4)
                {
                    Worksheet.Columns[m].ColumnWidth = 50;
                }
                else if (m == 5)
                {
                    Worksheet.Columns[m].ColumnWidth = 16;
                }
                else
                {
                    Worksheet.Columns[m].ColumnWidth = 12.5;
                }

                if (m >= 6)
                {
                    // Worksheet.Columns[m].ColumnWidth = 28;
                    Worksheet.Columns[m].WrapText = true;
                }



            }

            // check fielpath
            if (ExcelFilePath != null && ExcelFilePath != "")
            {
                try
                {
                    Worksheet.SaveAs(ExcelFilePath);
                    Excel.Quit();
                    MessageBox.Show("Report saved!");
                }
                catch (Exception ex)
                {
                    throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                        + ex.Message);
                }
            }
            else    // no filepath is given
            {
                Excel.Visible = true;
            }

            Marshal.FinalReleaseComObject(Worksheet);
            Marshal.FinalReleaseComObject(HeaderRange);
            Marshal.FinalReleaseComObject(Excel);
        }


        public static void WriteToExcelFileRawData(DataTable dataTablePrimary, DataTable dataTableSecondary, string ExcelFilePath)
        {
            var results = from table1 in dataTablePrimary.AsEnumerable()
                          join table2 in dataTableSecondary.AsEnumerable()
                          on (string)table1["Tactic"] equals (string)table2["Tactic"]
                          select new
                          {
                              Priority = (string)table1["Priority Area"],
                              Subgroup = (string)table1["Subgrouping"],
                              Tactic = (string)table1["Tactic"],
                              Outcomes = (string)table1["Outcomes"],
                              Assignee = (string)table1["Assignee"],
                              tacticStatus = (string)table1["Tactic Status"],
                              StartDate = table1["Start Date"],
                              ExpectedCompletion = table1["Expected Completion"],
                              ActualCompletion = table1["Actual Completion"],
                              ReportPeriod = (string)table2["Period"],
                              StatusComment = (string)table2["Memo"],
                              ProjectRisk = (string)table2["Project Risk"],
                              RiskMitigation = (string)table2["Risk Mitigation"],
                              recordId = (string)table2["Record id"]
                          };

            // sort results by Option, then subgroup then tactic in ascending order

            // load excel, and create a new workbook
            Microsoft.Office.Interop.Excel.Application Excel = new Microsoft.Office.Interop.Excel.Application();
            Excel.Workbooks.Add();

            // single worksheet
            Microsoft.Office.Interop.Excel._Worksheet Worksheet = Excel.ActiveSheet;


            string[] Header = new string[] { "Priority Area", "Subgrouping", "Tactic", "Assignee", "Start Date", "Expected Completion", "Actual Completion",
                                            "Report Status", "Period", "Memo", "Project Risk", "Risk Mitigation", "Tactic Status", "Reduce PH Waitlist", "Safe, Connected Communities",
                                            "Ensure Long-Term Sustainability", "Serve Most Vulnerable", "Increase Affordable Supply", "Leverage Federal Funding",
                                            "Effective/Efficient Ops" }; // use this header for the array dimension */



            string[] outcomes = {"Reduce PH Waitlist", "Safe, Connected Communities", "Ensure Long-Term Sustainability",
                                          "Serve Most Vulnerable", "Increase Affordable Supply", "Leverage Federal Funding", "Effective/Efficient Ops" };

            int colCount = Header.Length;
            int rowCount = results.Count();

            Microsoft.Office.Interop.Excel.Range HeaderRange = Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[2, colCount]));
            HeaderRange.Value = Header;
            HeaderRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
            HeaderRange.Font.Bold = true;


            int extractRows = 5;
            object[,] Cells = new object[rowCount+ extractRows, colCount];

            int i = 0;
            // string tactic_status = null;

            foreach (var item in results)
            {


                Cells[i, 0] = item.Priority;
                Cells[i, 1] = item.Subgroup;
                Cells[i, 2] = item.Tactic;
                Cells[i, 3] = item.Assignee;
                Cells[i, 4] = item.StartDate;
                Cells[i, 5] = item.ExpectedCompletion;
                Cells[i, 6] = item.ActualCompletion;

                Cells[i, 8] = item.ReportPeriod;
                Cells[i, 9] = item.StatusComment;
                Cells[i, 10] = item.ProjectRisk;
                Cells[i, 11] = item.RiskMitigation;
                Cells[i, 12] = item.tacticStatus;

                switch (item.recordId)
                {
                    case "-1":
                        Cells[i, 7] = "Due Later"; // report due after this fq                            
                        break;
                    case "-2":
                        Cells[i, 7] = "Due This Month"; // report due in this fq                       
                        break;
                    case "-3":
                        Cells[i, 7] = "Overdue"; // report overdue                           
                        break;
                    default:
                        Cells[i, 7] = "Submitted"; // report was submitted                          
                        break;
                }

                string[] outcomes_details = item.Outcomes.ToString().Split(';');  // split out the Outcomes Column 
                int j = 1;
                foreach (string outcome in outcomes)
                {

                    if (Array.IndexOf(outcomes_details, outcome) >= 0)
                    {
                        Cells[i, 12 + j] = "X";
                    }
                    j++;
                }
                i++;
            }

            Worksheet.Cells[1, 1].Value = "Report generated " + DateTime.Today.ToString("yyyy-MM-dd");
            Worksheet.Cells[1, 1].Font.Italic = true;

            if (rowCount == 0)
            {
                Worksheet.Cells[3, 1].Value = "No results";
            }
            else
            {
                Worksheet.get_Range((Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[3, 1]), (Microsoft.Office.Interop.Excel.Range)(Worksheet.Cells[rowCount+extractRows, colCount])).Value = Cells;
            }

            // check fielpath
            if (ExcelFilePath != null && ExcelFilePath != "")
            {
                try
                {
                    Worksheet.SaveAs(ExcelFilePath);
                    Excel.Quit();
                    MessageBox.Show("Report saved!");
                }
                catch (Exception ex)
                {
                    throw new Exception("ExportToExcel: Excel file could not be saved! Check filepath.\n"
                        + ex.Message);
                }
            }
            else    // no filepath is given
            {
                Excel.Visible = true;
            }

            Marshal.FinalReleaseComObject(Worksheet);
            Marshal.FinalReleaseComObject(HeaderRange);
            Marshal.FinalReleaseComObject(Excel);

        }


        public static void WriteToCsvFile(DataTable dataTable, string path)
        {
            StringBuilder fileContent = new StringBuilder();
            string[] outcomes = {"Reduce PH Waitlist", "Safe, Connected Communities", "Ensure Long-Term Sustainability",
                                         "Serve Most Vulnerable", "Increase Affordable Supply", "Leverage Federal Funding", "Effective/Efficient Ops" };

            foreach (var col in dataTable.Columns)
            {
                if (col.ToString() == "Outcomes")
                {

                    foreach (string outcome in outcomes)  // split out the Outcomes Column 
                    {
                        fileContent.Append("\"" + outcome + "\",");
                    }
                }
                else
                {
                    fileContent.Append(col.ToString() + ",");
                }

            }

            fileContent.Replace(",", System.Environment.NewLine, fileContent.Length - 1, 1);

            foreach (DataRow dr in dataTable.Rows)
            {
                int i = 0;
                foreach (var column in dr.ItemArray)
                {
                    if (i == 4) // Outcomes column (column # 5) has to be split into multiple columns
                    {
                        string[] outcomes_details = column.ToString().Split(';');  // split out the Outcomes Column 
                        foreach (string item in outcomes)
                        {

                            if (Array.IndexOf(outcomes_details, item) >= 0)
                            {
                                fileContent.Append("1,");
                            }
                            else
                            {
                                fileContent.Append("0,");
                            }


                        }
                    }
                    else
                    {
                        fileContent.Append("\"" + column.ToString() + "\",");
                    }
                    i++;
                }
                fileContent.Replace(",", System.Environment.NewLine, fileContent.Length - 1, 1);
            }

            System.IO.File.WriteAllText(path, fileContent.ToString());
        }
    }
}
