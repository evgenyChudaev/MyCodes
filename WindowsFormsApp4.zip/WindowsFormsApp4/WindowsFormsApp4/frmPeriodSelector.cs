﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class frmPeriodSelector : Form
    {
        public frmPeriodSelector()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
                

        private void btnSaveReportPeriod_Click(object sender, EventArgs e)
        {
            string[] reportPeriods = UpdateReportPeriods();
            Form1.reportFrom = reportPeriods[0];
            Form1.reportTo = reportPeriods[1];
            Form1.extractReportFlag = true;
            this.Close();
        }

        private string[] UpdateReportPeriods()
        {
            DateTime dtFrom = dtReportFrom.Value;
            DateTime dtTo = dtReportTo.Value;
            int[] adj_start_period = HelperClass.adjustForFiscalPeriod(dtFrom, 9);
            int[] adj_end_period = HelperClass.adjustForFiscalPeriod(dtTo, 9);

            string periodFrom = HelperClass.formPeriodNameMonth(adj_start_period);
            string periodTo = HelperClass.formPeriodNameMonth(adj_end_period);

            return new string[] {periodFrom, periodTo };

        }

        private void btnCloseReportPeriod_Click(object sender, EventArgs e)
        {
            Form1.extractReportFlag = false;
            this.Close();
        }
    }
}
