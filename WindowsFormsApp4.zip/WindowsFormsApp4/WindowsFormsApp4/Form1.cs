﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft.WindowsAPICodePack;
using Microsoft.WindowsAPICodePack.Dialogs;
using System.Runtime.InteropServices;
using System.Collections;

namespace WindowsFormsApp4
{
    
    public partial class Form1 : System.Windows.Forms.Form
    {
        public static string str_priority, str_subgroup, str_tactic, str_fy, str_details = null;
        public static int record_id;
        public static bool updated = false;
        string webUrl = "https://novascotia.sharepoint.com/sites/HNSProjects";
        public static string userName;
        public static string pw;
        public static string reportFrom;
        public static string reportTo;
        SecureString password;
        // Microsoft.SharePoint.Client.List oList;
        bool data_loaded = false;
        int selected_row_id = 1;
        int totalSubmitted, totalOutstanding, totalOutstandingThisPeriod, totalOverdueReports, totalTacticsAssigned;
        public static bool extractReportFlag;
        public static bool reportPasswordCorrect;
        public static string reportPasswordStr;
        List<string[]> tactic_details_list;
        List<string[]> expected_tactic_details_list;

        public static bool data_update = false;

        public Form1()
        {
            InitializeComponent();
            // get credentials from the user
            LoginForm myLoginFrm = new LoginForm();
            myLoginFrm.ShowDialog();

            load_data();
            data_loaded = true;
            reportPasswordCorrect = false;
            reportPasswordStr = null;

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            create_item();
        }

        
        private DataTable[] createTables(ListItemCollection listItemsMaster, ListItemCollection listItemsDetails,  SPContext context, bool extractAll= false)
        {
            
            DataTable dt = new DataTable();
            dt.Columns.Add("Record id", typeof(string));
            dt.Columns.Add("Priority Area", typeof(string));
            dt.Columns.Add("Subgrouping", typeof(string));
            dt.Columns.Add("Tactic", typeof(string));
            dt.Columns.Add("Outcomes", typeof(string));
            dt.Columns.Add("Assignee", typeof(string));
            dt.Columns.Add("Tactic Status", typeof(string));

            dt.Columns.Add("Start Date", typeof(DateTime));
            dt.Columns.Add("Expected Completion", typeof(DateTime));
            dt.Columns.Add("Actual Completion", typeof(DateTime));

            // Data table for Tactic Details
            DataTable dt_details = new DataTable();
            dt_details.Columns.Add("Tactic", typeof(string));
            dt_details.Columns.Add("Period", typeof(string));
            dt_details.Columns.Add("Memo", typeof(string));
            dt_details.Columns.Add("Project Risk", typeof(string));
            dt_details.Columns.Add("Risk Mitigation", typeof(string));

            dt_details.Columns.Add("Record id", typeof(string));

            DataTable[] myTables = populateDataTables(ref dt, ref dt_details, ref listItemsMaster, ref listItemsDetails, ref context, extractAll);
            //DataTable[] myTables = { dt };
            return myTables;
        }

        private DataTable[] populateDataTables(ref DataTable dt, ref DataTable dt_details, ref ListItemCollection listItemsMaster,  ref ListItemCollection listItemsDetails, ref SPContext context, bool extractAllItems = false)
        {

            string current_user = System.DirectoryServices.AccountManagement.UserPrincipal.Current.DisplayName;
            int i = 0;

            // load expected reporting periods to the list
            expected_tactic_details_list = new List<string[]>();
            foreach (var spItem in listItemsMaster)
            {

                int record_id = (int)spItem.Id;
                string tactic = (string)spItem["Title"];
                string priority = (string)spItem["Priority"];
                string subgroup = (string)spItem["marz"];
                string tacticStatus = (string)spItem["Tactic_x0020_Status"];
                // string start_date = spItem["StartDate"] == null? null : ((DateTime)spItem["StartDate"]).ToString("yyyy-MM-dd");
                // DateTime start_date = ((DateTime)spItem["StartDate"]).Date;
                DateTime start_date = ((DateTime)spItem["StartDate"]).Date;
                DateTime exp_completion_date = ((DateTime)spItem["ExpectedCompletion"]).Date;
                //Nullable<DateTime> exp_completion_date = (Nullable<DateTime>)spItem["ExpectedCompletion"];

                //  Nullable<DateTime> actual_completion_date = (Nullable<DateTime>)spItem["ActualCompletion"];
                DateTime actual_completion_date = ((DateTime)spItem["ActualCompletion"]).Date;

                DateTime end_date = actual_completion_date; //actual_completion_date.HasValue ? (DateTime)actual_completion_date : exp_completion_date;

                string outcomes_concat = null;
                foreach (string outcome in (string[])spItem["Outcomes"])
                {
                    outcomes_concat += ";" + outcome;
                }
                outcomes_concat = outcomes_concat.Substring(1, outcomes_concat.Length - 1);
                FieldUserValue assignee = (FieldUserValue)spItem["Assignee"];
                string assignee_str = assignee.LookupValue;


               
                i++;
               
                if (extractAllItems || current_user == assignee_str) // if we are extracting report, then we extract all tactics, otherwise we only extract items where user = creator for the data grid view
                {
                    
                    dt.Rows.Add(record_id, priority, subgroup, tactic, outcomes_concat, assignee_str, tacticStatus, start_date, exp_completion_date, actual_completion_date);
                    // Determine for which FYs/Quarters reports are due based on the start date and expected end date
                    // Later add a check if start and end dates are null,let user know and continue the loop for other tactics
                    /*  DateTime adjStartDate = start_date.AddMonths(9), adjExpEndDate = exp_completion_date.AddMonths(9);
                      int adj_start_fy = adjStartDate.Year, adj_exp_end_fy = adjExpEndDate.Year;
                      int adj_start_fq = (int) Math.Ceiling((double) adjStartDate.Month / 3);
                      int adj_exp_end_fq = (int)Math.Ceiling((double)adjExpEndDate.Month / 3); */

                    

                    int[] adj_start_period = HelperClass.adjustForFiscalPeriod(start_date, 9);
                    int adj_start_fy = adj_start_period[0];
                    int adj_start_fq = adj_start_period[1];

                    int[] adj_end_period = HelperClass.adjustForFiscalPeriod(end_date, 9);
                    int adj_exp_end_fy = adj_end_period[0];
                    int adj_exp_end_fq = adj_end_period[1];



                    int fq_current = adj_start_fq;
                    int fy_current = adj_start_fy;


                    while (fy_current <= adj_exp_end_fy)
                    {
                        //  string adj_month;
                        if (fy_current < adj_exp_end_fy)
                        {
                            while (fq_current <= 12)
                            {
                                expected_tactic_details_list.Add(new string[] { tactic, HelperClass.formPeriodNameMonth(new int[] { fy_current, fq_current }), " ", "-1" });
                                fq_current++;
                            }
                        }
                        else
                        {
                            while (fq_current <= adj_exp_end_fq)
                            {
                                expected_tactic_details_list.Add(new string[] { tactic, HelperClass.formPeriodNameMonth(new int[] { fy_current, fq_current }) });
                                fq_current++;
                            }
                        }

                        // Add outstanding reports to datagridView so that user can see what other reports are outstanding                             
                        // reset fq to 1 for the next FY
                        fq_current = 1;
                        fy_current++;
                    }
                }      

            }

            // load data into array of objects from the tactics details list

            tactic_details_list = new List<string[]>();



           // listItems = context.getList("Tactics Details");
            string creator_str = null;
            foreach (var spItem in listItemsDetails)
            {
                FieldUserValue creator = (FieldUserValue)spItem["Author"];
                creator_str = creator.LookupValue;
                if (current_user != creator_str) // remove this to get the entire list of details (reports) or substitute with 1 != 1
                {
                    continue;
                }

                // ** Hack to prevent user totals from being updated when report is extracted. Update to something more robust later.
                if(!extractAllItems)
                    totalSubmitted++; // increment total submitted report counter
                string title, memo, period, projRisk, projMitigation;
                title = (string)spItem["Title"];
                memo = (string)spItem["Memo"];
                period = (string)spItem["Period"];
                projRisk = (string)spItem["ProjectRisk"];
                projMitigation = (string)spItem["ProjectMitigation"];
                string record_id = spItem.Id.ToString();

                tactic_details_list.Add(new string[] { title, memo, period, record_id, projRisk, projMitigation });



                var itemToRemove = expected_tactic_details_list.Find(x => x[0].ToString() == title && x[1].ToString() == period);
                if (itemToRemove != null)
                {
                    expected_tactic_details_list.Remove(itemToRemove);
                }

            }

            // check total number of outstanding reports***
            // ***
            if (!extractAllItems)
                totalOutstanding = expected_tactic_details_list.Count;

            // Check how many reports are outstanding for current FQ
            int[] adj_period_now = HelperClass.adjustForFiscalPeriod(DateTime.Today, 9);
            int adj_now_fy = adj_period_now[0];
            int adj_now_fq = adj_period_now[1];
            // string adj_now_month = adj_now_fq < 10 ? String.Format("0{0}", adj_now_fq) : Convert.ToString(adj_now_fq);
            string now_period = HelperClass.formPeriodNameMonth(new int[] { adj_now_fy, adj_now_fq });//String.Format("FY{0}-{1}", adj_now_fy, adj_now_month);
            string report_type_code; // report type will differentiate overdue and outstanding items
                                     // add outstanding tactic reports to the datatable
            foreach (var item in expected_tactic_details_list)
            {
                report_type_code = "-1"; // -1 is default for outstanding reports due after this fq

                if (item[1] == now_period)  // Check how many reports are outstanding for current FQ
                {
                    // ***
                    if (!extractAllItems)
                        totalOutstandingThisPeriod++;
                    if (DateTime.Today.Month % 3 == 0) // check how many reports are outstanding for current month (applies only to quarterly report scenario)
                    {
                        // totalOutstandingThisMonth++;
                    }
                    report_type_code = "-2";  // report is due this quarter
                }
                else if (item[1].CompareTo(now_period) < 0) // check how many reports are overdue
                {
                    // ***
                    if (!extractAllItems)
                        totalOverdueReports++;
                    report_type_code = "-3";  // report is overdue
                }

                tactic_details_list.Add(new string[] { item[0], " ", item[1], report_type_code, " ", " ", });

            }

            foreach (var item in tactic_details_list)
            {

                dt_details.Rows.Add(item[0], item[2], item[1], item[4], item[5], item[3]);
            }

            return new DataTable[] { dt, dt_details };
        }



        private void load_data()
        {
            try
            {
                totalSubmitted = 0;
                totalOutstanding = 0;
                totalOutstandingThisPeriod = 0;
                totalTacticsAssigned = 0;
                totalOverdueReports = 0;

                    string webUrl = "https://novascotia.sharepoint.com/sites/HNSProjects";
                    password = HelperClass.GetPasswordFromConsoleInput(pw);            

                    SPContext context = new SPContext(password, userName, webUrl);                    
              
                    ListItemCollection listItemsMaster = context.getList("Tactics Master");
                    ListItemCollection listItemsDetails = context.getList("Tactics Details");
                   
                    DataTable[] myDataTables = createTables(listItemsMaster, listItemsDetails, context);
                    DataTable dt = myDataTables[0];
                    DataTable dt_details = myDataTables[1];
                    totalTacticsAssigned = dt.Rows.Count;

                    dgv_Main.DataSource = dt;
                    dgv_Main.Columns["Record id"].Visible = false;


                    if (!data_loaded)
                    {
                        addGridViewFields("dataGridViewEditButton", "", "Edit", ref dgv_Main);
                    }

                    dgv_Details.DataSource = dt_details;
                    dgv_Details.Columns["Record id"].Visible = false;
                    dgv_Details.Columns["Tactic"].Visible = false;

                    if (!data_loaded)
                    {
                        addGridViewFields("dataGridViewDetailsEditButton", "", "Update/Create", ref dgv_Details);
                        addGridViewFields("dataGridViewDetailsDeleteButton", "", "Delete", ref dgv_Details);
                    }

                    formatDetailsDataGrid();          
            }
            catch (System.IO.IOException e)
            {
                MessageBox.Show(e.Message);

            }            
        }

        private void formatDetailsDataGrid()
        {
            // sort datagrid view by period
           dgv_Details.Sort(dgv_Details.Columns["Period"], ListSortDirection.Ascending);
           int submitted_items = dgv_Details.Rows.Count, outstanding_items = 0;
           foreach (DataGridViewRow row in dgv_Details.Rows)
           {
                switch(row.Cells["Record id"].Value)
                {
                    case "-1":
                        row.DefaultCellStyle.BackColor = Color.FromArgb(204, 255, 204);//Color.Green; // report due after this fq
                        outstanding_items++;
                        submitted_items--;
                        break;
                    case "-2":
                        row.DefaultCellStyle.BackColor = Color.FromArgb(255, 255, 179);//Color.Yellow; // report due in this fq
                        outstanding_items++;
                        submitted_items--;
                        break;
                    case "-3":
                        row.DefaultCellStyle.BackColor = Color.FromArgb(255, 153, 153); //Color.Red; // report overdue
                        outstanding_items++;
                        submitted_items--;
                        break;
                }
               

            }
            //totalTacticsAssigned = dgv_Main.RowCount;
            updateReportStats(outstanding_items, submitted_items, totalOutstanding, totalSubmitted, totalOutstandingThisPeriod, totalOverdueReports, totalTacticsAssigned);
           

        }

        private void delete_item(int id)
        {
            using (var context = new Microsoft.SharePoint.Client.ClientContext(webUrl))
            {
                context.Credentials = new Microsoft.SharePoint.Client.SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Add new item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Details");
                Microsoft.SharePoint.Client.ListItemCreationInformation itemCreateInfo = new Microsoft.SharePoint.Client.ListItemCreationInformation();
                Microsoft.SharePoint.Client.ListItem oListItem = oList.GetItemById(id);

                oListItem.DeleteObject();
                context.ExecuteQuery();

            }
        }


        // add additional fields/controls to the gridview
        void addGridViewFields(string btnName, string headerText, string buttonText, ref DataGridView myDgv)
        {
            var dgvButton = new DataGridViewButtonColumn();
            dgvButton.Name = btnName;
            dgvButton.HeaderText = headerText;
            dgvButton.Text = buttonText;
            dgvButton.UseColumnTextForButtonValue = true;
            myDgv.Columns.Add(dgvButton);
        }

       

        private void dgv_Main_CellClick(object sender, DataGridViewCellEventArgs e)
        {            
                
                filterDetailsDataGrid();
                formatDetailsDataGrid();
        }

        private void filterDetailsDataGrid()
        {
            if (dgv_Main.CurrentCell == null)
                return;

            string tactic = dgv_Main.CurrentCell.OwningRow.Cells["Tactic"].Value.ToString();
            selected_row_id = Convert.ToInt32(dgv_Main.CurrentCell.OwningRow.Index);
          
            ((DataTable)dgv_Details.DataSource).DefaultView.RowFilter = string.Format("Tactic = '{0}'", tactic);
          
            DataGridViewColumn column = dgv_Details.Columns[1];
            column.Width = 100;

            column = dgv_Details.Columns[2];
            column.Width = 290;

            column = dgv_Details.Columns[4];
            column.Width = 290;

            column = dgv_Details.Columns[5];
            column.Width = 290; 
        }

        private void updateReportStats( int outstanding,int submitted, int totalOutstanding, int totalSubmitted, int dueThisPeriod, int overdue, int totalTactics)
        {
            txtCompletedReports.Text = submitted.ToString();
            txtOutstandingReports.Text = outstanding.ToString();
            txtTotalSubmitted.Text = totalSubmitted.ToString();
            txtTotalOutstanding.Text = totalOutstanding.ToString();
            txtDueWithinQuarter.Text = dueThisPeriod.ToString();
            txtTacticsAssigned.Text = totalTactics.ToString();
           // txtDueWithinMonth.Text = dueThisMonth.ToString();

            txtOverdueReports.Text = overdue.ToString();
            if (overdue > 0)
            {
                txtOverdueReports.ForeColor = Color.Red;
            }
            else
            {
                txtOverdueReports.ForeColor = Color.Green;
            }
            txtOverdueReports.ReadOnly = true;


        }       
      

        private void masterDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reportPasswordStr = null;
            reportPasswordCorrect = false;
            frmReportPassword passwordInputForm = new frmReportPassword();
            passwordInputForm.ShowDialog();

            reportPasswordCorrect = HelperClass.validatePassword(reportPasswordStr);

            if (!reportPasswordCorrect)
            {
                MessageBox.Show("Invalid Password!");
                return;
            }
            
            frmPeriodSelector periodSelectorForm = new frmPeriodSelector();
            periodSelectorForm.ShowDialog();
            if (extractReportFlag)
            {
               
                string folderPath = HelperClass.getFolderpath();
                if (folderPath != null)
                {
                    string webUrl = "https://novascotia.sharepoint.com/sites/HNSProjects";
                    password = HelperClass.GetPasswordFromConsoleInput(pw);

                    SPContext context = new SPContext(password, userName, webUrl);

                    ListItemCollection listItemsMaster = context.getList("Tactics Master");
                    ListItemCollection listItemsDetails = context.getList("Tactics Details");


                    DataTable[] myDataTables = createTables(listItemsMaster, listItemsDetails, context, true);
                    DataTable dt = myDataTables[0];
                    DataTable dt_details = myDataTables[1];

                    ReportGenerator.WriteToExcelFile(dt, dt_details, folderPath + @"\Report.xlsx", reportFrom, reportTo);
                     
                }               
            }   
           
        }

        // DELETE LATER
        private IEnumerable selectDistinctReportPeriods( ref DataTable myDataTable)
        {
            var distinctPeriods = myDataTable.AsEnumerable().Select(row => new { period = row.Field<string>("Period") }).Distinct();
            return distinctPeriods;
        } 

        
 

        private void formattedReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reportPasswordStr = null;
            reportPasswordCorrect = false;
            frmReportPassword passwordInputForm = new frmReportPassword();
            passwordInputForm.ShowDialog();

            reportPasswordCorrect = HelperClass.validatePassword(reportPasswordStr);

            if (!reportPasswordCorrect)
            {
                MessageBox.Show("Invalid Password!");
                return;
            }

            string folderPath = HelperClass.getFolderpath();
            if (folderPath != null)
            {
                string webUrl = "https://novascotia.sharepoint.com/sites/HNSProjects";
                password = HelperClass.GetPasswordFromConsoleInput(pw);

                SPContext context = new SPContext(password, userName, webUrl);

                ListItemCollection listItemsMaster = context.getList("Tactics Master");
                ListItemCollection listItemsDetails = context.getList("Tactics Details");

                DataTable[] myDataTables = createTables(listItemsMaster, listItemsDetails, context, true);
                DataTable dt = myDataTables[0];
                DataTable dt_details = myDataTables[1];
              
                ReportGenerator.WriteToExcelFileRawData(dt, dt_details, folderPath + @"\Report.xlsx");

            }
        }    

        private void dgv_Main_SelectionChanged(object sender, EventArgs e)
        {
            filterDetailsDataGrid();
            formatDetailsDataGrid();
        }

       

        private void dgv_Details_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            formatDetailsDataGrid();
        }
       

        private void dgv_Main_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MessageBox.Show("Sorted");
        }       

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            load_data();
        }      


        private void dgv_Details_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

           
            if (e.RowIndex == dgv_Details.NewRowIndex || e.RowIndex < 0)
                return;

            int record_num;
            string tactic, period;
            tactic = (string)dgv_Details.CurrentCell.OwningRow.Cells["Tactic"].Value;
            period = (string)dgv_Details.CurrentCell.OwningRow.Cells["Period"].Value;
            record_num = Convert.ToInt32(dgv_Details.CurrentCell.OwningRow.Cells["Record id"].Value.ToString());

            if (e.ColumnIndex == dgv_Details.Columns["dataGridViewDetailsEditButton"].Index)
            {
                string details;
                string projRisk;
                string projMitigation;

                details = dgv_Details.CurrentCell.OwningRow.Cells["Memo"].Value.ToString();       
                projRisk = dgv_Details.CurrentCell.OwningRow.Cells["Project Risk"].Value.ToString();
                projMitigation = dgv_Details.CurrentCell.OwningRow.Cells["Risk Mitigation"].Value.ToString();

                EditDetails.webUrl = webUrl;
                EditDetails.password = password;
                EditDetails.userName = userName;          
                
                EditDetails editForm = new EditDetails(details, projRisk, projMitigation, record_num, tactic, period);
                editForm.ShowDialog();
                
                load_data();
                filterDetailsDataGrid();
                formatDetailsDataGrid();
            }
            else if (e.ColumnIndex == dgv_Details.Columns["dataGridViewDetailsDeleteButton"].Index)
            {
                if (record_num <0)
                {
                    MessageBox.Show("Only submitted reports can be deleted.");
                    return;
                }

                DialogResult updateDialog = MessageBox.Show("Are you sure you want to update this record?", "Update record", MessageBoxButtons.YesNo);

                if (updateDialog == DialogResult.Yes)
                {
                    delete_item(record_num);
                    load_data();
                    filterDetailsDataGrid();
                    formatDetailsDataGrid();
                }
                else
                {
                    MessageBox.Show("Record has NOT been updated");
                }
               
            }
        }       


        private void create_item()
        {
            using (var context = new ClientContext(webUrl))
            {
                context.Credentials = new SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Add new item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Master");
                ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                ListItem oListItem = oList.AddItem(itemCreateInfo);
                oListItem["Title"] = "TEST!!!";

                oListItem.Update();
                context.ExecuteQuery();
            }           
        }

        private void dgv_Main_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //if click is on new row or header row
            if (e.RowIndex == dgv_Main.NewRowIndex || e.RowIndex < 0)
                return;

         

            if (e.ColumnIndex == dgv_Main.Columns["dataGridViewEditButton"].Index)
            {
                string title, tactic, priority, subgrouping, tacticStatus, details, outcomes;
                string start_dt, exp_comp_date, actual_comp_dt;
                int record_num;

             
                priority = dgv_Main.CurrentCell.OwningRow.Cells["Priority Area"].Value.ToString();
                subgrouping = dgv_Main.CurrentCell.OwningRow.Cells["Subgrouping"].Value.ToString();
                tactic = dgv_Main.CurrentCell.OwningRow.Cells["Tactic"].Value.ToString();
                //fy = dgv_Main.CurrentCell.OwningRow.Cells["Periods"].Value.ToString();
                details = dgv_Main.CurrentCell.OwningRow.Cells["Assignee"].Value.ToString();
                record_num = Convert.ToInt32(dgv_Main.CurrentCell.OwningRow.Cells["Record id"].Value.ToString());
                outcomes = dgv_Main.CurrentCell.OwningRow.Cells["Outcomes"].Value.ToString();
                tacticStatus = dgv_Main.CurrentCell.OwningRow.Cells["Tactic Status"].Value.ToString();  

                start_dt = dgv_Main.CurrentCell.OwningRow.Cells["Start Date"].Value.ToString();
                exp_comp_date = dgv_Main.CurrentCell.OwningRow.Cells["Expected Completion"].Value.ToString();
                actual_comp_dt = dgv_Main.CurrentCell.OwningRow.Cells["Actual Completion"].Value.ToString();

                frmEdit.webUrl = webUrl;
                frmEdit.password = password;
                frmEdit.userName = userName;

                // filter existing tactic report list for relevant tacticts only
                List<string[]> relevant_list = (from s in tactic_details_list where s[0] == tactic select s).ToList();

                frmEdit editForm = new frmEdit(priority, subgrouping, tactic, tacticStatus, details, outcomes, record_num, relevant_list, start_dt, exp_comp_date, actual_comp_dt);
                //frmEdit editForm = new frmEdit(priority, subgrouping, tactic, fy, details, outcomes, record_num, relevant_list, start_dt, exp_comp_date, actual_comp_dt);
                editForm.ShowDialog();

                if (data_update)
                {                   

                    using (var context = new ClientContext(webUrl))
                    {
                        context.Credentials = new SharePointOnlineCredentials(userName, password);
                        context.Load(context.Web, w => w.Title);
                        context.ExecuteQuery();
                        Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Master");
                        ListItem oListItemUpd = oList.GetItemById(record_id);
                        oListItemUpd.Update();
                        context.ExecuteQuery();
                    }                   
                }
                load_data();
                filterDetailsDataGrid();
                formatDetailsDataGrid();
            }
           
        }

       /* private SecureString GetPasswordFromConsoleInput(string password)
        {       

            //Get the user's password as a SecureString
            SecureString securePassword = new SecureString();

            foreach (char c in password)
            {
                securePassword.AppendChar(c);
            }           

            return securePassword;
        } */
    }
}
