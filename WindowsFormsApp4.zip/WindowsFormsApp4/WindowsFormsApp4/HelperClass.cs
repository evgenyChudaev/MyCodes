﻿using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp4
{
    // Class contains various simple support/calculation functions
    class HelperClass
    {
        public static void ResizeArray<T>(ref T[,] original, int rows, int cols)
        {


            T[,] newArray = new T[rows, cols];
            int minX = Math.Min(original.GetLength(0), newArray.GetLength(0));
            int minY = Math.Min(original.GetLength(1), newArray.GetLength(1));

            // fast copying for array
            for (int i = 0; i < minX; ++i)
                Array.Copy(original, i * original.GetLength(1), newArray, i * newArray.GetLength(1), minY);

            original = newArray;



            // SLOW COPY
            /*T[,] newArray = new T[rows, cols];
            int minX = original.GetLength(0);
           int minY = original.GetLength(1);
             for (int i = 0; i < minX; i++)
             {
                 for (int j = 0; j < minY; j++)
                 {
                     newArray[i, j] = original[i, j];
                 }
             }   
               original = newArray;*/


        }

        public static SecureString GetPasswordFromConsoleInput(string password)
        {

            //Get the user's password as a SecureString
            SecureString securePassword = new SecureString();

            foreach (char c in password)
            {
                securePassword.AppendChar(c);
            }

            return securePassword;
        }

        // temporary validation procedure. To make it more robust, password has to be stored somewhere in the 
        public static bool validatePassword(string password)
        {
            return password == "13Zxotm13!";
        }

        // creating formatted period names in the format of FY<YYYY>-<MM> (<MMM>)
        public static string formPeriodNameMonth(int[] yearMonthArr)
        {
            string[] months = { ""," (APR)", " (MAY)", " (JUN)", " (JUL)", " (AUG)", " (SEP)",
                                            " (OCT)", " (NOV)", " (DEC)", " (JAN)", " (FEB)",  " (MAR)"};
            int yr = yearMonthArr[0];
            int mos = yearMonthArr[1];
            string formatted_month = mos < 10 ? String.Format("0{0}", mos) : Convert.ToString(mos);// adding preceding 0 to month # for months < 10
            return "FY" + yr + "-" + formatted_month + months[mos];
        }

        public static int[] adjustForFiscalPeriod(DateTime myDate, int periodsForward)
        {
            myDate = myDate.AddMonths(periodsForward);
            int adj_fy = myDate.Year;
            //int adj_fq = (int)Math.Ceiling((double)myDate.Month / 3);
            int adj_fq = myDate.Month;


            return new int[] { adj_fy, adj_fq };
        }

        public static string getFolderpath()
        {
            string fldrPath = null;
            Form1.extractReportFlag = false;

            CommonOpenFileDialog dialog = new CommonOpenFileDialog();
            dialog.InitialDirectory = "C:\\Users";
            dialog.IsFolderPicker = true;
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                fldrPath = dialog.FileName;
            }

            return fldrPath;
        }
    }
}
