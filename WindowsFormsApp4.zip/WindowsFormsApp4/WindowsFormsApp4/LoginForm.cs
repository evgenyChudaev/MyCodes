﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
            InitializePasswordTextBox();
        }

        private void InitializePasswordTextBox()
        {
            // Set to no text.
            txtPassword.Text = "";
            // The password character is an asterisk.
            txtPassword.PasswordChar = '*';
            // The control will allow no more than 14 characters.
            txtPassword.MaxLength = 25;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Form1.userName = txtLogin.Text;
            Form1.pw = txtPassword.Text;
            this.Close();
        }
    }
}
