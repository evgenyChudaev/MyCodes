﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class EditDetails : Form
    {
        public static string webUrl;
        public static string userName;
        public static System.Security.SecureString password;
        int record_id;
        string tactic;
        string period;

        public EditDetails(string details, string projRisk, string projMitigation, int record_id, string tactic, string period)
        {
            InitializeComponent();
            this.record_id = record_id;
            txtMemo.Text = details;
            txtProjectRiskMemo.Text = projRisk;
            txtProjectMitigationMemo.Text = projMitigation;
            this.tactic = tactic;
            this.period = period;
        }

        private void btnSaveDetails_Click(object sender, EventArgs e)
        {          
            string update_memo = txtMemo.Text;
            string update_risk = txtProjectRiskMemo.Text;
            string update_mitigation = txtProjectMitigationMemo.Text;

            string operation_message;
           
            if (record_id < 0)
            {
                operation_message = "create";
            }
            else
            {
                operation_message = "update";
            }

            DialogResult updateDialog = MessageBox.Show("Are you sure you want to " + operation_message + " this record?", "Update record", MessageBoxButtons.YesNo);

            if (updateDialog == DialogResult.Yes)
            {
                if (record_id < 0 )
                {
                    create_item(update_memo, update_risk, update_mitigation);                   
                }
                else
                {
                    update_item(update_memo, update_risk, update_mitigation, record_id);                   
                }

                MessageBox.Show("Report has been "+ operation_message + "d");
                this.Close();
            }
            else
            {
                MessageBox.Show("Record has NOT been " + operation_message +"d");               
            }
        }


        private void update_item(string memo, string risk, string mitigation, int id)
        {
            using (var context = new Microsoft.SharePoint.Client.ClientContext(webUrl))
            {
                context.Credentials = new Microsoft.SharePoint.Client.SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Update item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Details");
                Microsoft.SharePoint.Client.ListItemCreationInformation itemCreateInfo = new Microsoft.SharePoint.Client.ListItemCreationInformation();
                Microsoft.SharePoint.Client.ListItem oListItem = oList.GetItemById(id);
                oListItem["Memo"] = memo;
                oListItem["ProjectRisk"] = risk;
                oListItem["ProjectMitigation"] = mitigation;
                oListItem.Update();
                context.ExecuteQuery();
            }
        }

        private void create_item(string memo, string risk, string mitigation)
        {
            using (var context = new Microsoft.SharePoint.Client.ClientContext(webUrl))
            {
                context.Credentials = new Microsoft.SharePoint.Client.SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();

                // Add new item
                Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle("Tactics Details");            
                Microsoft.SharePoint.Client.ListItemCreationInformation itemCreateInfo = new Microsoft.SharePoint.Client.ListItemCreationInformation();
                Microsoft.SharePoint.Client.ListItem oListItem = oList.AddItem(itemCreateInfo);
                oListItem["Title"] = tactic;
                oListItem["Period"] = period;
                oListItem["Memo"] = memo;
                oListItem["ProjectRisk"] = risk;
                oListItem["ProjectMitigation"] = mitigation;

                oListItem.Update();
                context.ExecuteQuery();
            }
        }

        private void btnCloseDeitDetails_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
