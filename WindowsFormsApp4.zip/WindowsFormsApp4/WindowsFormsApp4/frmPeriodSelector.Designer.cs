﻿namespace WindowsFormsApp4
{
    partial class frmPeriodSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCloseReportPeriod = new System.Windows.Forms.Button();
            this.btnSaveReportPeriod = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.dtReportFrom = new System.Windows.Forms.DateTimePicker();
            this.dtReportTo = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Period From:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(243, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Period To:";
            // 
            // btnCloseReportPeriod
            // 
            this.btnCloseReportPeriod.Location = new System.Drawing.Point(246, 95);
            this.btnCloseReportPeriod.Name = "btnCloseReportPeriod";
            this.btnCloseReportPeriod.Size = new System.Drawing.Size(200, 41);
            this.btnCloseReportPeriod.TabIndex = 4;
            this.btnCloseReportPeriod.Text = "Cancel";
            this.btnCloseReportPeriod.UseVisualStyleBackColor = true;
            this.btnCloseReportPeriod.Click += new System.EventHandler(this.btnCloseReportPeriod_Click);
            // 
            // btnSaveReportPeriod
            // 
            this.btnSaveReportPeriod.Location = new System.Drawing.Point(23, 95);
            this.btnSaveReportPeriod.Name = "btnSaveReportPeriod";
            this.btnSaveReportPeriod.Size = new System.Drawing.Size(200, 41);
            this.btnSaveReportPeriod.TabIndex = 5;
            this.btnSaveReportPeriod.Text = "Generate Report";
            this.btnSaveReportPeriod.UseVisualStyleBackColor = true;
            this.btnSaveReportPeriod.Click += new System.EventHandler(this.btnSaveReportPeriod_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(176, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Select period From/To for the report";
            // 
            // dtReportFrom
            // 
            this.dtReportFrom.Location = new System.Drawing.Point(23, 55);
            this.dtReportFrom.Name = "dtReportFrom";
            this.dtReportFrom.Size = new System.Drawing.Size(200, 20);
            this.dtReportFrom.TabIndex = 7;
            // 
            // dtReportTo
            // 
            this.dtReportTo.Location = new System.Drawing.Point(246, 55);
            this.dtReportTo.Name = "dtReportTo";
            this.dtReportTo.Size = new System.Drawing.Size(200, 20);
            this.dtReportTo.TabIndex = 8;
            // 
            // frmPeriodSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(474, 153);
            this.Controls.Add(this.dtReportTo);
            this.Controls.Add(this.dtReportFrom);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSaveReportPeriod);
            this.Controls.Add(this.btnCloseReportPeriod);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmPeriodSelector";
            this.Text = "Report Period";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCloseReportPeriod;
        private System.Windows.Forms.Button btnSaveReportPeriod;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtReportFrom;
        private System.Windows.Forms.DateTimePicker dtReportTo;
    }
}