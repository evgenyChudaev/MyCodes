﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp4
{
    class SPContext
    {
        private ClientContext context = null;
        public SPContext(SecureString password, string userName, string webUrl)
        {
            // string webUrl = "https://novascotia.sharepoint.com/sites/HNSProjects";
             context = new ClientContext(webUrl);
             using (context)
             {
                context.Credentials = new SharePointOnlineCredentials(userName, password);
                context.Load(context.Web, w => w.Title);
                context.ExecuteQuery();               
            } 
        }

        public ListItemCollection getList(string name)
        {
            Microsoft.SharePoint.Client.List oList = context.Web.Lists.GetByTitle(name);
            // Read list
            CamlQuery query = new CamlQuery();
            ListItemCollection listItems = oList.GetItems(query);
            context.Load(listItems);
            context.ExecuteQuery();
           return listItems;
        }
    }
}
